# TWEAK.md — shiv tweak development recipes

Read this BEFORE doing tweak work. Everything here was MEASURED on
device, not guessed. Written for the model; the user's own notes live
in `belgeler/`.

**Priority when sources disagree:**

1. **MEASUREMENT** — what you just read off the device
2. **RULE** — an absolute line in the system prompt
3. **RECIPE** — a pattern in this file

If a measurement contradicts a recipe, the MEASUREMENT wins and the
recipe is stale — say so, and tell the user which line to update.

---

## 0. FIRST: probe the environment, once

Never guess paths or tool availability. At the start of tweak work run
`shiv-ortam` (it sits next to the bundle; the prompt gives the absolute
path) and keep its result for the whole session — do not re-probe per
request. The user sees the same measurement with `/ortam`.

It ends with a RECOMMENDED FLOW: the exact build and install commands
for this device, chosen from what it just measured. Follow that rather
than picking a flow from this file by hand.

What it measures:

| Thing | How to read it |
|---|---|
| jailbreak kind | roothide / rootless / rootful |
| theos path + kind | `ls <theos>/vendor/mod/` → `roothide` present = fork |
| SDKs | `ls <theos>/sdks/` |
| toolchain | `command -v clang ldid make perl swift` |
| RootHide Patcher | `/Applications/Patcher.app/patch.sh` exists? |
| frida-server | `ps ax \| grep '[f]rida-server'` |
| shiv frida tools | `shiv-cek`, `shiv-oku`, `shiv-sinif` (on PATH) |
| inject dir | `/usr/lib/TweakInject` |

---

## 1. BUILD + INSTALL

### 1.1 Which theos do you have

```
ls <theos>/vendor/mod/
  roothide rootless   → roothide FORK  (superset: does BOTH schemes)
  rootless            → standard theos (roothide scheme absent)
```

A standard theos fails with `'roothide' package scheme does not exist`.

### 1.2 Two flows

**A — roothide-native (fork only, no patcher):**

```
make THEOS=<fork> clean package THEOS_PACKAGE_SCHEME=roothide
  → iphoneos-arm64e deb
dpkg -i packages/<name>_iphoneos-arm64e.deb
```

**B — rootless + patcher (works with either theos):**

```
make THEOS=<theos> clean package THEOS_PACKAGE_SCHEME=rootless
  → iphoneos-arm64 deb
/Applications/Patcher.app/patch.sh <deb> <out.deb> AutoPatches
dpkg -i <out.deb>
```

`patch.sh` accepts a ROOTLESS input only. Give it an arm64e deb and it
prints `*** Not a rootless package!` and exits.

`dpkg -i` on an unpatched, non-roothide deb fails with `/Library`
"Operation not permitted". Either roothide-native or patch.sh — there
is no third way. Hand-placing files into `/usr/lib/TweakInject/` is a
last-resort test, not an install.

**Confidence:** B has been used for dozens of builds over months and is
what shipped. A was measured 12 Sep 2026 (app + SpringBoard tweaks,
worked first try, no patch.sh). Both are valid; B is more battle-tested,
A is shorter. The older note claiming "rootless+patch is more stable"
belonged to a different theos install and never recorded a reason.

### 1.3 Arch: the dylib and the deb label are different things

- **dylib arch = the TARGET process's arch.** App is arm64 → `ARCHS = arm64`.
  SpringBoard is arm64e → `ARCHS = arm64e`. An arm64 dylib does not load
  into an arm64e process.
  (Cross-arch loading is lenient in the other direction: an arm64e
  caps-0x00 tweak also loaded into the arm64 e-Nabız app.)
- **deb label** is written by Theos from `THEOS_PACKAGE_SCHEME`. Theos
  IGNORES `Architecture:` in your `control` file — do not bother setting
  it. If the label comes out arm64e when you wanted rootless, the scheme
  is wrong; fix the scheme, not the control file.

So a SpringBoard tweak via flow B is `ARCHS = arm64e` **and**
`THEOS_PACKAGE_SCHEME=rootless` at the same time. That is not a
contradiction — arch ≠ label.

### 1.4 `make THEOS=` — not `THEOS= make`

```
make THEOS=/var/mobile/theos-roothide ...   command-line assignment, beats everything  ✓
THEOS=/var/mobile/theos-roothide make ...   environment var, a Makefile `export` overrides it  ✗
```

A Makefile line `export THEOS=/var/mobile/theos` silently wins over the
environment form. This cost a wasted rebuild.

**When you generate a Makefile, do NOT write `export THEOS=`.** Leave
THEOS to come from outside so switching toolchains is one flag.

### 1.5 Never trust `ls -t`

`ls -t packages/*.deb | head -1` gives the newest FILE, not the newest
BUILD. If the build failed, a stale deb is still there and gets
installed silently — this is the most repeated mistake in this project.

Instead: read the build output line

```
dm.pl: building package `...' in `./packages/<exact-name>.deb'
```

That line present = build succeeded, and it gives the exact path. No
line = build failed; do not go looking for a deb.

Before installing, verify the artifact actually contains your change:

```
strings <dylib> | grep <your marker>
otool -l <dylib> | grep -A2 LC_UUID     # changes on rebuild, not on copy
```

### 1.6 caps 0x00 — what actually breaks

The on-device toolchain emits arm64e with `caps 0x00` instead of `0x80`.
This is NOT a version problem: a newer clang will not fix it (Apple has
not open-sourced the relevant ld64 changes). Do not suggest installing a
different clang to solve it.

```
caps 0x00 LOADS and runs. Working: selector calls, %hook/%orig,
reading ivars.

It CRASHES when the code hands a BLOCK to the system:
  object_setIvar of a block into an @? ivar
  passing a block to a completion: parameter
  a ^{ } literal given to a system API
→ that path needs a Mac build (caps 0x80).
```

Measured: ActionButtonFix (caps 0x00) — flashlight, screenshot, prefs
all worked; the camera path crashed, and it was the one handing a block
to the system. ShivLockLabel (caps 0x00, `%hook`, no blocks) worked.
"Camera" is an example, not the rule. Route only the block-passing code
path to a Mac; do not refuse the whole build.

### 1.6b Before installing: is an older build already in?

Check first — it is the same trap every rebuild:

```
dpkg -l | grep -i <name>          # an earlier version of THIS tweak?
ls /usr/lib/TweakInject/          # anything hooking the same thing?
```

If a previous tweak hooks the SAME method, Substrate/ElleKit **chains**
the hooks: every hook stores the previous implementation and calls it,
so BOTH run. You do not get an error and nothing is disabled — you get
the effect twice (two labels stacked at the same spot, measured with
ShivLockLabel + ShivLockVersion). Remove the old package first
(`dpkg -r <package>`) unless you genuinely want both.

Safe Mode is a different failure: it needs a tweak that CRASHES
SpringBoard (e.g. the caps-0x00 block case in §1.6), not a duplicate
hook.

### 1.6c Substrate, ElleKit and Safe Mode — measured

These are Substrate-API tweaks and ElleKit is what provides that API
here (not a separate Substrate install):

```
/usr/lib/libsubstrate.dylib -> /usr/lib/libellekit.dylib   (package: ellekit)
ellekit also ships: CydiaSubstrate.framework, /usr/lib/TweakInject,
                    /usr/lib/ellekit/MobileSafety.dylib
```

Safe Mode is real and file-flagged. `TweakInject` checks `_MSSafeMode`
/ `_SafeMode` against the marker file, and `MobileSafety` shows:

> *"You've entered safe mode. SpringBoard tweaks will not get injected
> until you respring your device. You can select Dismiss to safely
> remove your broken tweaks."*

```
marker: /var/mobile/.eksafemode
```

So if the device is in Safe Mode: SpringBoard tweaks are NOT injected
until a respring — do not conclude "my tweak did not load, the build is
wrong". Check the marker first, remove the offending package
(`dpkg -r <package>`), then ask the user to respring.

`/device` also reports how many tweaks hook one process — the cheap way
to spot a crowded target before adding one more.

### 1.7 Distribution: publish the ROOTLESS deb

```
rootless deb  → rootless user installs it directly
              → roothide user converts it with patch.sh
roothide deb  → rootless user CANNOT install it
```

The conversion is one-way, so rootless is the superset and the
distribution format. Keep both: install the roothide one locally, keep
`packages/..._iphoneos-arm64.deb` to share.

And state the limit honestly: *"Distribute the rootless build. I could
only test it on this device."* Do not hand the user an untested-elsewhere
package as if it were verified.

### 1.8 Building on the Mac (when caps 0x80 is needed)

The one thing the device cannot do is emit `caps 0x80`. A Mac can, and
the whole chain was measured end to end (13 Sep 2026, ShivLockLabel):

```
Mac + roothide fork, ARCHS = arm64e, THEOS_PACKAGE_SCHEME=roothide
  → arm64e deb whose dylib is caps 0x80   (device build gives 0x00)
  → scp to the device
  → dpkg -i            (roothide-native, no patch.sh)
  → loaded in SpringBoard, label showed
```

The Mac's theos is a separate install with its own kind — **measure it,
do not infer it from the folder name.** A directory literally named
`theos-roothide` turned out to be standard theos (git remote
`theos/theos`, `vendor/mod/` only `rootless`), so it could not build the
roothide scheme at all.

```
ls <mac-theos>/vendor/mod/        roothide present = fork
grep -m1 url <mac-theos>/.git/config
ls <mac-theos>/sdks/              SDKs are a separate copy from the device's
```

If the Mac lacks the fork: either install it there the same way (clone
into its own path, copy SDKs from the existing theos), or build the
ROOTLESS scheme on the Mac and convert on the device with patch.sh.

Only send a project to the Mac when you need caps 0x80 (a block handed
to the system) — on-device is faster for everything else. Ask before the
first command on the user's computer.

---

## 2. INSTALLING THE ENVIRONMENT (when something is missing)

theos is NOT a package — it is not in any repo. Only
`theos-dependencies` is (Procursus, and RootHide's own Procursus fork).
On RootHide, prefer RootHide's repo.

You may install things yourself, but the device is the user's: show the
exact command, say what it does, and give the rollback, then ask.

| Action | Risk | Gate |
|---|---|---|
| `apt install <named pkg>` | reversible, tracked by apt | ask, then do |
| `git clone <dir>` | adds a directory only | ask, then do |
| `install-theos` / `install-sdk` | downloads and runs a script | ask, SHOW THE URL |
| `apt upgrade` / `dist-upgrade` | can break the jailbreak | **NEVER** |

Ask like this, not "shall I install theos?":

```
I will run:
    git clone --recursive https://github.com/roothide/theos.git \
      /var/mobile/theos-roothide
What it does: downloads the RootHide fork into its own directory.
It does not touch the existing theos.
To undo: rm -rf /var/mobile/theos-roothide
```

### Ladder

1. **Basics** (if missing): `bash curl sudo coreutils xz-utils`
2. **`theos-dependencies`** — pulls clang, ldid, make, perl, odcctools
3. **theos itself:**
   - RootHide: `git clone --recursive https://github.com/roothide/theos.git $THEOS`
   - rootless/standard: `bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"`
   - `install-theos` respects a preset `$THEOS` and does not delete an
     existing install (it runs update-theos instead).
   - **Where:** fork already installed → install nothing. A standard
     theos exists → put the fork in its OWN path and leave the other
     alone. Nothing installed → install the fork directly, one install
     is enough (the fork does rootless too).
   - Do NOT repoint the global `$THEOS` at the fork; pass
     `make THEOS=<fork>` instead.
4. **SDK:**
   - `ls <fork>/sdks/` — present? done.
   - else copy: `cp -r /var/mobile/theos/sdks/*.sdk <fork>/sdks/` (fastest, worked here)
   - last resort: `<fork>/bin/install-sdk`
5. **VERIFY — do not say "installed", measure:**
   ```
   ls <fork>/vendor/mod/roothide     # really the fork?
   ls <fork>/sdks/                   # SDK there?
   command -v clang ldid make perl   # tools on PATH?
   ```
   Anything missing = the install is half done; say so.
6. **First real test:** build a tiny tweak. The
   `dm.pl: building package ... in <path>` line must appear. If it does
   not, the environment is not ready.
7. **Tell the user what landed where** — what was installed, to which
   path, and how to undo it.

---

## 3. DISCOVERY — find the class to hook

| Need | Tool |
|---|---|
| classes of a RUNNING app | `shiv-oku <bundle-id> <regex> [secs]` |
| decrypt an App Store binary (offline use) | `shiv-cek <bundle-id>` |
| SYSTEM classes (dyld cache / cache-external) | `shiv-sinif <pattern>` / `--tara` |
| METHODS of one cache-external binary | `shiv-sinif --metod <path>` |

- `shiv-oku` spawns the app once, caches the full class list (~10 min),
  then re-filters the cache — refine the regex freely, it will not
  relaunch. `--taze` forces a fresh launch. The regex is
  CASE-SENSITIVE; `^HP`, `^EnabizPlus\.` etc. give the app's own prefix.
- Do NOT static-read `shiv-cek` output with `shiv-sinif --tara` —
  `--tara` scans cache-external SYSTEM dirs, not your decrypted file.
- **Never** fall back to `nm -gU`: it under-counts badly (6 vs 410).
- Bundle id: `grep -A1 CFBundleIdentifier <App>.app/Info.plist`
  (`plutil -extract` printed nothing on this device). For a binary
  plist, `strings Info.plist | grep -i <vendor>`.
- App-embedded SDK frameworks (`<App>.app/Frameworks/NAME.framework`)
  are usually already unencrypted — scan them directly.

**EXISTING IS NOT CALLABLE — measured, cost a Safe Mode.**
These tools answer "does the symbol exist", never "may I call it".
`setBacklightState:` was in the cache and still put the device into
Safe Mode. So:

- Static lookup is the FIRST filter, not the verdict.
- A selector that exists may still be unavailable in THIS process, may
  require an entitlement, or may be a PAC-protected API (section 1.6).
- Confirm at runtime before relying on it: `respondsToSelector:` /
  `objc_getClass` on the live process, or a marker-file probe
  (section 5). Do not ship a hook whose only evidence is a name in a
  class dump.

### Custom frida agents

```
write the agent to a WRITABLE dir first (/var/mobile/tw/agent.js)
cd /var/mobile/tw && <shivfrida> spawn <bundle-id> agent.js [secs]
```

You must `cd` into the agent's directory and pass a RELATIVE name — an
absolute agent path is rejected ("agent okunamadi"). The shivfrida
directory is root-owned, so you cannot create files there.

Agent walls: the main executable is not `enumerateModules()[0]` — match
`NSBundle.mainBundle().executablePath()`. A spawned app is sandboxed;
write output to its own `NSTemporaryDirectory()` and read it from the
shell under `/rootfs/.../Containers/Data/Application/<UUID>/tmp/`. Poll
with `setInterval` until `ObjC.available` and the module is loaded — a
fixed `setTimeout` fires too early and produces nothing.

---

## 4. HOOK PATTERNS

- **Hook only a class's OWN method.** Swizzling an inherited method
  rewrites the superclass and can black-screen the app.
- **Firebase/Google-wrapped AppDelegate:** `%hook <App>.AppDelegate` on
  delegate methods never fires — at runtime the class is re-wrapped
  (`GUL_<App>.AppDelegate-...`). Instead run from `%ctor` and observe
  `UIApplicationDidFinishLaunchingNotification`; that fires regardless
  of the wrapping. (Measured: e-Nabız, Yandex Navi.)
- **Bridged Swift class** (`%hook Module.Class`, e.g.
  `Excel.XLApplicationSceneDelegate`): logos warns and Theos treats the
  warning as an error, so the build fails. Add to the Makefile:
  ```
  ADDITIONAL_LOGOSFLAGS = -c warnings=default
  ```
  Heed the warning though — a bridged-Swift hook may not catch every
  invocation. If it is flaky, hook a stable scene/lifecycle selector.
- **Presenting UI:** walk `keyWindow.rootViewController` down through
  `presentedViewController` to the top VC, and present inside a
  `dispatch_after` (~0.5 s). Presenting straight inside
  `scene:willConnectToSession:` or didFinishLaunching — before the
  window hierarchy exists — silently shows nothing.
- **Removing ads/promos in a modern SwiftUI app:** hiding the VIEW is
  the beginner trap (SwiftUI keeps the layout space → a gap; and a
  shared view class breaks other UI). The real fix is the DATA/NETWORK
  layer: filter the promo out of the API response. A compiled swizzle of
  a Swift/Alamofire delegate is fragile; frida-runtime or a proxy is the
  practical path.
- Logos/`%hook` links libsubstrate; on RootHide the
  `@loader_path/.jbroot/...` resolution is handled by the fork — nothing
  extra to do.

---

## 5. VERIFY WITHOUT RE-PLOWING THE FIELD

Ranked, cheapest first:

1. **Marker file** — have the hook write a small file into the app's own
   `NSTemporaryDirectory()` when it fires, then read it ONCE from the
   shell. This machine-proves the hook ran; no screen needed.
2. **Loaded?** — one attach that finds your dylib among the loaded
   modules proves the tweak LOADED.
3. **Purely visual effect you cannot see** — ask the user ONCE. Do not
   keep re-attaching.

Facts that look like failures but are not:

- A modal alert FREEZES the app (`0% CPU`, frida attach timeout). That
  is the alert SHOWING, not a crash.
- `uiopen <bundle-id>` is a normal launch, so TweakInject loads your
  dylib. `frida spawn` uses its own loader and does NOT load installed
  tweaks — never verify an installed tweak via spawn.
- A SpringBoard tweak needs a respring. Do not respring or
  `killall SpringBoard` yourself — ask the user.

---

## 6. NAMESPACE

- **node** sees logical paths (`/System`); the **shell** sees the same
  content under `/rootfs/System`. A system process (SpringBoard) writes
  `/var/mobile/x`; from the shell that file is at `/rootfs/var/mobile/x`.
  When a file you expect is "missing", look under `/rootfs` before
  concluding a tweak did not load. `/rootfs` is RootHide-only.
- `/var/jb` → `/` on RootHide (a compat symlink for rootless tweaks);
  on rootless it is the real jailbreak root.
- `/Library/MobileSubstrate/DynamicLibraries` is a **symlink** to
  `/usr/lib/TweakInject` — the same directory. A roothide-native deb
  installs into the MobileSubstrate path and still loads. Do not treat
  them as two places.
- jbroot multi-mount: measured on this device and NOT confirmed
  (`mount | grep jbroot` empty, one `.jbroot-*` dir). If paths behave
  strangely, measure again rather than assuming.
- `<roothide.h>` + `jbroot()` exists for tweaks that need to reach
  jailbreak files, but most tweaks do not. Globbing
  `/var/containers/Bundle/Application/.jbroot-*/...` also works.

---

## 7. KNOWN-GOOD REFERENCE TWEAKS

Sources and reports live in the user's `shiv-tweaks/` archive on the
desktop:

| Tweak | What it proves |
|---|---|
| EnabizShiv | app tweak; Firebase-wrapped delegate → `%ctor` + notification |
| ShivYTAlert | the rootless → patch.sh → dpkg -i flow, and later roothide-native |
| ExcelShiv | bridged-Swift hook + logos flag |
| YandexNaviShiv | Flutter/Swift hybrid; finding the REAL delegate |
| ShivLockLabel | SpringBoard (arm64e) tweak, both build flows |
