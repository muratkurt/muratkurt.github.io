# shiv 2.0.0 — Değişiklikler

**14 Eylül 2026** · önceki sürüm: 1.3.0 (11 Eylül 2026)

Bu sürüm shiv'i "telefonda çalışan bir AI CLI"dan **telefonda tweak
geliştirebilen** bir araca çevirdi. İki büyük eksen var: **tweak zemini**
ve **arayüzün gerçekten doğru çizilmesi**.

Bu belge sadece "ne değişti" listesi değil; **nasıl kullanılacağını** da
anlatır. Aceleniz varsa doğrudan [Nasıl kullanılır](#nasıl-kullanılır)
bölümüne gidin.

---

## Özet

| alan | ne geldi |
|---|---|
| **Tweak geliştirme** | Cihazda frida, şifre çözme, sınıf keşfi, `/ortam` sondası, TWEAK.md reçeteleri |
| **Arka plan işleri** | `ctrl+b` ile arka plana alma + `↓` ile yönetim paneli |
| **Çizim** | Aylardır süren satır kesilme hatası çözüldü |
| **Oturum** | `resume` sonrası bozulan katlama ve API hatası düzeldi |
| **İzinler** | Mac bağlantısı ve `sbreload` artık izin mekanizmasından geçiyor |
| **Belgeler** | Bağımsız tweak rehberi (515 satır) + güncellenen raporlar |

---

## 1. Tweak geliştirme zemini

shiv artık bir tweak'i **baştan sona** yapabiliyor: ortamı ölçer, sınıfı
bulur, derler, kurar, doğrular.

### 1.1 `/ortam` — ortam sondası

`/device` cihazı anlatır; `/ortam` **tweak geliştirme ortamını** ölçer:
jailbreak türü, iOS sürümü, theos yolu ve türü (çatal mı standart mı),
SDK'lar, frida durumu, ve **önerilen derleme akışı**.

Tweak işine başlamadan önce çalıştırılması gereken ilk şey budur.
Tahmin yerine ölçüm koyar.

### 1.2 Cihazda frida — Mac gerekmiyor

Şifreli App Store uygulamalarını **cihazda** çözer. Ne Mac ne `pip`:

- `shiv-cek <bundle-id>` — FairPlay şifresini çözer (ölçüldü: YouTube
  196 MB, cryptid 1→0, 32.929 sınıf)
- `shiv-oku [--taze] <bundle-id> [desen]` — çalışan uygulamadan canlı
  sınıf listesi, 10 dakika önbellekli
- `shiv-sinif --tara` / `--metod <yol>` — dyld cache **dışındaki**
  ikililerden sınıf/metot okuma (CC modülleri, prefs bundle'ları,
  uygulamaya gömülü SDK'ler)

**Kapsam sınırı (dürüstçe):** `.appex` uzantıları ayrı süreç olduğu için
bu yolla çözülmüyor; harici `mach_vm_read` gerekiyor. Ertelendi.

### 1.3 TWEAK.md — modelin reçete kitabı

shiv'in kendi istemi artık TWEAK.md'ye bakıyor. İçinde ölçülmüş kurallar
var: iki derleme akışı, mimari ile deb etiketinin farkı, `caps 0x00`
sınırı, `ls -t` tuzağı, doğrulama merdiveni.

Önceliklendirme kuralı da istemde: **(1)** cihazdan az önce alınan
ölçüm, **(2)** istemdeki kural, **(3)** TWEAK.md'deki reçete.

### 1.4 Dört yönlü derleme matrisi kanıtlandı

Cihaz ve Mac × roothide-native ve rootless+patcher — dördü de uçtan uca
çalıştırıldı, ayrı etiketlerle (`shiv A1/A2/B1/B2`) ve `caps`
damgalarıyla (`0x00` / `0x80`) doğrulandı.

---

## 2. Arka plan işleri

Uzun süren bir komutu artık bekletmeden bırakabilirsiniz.

- **`ctrl+b`** — çalışan işi arka plana alır
- **`↓`** — alttaki `N background task` sayacını seçer
- **`enter`** — tek iş varsa doğrudan **ayrıntı**, birden çoksa **liste**
- Ayrıntı panelinde: **Durum / Süre / Komut / Çıktı**
- **`k`** işi durdurur, **`←`** listeye döner, **`esc`** kapatır

Çıktı **sürerken de** görünür. (Önceden çıktı ancak iş bitince dosyaya
yazılıyordu; süren bir işin çıktısını gösterecek kaynak yoktu.)

Panel açıkken süre **saniyede bir** akar. Önceden nabız yalnız model
çalışırken attığı için sayı donuyordu — "bazen düzgün, bazen takılıyor"
belirtisinin sebebi buydu.

---

## 3. Çizim: aylardır süren satır kesilmesi

**Belirti:** araç kartlarında satır sonları yeniyordu —
`Running…` → `Runnin…`, `Read 459 lines` → `Read 459 lin…`. Genişlikle
büyümüyor, `ctrl+o` da açmıyordu.

**Kök sebep:** oluk işareti `⎿` (U+23BF) bu terminalde **iki sütun**
çiziliyor, biz **bir** sayıyorduk. Her oluk satırı bir sütun kayıyor,
kare çizicinin hücre modeli gerçekle uyuşmuyor ve sonraki fark çizimleri
yanlış sütuna gidip karakter eziyordu. Kısa satırlarda zarar görünmüyordu
(kenara dayanmıyor), uzunlarda son karakter düşüyordu.

**Çözüm:** oluk işareti `└` (U+2514) oldu.

**Elenen hipotezler** (hepsi ölçümle): kırpma kodu, stdout'a giden bayt
(68 KB yakalandı), terminal genişliği (`ESC[6n` → 52), terminal
yüksekliği, eşzamanlı çıktı modu, `…` karakterinin belirsiz genişliği,
yazı tipi ligatürü.

**Çözen ölçüm:** shiv'i denklemden çıkarıp terminali tek başına `printf`
ile ölçmek. Üç satırlık bir kabuk komutu cevabı verdi.

### Yol üstünde düzelen diğer hatalar

- **Kuyruk taşması** — komut `en-6` genişliğe sarılıp 6 boşluk girinti
  alıyor, sonra `)` ve kuyruk (`  exit=1`, `  21.2s`) **bütçeye girmeden**
  ekleniyordu. Ölçüm: 9 taşan satır → **0**.
- **`ctrl+b` çalışmıyordu** — tuş **iki yere** bağlıydı; sayfa kaydırma
  önce çalışıp `return` ediyordu, arka plan dalı **ulaşılmayan ölü koddu**.
- **Kırpma işareti** `…` → `...` (satır sonunda komşu hücreyi eziyordu).

---

## 4. Oturum ve akış

- **Katlama bayrağı kaydediliyor** — ara anlatım metinleri canlıda
  katlanıyor ama `resume` sonrası açık geliyordu. Bayrak oturum
  dosyasındaki beyaz listede yoktu.
- **API 400 onarımı** — `sbreload` gibi süreci öldüren komutlardan sonra
  yarım kalan araç çağrıları oturumu bozuyordu. Artık yükleme sırasında
  onarılıyor.
- **`Took` satırı** yalnız turun sonunda ve 30 saniye üstünde çıkıyor.
- **Bitiş algısı** yapısal hale geldi — "bir işin varsa söyle" gibi
  davet cümleleri artık yanlışlıkla "iş bitti" sayılmıyor.

---

## 5. İzinler

Mac'e bağlanma (`ssh`, `scp`, `rsync`) ve respring (`sbreload`,
`ldrestart`) artık **mevcut izin mekanizmasından** geçiyor. Bir kez
"hepsine izin ver" dediğinizde tekrar sormaz.

Model artık bunları düzyazıyla sormuyor; izin isteği **ekranda** çıkıyor.

---

## 6. Belgeler

- **`belgeler/TWEAK-GELISTIRME-REHBERI.txt`** (515 satır) — shiv'den
  **bağımsız**, insana hitap eden tweak rehberi. Ortam, theos, iki akış,
  `caps`, keşif, hook kalıpları, doğrulama, 9 duvar, hızlı referans ve
  rehberin sınırları.
- **`belgeler/EKRAN-LEKESI-cell366.txt`** — çizim hatasının tam
  soruşturma kaydı; elenen her hipotez ve nasıl elendiği.
- Ana rapor, devir raporu ve OKU-ONCE güncellendi.

---

## Nasıl kullanılır

### Tweak yapmak istiyorum

```
1. /ortam                      ← önce ortamı ölç, tahmin etme
2. "X uygulamasında Y'yi değiştiren bir tweak yaz"
```

shiv gerisini yapar: sınıfı bulur (gerekirse uygulamayı çözer), iskeleti
kurar, derler, kurar, doğrular. Karar verirken `/ortam` çıktısındaki
**önerilen akışı** kullanır.

Kendiniz öğrenmek isterseniz `belgeler/TWEAK-GELISTIRME-REHBERI.txt`
tek başına yeterli — shiv olmadan da okunur.

### Uzun süren bir iş var, beklemek istemiyorum

```
1. Komutu çalıştır (make, find, dpkg…)
2. ctrl+b                      ← arka plana al
3. ↓                           ← alttaki sayacı seç
4. enter                       ← ayrıntı paneli
   ← geri · k durdur · esc kapat
```

Çıktı sürerken de görünür, süre saniyede bir akar.

### Bir şey ekranda yanlış görünüyor

Önce **terminali kendi başına** ölçün — shiv'i denklemden çıkarın:

```sh
printf 'A.B\nA└B\nA…B\n'
```

`B` harfleri hizalı değilse o glif çift genişlikte çiziliyordur. Bu
sürümdeki en pahalı hata tam buydu ve üç satırlık bu komutla çözüldü.

Oluk işaretini değiştirmek isterseniz, yeniden derleme gerekmez:

```sh
SHIV_OLUK='╰' shivs
```

### Bir komutun izin sorması canımı sıkıyor

İzin ekranında **"hepsine izin ver"** seçeneğini kullanın; o komut tabanı
için bir daha sormaz. Mac bağlantısı ve respring de bu mekanizmadan geçer.

### Kurulum ve paketleme

```sh
# cihazda, ~/Documents içindeki shiv.zip'ten kurulum
shivkur

# paket üretme (kaynak agacından çalıştırılmalı)
sh paket/paketle.sh her-ikisi
```

**Uyarı:** paketleme betiğini **her zaman kaynak ağacından** çalıştırın.
Ev dizininde eski bir `paket/` kopyası varsa silin — o kopyada sürüm elle
yazılı olabilir ve `.deb` yanlış numarayla çıkar.

---

## Bilinen sınırlar

Dürüst olmak gerekirse:

- Her şey **tek cihazda** ölçüldü (iPhone 16,1 / iOS 17.0.3 / RootHide).
  Rootless ve rootful için yazılanlar bilgiye dayanıyor, o cihazlarda
  sınanmadı.
- `.appex` uzantılarının şifresi çözülmüyor (ayrı süreç).
- IPA paketleme (`shiv-cek` içinde) ertelendi.
- Arka plan ayrıntı panelinin ipucu satırı kutunun **içinde**;
  referansta dışarıda. Uygulamadaki diğer paneller de içeride tuttuğu
  için tutarlılık tercih edildi.
- `/notlar` bu turda **elle test edilmedi**.

---

## Yükseltme notu

Ayar dosyaları ve oturumlar olduğu gibi taşınır; elle bir şey yapmanız
gerekmez. `resume` ile eski oturumlar açılır — 1.3.0'da yazılmış
oturumlarda katlama bilgisi olmadığı için o kayıtlar açık görünür, yeni
oturumlar doğru katlanır.
