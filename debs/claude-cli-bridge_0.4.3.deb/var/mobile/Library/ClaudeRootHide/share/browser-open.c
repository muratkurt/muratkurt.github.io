/*
 * browser-open.c  -  ClaudeCLIBridge (RootHide)
 * 0.3.0  (rapor 22.1 / 19.8.2)
 *
 * DEGISIKLIKLER (0.2.2 -> 0.3.0):
 *
 *  1) KUSUR 1 - log yazamayinca OLMEK.  Tanilama gunlugu artik ISTEGE
 *     BAGLIDIR.  Yazilabilir yol bulunamazsa log devre disi kalir ve
 *     URL YINE ACILIR.  Eskiden burada "return 9" vardi ve Safari hic
 *     acilmiyordu (19.8.1'deki Bug 1'i olumcul yapan sey buydu).
 *
 *  2) KUSUR 2 - cwd bagimliligi.  Kendi fiziksel yolu artik
 *     _NSGetExecutablePath() ile bulunuyor; bu cagri cwd'den ve
 *     argv[0]'dan BAGIMSIZDIR.  libSystem icindedir, YENI DYLIB
 *     BAGIMLILIGI DEGILDIR (rapor 20.3 kurali korunur).
 *
 *  3) stderr ciktisi VARSAYILAN SESSIZ.  Bu binary Claude Code'un
 *     icinden BROWSER olarak spawn edilir; OAuth tam ekran akisinin
 *     ortasina satir basmak TUI render'ini bozar.  Tanilama yalniz
 *     CLAUDE_RH_DEBUG=1 ile acilir.
 *
 *  4) BULGU - SELF_SUFFIX olu koddu.  Eski kod argv[0]'i
 *     "/var/mobile/.claude-bridge/bin/browser-open" sonekiyle
 *     karsilastiriyordu; payload Library/ClaudeRootHide'a tasindiginda
 *     bu esleme kalici olarak bozuldu ve fonksiyon HER ZAMAN NULL
 *     donmeye basladi.  diag ciktisindaki realpath=(null) bunun
 *     sonucuydu; realpath basarisiz DEGILDI.  Sabit sonek kaldirildi,
 *     yerine .jbroot-<UUID> desenine dayali genel turetme kondu
 *     (rapor 13.3 / 20.9 ile ayni kural).
 *
 *  5) BULGU - tampon tasmasi.  tries[] dizisi 5 elemanliydi ama kod
 *     alti adaya kadar yaziyordu.  tries[8] yapildi.
 *
 * DERLEME (rapor 12.4.3 - harfiyen):
 *   clang -arch arm64 -O2 -o ./bo.test browser-open.c
 *   ldid -S<...>/bash-ios7.entitlements.plist ./bo.test
 *   -arch arm64e KULLANILMAZ, entitlement'li imzalama ZORUNLUDUR.
 */

#define _POSIX_C_SOURCE 200809L
#define _DARWIN_C_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <unistd.h>
#include <limits.h>
#include <spawn.h>
#include <sys/wait.h>
#include <mach-o/dyld.h>

#define LOG_SUFFIX "/.claude-bridge/oauth-browser-debug.log"

extern char **environ;

static char log_path[PATH_MAX] = "";
static char self_path[PATH_MAX] = "";
static char self_dir[PATH_MAX] = "";

/* Tanilama ciktisi yalniz CLAUDE_RH_DEBUG=1 ile acilir. */
static int diag_on(void) {
    const char *d = getenv("CLAUDE_RH_DEBUG");
    return d && *d && strcmp(d, "0") != 0;
}

static int try_log_path(const char *base) {
    if (!base || !*base) return 0;
    snprintf(log_path, sizeof(log_path), "%s%s", base, LOG_SUFFIX);
    FILE *fp = fopen(log_path, "a");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

/* log_path bos ise fopen basarisiz olur ve fonksiyon sessizce doner.
   Log devre disiyken cagrilmasi guvenlidir. */
static void log_diag(const char *fmt, ...) {
    if (!log_path[0]) return;
    FILE *fp = fopen(log_path, "a");
    if (!fp) return;
    time_t now = time(NULL);
    struct tm *tm = localtime(&now);
    char ts[64];
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S %z", tm);
    fprintf(fp, "[%s] ", ts);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(fp, fmt, ap);
    va_end(ap);
    fprintf(fp, "\n");
    fclose(fp);
}

/*
 * Mutlak bir yoldan jbroot kokunu turetir.
 *
 *   1) Yolda "/.jbroot-" bileseni varsa, O BILESENIN SONUNA kadar alinir.
 *      UUID hardcode EDILMEZ; desen dinamiktir (rapor 20.9).
 *   2) Yoksa son "/var/mobile" gecisinde kesilir (eski davranis, fallback).
 *
 * Basarili ise 1 doner ve out doldurulur.
 */
static int root_from_full_path(const char *path, char *out, size_t outsz) {
    if (!path || !*path) return 0;

    const char *m = strstr(path, "/.jbroot-");
    if (m) {
        const char *end = strchr(m + 1, '/');
        size_t len = end ? (size_t)(end - path) : strlen(path);
        if (len == 0 || len >= outsz) return 0;
        memcpy(out, path, len);
        out[len] = '\0';
        return 1;
    }

    const char *last = NULL;
    const char *p = path;
    while ((p = strstr(p, "/var/mobile")) != NULL) {
        last = p;
        p++;
    }
    if (!last) return 0;
    size_t len = (size_t)(last - path);
    if (len == 0 || len >= outsz) return 0;
    memcpy(out, path, len);
    out[len] = '\0';
    return 1;
}

/*
 * Binary'nin kendi fiziksel yolunu bulur.  cwd'den ve argv[0]'dan
 * bagimsizdir.
 *
 * _NSGetExecutablePath tampon kucukse -1 doner ve gereken boyutu
 * bufsize'a yazar; donus degeri KONTROL EDILMELIDIR, aksi halde
 * fallback zinciri hic devreye girmez.  Ayrica symlink COZMEZ,
 * o yuzden sonuca realpath() uygulanir.
 */
static int resolve_self(void) {
    char buf[PATH_MAX];
    uint32_t sz = (uint32_t)sizeof(buf);
    if (_NSGetExecutablePath(buf, &sz) != 0) return 0;

    if (!realpath(buf, self_path)) {
        if (strlen(buf) >= sizeof(self_path)) return 0;
        snprintf(self_path, sizeof(self_path), "%s", buf);
    }

    const char *slash = strrchr(self_path, '/');
    if (!slash || slash == self_path) return 0;
    size_t len = (size_t)(slash - self_path);
    if (len >= sizeof(self_dir)) return 0;
    memcpy(self_dir, self_path, len);
    self_dir[len] = '\0';
    return 1;
}

static const char *derive_root_from_argv0(const char *argv0) {
    static char resolved[PATH_MAX];
    static char root[PATH_MAX];
    if (!argv0 || !*argv0) return NULL;
    if (!realpath(argv0, resolved)) return NULL;
    if (!root_from_full_path(resolved, root, sizeof(root))) return NULL;
    return root;
}

static const char *derive_root_from_cwd(void) {
    static char buf[PATH_MAX];
    static char root[PATH_MAX];
    if (!getcwd(buf, sizeof(buf))) return NULL;
    if (!root_from_full_path(buf, root, sizeof(root))) return NULL;
    return root;
}

static const char *derive_root_from_self(void) {
    static char root[PATH_MAX];
    if (!self_path[0]) return NULL;
    if (!root_from_full_path(self_path, root, sizeof(root))) return NULL;
    return root;
}

int main(int argc, char *argv[]) {
    const char *url = argc >= 2 ? argv[1] : "(none)";
    size_t url_len = strlen(url);
    char prefix[81];
    size_t copy_len = url_len < 80 ? url_len : 80;
    memcpy(prefix, url, copy_len);
    prefix[copy_len] = '\0';

    const char *home = getenv("HOME");
    const char *jbroot = getenv("JBROOT");
    char cwd[PATH_MAX];
    if (!getcwd(cwd, sizeof(cwd))) snprintf(cwd, sizeof(cwd), "(err)");

    resolve_self();
    const char *root_from_self  = derive_root_from_self();
    const char *root_from_argv0 = derive_root_from_argv0(argc > 0 && argv[0] ? argv[0] : NULL);
    const char *root_from_cwd   = derive_root_from_cwd();

    if (diag_on()) {
        fprintf(stderr,
            "browser-open diag: HOME=%s JBROOT=%s PWD=%s argv0=%s self=%s selfroot=%s argv0root=%s cwdroot=%s\n",
            home ? home : "(null)",
            jbroot ? jbroot : "(null)",
            cwd,
            argc > 0 && argv[0] ? argv[0] : "(null)",
            self_path[0] ? self_path : "(null)",
            root_from_self ? root_from_self : "(null)",
            root_from_argv0 ? root_from_argv0 : "(null)",
            root_from_cwd ? root_from_cwd : "(null)");
    }

    /* Etkin jbroot koku.  Kendi yolu EN GUVENILIR kaynaktir; sonraki
       halkalar 0.2.2'deki sirayla korundu. */
    const char *jbroot_eff = root_from_self;
    if (!jbroot_eff || !*jbroot_eff) jbroot_eff = jbroot;
    if (!jbroot_eff || !*jbroot_eff) jbroot_eff = root_from_cwd;
    if (!jbroot_eff || !*jbroot_eff) jbroot_eff = root_from_argv0;
    if (!jbroot_eff || !*jbroot_eff) {
        if (home) {
            size_t len = strlen(home);
            const char *suffix = "/var/mobile";
            size_t slen = strlen(suffix);
            if (len > slen && strcmp(home + len - slen, suffix) == 0) {
                jbroot_eff = strndup(home, len - slen);
            }
        }
    }
    if (!jbroot_eff || !*jbroot_eff) jbroot_eff = "";

    /*
     * bash-ios7 YOLU.
     *
     * Birincil kaynak: kendi dizinimiz.  bash-ios7 bizimle AYNI bin/
     * dizinindedir; boylece jbroot turetmeye hic gerek kalmaz ve yol
     * otomatik olarak .jbroot-<UUID> iceren, ciplak namespace'te
     * cozulebilen bicimde olur (rapor 17.7'nin uc kosulu).
     *
     * Ikincil: eski hesap (jbroot_eff + sabit alt yol).
     */
    char bash[PATH_MAX];
    int bash_found = 0;
    if (self_dir[0]) {
        snprintf(bash, sizeof(bash), "%s/bash-ios7", self_dir);
        if (access(bash, X_OK) == 0) bash_found = 1;
    }
    if (!bash_found) {
        snprintf(bash, sizeof(bash),
            "%s/var/mobile/Library/ClaudeRootHide/bin/bash-ios7",
            jbroot_eff);
    }

    /* Log adaylari.  Dizi boyutu 8: kod alti adaya kadar ekleyebiliyor,
       eski tries[5] tanimi tampon disina yaziyordu. */
    char candidate[PATH_MAX];
    struct { const char *base; const char *label; } tries[8];
    int n = 0;

    if (root_from_self) {
        snprintf(candidate, sizeof(candidate), "%s/var/mobile", root_from_self);
        tries[n].base = strdup(candidate);
        tries[n].label = "self-derived/var/mobile";
        n++;
    }

    if (jbroot && *jbroot) {
        snprintf(candidate, sizeof(candidate), "%s/var/mobile", jbroot);
        tries[n].base = strdup(candidate);
        tries[n].label = "JBROOT/var/mobile";
        n++;
    }

    if (root_from_cwd) {
        snprintf(candidate, sizeof(candidate), "%s/var/mobile", root_from_cwd);
        tries[n].base = strdup(candidate);
        tries[n].label = "CWD-derived/var/mobile";
        n++;
    }

    if (root_from_argv0) {
        snprintf(candidate, sizeof(candidate), "%s/var/mobile", root_from_argv0);
        tries[n].base = strdup(candidate);
        tries[n].label = "argv0-derived/var/mobile";
        n++;
    }

    if (home && *home) {
        tries[n].base = strdup(home);
        tries[n].label = "HOME";
        n++;
    }

    tries[n].base = "/private/var/mobile";
    tries[n].label = "/private/var/mobile";
    n++;

    tries[n].base = "/var/mobile";
    tries[n].label = "/var/mobile";
    n++;

    int log_ready = 0;
    for (int i = 0; i < n; i++) {
        if (try_log_path(tries[i].base)) {
            log_ready = 1;
            if (diag_on()) {
                fprintf(stderr, "browser-open: logging to %s (via %s)\n",
                        log_path, tries[i].label);
            }
            break;
        }
    }

    /*
     * KUSUR 1 DUZELTMESI.  Burada eskiden "return 9" vardi.
     * Tanilama gunlugu ISTEGE BAGLIDIR; yazilamiyorsa devre disi
     * kalir, akis DEVAM EDER ve URL yine acilir.
     */
    if (!log_ready) {
        log_path[0] = '\0';
        if (diag_on()) {
            fprintf(stderr, "browser-open: no writable log path, log devre disi. tried:\n");
            for (int i = 0; i < n; i++) {
                snprintf(candidate, sizeof(candidate), "%s%s", tries[i].base, LOG_SUFFIX);
                fprintf(stderr, "  [%s] %s\n", tries[i].label, candidate);
            }
        }
    }

    log_diag("invoked argc=%d url_len=%zu url_prefix=\"%.80s\" HOME=\"%s\" JBROOT=\"%s\" jbroot_eff=\"%s\" self=\"%s\" selfroot=\"%s\" cwdroot=\"%s\" argv0root=\"%s\" bash=\"%s\" log=\"%s\"",
        argc, url_len, prefix,
        home ? home : "(null)",
        jbroot ? jbroot : "(null)",
        jbroot_eff,
        self_path[0] ? self_path : "(null)",
        root_from_self ? root_from_self : "(null)",
        root_from_cwd ? root_from_cwd : "(null)",
        root_from_argv0 ? root_from_argv0 : "(null)",
        bash, log_path[0] ? log_path : "(disabled)");

    if (argc < 2) {
        log_diag("error: argc < 2, exit=1");
        if (diag_on()) fprintf(stderr, "browser-open: URL verilmedi\n");
        return 1;
    }

    if (access(bash, X_OK) != 0) {
        log_diag("error: bash not executable: %s, exit=5", strerror(errno));
        if (diag_on()) {
            fprintf(stderr, "browser-open: bash-ios7 calistirilabilir degil: %s (%s)\n",
                    bash, strerror(errno));
        }
        return 5;
    }

    /* URL pozisyonel argumanla DEGIL, komut dizesine gomulerek verilir.
       bash-ios7 -c ile calisan komuta $1'i aktarmaz (rapor 12.1/12.4). */
    char cmd[8192];
    snprintf(cmd, sizeof(cmd), "/usr/bin/uiopen --url '%s'", url);
    log_diag("cmd=\"%s\"", cmd);

    char *args[] = { (char *)bash, "-c", cmd, NULL };

    pid_t pid;
    int ret = posix_spawn(&pid, bash, NULL, NULL, args, environ);
    if (ret != 0) {
        log_diag("error: posix_spawn failed: %d (%s), exit=6", ret, strerror(ret));
        if (diag_on()) {
            fprintf(stderr, "browser-open: posix_spawn basarisiz: %s\n", strerror(ret));
        }
        return 6;
    }

    int status;
    pid_t w = waitpid(pid, &status, 0);
    if (w == -1) {
        log_diag("error: waitpid failed: %s, exit=7", strerror(errno));
        return 7;
    }

    if (WIFEXITED(status)) {
        int code = WEXITSTATUS(status);
        log_diag("child exited with status=%d", code);
        return code;
    } else if (WIFSIGNALED(status)) {
        log_diag("child terminated by signal=%d", WTERMSIG(status));
        return 128 + WTERMSIG(status);
    } else {
        log_diag("child unknown status=%d", status);
        return 8;
    }
}
