# shivtools ortak cozucu — bu dosya KAYNAK olarak okunur (`.` ile).
#
# Amac: dokuz arac yollari ve eksik bagimliliklari TEK yerden bilsin.
# Sahada olculen uc sorun buradan cozuluyor:
#   - 'shivfrida' PATH'te degildi ve klasorle ayni adi tasiyordu
#     (…/lib/shivfrida/shivfrida) - dogru yolu bulmak uc deneme yedi.
#   - Rootless cihazda ne 'frida' ne 'lsof' vardi; araclar sessizce
#     patliyordu, eksigin ADINI soylemiyordu.
#   - Modul dizinini $0'dan tahmin etmek kirilgan: sh'de
#     `dirname "$0"` sembolik bagin HEDEFINI vermez.
#
# Cevre degiskenleriyle ezilebilir:
#   SHIVTOOLS_LIB   /usr/local/lib/shivtools
#   SHIVTOOLS_AJAN  $SHIVTOOLS_LIB/ajanlar
#   SHIVFRIDA       shivfrida ikilisinin tam yolu
#   SHIVTOOLS_PAY   /usr/local/share/shivtools

# ---- kok: rootless'ta /var/jb oneki olabilir ----
st_kok() {
  for k in "" /var/jb; do
    [ -d "$k/usr/local/lib/shivtools" ] && { echo "$k"; return; }
  done
  echo ""
}
ST_KOK="$(st_kok)"

SHIVTOOLS_LIB="${SHIVTOOLS_LIB:-$ST_KOK/usr/local/lib/shivtools}"
SHIVTOOLS_AJAN="${SHIVTOOLS_AJAN:-$SHIVTOOLS_LIB/ajanlar}"
SHIVTOOLS_PAY="${SHIVTOOLS_PAY:-$ST_KOK/usr/local/share/shivtools}"

# ---- shivfrida ikilisi ----
# ONCE PATH: paket onu /usr/local/bin'e koyuyor. Sonra eski shiv
# duzeni (klasor adi = ikili adi), en son kaynak agaci.
st_shivfrida() {
  if [ -n "$SHIVFRIDA" ] && [ -x "$SHIVFRIDA" ]; then echo "$SHIVFRIDA"; return; fi
  P=$(command -v shivfrida 2>/dev/null)
  [ -n "$P" ] && [ -x "$P" ] && { echo "$P"; return; }
  for c in "$ST_KOK/usr/local/bin/shivfrida" \
           /var/jb/usr/local/bin/shivfrida \
           /usr/local/bin/shivfrida \
           /var/jb/usr/local/lib/shivfrida/shivfrida \
           /usr/local/lib/shivfrida/shivfrida; do
    [ -x "$c" ] && { echo "$c"; return; }
  done
  echo ""
}

# ---- ajan dosyasi ----
st_ajan() {   # st_ajan ekran.js -> tam yol ya da bos
  for d in "$SHIVTOOLS_AJAN" \
           /var/jb/usr/local/lib/shivtools/ajanlar \
           /usr/local/lib/shivtools/ajanlar \
           /var/jb/usr/local/lib/shivfrida \
           /usr/local/lib/shivfrida \
           /var/mobile/tw; do
    [ -f "$d/$1" ] && { echo "$d/$1"; return; }
  done
  echo ""
}

# ---- eksik bagimliligi ADIYLA soyle ----
# st_eksik <arac-adi> <eksik> [alternatif cumlesi]
st_eksik() {
  echo "[$1] eksik: $2" >&2
  [ -n "$3" ] && echo "[$1]   $3" >&2
  return 1
}

# frida zinciri: ikili + sunucu. Eksikse hangisinin eksik oldugunu
# ve NE YAPILACAGINI yazar. Donus 0 = hazir.
st_frida_hazir() {   # st_frida_hazir <arac-adi>
  ARAC="$1"
  SF=$(st_shivfrida)
  if [ -z "$SF" ]; then
    st_eksik "$ARAC" "shivfrida (frida istemcisi)" \
      "shivtools paketi eksik kurulmus; 'dpkg -l | grep shivtools' ile bakin."
    return 1
  fi
  # frida-server: ADI ve YERI ile. 'frida' CLI'si GEREKMIYOR - araclar
  # sunucuya kendileri baglaniyor (rootless cihazda 'frida' yoktu ama
  # frida-server /var/jb/usr/sbin altinda duruyordu - olculdu).
  FS=""
  for c in /var/jb/usr/sbin/frida-server /usr/sbin/frida-server \
           "$(command -v frida-server 2>/dev/null)"; do
    [ -n "$c" ] && [ -x "$c" ] && { FS="$c"; break; }
  done
  if [ -z "$FS" ]; then
    st_eksik "$ARAC" "frida-server (cihazda kurulu degil)" \
      "Denetlemek icin: shiv-frida-kur · kurmak icin: sudo shiv-frida-kur --kur"
    return 1
  fi
  CALISIYOR=0
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -x frida-server >/dev/null 2>&1 && CALISIYOR=1
  fi
  if [ "$CALISIYOR" = "0" ] && ps ax -o comm= >/dev/null 2>&1; then
    ps ax -o comm= 2>/dev/null | sed 's#.*/##' | grep -qx frida-server && CALISIYOR=1
  fi
  if [ "$CALISIYOR" = "0" ]; then
    launchctl list 2>/dev/null | grep -qi 're\.frida\.server' && CALISIYOR=1
  fi
  if [ "$CALISIYOR" = "0" ]; then
    st_eksik "$ARAC" "frida-server calismiyor ($FS var ama surec yok)" \
      "Durum icin: shiv-frida-kur"
    return 1
  fi
  # MIMARI SINIRI: shivfrida arm64e. A11 ve oncesi cihazlarda
  # (iPhone X/8 ve eski iPad'ler) bu ikili CALISMAZ. Paket kurulumu
  # engellenmiyor - shiv-sinif frida'ya hic dokunmuyor ve A11
  # kullanicisi onu kullanabilmeli.
  return 0
}

# Donanim arm64e mi (A12+)? Emin olamazsak 'bilinmiyor' deriz.
st_arm64e_mi() {
  S=$(sysctl -n hw.optional.arm64 2>/dev/null)
  [ "$S" = "1" ] && return 0
  S2=$(sysctl -n hw.cpusubtype 2>/dev/null)
  [ "$S2" = "2" ] && return 0
  return 2      # bilinmiyor
}

# Tek satirlik yardim basligi (her aracin kendi metni var).
st_pay_dosya() {   # st_pay_dosya SHIVTOOLS.md
  for d in "$SHIVTOOLS_PAY" /var/jb/usr/local/share/shivtools \
           /usr/local/share/shivtools; do
    [ -f "$d/$1" ] && { echo "$d/$1"; return; }
  done
  echo ""
}

# shiv'in GOLGELEDIGI arac adlarini yazar (bosluk ayirmali), yoksa
# hicbir sey. 24 Eyl 2026'da cihazda olculdu:
#   shiv'in postinst'i /usr/local/bin/shiv-* adlarini 'ln -sf' ile
#   KENDI kopyalarina baglar, postrm'i ayni yollari 'rm -f' eder.
#   Ikisi de shivtools'un GERCEK dosyalarinin ustune yazar:
#     shiv kurulur/guncellenir -> shivtools araclari GOLGELENIR
#     shiv kaldirilir          -> shivtools araclari SILINIR (9 dosya)
#   dpkg cakismayi gormez, cunku baglari dpkg degil postinst yapiyor.
# Gercek cozum shiv tarafinda (bag kurarken/silerken sahibe bakmak) -
# ayri tur. Care tek satir: shiv'den SONRA shivtools'u yeniden kur.
st_golge() {
  _g=""
  for _t in shiv-sinif shiv-ortam shiv-ekran shiv-oku shiv-cek \
            shiv-pencere shiv-yol shiv-prefs-ornek shiv-frida-kur; do
    _y=$(command -v "$_t" 2>/dev/null)
    [ -n "$_y" ] && [ -L "$_y" ] || continue
    _h=$(readlink "$_y" 2>/dev/null)
    case "$_h" in */lib/shiv/*) _g="$_g $_t" ;; esac
  done
  echo $_g
}
