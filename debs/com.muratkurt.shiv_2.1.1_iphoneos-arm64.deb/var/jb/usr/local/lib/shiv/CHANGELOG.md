# shiv 2.1.1 — Değişiklikler

**17 Eylül 2026** · cell-400 · önceki sürüm: 2.1.0 (16 Eylül 2026)

İki cihaz saha testinin ortaya çıkardığı arızaların kapatıldığı bir
düzeltme sürümü + frida sürüm uyumu.

- **shiv-sinif artık çalışıyor** — `dsc-disk.js` pakete girmiyordu
  (paketle.sh cp satırında yoktu); eklendi + doğrulama. Temiz kurulumda
  `ERR_MODULE_NOT_FOUND` bitti. İki cihazda gerçek sınıf sorgusuyla
  doğrulandı (UIKitCore 4000+ sınıf).
- **/ortam artık araçları ÇALIŞTIRARAK sınıyor** — eskiden dosya varlığına
  bakıp bozuk araca "ok" diyordu. shiv-sinif argümansız koşulup modül
  hatası yakalanıyor; shiv-cek/oku `shivfrida` dizinini sınıyor; bozuksa
  `[FAIL]`.
- **shivfrida her yeniden kurulumda kayboluyordu** — kök neden: `postrm`
  guard'sızdı, dpkg upgrade'de yeni açılan dizini siliyordu. Temizlik
  `remove|purge`'e bağlandı (Debian standardı).
- **frida sürüm uyumu** — shivfrida frida-core 16.x'e linkli; frida-server
  major'ı 16 olmalı. `/ortam` bunu ölçüp uyumsuzsa/eksikse uyarıyor.
  Rootless'ta **`shiv-frida-kur`** (yeni) uyumlu **frida 16.1.4**'ü GitHub
  releases'ten indirip kurar ve tutar; kullanıcı elle uğraşmaz. (Not:
  kurulum root ister; frida-server'ı gömme sürümünde bu tamamen kalkacak.)
- **shiv-cek** rootless'ta `awk` yüzünden boş çıktı veriyordu → `tr`/`cut`;
  ayrıca kendi konumundan türeyen `shivfrida` araması (yedek yol).
- **Mac cross-build** — `SHIV_NODE_CAPRAZ=1` ile gömülü iOS node
  çalıştırılmadan (Mach-O) doğrulanıyor; deb'ler artık cihaza gerek
  kalmadan Mac'te üretilebiliyor.

---

# shiv 2.1.0 — Değişiklikler

**16 Eylül 2026** · cell-399h · önceki sürüm: 2.0.0 (14 Eylül 2026)

2.1.0, shiv'i **iki cihazda** ölçerek olgunlaştırdı: RootHide
(iPhone16,1 / iOS 17.0.3) ve rootless (iPhone11,2 / iOS 16.1.1,
Dopamine). Ağırlık noktaları: **rootless desteğinin gerçekten doğru
olması**, **oldabi'nin ortama göre öğretilmesi** ve belgelenip pakete
konmayan araçların kapatılması. Yeni bir özellik sürümü değil; ölçümle
düzeltme sürümü.

## Özet

| alan | ne değişti |
|---|---|
| **Ortam tespiti** | shiv-ortam artık rootless/roothide'yi doğru ayırıyor (`/rootfs` + `.jbroot-*` + `readlink /var/jb`); `awk` bağımlılığı kaldırıldı (Dopamine'de yok) |
| **/ortam rehberliği** | theos / patcher / önerilen-akış **ortama göre** şekilleniyor — rootless'a artık roothide çatalı önerilmiyor, standart theos deniyor |
| **oldabi** | /ortam yeni bir **oldabi** satırı ölçüyor; iki tetikleyici (`@""` + sisteme blok), dağıtım için `Depends` ve paket adları ("Legacy arm64e Support" / kimlik `oldabi`) öğretiliyor |
| **Sistem prompt** | confound-era "block → Mac gerekir" metni düzeltildi: cihazda **derlenir**, oldabi köprüler; dağıtımda Depends; temiz deb için Mac (0x80) **alternatif** |
| **Paketleme** | `shiv-cek`, `shiv-oku` ve **shivfrida** (14 MB) artık deb'e gömülüyor + paketten çıkıp doğrulanıyor |
| **Ev dizini** | `/aktar` ve `~/.shiv` rootless'ta bootstrap gölgesine değil gerçek `/var/mobile`'a yazıyor |
| **Kurulum ekranı** | dil seçilirken alttaki açıklama artık imlecin üstündeki dilde (önizleme) |
| **Katlama** | asistan anlatımı katlanmıyor; yalnız araç çıktısı katlanır (opt-in) |
| **Kuyruk** | `ctrl+g` "hemen gönder" düzeldi; bekleyen mesajlar spinner altında görünüyor |
| **TWEAK.md** | §1.2 "hangi ortam → hangi akış"; §1.6 oldabi paketleri, ellekit.space, Swift'in neden çalışmadığı, Depends |

---

## 1. Rootless desteği (iki cihazda ölçüldü)

2.0.0 rootless'ı "kısmen" destekliyordu; ekran görüntüleri gerçeği
gösterdi:

- **Ortam yanlış tespit ediliyordu.** `[ -L /var/jb ]` Dopamine'de de
  doğru (o da symlink) → rootless cihaz "roothide" görünüyordu ve bütün
  rehberlik (şema, yollar, patcher) bu tek yanlış testten bozuluyordu.
  Artık `/rootfs`, `.jbroot-*` dizini ve `readlink /var/jb` ile ölçülüyor.
- **`awk` yoktu.** Dopamine bootstrap'inde `awk` yok; shiv-ortam sessizce
  "frida yok" diyordu (oysa PID 6920'de çalışıyordu). `sed`/`grep` ile
  yeniden yazıldı.
- **Ev dizini gölgeye düşüyordu.** `$HOME` rootless'ta
  `/var/jb/var/mobile`'ı gösteriyor; `/aktar` oraya yazınca kullanıcı
  Dosyalar/Filza'da göremiyordu. Artık gerçek `/var/mobile`.
- **frida deposu.** Rootless'ta Frida varsayılan depoda yok; /ortam artık
  `https://build.frida.re/` deposunu söylüyor.

## 2. oldabi ve ortama-göre rehberlik

Tweak rehberliği artık **ölçülen ortama** göre şekilleniyor: rootless
cihazda roothide çatalı/patcher dayatılmıyor (çatal yalnız roothide'ye de
derleyeceksen gerekli; patcher rootless-şemalı deb'i roothide'ye çevirir).

/ortam yeni bir **oldabi** satırı ölçüyor (`OldABI.dylib` var mı). Bu, bu
projenin en pahalı dersinin (ölçmeden varsaymak) tweak tarafına
sızmasını gösterdi: cihazda derlenen `caps 0x00` tweak'ler oldabi kuruluysa
"çalışıyor" — ama bu **oldabi'yi kanıtlar, tweak'i değil**. Doğru model:
iki tetikleyici (`@""` NSString literali, sisteme verilen blok), OldABI
ikisini de köprüler, ve **dağıtımda kullanıcıda da olması gerekir** →
`Depends: firmware (<< 15.0) | cy+cpu.arm64v8 | oldabi`. Paket adları
araştırıldı (kaynak: NightwindDev oldabi.md, roothide Packages,
ellekit.space): Sileo başlığı "Legacy arm64e Support", kimlik `oldabi`;
rootless → ellekit.space, roothide → `2.0.1+roothide`.

## 3. Sistem prompt oldabi-farkında

Modelin "block içeren tweak → Mac'te build gerekir" cevabı prompttan
geliyordu (confound öncesi metin, oldabi'den hiç bahsetmiyordu). Prompt
düzeltildi: cihazda **derlenir**; `@""` ve blok tetikleyicilerini OldABI
köprüler (/ortam ölçer); dağıtım için `Depends`; temiz/bağımsız deb
isteniyorsa Mac (`caps 0x80`, `/mac` ile bağlan) **alternatif**. "Derlenemez"
demek yasak; iki yol da sunulur, biri dayatılmaz.

## 4. Paketleme borcu kapandı

`shiv-cek`, `shiv-oku` ve `shivfrida` belgelerde/CHANGELOG'da vardı ama
`paketle.sh` yalnız `shiv-sinif`/`shiv-ortam` kopyalıyordu — yani anlatılıp
pakete konmayan araçlar. Üçü de deb'e eklendi (shivfrida 14 MB, arm64e caps
0x80, frida-core statik) + paketleme sonunda deb'den çıkarılıp **doğrulanıyor**
(eksikse `dur`). postinst/postrm sembolik bağları da eklendi.

## 5. Arayüz düzeltmeleri

- **Katlama:** asistan anlatımı ("tamam başlıyorum") artık katlanmıyor;
  referans yalnız araç ÇIKTISINI katlıyor. `SHIV_ANLATIM_KATLA=1` ile
  eski davranış.
- **Kuyruk:** `ctrl+g` hemen-gönder düzeldi; bekleyen mesajlar spinner
  altında `❯` ile görünüyor; Esc geri yazar, ↑ geri alır.
- **Kurulum dil önizlemesi:** dil adımında imleç "English" üstündeyken
  açıklama artık İngilizce (yeni `tDil` yardımcısı); önceden kayıtlı dile
  düşüp Türkçe kalıyordu.
- **/ortam okunurluğu:** notlar ayrı bloklar (boşluklu), nötr ton,
  adlar tırnakta ("RootHide Patcher"), oldabi açıklaması tutarlı yapıda
  (durum → KUR → DAĞITIM).

## 6. Saha testi düzeltmeleri (cell-399i)

İki cihazda saha testi üç arızayı ortaya çıkardı — **üçü de önceki
turlardan biliniyordu, kapatılmamıştı**. Hepsi kaynağa inilerek düzeltildi
ve cihazda ölçülerek doğrulandı:

- **dsc-disk.js pakete girmiyordu** → `shiv-sinif` temiz kurulumda
  `ERR_MODULE_NOT_FOUND`. `paketle.sh` cp satırına eklendi + doğrulama
  (dsc.js/dsc-ara.mjs/dsc-disk.js zinciri) + sızıntı-kontrolü istisnası.
  15 Eylül'de elle kopyalanmış ama sebep (bu satır) aranmamıştı.
- **/ortam varlık kontrolü yapıp bozuk araca "ok" diyordu** → artık
  ÇALIŞTIRARAK sınıyor: `shiv-sinif` argümansız koşulup modül hatası
  yakalanıyor, `shiv-cek/oku` bağlı olduğu `shivfrida` dizinini sınıyor.
  Bozuksa `[FAIL]`/✗ + neden. (14 Eylül raporu C.1'de yazılmış,
  uygulanmamıştı.)
- **shivfrida her yeniden kurulumda kayboluyordu** → kök neden ölçülerek
  bulundu: `postrm` guard'sızdı; dpkg **upgrade**'de eski postrm'i yeni
  dosyalar açıldıktan sonra çağırıp `rm -rf shivfrida` ile siliyordu.
  Temizlik `remove|purge`'e bağlandı (Debian standardı). Üç kurulumla
  upgrade-güvenliği kanıtlandı.
- **Yan:** `shiv-cek` awk kullanıyordu (Dopamine'de yok → cryptid/boyut
  boş) → `tr`/`cut`. Ve yedek yolu yoktu → kendi konumundan türeyen
  `shivfrida` araması (shiv-oku ile aynı desen).

---

# shiv 2.0.0 — Değişiklikler

**14 Eylül 2026** · önceki sürüm: 1.3.0 (11 Eylül 2026)

Bu sürüm shiv'i "telefonda çalışan bir AI CLI"dan **telefonda tweak
geliştirebilen** bir araca çevirdi. İki büyük eksen var: **tweak zemini**
ve **arayüzün gerçekten doğru çizilmesi**.

Bu belge sadece "ne değişti" listesi değil; **nasıl kullanılacağını** da
anlatır. Aceleniz varsa doğrudan [Nasıl kullanılır](#nasıl-kullanılır)
bölümüne gidin.

---

## Özet

| alan | ne geldi |
|---|---|
| **Tweak geliştirme** | Cihazda frida, şifre çözme, sınıf keşfi, `/ortam` sondası, TWEAK.md reçeteleri |
| **Arka plan işleri** | `ctrl+b` ile arka plana alma + `↓` ile yönetim paneli |
| **Çizim** | Aylardır süren satır kesilme hatası çözüldü |
| **Oturum** | `resume` sonrası bozulan katlama ve API hatası düzeldi |
| **İzinler** | Mac bağlantısı ve `sbreload` artık izin mekanizmasından geçiyor |
| **Belgeler** | Bağımsız tweak rehberi (515 satır) + güncellenen raporlar |

---

## 1. Tweak geliştirme zemini

shiv artık bir tweak'i **baştan sona** yapabiliyor: ortamı ölçer, sınıfı
bulur, derler, kurar, doğrular.

### 1.1 `/ortam` — ortam sondası

`/device` cihazı anlatır; `/ortam` **tweak geliştirme ortamını** ölçer:
jailbreak türü, iOS sürümü, theos yolu ve türü (çatal mı standart mı),
SDK'lar, frida durumu, ve **önerilen derleme akışı**.

Tweak işine başlamadan önce çalıştırılması gereken ilk şey budur.
Tahmin yerine ölçüm koyar.

### 1.2 Cihazda frida — Mac gerekmiyor

Şifreli App Store uygulamalarını **cihazda** çözer. Ne Mac ne `pip`:

- `shiv-cek <bundle-id>` — FairPlay şifresini çözer (ölçüldü: YouTube
  196 MB, cryptid 1→0, 32.929 sınıf)
- `shiv-oku [--taze] <bundle-id> [desen]` — çalışan uygulamadan canlı
  sınıf listesi, 10 dakika önbellekli
- `shiv-sinif --tara` / `--metod <yol>` — dyld cache **dışındaki**
  ikililerden sınıf/metot okuma (CC modülleri, prefs bundle'ları,
  uygulamaya gömülü SDK'ler)

**Kapsam sınırı (dürüstçe):** `.appex` uzantıları ayrı süreç olduğu için
bu yolla çözülmüyor; harici `mach_vm_read` gerekiyor. Ertelendi.

### 1.3 TWEAK.md — modelin reçete kitabı

shiv'in kendi istemi artık TWEAK.md'ye bakıyor. İçinde ölçülmüş kurallar
var: iki derleme akışı, mimari ile deb etiketinin farkı, `caps 0x00`
sınırı, `ls -t` tuzağı, doğrulama merdiveni.

Önceliklendirme kuralı da istemde: **(1)** cihazdan az önce alınan
ölçüm, **(2)** istemdeki kural, **(3)** TWEAK.md'deki reçete.

### 1.4 Dört yönlü derleme matrisi kanıtlandı

Cihaz ve Mac × roothide-native ve rootless+patcher — dördü de uçtan uca
çalıştırıldı, ayrı etiketlerle (`shiv A1/A2/B1/B2`) ve `caps`
damgalarıyla (`0x00` / `0x80`) doğrulandı.

---

## 2. Arka plan işleri

Uzun süren bir komutu artık bekletmeden bırakabilirsiniz.

- **`ctrl+b`** — çalışan işi arka plana alır
- **`↓`** — alttaki `N background task` sayacını seçer
- **`enter`** — tek iş varsa doğrudan **ayrıntı**, birden çoksa **liste**
- Ayrıntı panelinde: **Durum / Süre / Komut / Çıktı**
- **`k`** işi durdurur, **`←`** listeye döner, **`esc`** kapatır

Çıktı **sürerken de** görünür. (Önceden çıktı ancak iş bitince dosyaya
yazılıyordu; süren bir işin çıktısını gösterecek kaynak yoktu.)

Panel açıkken süre **saniyede bir** akar. Önceden nabız yalnız model
çalışırken attığı için sayı donuyordu — "bazen düzgün, bazen takılıyor"
belirtisinin sebebi buydu.

---

## 3. Çizim: aylardır süren satır kesilmesi

**Belirti:** araç kartlarında satır sonları yeniyordu —
`Running…` → `Runnin…`, `Read 459 lines` → `Read 459 lin…`. Genişlikle
büyümüyor, `ctrl+o` da açmıyordu.

**Kök sebep:** oluk işareti `⎿` (U+23BF) bu terminalde **iki sütun**
çiziliyor, biz **bir** sayıyorduk. Her oluk satırı bir sütun kayıyor,
kare çizicinin hücre modeli gerçekle uyuşmuyor ve sonraki fark çizimleri
yanlış sütuna gidip karakter eziyordu. Kısa satırlarda zarar görünmüyordu
(kenara dayanmıyor), uzunlarda son karakter düşüyordu.

**Çözüm:** oluk işareti `└` (U+2514) oldu.

**Elenen hipotezler** (hepsi ölçümle): kırpma kodu, stdout'a giden bayt
(68 KB yakalandı), terminal genişliği (`ESC[6n` → 52), terminal
yüksekliği, eşzamanlı çıktı modu, `…` karakterinin belirsiz genişliği,
yazı tipi ligatürü.

**Çözen ölçüm:** shiv'i denklemden çıkarıp terminali tek başına `printf`
ile ölçmek. Üç satırlık bir kabuk komutu cevabı verdi.

### Yol üstünde düzelen diğer hatalar

- **Kuyruk taşması** — komut `en-6` genişliğe sarılıp 6 boşluk girinti
  alıyor, sonra `)` ve kuyruk (`  exit=1`, `  21.2s`) **bütçeye girmeden**
  ekleniyordu. Ölçüm: 9 taşan satır → **0**.
- **`ctrl+b` çalışmıyordu** — tuş **iki yere** bağlıydı; sayfa kaydırma
  önce çalışıp `return` ediyordu, arka plan dalı **ulaşılmayan ölü koddu**.
- **Kırpma işareti** `…` → `...` (satır sonunda komşu hücreyi eziyordu).

---

## 4. Oturum ve akış

- **Katlama bayrağı kaydediliyor** — ara anlatım metinleri canlıda
  katlanıyor ama `resume` sonrası açık geliyordu. Bayrak oturum
  dosyasındaki beyaz listede yoktu.
- **API 400 onarımı** — `sbreload` gibi süreci öldüren komutlardan sonra
  yarım kalan araç çağrıları oturumu bozuyordu. Artık yükleme sırasında
  onarılıyor.
- **`Took` satırı** yalnız turun sonunda ve 30 saniye üstünde çıkıyor.
- **Bitiş algısı** yapısal hale geldi — "bir işin varsa söyle" gibi
  davet cümleleri artık yanlışlıkla "iş bitti" sayılmıyor.

---

## 5. İzinler

Mac'e bağlanma (`ssh`, `scp`, `rsync`) ve respring (`sbreload`,
`ldrestart`) artık **mevcut izin mekanizmasından** geçiyor. Bir kez
"hepsine izin ver" dediğinizde tekrar sormaz.

Model artık bunları düzyazıyla sormuyor; izin isteği **ekranda** çıkıyor.

---

## 6. Belgeler

- **`belgeler/TWEAK-GELISTIRME-REHBERI.txt`** (515 satır) — shiv'den
  **bağımsız**, insana hitap eden tweak rehberi. Ortam, theos, iki akış,
  `caps`, keşif, hook kalıpları, doğrulama, 9 duvar, hızlı referans ve
  rehberin sınırları.
- **`belgeler/EKRAN-LEKESI-cell366.txt`** — çizim hatasının tam
  soruşturma kaydı; elenen her hipotez ve nasıl elendiği.
- Ana rapor, devir raporu ve OKU-ONCE güncellendi.

---

## Nasıl kullanılır

### Tweak yapmak istiyorum

```
1. /ortam                      ← önce ortamı ölç, tahmin etme
2. "X uygulamasında Y'yi değiştiren bir tweak yaz"
```

shiv gerisini yapar: sınıfı bulur (gerekirse uygulamayı çözer), iskeleti
kurar, derler, kurar, doğrular. Karar verirken `/ortam` çıktısındaki
**önerilen akışı** kullanır.

Kendiniz öğrenmek isterseniz `belgeler/TWEAK-GELISTIRME-REHBERI.txt`
tek başına yeterli — shiv olmadan da okunur.

### Uzun süren bir iş var, beklemek istemiyorum

```
1. Komutu çalıştır (make, find, dpkg…)
2. ctrl+b                      ← arka plana al
3. ↓                           ← alttaki sayacı seç
4. enter                       ← ayrıntı paneli
   ← geri · k durdur · esc kapat
```

Çıktı sürerken de görünür, süre saniyede bir akar.

### Bir şey ekranda yanlış görünüyor

Önce **terminali kendi başına** ölçün — shiv'i denklemden çıkarın:

```sh
printf 'A.B\nA└B\nA…B\n'
```

`B` harfleri hizalı değilse o glif çift genişlikte çiziliyordur. Bu
sürümdeki en pahalı hata tam buydu ve üç satırlık bu komutla çözüldü.

Oluk işaretini değiştirmek isterseniz, yeniden derleme gerekmez:

```sh
SHIV_OLUK='╰' shivs
```

### Bir komutun izin sorması canımı sıkıyor

İzin ekranında **"hepsine izin ver"** seçeneğini kullanın; o komut tabanı
için bir daha sormaz. Mac bağlantısı ve respring de bu mekanizmadan geçer.

### Kurulum ve paketleme

```sh
# cihazda, ~/Documents içindeki shiv.zip'ten kurulum
shivkur

# paket üretme (kaynak agacından çalıştırılmalı)
sh paket/paketle.sh her-ikisi
```

**Uyarı:** paketleme betiğini **her zaman kaynak ağacından** çalıştırın.
Ev dizininde eski bir `paket/` kopyası varsa silin — o kopyada sürüm elle
yazılı olabilir ve `.deb` yanlış numarayla çıkar.

---

## Bilinen sınırlar

Dürüst olmak gerekirse:

- Her şey **tek cihazda** ölçüldü (iPhone 16,1 / iOS 17.0.3 / RootHide).
  Rootless ve rootful için yazılanlar bilgiye dayanıyor, o cihazlarda
  sınanmadı.
- `.appex` uzantılarının şifresi çözülmüyor (ayrı süreç).
- IPA paketleme (`shiv-cek` içinde) ertelendi.
- Arka plan ayrıntı panelinin ipucu satırı kutunun **içinde**;
  referansta dışarıda. Uygulamadaki diğer paneller de içeride tuttuğu
  için tutarlılık tercih edildi.
- `/notlar` bu turda **elle test edilmedi**.

---

## Yükseltme notu

Ayar dosyaları ve oturumlar olduğu gibi taşınır; elle bir şey yapmanız
gerekmez. `resume` ile eski oturumlar açılır — 1.3.0'da yazılmış
oturumlarda katlama bilgisi olmadığı için o kayıtlar açık görünür, yeni
oturumlar doğru katlanır.
