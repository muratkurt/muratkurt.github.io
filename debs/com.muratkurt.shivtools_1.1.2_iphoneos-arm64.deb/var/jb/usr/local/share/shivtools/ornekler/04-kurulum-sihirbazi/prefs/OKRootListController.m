// OKRootListController — kok Ayarlar sayfasi (ISKELET).
//
// Tek isi var: eksik varsa KURULUM bolumunu gosterip sihirbaza
// gecmek. Asil is sihirbazda (OKKurulumController).

#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import "OKKurulumController.h"

@interface PSListController (OKPush)
- (void)pushController:(id)controller;
@end

@interface OKRootListController : PSListController
@end

@implementation OKRootListController

- (PSSpecifier *)baslik:(NSString *)ad dipnot:(NSString *)dip {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:ad target:self set:NULL
                                                       get:NULL detail:Nil
                                                      cell:PSGroupCell edit:Nil];
    if (dip) [s setProperty:dip forKey:@"footerText"];
    return s;
}

- (NSArray *)specifiers {
    if (_specifiers) return _specifiers;
    NSMutableArray *m = [NSMutableArray array];

    [m addObject:[self baslik:@"KURULUM"
                       dipnot:@"Satıra dokun, kurulum burada başlar — "
                               "Ayarlar'dan çıkmana gerek yok."]];

    // 'kur' AYRI BIR SAYFA ACIYOR, kopyalamiyor: chevron o yuzden.
    // Satirin simgesi ne yaptigini soylemeli.
    PSSpecifier *k = [PSSpecifier preferenceSpecifierNamed:@"Eksikleri kur"
                                                    target:self set:NULL get:NULL
                                                    detail:Nil cell:PSLinkCell edit:Nil];
    [k setProperty:@YES forKey:@"enabled"];
    [k setButtonAction:@selector(sihirbaziAc)];
    [m addObject:k];

    _specifiers = [m copy];
    return _specifiers;
}

- (void)sihirbaziAc {
    // Detay sinifi PSViewController soyundan olmak ZORUNDA; duz bir
    // UIViewController push edilirse Ayarlar 'setRootController:'
    // cagrisinda coker.
    OKKurulumController *vc = [OKKurulumController new];
    vc.rootController = self.rootController;
    vc.parentController = self;
    [self pushController:vc];
}

@end
