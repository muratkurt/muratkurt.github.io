#import "OKKurulumController.h"
#import <spawn.h>
#import <sys/wait.h>

// Sayfa GERCEK kokte calisir; daemon jbroot'u gorup kendi tarafinda
// /rootfs onekini ekler. Buradaki yollar DUZ yazilir.
static NSString *const kIstek = @"/var/mobile/Library/Preferences/ornek-kur-istek";
static NSString *const kSayac = @"/var/mobile/Library/Preferences/ornek-kur-deneme";
static NSString *const kDurum = @"/var/mobile/Library/Preferences/ornek-kur.json";
static NSString *const kGunluk= @"/var/mobile/Library/Preferences/ornek-kurd.log";
static NSString *const kPlan  = @"/var/mobile/Library/Preferences/ornek-kur-plan.txt";

static const int kUyanmaSiniri = 60;        // 60 x 0,5 sn = 30 sn

#pragma mark - kucuk yardimcilar

static NSDictionary *OKJson(NSString *yol) {
    NSData *d = [NSData dataWithContentsOfFile:yol];
    id j = d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
    return [j isKindOfClass:[NSDictionary class]] ? j : nil;
}

static NSTimeInterval OKYas(NSString *yol) {
    NSDictionary *a = [[NSFileManager defaultManager] attributesOfItemAtPath:yol error:nil];
    return a ? [[NSDate date] timeIntervalSinceDate:a[NSFileModificationDate]] : -1;
}

// 0 = calismiyor · 1 = sirada · 2 = suruyor.
//
// OLCUT TAZELIK, DOSYA VARLIGI DEGIL. "Istek dosyasi var" diye
// bakarsan, yardimci isi bitiremediginde o dosya sonsuza kadar kalir
// ve sayfa sonsuza kadar "kurulum suruyor" der (olculdu; kullanici
// bunu bitmeyen bir dongu olarak yasadi). Bir seyin CALISTIGINI
// ancak YENI bir iz kanitlar.
static NSInteger OKCanlilik(void) {
    NSTimeInterval dy = OKYas(kDurum);
    if (dy >= 0 && dy < 180) {
        NSString *a = OKJson(kDurum)[@"asama"];
        if ([a isEqualToString:@"kuruluyor"] || [a isEqualToString:@"tamam"] ||
            [a isEqualToString:@"basarisiz"]) return 2;
    }
    NSTimeInterval iy = OKYas(kIstek);
    return (iy >= 0 && iy < 120) ? 1 : 0;
}

static void OKBayatTemizle(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm removeItemAtPath:kIstek error:nil];
    [fm removeItemAtPath:kSayac error:nil];
}

// shiv-kur ciktisi renkli; gunluge ham gidiyor.
static NSString *OKAnsisiz(NSString *s) {
    static NSRegularExpression *re; static dispatch_once_t o;
    dispatch_once(&o, ^{ re = [NSRegularExpression
        regularExpressionWithPattern:@"\033\\[[0-9;]*m" options:0 error:nil]; });
    return [re stringByReplacingMatchesInString:s options:0
                                          range:NSMakeRange(0, s.length) withTemplate:@""];
}

// Gunlugun SON TURU. Bayt ofseti tutmak yerine gunlugun kendi
// isaretine bakiyoruz ('[kurd] istek:'); boylece ekrandan cikip
// geri gelince tarihce kaybolmuyor.
static NSString *OKSonTur(NSString *tum) {
    if (![tum length]) return @"";
    NSRange i = [tum rangeOfString:@"[kurd] istek:" options:NSBackwardsSearch];
    if (i.location == NSNotFound) return @"";
    NSRange nl = [tum rangeOfString:@"\n" options:NSBackwardsSearch
                              range:NSMakeRange(0, i.location)];
    return [tum substringFromIndex:(nl.location == NSNotFound ? 0 : nl.location + 1)];
}

#pragma mark - satir

@interface OKSatir : UIView
@property (nonatomic, strong) UILabel *ad, *alt;
@property (nonatomic, strong) UIImageView *isaret;
@property (nonatomic, strong) UIActivityIndicatorView *donen;
@property (nonatomic, assign) BOOL secili, secimModu;
@property (nonatomic, copy)   void (^dokunma)(void);
@end

@implementation OKSatir
- (instancetype)initWithAd:(NSString *)ad alt:(NSString *)alt {
    if ((self = [super initWithFrame:CGRectZero])) {
        _ad = [UILabel new];  _ad.text = ad;  _ad.font = [UIFont systemFontOfSize:16];
        _alt = [UILabel new]; _alt.text = alt; _alt.numberOfLines = 0;
        _alt.textColor = UIColor.secondaryLabelColor;
        _alt.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
        _isaret = [UIImageView new];
        _donen = [[UIActivityIndicatorView alloc]
            initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
        _donen.hidesWhenStopped = YES;
        UIStackView *y = [[UIStackView alloc] initWithArrangedSubviews:@[_ad, _alt]];
        y.axis = UILayoutConstraintAxisVertical; y.spacing = 2;
        for (UIView *v in @[y, _isaret, _donen]) {
            v.translatesAutoresizingMaskIntoConstraints = NO; [self addSubview:v];
        }
        [NSLayoutConstraint activateConstraints:@[
            [y.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:16],
            [y.topAnchor constraintEqualToAnchor:self.topAnchor constant:10],
            [y.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-10],
            [y.trailingAnchor constraintEqualToAnchor:_isaret.leadingAnchor constant:-10],
            [_isaret.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-16],
            [_isaret.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
            [_isaret.widthAnchor constraintEqualToConstant:22],
            [_isaret.heightAnchor constraintEqualToConstant:22],
            [_donen.centerXAnchor constraintEqualToAnchor:_isaret.centerXAnchor],
            [_donen.centerYAnchor constraintEqualToAnchor:_isaret.centerYAnchor],
        ]];
    }
    return self;
}
- (void)simge:(NSString *)s renk:(UIColor *)r {
    if (!s) { self.isaret.image = nil; return; }
    UIImageSymbolConfiguration *c = [UIImageSymbolConfiguration
        configurationWithPointSize:21 weight:UIImageSymbolWeightRegular];
    self.isaret.image = [[UIImage systemImageNamed:s withConfiguration:c]
        imageWithTintColor:r renderingMode:UIImageRenderingModeAlwaysOriginal];
}
// ISARETLER BELIRLEYICI OLMALI: yesil tik / KIRMIZI carpi / saat /
// donen gosterge. Birbirine benzeyen isaretler bilgi tasimaz.
- (void)durumu:(NSString *)d {
    self.secimModu = NO;
    if ([d isEqualToString:@"kuruluyor"]) { self.isaret.image = nil; [self.donen startAnimating]; return; }
    [self.donen stopAnimating];
    if ([d isEqualToString:@"tamam"])          [self simge:@"checkmark.circle.fill" renk:UIColor.systemGreenColor];
    else if ([d isEqualToString:@"basarisiz"]) [self simge:@"xmark.circle.fill" renk:UIColor.systemRedColor];
    else if ([d isEqualToString:@"bekliyor"])  [self simge:@"clock" renk:UIColor.tertiaryLabelColor];
    else self.isaret.image = nil;
}
- (void)secimiCiz {
    [self simge:(self.secili ? @"checkmark.circle.fill" : @"circle")
           renk:(self.secili ? UIColor.systemBlueColor : UIColor.tertiaryLabelColor)];
    self.ad.textColor = self.secili ? UIColor.labelColor : UIColor.secondaryLabelColor;
}
// ISARETLEYICI: varsayilan hepsi isaretli, istemedigini cikarir.
// Sagda "bekliyor" anlaminda bos bir daire gostermek yaniltiyordu —
// kullanici zaten ona dokunmak istiyordu. Bir sey gibi GORUNEN sey,
// o olmali.
- (void)isaretleyiciYap {
    self.secimModu = YES; self.secili = YES; [self secimiCiz];
    self.userInteractionEnabled = YES;
    [self addGestureRecognizer:[[UITapGestureRecognizer alloc]
        initWithTarget:self action:@selector(dokun)]];
}
- (void)dokun {
    if (!self.secimModu) return;
    self.secili = !self.secili; [self secimiCiz];
    [[UISelectionFeedbackGenerator new] selectionChanged];
    if (self.dokunma) self.dokunma();
}
@end

#pragma mark - denetleyici

@interface OKKurulumController ()
@property (nonatomic, strong) UIStackView *yigin;
@property (nonatomic, strong) UILabel *baslik, *altYazi;
@property (nonatomic, strong) UIProgressView *cubuk;
@property (nonatomic, strong) UIButton *kurDugme;
@property (nonatomic, strong) OKSatir *komutSatiri;
@property (nonatomic, strong) UITextView *gunluk;
@property (nonatomic, strong) NSMutableDictionary<NSString *, OKSatir *> *satirlar;
@property (nonatomic, strong) NSArray<NSDictionary *> *plan;
@property (nonatomic, strong) NSTimer *zamanlayici;
@property (nonatomic, copy)   NSString *oncekiZaman;
@property (nonatomic, assign) BOOL basladi, bitti, ilerlemeGoruldu;
@property (nonatomic, assign) int tur;
@end

@implementation OKKurulumController

// PLAN ELLE TUTULMAZ: paket adlari ve depo motordan gelir
// ('--makine' -> bilesen|durum|surum|paket|oneri|depo). Sayfaya
// kopyalarsan, bir paket adi degistiginde sayfa sessizce yalan soyler.
- (NSArray<NSDictionary *> *)planiOku {
    NSString *b = [NSBundle bundleForClass:[self class]].bundlePath;
    NSString *kok = [[[b stringByDeletingLastPathComponent]
                        stringByDeletingLastPathComponent] stringByDeletingLastPathComponent];
    NSString *sh   = [kok stringByAppendingPathComponent:@"bin/sh"];
    NSString *arac = [kok stringByAppendingPathComponent:@"usr/local/bin/ornek-kur"];
    NSString *yol = [NSString stringWithFormat:@"PATH=%@/usr/local/bin:%@/usr/bin:%@/bin:/usr/bin:/bin",
                     kok, kok, kok];
    char *argv[] = {"sh", (char *)arac.fileSystemRepresentation, "--makine", NULL};
    char *env[] = {(char *)yol.UTF8String, "HOME=/var/mobile", "USER=mobile", NULL};
    posix_spawn_file_actions_t fa; posix_spawn_file_actions_init(&fa);
    posix_spawn_file_actions_addopen(&fa, 1, kPlan.fileSystemRepresentation,
                                     O_WRONLY | O_CREAT | O_TRUNC, 0644);
    posix_spawn_file_actions_addopen(&fa, 2, "/dev/null", O_WRONLY, 0);
    pid_t pid = 0; int st = 0;
    int rc = posix_spawn(&pid, sh.fileSystemRepresentation, &fa, NULL, argv, env);
    posix_spawn_file_actions_destroy(&fa);
    if (rc == 0) waitpid(pid, &st, 0);

    NSMutableArray *l = [NSMutableArray array];
    NSString *cik = [NSString stringWithContentsOfFile:kPlan
                                              encoding:NSUTF8StringEncoding error:nil];
    for (NSString *satir in [(cik ?: @"") componentsSeparatedByString:@"\n"]) {
        NSArray *p = [satir componentsSeparatedByString:@"|"];
        if ([p count] < 6 || [p[1] isEqualToString:@"ok"]) continue;
        [l addObject:@{@"ad": p[0], @"paket": p[3], @"depo": p[5]}];
    }
    return l;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Kurulum";
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.satirlar = [NSMutableDictionary dictionary];
    self.plan = [self planiOku];

    UIScrollView *k = [UIScrollView new]; k.alwaysBounceVertical = YES;
    k.translatesAutoresizingMaskIntoConstraints = NO; [self.view addSubview:k];
    self.yigin = [UIStackView new]; self.yigin.axis = UILayoutConstraintAxisVertical;
    self.yigin.spacing = 10; self.yigin.translatesAutoresizingMaskIntoConstraints = NO;
    [k addSubview:self.yigin];
    UILayoutGuide *g = self.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
        [k.topAnchor constraintEqualToAnchor:g.topAnchor],
        [k.bottomAnchor constraintEqualToAnchor:g.bottomAnchor],
        [k.leadingAnchor constraintEqualToAnchor:g.leadingAnchor],
        [k.trailingAnchor constraintEqualToAnchor:g.trailingAnchor],
        [self.yigin.topAnchor constraintEqualToAnchor:k.contentLayoutGuide.topAnchor constant:12],
        [self.yigin.bottomAnchor constraintEqualToAnchor:k.contentLayoutGuide.bottomAnchor constant:-24],
        [self.yigin.leadingAnchor constraintEqualToAnchor:k.frameLayoutGuide.leadingAnchor constant:16],
        [self.yigin.trailingAnchor constraintEqualToAnchor:k.frameLayoutGuide.trailingAnchor constant:-16],
    ]];

    self.baslik = [UILabel new]; self.baslik.numberOfLines = 0;
    self.baslik.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    self.baslik.text = [self.plan count] ? @"Kuruluma hazır" : @"Kurulacak bir şey yok";
    self.altYazi = [UILabel new]; self.altYazi.numberOfLines = 0;
    self.altYazi.font = [UIFont systemFontOfSize:13.5];
    self.altYazi.textColor = UIColor.secondaryLabelColor;
    // KISA TUT. "Ne kuruldugunu, nereden geldigini gorebilirsin" gibi
    // bir cumle savunmaya gecmektir; sayfa zaten paketi, depoyu ve
    // komutu gosteriyor. Gosterdigini ayrica ANLATMA.
    self.altYazi.text = [self.plan count] ? @"İstemediğinin işaretini kaldırabilirsin." : @"";
    [self.yigin addArrangedSubview:self.baslik];
    [self.yigin addArrangedSubview:self.altYazi];

    self.cubuk = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
    self.cubuk.hidden = YES; [self.yigin addArrangedSubview:self.cubuk];

    for (NSDictionary *b in self.plan) {
        OKSatir *s = [[OKSatir alloc] initWithAd:b[@"ad"] alt:b[@"paket"]];
        [s isaretleyiciYap];
        __weak typeof(self) z = self;
        s.dokunma = ^{ [z secimDegisti]; };
        [self.yigin addArrangedSubview:s];
        self.satirlar[b[@"ad"]] = s;
    }
    if ([self.plan count]) {
        self.komutSatiri = [[OKSatir alloc] initWithAd:@"Çalışacak komut" alt:@""];
        // SABIT kopyala ikonu: hata cikinca sonradan dugme belirmesin,
        // geri bildirim eylemin YANINDA olsun.
        [self.komutSatiri simge:@"doc.on.doc" renk:UIColor.systemBlueColor];
        self.komutSatiri.userInteractionEnabled = YES;
        [self.komutSatiri addGestureRecognizer:[[UITapGestureRecognizer alloc]
            initWithTarget:self action:@selector(komutuKopyala)]];
        [self.yigin addArrangedSubview:self.komutSatiri];

        UIButtonConfiguration *c = [UIButtonConfiguration filledButtonConfiguration];
        c.title = @"Kur"; c.buttonSize = UIButtonConfigurationSizeLarge;
        self.kurDugme = [UIButton buttonWithConfiguration:c primaryAction:nil];
        [self.kurDugme addTarget:self action:@selector(basla)
                forControlEvents:UIControlEventTouchUpInside];
        [self.yigin addArrangedSubview:self.kurDugme];
    }

    // AYRINTILAR SABIT ACIK: gizlemek, gizlenecek bir sey oldugunu
    // ima eder. Ama ham gunluk ONDE de olmaz — onde okunur ozet,
    // altta ham kayit.
    UILabel *ab = [UILabel new]; ab.text = @"AYRINTILAR";
    ab.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    ab.textColor = UIColor.secondaryLabelColor;
    [self.yigin addArrangedSubview:ab];
    self.gunluk = [UITextView new];
    self.gunluk.editable = NO; self.gunluk.selectable = YES;
    self.gunluk.font = [UIFont monospacedSystemFontOfSize:10.5 weight:UIFontWeightRegular];
    self.gunluk.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    self.gunluk.layer.cornerRadius = 12;
    [self.gunluk.heightAnchor constraintEqualToConstant:220].active = YES;
    [self.yigin addArrangedSubview:self.gunluk];

    if ([self.plan count]) [self secimDegisti];

    // SUREN KURULUMA BAGLAN. Durum dosyada oldugu icin ekranin ne
    // zaman acildigi onemsiz. Canli bir sey yoksa bayat artiklari
    // temizle, yoksa sayfa sonsuza kadar "suruyor" der.
    if (OKCanlilik() > 0) {
        self.basladi = YES; self.kurDugme.hidden = YES; self.cubuk.hidden = NO;
        self.baslik.text = @"Kuruluyor";
        [self tikla]; [self zamanlayiciKur];
    } else {
        OKBayatTemizle();
    }
}

- (NSArray<NSString *> *)secilenler {
    NSMutableArray *l = [NSMutableArray array];
    for (NSDictionary *b in self.plan)
        if (self.satirlar[b[@"ad"]].secili) [l addObject:b[@"ad"]];
    return l;
}

- (void)secimDegisti {
    NSArray *s = [self secilenler];
    UIButtonConfiguration *c = self.kurDugme.configuration;
    c.title = [s count] ? [NSString stringWithFormat:@"Kur (%lu)", (unsigned long)[s count]] : @"Kur";
    self.kurDugme.configuration = c;
    self.kurDugme.enabled = [s count] > 0;
    // EKRANDA YAZAN KOMUT ile GONDERILEN ISTEK ayni listeden uretilir;
    // yoksa "seffaf" lafta kalir.
    self.komutSatiri.alt.text = [s count]
        ? [NSString stringWithFormat:@"sudo ornek-kur %@ --yap", [s componentsJoinedByString:@" "]]
        : @"— hiçbir şey seçilmedi —";
}

- (void)komutuKopyala {
    NSString *k = self.komutSatiri.alt.text;
    if (![k hasPrefix:@"sudo"]) return;
    [UIPasteboard generalPasteboard].string = k;
    [[UINotificationFeedbackGenerator new] notificationOccurred:UINotificationFeedbackTypeSuccess];
    [self.komutSatiri simge:@"checkmark.circle.fill" renk:UIColor.systemGreenColor];
    __weak typeof(self) z = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [z.komutSatiri simge:@"doc.on.doc" renk:UIColor.systemBlueColor];
    });
}

- (void)basla {
    if (self.basladi) return;
    self.basladi = YES;
    self.kurDugme.hidden = YES; self.cubuk.hidden = NO;

    // ONCEKI TURUN SONUCUNU BU TURUN SONUCU SANMA. Ilk tikta daemon
    // henuz yazmamis olur ve dosyada onceki turun 'bitti' kaydi
    // durur; ekran bir saniyede "Kurulamadi" der. Iki onlem:
    // (a) eski durum dosyasini sil  (b) damgasini not et, aynisi
    // gelirse yok say.
    self.oncekiZaman = OKJson(kDurum)[@"zaman"];
    self.ilerlemeGoruldu = NO;
    [[NSFileManager defaultManager] removeItemAtPath:kDurum error:nil];

    // SUREN ISIN USTUNE YAZMA: izlenen dosyayi degistirmek launchd'yi
    // yeniden tetikler ve calisan isi kesebilir.
    if (OKCanlilik() > 0) { [self zamanlayiciKur]; return; }

    NSString *istenen = [[self secilenler] componentsJoinedByString:@" "];
    NSError *h = nil;
    if (![istenen writeToFile:kIstek atomically:YES encoding:NSUTF8StringEncoding error:&h]) {
        [self bitir:@"İstek gönderilemedi" alt:(h.localizedDescription ?: @"?") basarili:NO];
        return;
    }
    self.baslik.text = @"Kuruluyor";
    self.altYazi.text = @"Kurulum yardımcısı uyandırılıyor…";
    for (OKSatir *s in self.satirlar.allValues) [s durumu:(s.secili ? @"bekliyor" : @"")];
    [self zamanlayiciKur];
}

- (void)zamanlayiciKur {
    [self.zamanlayici invalidate];
    __weak typeof(self) z = self;
    self.zamanlayici = [NSTimer timerWithTimeInterval:0.5 repeats:YES
                                                block:^(NSTimer *t) { [z tikla]; }];
    // ORTAK KIP SART: varsayilan kipteki zamanlayici kaydirma ve
    // gecis animasyonu sirasinda DURUR; ekran donmus gorunur, sonra
    // birden guncellenir.
    [[NSRunLoop mainRunLoop] addTimer:self.zamanlayici forMode:NSRunLoopCommonModes];
}

- (void)tikla {
    self.tur++;
    NSString *tum = [NSString stringWithContentsOfFile:kGunluk
                                              encoding:NSUTF8StringEncoding error:nil];
    NSString *yeni = OKAnsisiz(OKSonTur(tum ?: @""));
    if (![yeni isEqualToString:self.gunluk.text]) {
        self.gunluk.text = yeni;
        if (yeni.length) [self.gunluk scrollRangeToVisible:NSMakeRange(yeni.length - 1, 1)];
    }

    NSDictionary *j = OKJson(kDurum);
    if (j) {
        NSString *asama = j[@"asama"] ?: @"";
        if ([self.oncekiZaman length] && [j[@"zaman"] isEqualToString:self.oncekiZaman]) return;
        if (![asama isEqualToString:@"bitti"]) self.ilerlemeGoruldu = YES;
        if ([asama isEqualToString:@"bitti"] && !self.ilerlemeGoruldu && self.basladi) return;

        // SATIR DURUMLARI HARITADAN, tek tek olaylardan degil: ekran
        // ne zaman acilirsa acilsin butun satirlar dogru gorunsun.
        NSString *harita = j[@"sonuc"] ?: @"";
        NSInteger tamam = 0, hata = 0, kalan = 0;
        for (NSString *c in [harita componentsSeparatedByString:@" "]) {
            NSArray *kv = [c componentsSeparatedByString:@"="];
            if ([kv count] != 2) continue;
            if ([kv[1] isEqualToString:@"tamam"]) tamam++;
            else if ([kv[1] isEqualToString:@"basarisiz"]) hata++;
            else if ([kv[1] isEqualToString:@"bekliyor"]) kalan++;
            [self.satirlar[kv[0]] durumu:kv[1]];
        }
        double biten = [j[@"biten"] doubleValue], toplam = [j[@"toplam"] doubleValue];
        double alt = [j[@"altadim"] doubleValue];
        if (toplam > 0)
            [self.cubuk setProgress:(float)((biten + alt / 100.0) / toplam) animated:YES];

        if ([asama isEqualToString:@"kuruluyor"]) {
            self.baslik.text = [NSString stringWithFormat:@"Kuruluyor: %@", j[@"bilesen"]];
            self.altYazi.text = j[@"ileti"] ?: @"";
        } else if ([asama isEqualToString:@"basarisiz"]) {
            // BILESEN HATASI TURU BITIRMEZ. Motor siradakine gecer;
            // ekran "tamamlanamadi" derse yalan soyler.
            self.altYazi.text = kalan > 0 ? @"kurulamadı — sıradakine geçiliyor"
                                          : @"kurulamadı — sonuç hesaplanıyor";
        } else if ([asama isEqualToString:@"bitti"]) {
            // TEK TERMINAL ASAMA; basarili/kismi/basarisiz ayrimi
            // SAYILARDAN cikar.
            if (hata == 0) [self bitir:@"Kuruldu" alt:@"Hepsi yerinde." basarili:YES];
            else if (tamam > 0) [self bitir:@"Kısmen kuruldu"
                alt:[NSString stringWithFormat:@"%ld kuruldu · %ld kurulamadı", (long)tamam, (long)hata]
               basarili:NO];
            else [self bitir:@"Kurulamadı" alt:@"Ayrıntılar aşağıda." basarili:NO];
            return;
        }
    }

    if (self.tur >= kUyanmaSiniri && OKCanlilik() > 0 && yeni.length == 0) {
        OKBayatTemizle();   // olu turu birakma, yoksa her giriste geri gelir
        [self bitir:@"Kurulum yardımcısı yanıt vermedi"
                alt:@"Komutu terminalde çalıştırabilirsin." basarili:NO];
    }
}

- (void)bitir:(NSString *)b alt:(NSString *)a basarili:(BOOL)ok {
    if (self.bitti) return;
    self.bitti = YES;
    [self.zamanlayici invalidate]; self.zamanlayici = nil;
    self.baslik.text = b; self.altYazi.text = a;
    // CUBUK KAYBOLMAZ, RENK DEGISTIRIR: ne kadarinin kuruldugunu
    // gosteren dolu bir cubuk, bos bir cubuktan cok sey soyler.
    self.cubuk.hidden = NO;
    self.cubuk.progressTintColor = ok ? UIColor.systemGreenColor : UIColor.systemOrangeColor;
    if (ok) [self.cubuk setProgress:1.0 animated:YES];
    [[UINotificationFeedbackGenerator new] notificationOccurred:
        (ok ? UINotificationFeedbackTypeSuccess : UINotificationFeedbackTypeWarning)];
}

// Ekrandan cikilsa da is SURER (daemon ayri surec); zamanlayici bos
// yere donmesin, geri gelince yeniden kurulur.
- (void)viewWillDisappear:(BOOL)a { [super viewWillDisappear:a];
    [self.zamanlayici invalidate]; self.zamanlayici = nil; }
- (void)viewWillAppear:(BOOL)a { [super viewWillAppear:a];
    if (self.basladi && !self.bitti && !self.zamanlayici) [self zamanlayiciKur]; }
@end
