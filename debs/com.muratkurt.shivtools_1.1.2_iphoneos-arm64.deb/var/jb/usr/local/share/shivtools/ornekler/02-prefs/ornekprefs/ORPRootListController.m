#import "ORPRootListController.h"
#import <Preferences/PSSpecifier.h>

// SURUM UC YERDE GECER - birlikte guncellenir, yoksa paket bir surum,
// Ayarlar baska surum gosterir:
//   control -> Version:   Resources/Info.plist -> CFBundleShortVersionString
//   asagidaki kSurum      -> ekranda GORUNEN
static NSString * const kSurum = @"0.1.0";

@implementation ORPRootListController

// STOK YOL: Root.plist'i PSListController'in kendi yukleyicisi okur.
// Bu CALISIYORSA hicbir sey icat etme. Calismiyorsa (ornegin sinif
// calisma aninda kuruluyorsa 'bundleForClass:' nil doner ve count=0
// gelir) kendi yukleyicini yazman gerekir - ama once bunu OLC.
- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

- (id)versionValue:(PSSpecifier *)spec {
    return kSurum;
}

// BAGLANTI SATIRI: alt sayfasi olmayan PSLinkCell'e dokununca super'e
// gidersen Ayarlar bos bir sayfa push eder. Dokunusu burada yakala ve
// DON.
- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    NSString *kimlik = [[self specifierAtIndexPath:ip] identifier];
    if ([kimlik isEqualToString:@"orp-github"]) {
        [tv deselectRowAtIndexPath:ip animated:YES];
        NSURL *u = [NSURL URLWithString:@"https://github.com/"];
        [[UIApplication sharedApplication] openURL:u options:@{} completionHandler:nil];
        return;
    }
    [super tableView:tv didSelectRowAtIndexPath:ip];
}

@end
