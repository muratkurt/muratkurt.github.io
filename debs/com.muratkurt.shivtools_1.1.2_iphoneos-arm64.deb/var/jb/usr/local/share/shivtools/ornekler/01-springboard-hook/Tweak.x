// OrnekTweak — SpringBoard tweak iskeleti
//
// KASwitcher 0.0.1 -> 0.5.1 boyunca olculen desenler. Her blok
// "neden boyle" yorumuyla duruyor; kopyalayip kendi hook'unu yaz.
//
// ICINDEKILER
//   1. Olcum gunlugu        NSLog okunmuyor, dosyaya yaz
//   2. Ayar okuma           prefs ile AYNI alan + Darwin bildirimi
//   3. Grup + %ctor         sinif yoksa hook KURULMAZ
//   4. Gorunum ekleme       durum makinesinin KAPALI durumunda dogar
//   5. Yeniden kullanim     idempotent kurulum
//   6. Animasyon            sistemin sahiplendigi ozelliğe dokunma

#import <UIKit/UIKit.h>
#import <notify.h>
#import <sys/time.h>
#import <objc/runtime.h>

static NSString * const kAlan     = @"com.ornek.tweak";
static NSString * const kBildirim = @"com.ornek.tweak/prefs-changed";

// ─────────────────────────────────────────────────────────────
// 1. OLCUM GUNLUGU
//
// NSLog ve 'log show' bu kurulumlarda OKUNAMIYOR. Dosyaya yaz:
// ms damgasi + OLAY ADI + alanlar. Ikinci alan olay adi olursa
//   cut -d' ' -f2 | sort | uniq -c
// ile sayabilirsin. Her turdan once dosyayi sil.
//
// SpringBoard tweak'i /var/mobile/tw'ye yazabilir; UYGULAMA ICI
// tweak YAZAMAZ (sandbox) - orada NSTemporaryDirectory() kullan.
// RootHide'da kabuk bu dosyayi /rootfs/var/mobile/tw/... altinda gorur.
// ─────────────────────────────────────────────────────────────
static BOOL gGunluk = NO;          // ayardan gelir; yayinda kapali

static void oLog(NSString *fmt, ...) {
    if (!gGunluk) return;
    va_list ap; va_start(ap, fmt);
    NSString *m = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tm; localtime_r(&tv.tv_sec, &tm);
    char ts[16];
    snprintf(ts, sizeof ts, "%02d:%02d:%02d.%03d",
             tm.tm_hour, tm.tm_min, tm.tm_sec, (int)(tv.tv_usec / 1000));
    FILE *f = fopen("/var/mobile/tw/ornek-log.txt", "a");
    if (f) { fprintf(f, "%s %s\n", ts, m.UTF8String); fclose(f); }
}

// Hook'un GERCEKTEN calistigini bir kez yazar. "%ctor'da kuruldu" ile
// "calisti" ayri seylerdir: kurulu ama hic cagrilmayan bir hook
// olculdu (DolapClean, CleverTap). Cagrildi satiri hic dusmuyorsa o
// yol tetiklenmiyordur - bu da bir olcumdur.
static void oLogBirKez(NSString *anahtar, NSString *mesaj) {
    static NSMutableSet *gorulen;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ gorulen = [NSMutableSet set]; });
    @synchronized (gorulen) {
        if ([gorulen containsObject:anahtar]) return;
        [gorulen addObject:anahtar];
    }
    oLog(@"%@ %@", anahtar, mesaj);
}

// ─────────────────────────────────────────────────────────────
// 2. AYAR OKUMA
//
// Tweak ile prefs bundle AYNI alani konusmali. Ayar degisince prefs
// tarafi PostNotification atar, burada yakalanir. Yoksa kullanici
// ayari degistirir, tweak eski degerle calismaya devam eder.
// ─────────────────────────────────────────────────────────────
static BOOL     gEtkin  = YES;
static CGFloat  gHiz    = 1.0;
static NSString *gBoyut = @"orta";

static void ayarlariOku(void) {
    CFPreferencesAppSynchronize((__bridge CFStringRef)kAlan);
    id v;
    v = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("etkin"),
            (__bridge CFStringRef)kAlan);
    gEtkin = v ? [v boolValue] : YES;
    v = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("animasyonHizi"),
            (__bridge CFStringRef)kAlan);
    gHiz = v ? [v doubleValue] : 1.0;
    v = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("butonBoyutu"),
            (__bridge CFStringRef)kAlan);
    gBoyut = [v isKindOfClass:[NSString class]] ? v : @"orta";
    v = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("gunluk"),
            (__bridge CFStringRef)kAlan);
    gGunluk = v ? [v boolValue] : NO;
    oLog(@"ayar etkin=%d hiz=%.2f boyut=%@", gEtkin, gHiz, gBoyut);
}

// ─────────────────────────────────────────────────────────────
// 4. GORUNUM EKLEME
//
// ★ Gorunurlugu bir durum makinesine bagli olan her view, makinenin
// "KAPALI" durumunda dogmali (hidden=YES, alpha=0). Gorunur dogan
// view ilk karara kadar yanlis durumda kalir ve respring sonrasi
// ILK acilista tek seferlik titreme olarak gorunur; sonraki
// denemelerde kacar. (KASwitcher 0.4.3'te olculdu.)
//
// ★ Kap gorunumler YENIDEN KULLANILIR: kurulum idempotent olmali
// (ayni view iki kez eklenmesin), 'prepareForReuse' animasyon
// surerken transform/alpha sifirlarsa animasyonu oldurur.
// ─────────────────────────────────────────────────────────────
static const char kButonAnahtar;   // associated object: idempotentlik

static UIView *butonuKur(UIView *kap) {
    UIView *var_ = objc_getAssociatedObject(kap, &kButonAnahtar);
    if (var_) return var_;                       // ZATEN kurulu

    UIView *b = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 38, 38)];
    b.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    b.layer.cornerRadius = 19;
    b.hidden = YES;                              // ★ KAPALI dogar
    b.alpha  = 0;
    [kap addSubview:b];
    objc_setAssociatedObject(kap, &kButonAnahtar, b,
                             OBJC_ASSOCIATION_ASSIGN);
    oLogBirKez(@"buton", @"kuruldu (gizli dogdu)");
    return b;
}

// ─────────────────────────────────────────────────────────────
// 6. ANIMASYON
//
// ★ Sistemin gecislerde kullandigi ozelliğe DOKUNMA. Kendi
// animasyonun tutmuyorsa once MODEL ile EKRANI ayri olc:
//   view.transform / view.alpha        -> model (senin yazdigin)
//   view.layer.presentationLayer       -> ekran (gorunun)
// Ikisi ayrisiyorsa o ozellik sistemindir ve her karede geri
// yaziliyordur. Care: asil goruunume dokunma, snapshot kopyasini
// canlandir. (KASwitcher 0.5.0'da olculdu: model olcegi hep 0.685,
// ekran alfasi hep 1.00.)
// ─────────────────────────────────────────────────────────────
static void modelEkranOlc(UIView *v, NSString *etiket) {
    CALayer *p = v.layer.presentationLayer;
    oLog(@"%@ model a=%.3f alpha=%.2f | ekran a=%.3f opacity=%.2f",
         etiket, v.transform.a, v.alpha,
         p ? p.transform.m11 : -1, p ? p.opacity : -1);
}

static void kopyayiCanlandir(UIView *asil, UIView *ustKap) {
    // Asil goruunume dokunmadan: ekrandaki halinin kopyasini al,
    // ayni yere koy, KOPYAYI canlandir.
    UIView *kopya = [asil snapshotViewAfterScreenUpdates:NO];
    if (!kopya) return;
    kopya.frame = [ustKap convertRect:asil.bounds fromView:asil];
    [ustKap addSubview:kopya];
    [UIView animateWithDuration:(0.3 * gHiz)
                     animations:^{
        kopya.alpha = 0;
        kopya.transform = CGAffineTransformMakeScale(0.2, 0.2);
    } completion:^(BOOL finished) {
        // ★ Bitis bayragini DA logla: finished=0 yarida kesildi demek.
        oLog(@"kopya animasyonu bitti finished=%d", finished);
        [kopya removeFromSuperview];
    }];
}

// ─────────────────────────────────────────────────────────────
// 3. HOOK GRUBU
//
// Hedef sinif adini DOGRUDAN yazmak yerine %group + %init kullan:
// sinif yoksa grup KURULMAZ (nil sinifa hook cokme riskidir) ve
// gunluge "YOK" dusurur - hangi iOS'ta neyin olmadigini boylece
// olcersin. Swift siniflari modul onekiyle kayitli
// ('Modul.Sinif'), Logos'ta takma adla hook'lanir.
// ─────────────────────────────────────────────────────────────
%group GKap
%hook ORNEK_KAP            // ornegin SBFluidSwitcherItemContainer

- (void)didMoveToWindow {
    %orig;
    oLogBirKez(@"kap", @"didMoveToWindow calisti");   // ★ CAGRILDI kaniti
    if (!gEtkin) return;
    UIView *self_ = (UIView *)self;
    if (!self_.window) return;
    butonuKur(self_);
}

- (void)layoutSubviews {
    %orig;
    if (!gEtkin) return;
    // Kap buyudukce/yeniden kullanildikca kurulumu TEKRAR uygula;
    // idempotent oldugu icin zararsiz.
    butonuKur((UIView *)self);
}

%end
%end

// ─────────────────────────────────────────────────────────────
%ctor {
    ayarlariOku();

    // Darwin bildirimi: prefs degisince ayarlari yeniden oku.
    int token;
    notify_register_dispatch([kBildirim UTF8String], &token,
                             dispatch_get_main_queue(),
                             ^(int t) { (void)t; ayarlariOku(); });

    // ★ Sinif VARSA kur, yoksa gunluge yaz. Boylece bir sonraki iOS'ta
    // sinif adi degisirse tweak CALISMAZ ama COKMEZ, ve sebebi
    // gunlukte yazar.
    Class c = objc_getClass("SBFluidSwitcherItemContainer");
    if (c) { %init(GKap, ORNEK_KAP = c); oLog(@"kuruldu SBFluidSwitcherItemContainer"); }
    else    { oLog(@"YOK SBFluidSwitcherItemContainer"); }

    // Kullanilmayan yardimcilar icin derleyici uyarisi cikmasin:
    (void)modelEkranOlc; (void)kopyayiCanlandir; (void)gBoyut;
}
