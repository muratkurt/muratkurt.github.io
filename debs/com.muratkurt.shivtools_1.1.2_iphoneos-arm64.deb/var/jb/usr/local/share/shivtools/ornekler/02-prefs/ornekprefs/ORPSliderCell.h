#import <Preferences/PSSliderTableCell.h>
@interface ORPSliderCell : PSSliderTableCell
@end
