# Tweak geliştirme rehberi — nereden başlanır

```
belgeler/
  TWEAK-GELISTIRME.md       Birikmiş rapor. ActionButtonFix, KASwitcher ve
                            DolapClean'den çıkan her şey: yöntem, bilinen
                            duvarlar, bilgi tabanı. shivtools araçlarına
                            atıf yapar.
  MAC-TWEAK-GELISTIRME.md   Aynı bilgi, HİÇBİR özel araca bağlı olmadan.
                            Mac + Theos + ssh yeter. Paylaşılabilir.

ornekler/
  01-springboard-hook/      SpringBoard tweak'i iskeleti (KASwitcher deseni)
  02-prefs/                 Ayarlar sayfası: anahtar, slider, seçim listesi,
                            ALT SAYFA, dinamik liste (ABF + KASwitcher)
  03-uygulama-ici/          Uygulama içi tweak: ağ katmanında JSON süzme
                            (DolapClean deseni, Swift uygulamalar için)
```

**Kime hangisi:**
- Cihazda shivtools ile çalışıyorsan → `TWEAK-GELISTIRME.md`
- Yalnız Mac'in ve bir cihazın varsa → `MAC-TWEAK-GELISTIRME.md`
- Kod yazmaya başlayacaksan → önce ilgili örneği kopyala, sonra belgedeki
  ilgili bölümü oku.

**Örnekler çalışır durumdadır**: üçü de Theos ile derlenip `.deb`
üretecek şekilde bırakıldı (bkz. `ornekler/OKU.md`). Kopyala, adları
değiştir, kendi hook'unu yaz.
