# Mac'te iOS tweak geliştirme — pratik rehber

Bu rehber **hiçbir özel araca bağlı değildir**. Gereken her şey Theos,
Apple'ın komut satırı araçları, `ssh`/`scp` ve cihazdaki `dpkg`. Bir
jailbreak'li iPhone ve bir Mac yeterli.

İçindekilerin hepsi üç gerçek tweak'te (bir SpringBoard tweak'i, bir
Ayarlar sayfası, bir uygulama içi tweak) **cihazda ölçülerek** öğrenildi.
"Muhtemelen böyledir" cümlesi yok; bilinmeyen yerler **DOĞRULANMADI**
diye işaretli.

---

## 0. Altın kural

> **Belirtinin sebebini tahmin etme. Cihazdan veri al.**

Dört adım, sırayla: **ölç → sebep → düzelt → doğrula.** Biri atlanınca
tur boşa gider. Ve **en fazla iki kurulum turu**: üçüncüye girme, dur,
ölçtüğünü yaz.

Her kurulum turu pahalıdır (derle + kopyala + kur + respring + test).
Bu rehberin çoğu, tur harcamadan bilgi almanın yollarıdır.

---

## 1. Kurulum

### 1.1 Theos
```
git clone --recursive https://github.com/theos/theos.git ~/theos
export THEOS=~/theos
```
**RootHide hedefliyorsan ayrı bir çatal gerekir:**
```
git clone --recursive https://github.com/roothide/theos.git ~/theos-rh
```

> **Tuzak:** klasör adına güvenme, içine bak.
> `git -C <klasör> config --get remote.origin.url` → `roothide/theos` mu
> `theos/theos` mu? Bir makinede `~/theos-roothide` adlı klasör
> **standart** theos çıktı. Adına bakıp seçen kişi iki paketi de yanlış
> şemayla derler.

SDK: `$THEOS/sdks/` altına bir iPhoneOS SDK koy (ör. `iPhoneOS16.5.sdk`).

### 1.2 Cihaz erişimi
```
ssh root@<ip>            # rootless varsayılan parola: alpine
scp paket.deb root@<ip>:/var/mobile/
ssh root@<ip> 'dpkg -i /var/mobile/paket.deb'
```
Cihazın IP'si değişir; bağlanmadan önce Mac'in kendi ağına bak
(`ipconfig getifaddr en0`) ve cihazı aynı `/24` içinde ara.

---

## 2. Hedefi tanı: hangi jailbreak, hangi paket

| Tür | Yol şeması | Paket mimarisi | Şema |
|---|---|---|---|
| **rootless** (Dopamine, Procursus) | `/var/jb/...` | `iphoneos-arm64` | `THEOS_PACKAGE_SCHEME=rootless` |
| **RootHide** | önek yok (`/Library/...`) | `iphoneos-arm64e` | `THEOS_PACKAGE_SCHEME=roothide` |
| rootful (eski) | `/Library/...` | `iphoneos-arm64` | şema yok |

**Şemayı hedef belirler, derleme cihazı değil.** İkisini de üret:

```
make THEOS=~/theos-rh        clean package THEOS_PACKAGE_SCHEME=roothide FINALPACKAGE=1
make THEOS=~/theos           clean package THEOS_PACKAGE_SCHEME=rootless FINALPACKAGE=1
```

`FINALPACKAGE=1` olmazsa sürüme `+debug` eklenir ve paket yayına uygun
olmaz.

Cihazın hangisi olduğunu anlamak: `/var/jb` bir **symlink** olabilir,
tek başına ayırt etmez (Dopamine'de de var). Ayırt eden:
```
ls -d /var/containers/Bundle/Application/.jbroot-* 2>/dev/null   # varsa RootHide
```

---

## 3. ABI / caps — safe mode'un en sık sebebi

arm64e tweak'lerde Mach-O başlığındaki **caps** baytı ABI'yi söyler:
`0x80` yeni, `0x00` eski. Eski ABI'li bir tweak, kullanıcıda `oldabi`
yoksa **safe mode** demektir.

**Doğru okuma (dylib genelde fat, `od` fat başlığını gösterir):**
```
lipo KASwitcher.dylib -thin arm64e -output /tmp/s
od -A n -t x1 -N 12 /tmp/s      # 12. bayt: 80 = yeni ABI, 00 = eski
otool -f KASwitcher.dylib       # capabilities 0x80
```
`file` çıktısındaki **`PAC00` caps baytı değildir** — 0x80 ve 0x00
ikilide aynı görünebilir. Her pakette **ölç**, varsayma.

**caps 0x00 tek başına zararsız.** Belirleyici iki tetikleyici: bir
`@"..."` literali ya da sisteme verilen bir blok (`[block copy]`).
Sınav tek komut:
```
otool -l <dylib> | grep -c __cfstring     # 0 olmalı
```
arm64 (uygulama) hedeflerinde bu konu **hiç** geçerli değildir.

Tetikleyici varsa iki dürüst yol: `control`'e
`Depends: firmware (<< 15.0) | cy+cpu.arm64v8 | oldabi` yaz, **ya da**
Mac'te derle (caps 0x80) ve hiçbir şeye bağımlı olma. Sessizce oldabi
gerektiren paket yayınlamak, kullanıcının cihazını safe mode'a
düşürmektir.

> **Ölçüm tuzağı:** derleme cihazında `oldabi` kuruluysa tetikleyicili
> paket de "çalışıyor" görünür. Gerçeği görmek için `OldABI.dylib`'i
> adından taşıyıp tek değişkenli A/B yap.

---

## 4. Hangi sınıfı, hangi metodu hook'layacaksın

### 4.1 Sınıfı bul (Mac'te, cihaz gerekmeden)
Cihazın `dyld_shared_cache`'ini Mac'e çek ve içinde ara:
```
scp root@<ip>:/System/Library/Caches/com.apple.dyld/dyld_shared_cache_arm64e .
# blacktop/ipsw ile:
ipsw dsc info  dyld_shared_cache_arm64e
ipsw dsc dump  dyld_shared_cache_arm64e --class 'SB.*Switcher.*'
ipsw dsc disass dyld_shared_cache_arm64e --symbol '-[SBMediaController nowPlayingApplication]'
```
Aynısını bir **IPSW**'den de yapabilirsin (cihaz hiç gerekmez): sistem ve
cryptex DMG'lerini mount et, cache'i oradan al. İki iOS sürümünü
karşılaştırmanın yolu budur.

Uygulama tweak'inde hedef ikili uygulamanın kendisidir:
```
strings -a <App.app>/<App> | grep -i 'endpoint\|banner\|promo'
otool -ov <App.app>/<App> | less     # ObjC sınıf/metot tablosu
```

### 4.2 İmzayı ÇALIŞAN süreçten oku — en önemli kural
> **İmzasını görmediğin private metodu çağırma.** Dönüş tipi bilinmeyen
> bir metodu çağırıp dönen değeri tutmak `objc_retain` çökmesi ve safe
> mode demektir. Bu iki kez yaşandı.

İmza = **tip kodlaması**, metot adı değil. Cache'ten güvenilir şekilde
çıkarılamıyor (denendi: hesaplanan adres komşu dizeye düştü, `v24@0:8@16`
yerine `q24@0:8@16`). Çalışan süreçten oku — frida ile, cihazda:

```js
// frida -U -n SpringBoard -l tip.js
var cls = ObjC.classes.SBMediaController;
var sel = "nowPlayingApplication";
var m = ObjC.api.class_getInstanceMethod(cls.handle,
          ObjC.api.sel_registerName(Memory.allocUtf8String(sel)));
console.log(new NativePointer(ObjC.api.method_getTypeEncoding(m)).readUtf8String());
```

Okuma:
```
@16@0:8        → döner: nesne(@) · self(@) · sel(:) · sayılar bayt ofseti
v24@0:8@16     → void döner, bir nesne argüman alır
i16@0:8        → int döner
?              → tip okunamadı: ÇAĞIRMA
v=void  B=BOOL  i=int  q=long  d=double  ^v=pointer  {CGRect=...}=yapı
```

### 4.3 Public mi private mi
SDK başlığında ara — ama **sınıfın kendi başlığı, üst sınıf zinciri ve
protokolleri** içinde:
```
grep -rn "performWithSender:" $THEOS/sdks/iPhoneOS16.5.sdk/System/Library/Frameworks/UIKit.framework/Headers/
```
Başka sınıfın başlığındaki aynı ad "public" demek değildir: `UIAction
-handler` tüm SDK'da arandığında alakasız bir CoreMotion başlığı eşleşti
ve private bir getter public sanıldı. İki ayrıntı:
- Çok parçalı seçici başlıkta **tam hâliyle geçmez**
  (`performWithSender:target:` yerine `- (void)performWithSender:(id)
  sender target:(id)target;`).
- Tek parçalı seçici **argüman adı** olarak geçebilir (`handler`).
  Bildirim sonunu ara: `)ad;`.

### 4.4 Sınıfın adı ne yaptığını söylemez
`SBFluidSwitcherViewController` switcher değil; `dolap.VerificationView`
bir doğrulama ekranı değil, Menü'deki resim banner'ı. **Metotlar için de
geçerli:** isimden tahmin edilen üç metodun ikisi yanlış çıktı. Hook
yazmadan önce, davranışı değiştirmeyen bir "yalnız ölçüm" kurulumuyla
(`%orig` + tek satır log) **çağrı zincirini çıkar**.

### 4.5 Swift sınıfları
Modül önekiyle kayıtlıdır (`dolap.Foo`, `UIComponents.Bar`) ve Logos'ta
doğrudan yazılamaz:
```objc
%group GAkis
%hook DCAgDelegesi          // takma ad
- (void)URLSession:(NSURLSession *)s dataTask:(id)t didReceiveData:(NSData *)d { … }
%end
%end

%ctor {
    Class c = objc_getClass("Alamofire.SessionDelegate");
    if (c) { %init(GAkis, DCAgDelegesi = c); }   // sınıf yoksa hook KURULMAZ
}
```
`%init`/`%orig` **`#define` içine konmaz** — Logos önişlemciden önce
genişletir.

---

## 4b. Hook noktasını seçmek — tetikleyici → sahip → stok yol

Bir donanım düğmesinin davranışını değiştiren tweak'te bu üç adım
sırayla öğrenildi; sırayı bilmeyen her adımda tur harcar.

**1. Tetikleyiciyi hook'la, ama EN DAR noktayı.** İlk akla gelen sınıf
genelde **paylaşılan altyapıdır**: düğmenin basılı tutma süresini tutan
parametre sınıfı hook'lanınca **bütün** düğmeler etkilendi. Doğru nokta
o düğmenin kendi `performActionsForButtonDown:/Up:/LongPress:`
metotlarıydı.

**2. Davranış yapışmıyorsa DURUMUN SAHİBİNİ bul.** Olayı yakalamak,
sonucu değiştirmeye yetmiyor. Hangi eylemin çalışacağını düğme değil bir
**veri kaynağı** tutuyordu (`…DataSource`, `_selectedSystemAction`).
Çözüm: tıklama anında o alana kendi eylemini yaz, akışı çalıştır,
**kısa süre sonra eski değeri geri koy** — kullanıcının ayarı bozulmasın.

> Kural: "gösteren" değil **tutan** hook'lanır. Bir şeyi değiştirip geri
> koyuyorsan geri koymayı da ölç.

**3. Stok davranış istiyorsan ORİJİNALİ OYNAT.** "Sistemin kendi eylemi
çalışsın" için iki yol denendi:
- Sistemin yürütücüsünü dışarıdan çağırmak → **her durumda Safe Mode**
  (yürütücünün içinde `isExecuting` assertion'ı var). Kapalı yol.
- Orijinal IMP'leri sırayla oynatmak (`Down → LongPress → Up`) →
  çalıştı. Hiçbir şey yeniden yazılmıyor, sistemin kendi zinciri kendi
  sırasıyla çalışıyor.

**4. "Bazı durumlarda çalışmıyor" ise sistemin durum bayrağını ara.**
Ekran kapalıyken hiç tetiklenmiyordu; tür farkı ve zamanlama elendi,
basışın ulaştığı ölçüldü. Sonra sistemin kendi bayrakları loglandı:
bastırma (suppression) değeri ekran kapalıyken 1, açıkken 2. Çare:
zinciri oynatmadan önce ekranı uyandır ve bayrak değişene kadar bekle
(250–300 ms ölçüldü). "Çoğunlukla çalışıyor" çözüm değildir.

### Yöntem: tek değişkenli ölçüm zinciri
Bu iş, **her satırı tek değişken** olan bir tabloyla yürütüldü:

| # | Hipotez | Değişiklik | Sonuç | Ders |
|---|---|---|---|---|
| A | Mod kimliği yeter | intent kimliği değişti | foto modunda açıldı | ✗ |
| … | | | | |
| N6 | Önce ekranı uyandır | suppression 1→2 beklendi | her durumda çalıştı | ✓ |

İki faydası ölçüldü: elenen yol bir daha denenmiyor, ve "neden boşa
gitti" satırı kendi hatanı da kaydediyor. O projede iki kez **kendi
kodunu okumadan** ölçüme girildi ve iki tur gitti: bir parametre
intent'e eklenip denendi, sonra görüldü ki kod o parametreyi hiç
okumuyordu.

---

## 5. Ölçüm yöntemleri

### 5.1 Dosyaya log (NSLog okunmaz)
Jailbreak kurulumlarında `NSLog` ve `log show` pratikte okunamıyor.
Tweak'ten dosyaya yaz:

```objc
#import <sys/time.h>
static void xLog(NSString *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    NSString *m = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tm; localtime_r(&tv.tv_sec, &tm);
    char ts[16];
    snprintf(ts, sizeof ts, "%02d:%02d:%02d.%03d",
             tm.tm_hour, tm.tm_min, tm.tm_sec, (int)(tv.tv_usec / 1000));
    FILE *f = fopen("/var/mobile/tw/x-log.txt", "a");     // SpringBoard tweak'i
    if (f) { fprintf(f, "%s %s\n", ts, m.UTF8String); fclose(f); }
}
```
- **Uygulama içi tweak'te bu yol çalışmaz** (sandbox):
  `NSTemporaryDirectory()` kullan, kabuktan
  `/rootfs/var/mobile/Containers/Data/Application/<UUID>/tmp/` oku.
- Satır biçimi: **ms damgası + olay adı + ilgili alanlar.** İkinci alan
  olay adı olursa `cut -d' ' -f2 | sort | uniq -c` ile sayabilirsin.
- Her turdan önce `rm -f` ile sıfırla. Okurken `cat` değil `tail -60` +
  `grep`.

### 5.2 Ölçüm hook'unun kuralları
- Ölçüm için **yeni API getirme**; tweak'in zaten kullandığı yolu kullan.
- Her adımda `respondsToSelector:`; nil değer ayrı etiketle loglanır —
  "yok" da veridir.
- Tamamı `@try`/`@catch`. Ölçüm kodu ürünü düşürmez.
- Private objeyi `%@` ile yazma; yalnız string etiket ve sayı.
- Animasyonda **bitiş bayrağını** da yaz (`finished=0` = yarıda kesildi).
- **Erken dönen her dalda kararı veren değerleri yaz.** Sessizce çıkan
  bir fonksiyon bir turu yedi; karar girdileri loglanınca sebep ilk
  bakışta göründü.
- **Kurulan hook ≠ çalışan hook:** `%ctor`'da "kuruldu", hook'un içinde
  bir kez "çağrıldı" yaz. İkincisi hiç düşmüyorsa o yol tetiklenmiyordur
  — bu da bir ölçümdür.

### 5.3 Model mi, ekran mı?
Kendi animasyonun saçmalıyorsa **model** ile **ekranı** ayrı ölç:
```objc
xLog(@"model tf.a=%.3f alpha=%.2f", v.transform.a, v.alpha);
CALayer *p = v.layer.presentationLayer;
xLog(@"ekran tf.a=%.3f opacity=%.2f", p.transform.m11, p.opacity);
```
İkisi ayrışıyorsa o özellik **sistemindir** ve her karede geri yazılıyor.
Çare: o görünüme dokunma; `snapshotViewAfterScreenUpdates:NO` kopyasını
canlandır, aslını kendi yolundan kaldır.

### 5.4 Görsel hatalar için ekran görüntüsü
Titreme, tek karelik yeniden çizim, yanlış konum günlükte görünmez.
Kullanıcı ekran kaydı alıp Fotoğraflar > Düzenle'de kare kare ilerler ve
ekran görüntüsü alır; kareler `/var/mobile/Media/DCIM/1xxAPPLE/` altında
(RootHide'da kabuktan `/rootfs/var/mobile/Media/DCIM/...`). Karşılaştırma
**numaraya** göre yapılır, tarihe göre değil — tarihler toplu yazılmış
olabiliyor.

### 5.5 Veri süzüyorsan: önce say
Yanıtı **değiştirmeden** kaydet, beklenen sonucu Mac'te önceden hesapla,
sonra tweak'in günlüğüyle karşılaştır (47→26, sponsorlu 6 gibi). "Ekran
temiz görünüyor" doğrulama değildir.

---

## 6. Namespace (RootHide) — dosyanı bulamıyorsan

Kabuk **jbroot** içinde, sistem süreçleri **gerçek** yolda çalışır.

| Belirti | Gerçek durum |
|---|---|
| Tweak `/var/mobile/tw/x.txt` yazdı, kabukta yok | `/rootfs/var/mobile/tw/...` |
| Kabuktan yazdığın dosyayı tweak göremiyor | Tweak gerçek kökte; `/var/...` ona başka yer |
| `node /mutlak/yol.mjs` → MODULE_NOT_FOUND | `cd` edip göreli adla çalıştır |
| Uzun jbroot yolu gerekiyor | `.jbroot-*` adı **yeniden başlatmada değişir** → `glob` |

Kural: "yazdığım dosya yok" demeden önce aynadaki yola bak.

---

## 7. Ayarlar sayfası (prefs)

> **Prefs'te hiçbir hata ses çıkarmaz.** Derleme geçer, tweak yüklenir,
> sayfa boş gelir ya da seçim kaydolmaz. Bir hücrenin görünmesi, onun
> eyleminin çalıştığını kanıtlamaz.

### 7.1 Stok yol (önce bunu dene)
`PSListController` + `Root.plist` + PreferenceLoader. Kuralları:
- Ayarlar'ın push ettiği detay sınıfı **`PSViewController` soyundan
  olmalı** (düz `UIViewController` → çökme).
- `specifiers` **gerçek bir dizi** olmalı (boş/nil → `NSRangeException`).
- Tekli seçim: `PSListItemsController` + `validValues`, `validTitles`,
  `shortTitles`; yanlış anahtar Ayarlar'ı çökertir.
- Dinamik liste stok yoldan: dinamik `PSSpecifier` + `reloadSpecifiers`.
  Kendi `UITableView`'ini kurma.
- Uygulama listesi: `LSApplicationWorkspace defaultWorkspace →
  allInstalledApplications`; hazır seçici için **AltList**.
- Örnek: `/System/Library/PreferenceBundles/*.bundle`.

### 7.2 Tek yazıcı kuralı — en pahalı prefs hatası
Bir ayarı `setPreferenceValue:` (CFPreferences) ile, başka bir ayarı
kendi yazıcınla dosyaya yazarsan: **cfprefsd senin yazdığını görmez ve
eski önbelleğini dosyaya geri yazar.** Kullanıcı bir ayarı değiştirdi,
başka bir ayar kendiliğinden eski değerine döndü.

**Prefs dosyasına tek bir yazıcı yazar.** Ya tamamen CFPreferences ya
tamamen kendi yazıcın. `CFPreferencesAppSynchronize` bunu çözmez
(denendi, ölçümle çürüdü).

### 7.3 Tweak ile prefs aynı alanı konuşmalı
- Aynı `com.…` alanı; değişince `PostNotification` + Darwin observer.
- RootHide'da dosya jbroot tarafına yazılıp rootfs'ten okunabiliyor:
  önce rootfs, yoksa `glob(".jbroot-*/var/mobile/Library/Preferences/…")`.
- SpringBoard tarafında CFPreferences riskliydi (ctor'da çökme, yazmada
  safe mode). Gerekirse minimal bir okuyucu/yazıcı çifti yaz — ama
  **dosya baştan yazılır**: yeni anahtarı okuma+değiştirme+yazma üçüne
  birden ekle, yoksa ilk yazımda silinir.
- Çevirileri sınamak için sistem dilini değiştirme: uygulamanın kendi
  `AppleLanguages` tercihini süreç içinden yaz, oku, **geri al**.

### 7.4 Ayarlar sayfasını açma
```
launchctl list | grep -F "UIKitApplication:com.apple.Preferences["
kill -9 <pid>
uiopen "prefs:root=<Sayfa>"        # alt sayfa: &path=<specifier-id>
```
Ayarlar ayaktayken `uiopen` yok sayılır; süreci öldürmek yeni bundle'ın
yüklenmesini de sağlar.

---

## 8. Uygulama içi tweak (Swift/SwiftUI uygulamalar)

- **Görünümü gizlemek delik bırakır, veriyi silmek bırakmaz.** Ölçüldü:
  boş liste dönen bölüm ekranda hiç çizilmedi; buna karşılık gizlenen bir
  banner'ın yerinde 160 pt boşluk kaldı. Kaldırmadan önce "veriyi
  susturursam bölüm doğar mı" diye ölç.
- **Ağ katmanı deseni** (Alamofire kullanan uygulamada ölçüldü):
  `URLSession:dataTask:didReceiveData:` parçaları biriktir ve iletme;
  `URLSession:task:didCompleteWithError:` anında JSON'u süz, kendi
  `didReceiveData:` çağrını bir **bayrakla** geçir, sonra `%orig`.
  Hata/çözülemeyen JSON'da **orijinali** ver.
- Tampon: görev başına `NSMapTable weakToStrongObjectsMapTable`,
  `@synchronized` ile korunur, görev bitince silinir.
- **Akış → beyaz liste** (yalnız gerçek içerik kalır; yeni tanıtım türü
  kendiliğinden düşer). **İşlevsel sayfa → kara liste.**
- Uygulama güncellenince sınıf adları ve uç noktalar değişir: sınıf
  yoksa hook kurulmasın, JSON çözülemezse orijinal geçsin. Böylece tweak
  bozulmaz, sadece etkisiz kalır.
- Aynı uygulamaya giren **başka tweak'ler ölçümü kirletir**; başlamadan
  önce bak.

---

## 9. SpringBoard tweak'i — sık düşülen yerler

- Görünürlüğü bir durum makinesine bağlı her view **kapalı doğmalı**
  (`hidden=YES, alpha=0`); görünür doğan view respring sonrası ilk
  açılışta tek seferlik titreme yapar ve sonraki denemelerde kaçar.
- Kart/hücre görünümleri **yeniden kullanılır**: kurulum idempotent
  olmalı, `prepareForReuse` animasyonu öldürebilir, "görünüm → kimlik"
  eşlemesi bayatlar (kimliği görünümün kendi modelinden oku).
- **Sistemin kullandığı transform bileşenine dokunma.**
- Yoklama (polling) ile görünürlük **geç ve yanlış**: 600–1000 ms sonra,
  bazen yanlış cevap. Yön taşıyan bir çağrı ara.
- **Pencere dönmez, içerik döner:** yatayda pencere hâlâ dikey ölçüde;
  `safeAreaInsets` dikey değerleri verir ve sistem context menüsü pencere
  yönünde açılır. Arayüz yönünü **içerik görünümünün boyutundan** oku.
- **Dikey VE yatay ölç.** Bir projede yatay hiç ölçülmemişti; ilk
  ölçümde butonun kartların üstünde kaldığı görüldü.
- Overlay'de sistem context menüsü yerine **kendi menünü** çizmek üç
  ayrı kusuru birden kaldırdı (yatay yön, önizleme sıçraması, konum).
  Punto sabit yazma: `preferredFontForTextStyle:UIFontTextStyleBody`.
- **Respring'i sen çalıştırma**, kullanıcıdan iste. `killall SpringBoard`
  onun o an ne yaptığını bilmiyorsun.

---

## 10. Kurulumdan önce altı adım

1. **Kaynak farkı:** son yedekle `diff` — değişen yalnız beklediğin yer mi?
2. **Bozuk yorum:** `grep -n '^[[:space:]]*/[^/*]' Tweak.x` boş dönmeli
   (tek `/` ile düşen yorum derlemeyi sessizce bozabiliyor).
3. **Derleme geçti mi — `ls -t`'ye güvenme.** Çıktıda
   `dm.pl: building package '...' in './packages/<ad>.deb'` satırını ara.
   Yoksa **eski deb yerinde duruyor** ve sessizce kurulur.
4. **Ürünün içinde iz:** `dpkg-deb -x` ile aç; `strings` çıplak ikilide
   yanıltır, kesin olan `LC_UUID`:
   `otool -l <dylib> | grep -A2 LC_UUID` — derlenen ile kurulanı
   karşılaştır.
5. **Kurulum:** `dpkg -i` → `exit=0`, sonra `dpkg -l | grep <paket>` ile
   **sürümü gözle doğrula.**
6. **Respring'i kullanıcıdan iste**, sonra en fazla 5 adımlık numaralı
   test betiği ver ve **geri dönüş komutunu** yaz.

**İki ölçülmüş tuzak:**
- **RootHide kurulumdan sonra dylib'i değiştiriyor** (41 bayt: `__TEXT`
  padding + imza bölgesi; boyut aynı). md5 karşılaştırmasını kurulumun
  **hemen ardından** yap, ya da md5 yerine `LC_UUID` kullan.
- **Kurulum ve respring'i aynı komutta çalıştırma.**
  `dpkg -i … ; (nohup sbreload &)` bir kez kurulumun hiç
  gerçekleşmemesine yol açtı (sürüm eski kaldı). Ayrı çalıştır ve
  `dpkg -i` çıktısının **tamamını** oku — `grep Setting` hatayı gizler.

---

## 11. Yayın (kendi Sileo deponu kurma)

Depo düz bir statik site: `debs/`, `Packages`, `Release`, depiction
dosyaları. GitHub Pages yeter.

- `control` alanları: `Package`, `Name`, `Version`, `Architecture`,
  `Depends`, `Section`, `Description` + depo için `Icon`, `Depiction`,
  `SileoDepiction`, `Homepage`. Son dördü yoksa **Sileo ikonu ve
  açıklamayı hiç göstermez.**
- `Packages` üretirken dikkat: `dpkg-scanpackages` **bilinmeyen alanları
  atar** ve `SileoDepiction` sessizce kaybolur; Sileo yerel depiction
  yerine HTML'e düşer, sebebi hiçbir yere yazılmaz. Alanları koruyan bir
  üretici kullan ve üretimden sonra alan sayısını **denetle**.
- Banner 1200×400; Sileo kenarlardan kırpıyor, içeriği **%15 içeride**
  tut. İkon köşeleri **saydam ve yuvarlak** olmalı: Sileo yuvarlıyor,
  Ayarlar yuvarlamıyor.
- Depoyu yayınlamak paketi test etmek değildir. Yükledikten sonra
  Sileo'da **gözünle gör**.

---

## 12. Bilinen duvarlar — tek tablo

| Belirti | Sebep | Çare |
|---|---|---|
| Kurulumdan sonra safe mode | İmzasız private çağrı · caps 0x00 + tetikleyici + oldabi yok | İmzayı ölç · caps'i ölç |
| Ayar kaydolmuyor / geri dönüyor | İki yazıcı, cfprefsd önbelleği | Tek yazıcı |
| Ayarlar sayfası boş / çöküyor | `specifiers` boş · detay sınıfı `PSViewController` değil · yanlış `validValues` | İlgili maddeyi düzelt |
| View gizlendi, yerinde boşluk | Alan veriden bağımsız ayrılıyor | Veriyi süz |
| Animasyon saçmalıyor | Özellik sistemin, her karede geri yazılıyor | Snapshot kopyası |
| İlk açılışta tek seferlik titreme | View görünür doğuyor | Kapalı doğsun |
| Yatayda düzen bozuk | Pencere dönmüyor, safeArea dikey | İçerik boyutundan yön oku |
| Hook kurulu, hiçbir şey olmuyor | O metot çağrılmıyor | İlk çağrıyı logla, zinciri ölç |
| Kurduğum sürüm eski davranıyor | Derleme başarısız, eski deb | `dm.pl` satırı + `LC_UUID` |
| Yazdığım dosya yok | RootHide namespace | `/rootfs/...` |
| Sileo'da paket var, ikon/açıklama yok | control alanları veya indeks üreticisi | Alanları ekle, denetle |

---

## 13. Son söz

Bu rehberdeki her madde bir turun bedeliyle öğrenildi. En pahalı üç ders:

1. **Tahmin, ölçümün yerini tutmaz.** İkili karşılaştırma "ne değişmiş"i
   verir, "neden bozuldu"yu vermez.
2. **Sessizlik veri değildir.** Loglanmayan bir karar, olmamış bir
   ölçümdür.
3. **İki turda çözülmeyen şey üçüncüde de çözülmez.** Dur, ölçtüğünü
   yaz, yön değiştir.
