// Prefs ornegi — TWEAK TARAFI
//
// Ayarlar sayfasi ne yazarsa yazsin, tweak onu OKUMUYORSA is bitmez.
// Bu dosya o baglantiyi gosterir: AYNI alan + Darwin bildirimi.

#import <UIKit/UIKit.h>
#import <notify.h>

static NSString * const kAlan     = @"com.ornek.tweak";
static NSString * const kBildirim = @"com.ornek.tweak/prefs-changed";

static BOOL      gEtkin = YES;
static CGFloat   gHiz   = 1.0;
static NSString *gBoyut = @"orta";
static NSArray  *gSecilen = nil;

static void oku(void) {
    // ★ AYNI ALAN. Prefs 'defaults = com.ornek.tweak' yaziyor; burada
    // baska bir ad kullanirsan ayar kaydolur ama tweak gormez -
    // "kaydetmiyor" diye saatler harcanir.
    CFPreferencesAppSynchronize((__bridge CFStringRef)kAlan);

    id v;
    v = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("etkin"),
            (__bridge CFStringRef)kAlan);
    gEtkin = v ? [v boolValue] : YES;

    v = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("animasyonHizi"),
            (__bridge CFStringRef)kAlan);
    gHiz = v ? [v doubleValue] : 1.0;

    v = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("butonBoyutu"),
            (__bridge CFStringRef)kAlan);
    gBoyut = [v isKindOfClass:[NSString class]] ? v : @"orta";

    v = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("secilenler"),
            (__bridge CFStringRef)kAlan);
    gSecilen = [v isKindOfClass:[NSArray class]] ? v : @[];
}

%ctor {
    oku();
    // ★ Bildirim olmazsa: kullanici ayari degistirir, tweak respring'e
    // kadar eski degerle calisir ve "ayar calismiyor" sanilir.
    int token;
    notify_register_dispatch([kBildirim UTF8String], &token,
                             dispatch_get_main_queue(),
                             ^(int t) { (void)t; oku(); });
    (void)gEtkin; (void)gHiz; (void)gBoyut; (void)gSecilen;
}
