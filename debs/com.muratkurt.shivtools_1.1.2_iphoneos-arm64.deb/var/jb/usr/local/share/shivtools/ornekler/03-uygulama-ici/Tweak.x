// Uygulama ici tweak — AG KATMANINDA JSON SUZME
//
// DolapClean (Dolap 4.134.0, Swift/SwiftUI) oturumunda OLCULDU.
//
// NEDEN GORUNUM DEGIL AG: SwiftUI listesinde bir hucreyi gizlemek
// yerinde BOSLUK birakiyor; tanitimlar sunucu listesinde ayri bir
// 'type' ile geliyor. Veriden silinen ogenin bolumu ekranda HIC
// cizilmiyor (olculdu: products=[] donen bolum hic dogmadi).
//
// SIRA: once DEGISTIRMEDEN kaydet (bir olcum turu), yapiyi ogren,
// beklenen sonucu Mac'te hesapla, SONRA suz ve sayilari karsilastir.

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <sys/time.h>

// ── Gunluk: uygulama sandbox'i /var/mobile/tw'ye YAZAMAZ (olculdu).
// NSTemporaryDirectory() kullanilir; kabuktan okumak icin:
//   /rootfs/var/mobile/Containers/Data/Application/<UUID>/tmp/
static void uLog(NSString *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    NSString *m = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    struct timeval tv; gettimeofday(&tv, NULL);
    struct tm tm; localtime_r(&tv.tv_sec, &tm);
    char ts[16];
    snprintf(ts, sizeof ts, "%02d:%02d:%02d.%03d",
             tm.tm_hour, tm.tm_min, tm.tm_sec, (int)(tv.tv_usec / 1000));
    NSString *yol = [NSTemporaryDirectory() stringByAppendingPathComponent:@"ornek-log.txt"];
    FILE *f = fopen(yol.UTF8String, "a");
    if (f) { fprintf(f, "%s %s\n", ts, m.UTF8String); fclose(f); }
}

// ── 1. HANGI ISTEK BIZIM?
// Yol parcasiyla esle. Uygulama guncellenince uc nokta degisebilir;
// eslesmezse tweak hicbir sey yapmaz (sessizce guvenli).
static BOOL hedefMi(NSURLSessionTask *t) {
    NSString *p = t.originalRequest.URL.path ?: @"";
    return [p containsString:@"/pages/HomePage/inventories/"] ||
           [p containsString:@"/seller-home-page/"];
}

// ── 2. OLCUM MODU
// Ilk turda YANITA DOKUNMA, yalnizca kopyasini yaz. Yapi ogrenilince
// kapatilir ama kod DURUR: bir sonraki uc nokta icin yeniden acilir.
static BOOL const kOlcumModu = NO;

static void olcumYaz(NSURLSessionTask *t, NSData *veri) {
    static int n = 0;
    NSString *p = t.originalRequest.URL.path ?: @"";
    NSString *ad = [NSString stringWithFormat:@"kayit-%02d%@.json", ++n,
                    [p stringByReplacingOccurrencesOfString:@"/" withString:@"_"]];
    [veri writeToFile:[NSTemporaryDirectory() stringByAppendingPathComponent:ad]
           atomically:YES];
    uLog(@"kayit %@ %lu bayt", p, (unsigned long)veri.length);
}

// ── 3. SUZGEC
// BEYAZ LISTE: yalniz gercek icerik ('type' == PRODUCT) kalir.
// Yeni bir tanitim turu eklenirse kendiliginden duser - kara liste
// bunu yapmaz. ISLEVSEL sayfalarda (hesap, siparis) tersi dogrudur:
// orada yalniz tanitim turlerini sil, gerisine dokunma.
//
// Kimlik alani yoksa METINLE ayir: sponsorlu urunun rozetinde kimlik
// yoktu, yalniz baslik metni vardi (olculdu).
static BOOL sponsorluMu(NSDictionary *oge) {
    id rozetler = [[[oge objectForKey:@"content"] valueForKey:@"productImage"]
                    valueForKey:@"bottomLeftBadges"];
    if (![rozetler isKindOfClass:[NSArray class]]) return NO;
    for (id r in rozetler) {
        id t = [r isKindOfClass:[NSDictionary class]] ? r[@"title"] : nil;
        if ([t isKindOfClass:[NSString class]] &&
            [t rangeOfString:@"sponsor" options:NSCaseInsensitiveSearch].location != NSNotFound)
            return YES;
    }
    return NO;
}

static NSData *suz(NSData *veri, NSString *yol) {
    @try {
        NSMutableDictionary *kok = [NSJSONSerialization
            JSONObjectWithData:veri
                       options:NSJSONReadingMutableContainers error:nil];
        if (![kok isKindOfClass:[NSDictionary class]]) return veri;   // ★ orijinal
        NSArray *bilesenler = kok[@"components"];
        if (![bilesenler isKindOfClass:[NSArray class]]) return veri; // ★ orijinal

        NSMutableArray *kalan = [NSMutableArray array];
        NSUInteger sponsor = 0;
        for (id o in bilesenler) {
            if (![o isKindOfClass:[NSDictionary class]]) continue;
            if (![o[@"type"] isEqual:@"PRODUCT"]) continue;           // beyaz liste
            if (sponsorluMu(o)) { sponsor++; continue; }
            [kalan addObject:o];
        }
        kok[@"components"] = kalan;
        NSData *yeni = [NSJSONSerialization dataWithJSONObject:kok options:0 error:nil];
        // ★ SAYIYI YAZ: dogrulama "ekran temiz gorunuyor" degil, Mac'te
        // onceden hesaplanan sayiyla BIREBIR tutmasidir.
        uLog(@"suzuldu %@: %lu -> %lu (sponsorlu %lu)", yol,
             (unsigned long)bilesenler.count, (unsigned long)kalan.count,
             (unsigned long)sponsor);
        return yeni ?: veri;
    } @catch (__unused NSException *e) {
        uLog(@"suz hata - orijinal gonderildi");
        return veri;                                                  // ★ orijinal
    }
}

// ── 4. TAMPON
// Yanit PARCALAR halinde gelir; tamami olmadan JSON cozulemez.
// Gorev basina tampon: NSMapTable weakToStrong - gorev serbest
// kalinca tampon da duser. Erisim @synchronized ile korunur.
static NSMapTable<NSURLSessionTask *, NSMutableData *> *tampon(void) {
    static NSMapTable *t;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ t = [NSMapTable weakToStrongObjectsMapTable]; });
    return t;
}
static BOOL gGecis;   // YES: kendi cagirdigimiz didReceiveData - dokunma

%group GAg
%hook ORNEK_DELEGE          // ornegin Alamofire.SessionDelegate

// v40@0:8@16@24@32 — imza CALISAN surecten okundu, tahmin degil.
- (void)URLSession:(NSURLSession *)s
          dataTask:(NSURLSessionDataTask *)t
    didReceiveData:(NSData *)d {
    if (!gGecis && hedefMi(t)) {
        @synchronized (tampon()) {
            NSMutableData *m = [tampon() objectForKey:t];
            if (!m) { m = [NSMutableData data]; [tampon() setObject:m forKey:t]; }
            [m appendData:d];
        }
        return;                 // ★ ILETME: tamamlaninca suzulmus hali gidecek
    }
    %orig;
}

- (void)URLSession:(NSURLSession *)s
              task:(NSURLSessionTask *)t
didCompleteWithError:(NSError *)e {
    NSMutableData *m = nil;
    @synchronized (tampon()) {
        m = [tampon() objectForKey:t];
        [tampon() removeObjectForKey:t];
    }
    if (m && [t isKindOfClass:[NSURLSessionDataTask class]]) {
        if (kOlcumModu) olcumYaz(t, m);
        // Hata varsa DOKUNMA: orijinali ver.
        NSData *ver = e ? m : suz(m, t.originalRequest.URL.path ?: @"?");
        gGecis = YES;           // ★ kendi cagrimiz hook'a takilmasin
        @try {
            [self URLSession:s dataTask:(NSURLSessionDataTask *)t didReceiveData:ver];
        } @catch (__unused NSException *x) { uLog(@"iletim hata"); }
        gGecis = NO;
    }
    %orig;
}

%end
%end

%ctor {
    uLog(@"--- ornek tweak yuklendi");
    // ★ Swift siniflari MODUL onekiyle kayitli ve Logos'ta dogrudan
    // yazilamaz: takma ad + objc_getClass. Sinif yoksa %init CAGRILMAZ,
    // yani nil sinifa hook kurulmaz (cokme riski yok) ve gunlukte
    // sebebi yazar.
    Class c = objc_getClass("Alamofire.SessionDelegate");
    if (c) { %init(GAg, ORNEK_DELEGE = c); uLog(@"kuruldu Alamofire.SessionDelegate"); }
    else    { uLog(@"YOK Alamofire.SessionDelegate"); }
}
