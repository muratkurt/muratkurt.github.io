// OKKurulumController — CANLI kurulum ekrani (ISKELET).
//
// NE OKUR (hicbirini kendisi URETMEZ):
//   ornek-kurd.log    root yardimcinin ham gunlugu
//   ornek-kur.json    motorun adim adim durumu
//
// Detay sinifi PSViewController soyundan olmak ZORUNDA: duz bir
// UIViewController push edilirse Ayarlar 'setRootController:'
// cagrisinda coker.

#import <Preferences/PSViewController.h>
#import <UIKit/UIKit.h>

@interface OKKurulumController : PSViewController
@end
