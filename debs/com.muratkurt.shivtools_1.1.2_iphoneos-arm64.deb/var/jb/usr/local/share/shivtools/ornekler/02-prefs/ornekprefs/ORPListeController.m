#import "ORPListeController.h"
#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import <notify.h>

// ALT SAYFA — dinamik liste (KASwitcher "Korunanlar" deseni)
//
// Kurallar (hepsi bir kez kirildi):
//  1. PSViewController SOYUNDAN olmak ZORUNDA. Duz UIViewController
//     verirsen Ayarlar 'setRootController:' ile coker.
//  2. 'specifiers' GERCEK BIR DIZI dondurmeli. Bos/nil ->
//     NSRangeException.
//  3. Dinamik satirlari STOK yoldan kur: PSSpecifier uret,
//     reloadSpecifiers ile tazele. Kendi UITableView'ini KURMA.
//  4. Yazdigin her degeri tweak'in okudugu ALANA yaz ve bildirim at.

static NSString * const kAlan     = @"com.ornek.tweak";
static NSString * const kBildirim = @"com.ornek.tweak/prefs-changed";
static NSString * const kAnahtar  = @"secilenler";   // NSArray<NSString *>

// Uygulama listesi icin private API. Baslikta yok, bu yuzden
// bildirimi burada yaziyoruz - imzalar SDK'da degil, calisan surecten
// dogrulanmis hallerdir.
@interface LSApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (NSArray *)allInstalledApplications;
@end
@interface LSApplicationProxy : NSObject
- (NSString *)localizedName;
- (NSString *)applicationIdentifier;
- (NSString *)applicationType;
@end

@interface ORPListeController () {
    NSMutableArray<NSString *> *_secilen;
    NSArray<LSApplicationProxy *> *_uygulamalar;
}
@end

@implementation ORPListeController

- (NSArray<NSString *> *)_secilenleriOku {
    id v = (__bridge_transfer id)CFPreferencesCopyAppValue(
        (__bridge CFStringRef)kAnahtar, (__bridge CFStringRef)kAlan);
    return [v isKindOfClass:[NSArray class]] ? v : @[];
}

- (void)_secilenleriYaz {
    CFPreferencesSetAppValue((__bridge CFStringRef)kAnahtar,
                             (__bridge CFPropertyListRef)_secilen,
                             (__bridge CFStringRef)kAlan);
    CFPreferencesAppSynchronize((__bridge CFStringRef)kAlan);
    notify_post([kBildirim UTF8String]);
}

- (instancetype)init {
    self = [super init];
    if (self) { _secilen = [[self _secilenleriOku] mutableCopy]; }
    return self;
}

// Sayfaya her donuste tazele: kullanici baska yerden degistirmis
// olabilir.
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _secilen = [[self _secilenleriOku] mutableCopy];
    [self reloadSpecifiers];
}

- (NSArray<LSApplicationProxy *> *)_uygulamalar {
    if (_uygulamalar) return _uygulamalar;
    NSMutableArray *l = [NSMutableArray array];
    for (LSApplicationProxy *p in [[LSApplicationWorkspace defaultWorkspace]
                                    allInstalledApplications]) {
        if (![[p applicationType] isEqualToString:@"User"]) continue;  // sistem uygulamalarini ele
        if ([p localizedName].length == 0) continue;
        [l addObject:p];
    }
    [l sortUsingComparator:^NSComparisonResult(LSApplicationProxy *a, LSApplicationProxy *b) {
        return [[a localizedName] localizedCaseInsensitiveCompare:[b localizedName]];
    }];
    _uygulamalar = l;
    return _uygulamalar;
}

- (NSArray *)specifiers {
    // Her cagrida YENIDEN kurulur: reloadSpecifiers bunu cagirir.
    NSMutableArray *s = [NSMutableArray array];

    PSSpecifier *baslik = [PSSpecifier preferenceSpecifierNamed:@"Seçilenler"
                                                         target:self
                                                            set:NULL
                                                            get:NULL
                                                         detail:Nil
                                                           cell:PSGroupCell
                                                           edit:Nil];
    [baslik setProperty:@"Dokunarak seçin. Seçim anında kaydedilir ve tweak'e bildirilir."
                 forKey:@"footerText"];
    [s addObject:baslik];

    for (LSApplicationProxy *p in [self _uygulamalar]) {
        NSString *bid = [p applicationIdentifier];
        PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:[p localizedName]
                                                         target:self
                                                            set:NULL
                                                            get:NULL
                                                         detail:Nil
                                                           cell:PSStaticTextCell   // ★ Link degil
                                                           edit:Nil];
        [sp setProperty:bid forKey:@"orpBid"];
        [sp setProperty:bid forKey:@"id"];
        // Lazy ikon: PSTableCell kendi yukler, biz UIImage kurmayiz.
        [sp setProperty:bid forKey:@"appIDForLazyIcon"];
        [sp setProperty:@YES forKey:@"useLazyIcons"];
        sp->action = @selector(_secimDegistir:);
        [s addObject:sp];
    }

    _specifiers = s;          // ★ gercek dizi; bos birakma
    return _specifiers;
}

// Onay isaretini hucre ciziminde uygula: specifier'da durum tutmak
// yerine kaynaktan (secilen listesi) oku - yeniden kullanilan hucre
// bayat durum tasimasin.
- (UITableViewCell *)tableView:(UITableView *)tv
         cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *c = [super tableView:tv cellForRowAtIndexPath:ip];
    NSString *bid = [[self specifierAtIndexPath:ip] propertyForKey:@"orpBid"];
    c.accessoryType = (bid && [_secilen containsObject:bid])
        ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    return c;
}

- (void)_secimDegistir:(PSSpecifier *)sp {
    NSString *bid = [sp propertyForKey:@"orpBid"];
    if (!bid) return;
    if ([_secilen containsObject:bid]) [_secilen removeObject:bid];
    else                               [_secilen addObject:bid];
    [self _secilenleriYaz];
    [self reloadSpecifiers];
}

@end
