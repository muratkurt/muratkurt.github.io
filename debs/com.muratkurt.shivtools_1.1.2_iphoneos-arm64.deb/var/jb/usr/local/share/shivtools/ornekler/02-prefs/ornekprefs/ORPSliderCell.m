#import "ORPSliderCell.h"

// SLIDER DEGER ETIKETI — KASwitcher'da OLCULEREK bulundu.
//
// Belirti: 'showValue = 1' ile gosterilen sayi 4 karakterde ("4.00")
// sag kenara carpip kirpiliyor.
//
// OLCUM (dosyaya loglayarak): PSSegmentableSlider'in TEK subview'i
// _UISlideriOSVisualElement; deger etiketi (UILabel) ONUN icinde,
// slider'in KENDI subview'i DEGIL. Yani asil alt gorunum IKI SEVIYE
// DERINDE - duzeltmeyi yanlis seviyeye uygularsan sessizce etkisiz
// kalir.
//
// Duzeltme: iki seviye tara, etiketi bul, SOLA dogru genislet
// (sag kenar SABIT kalir, yoksa slider'in disina tasar).
@implementation ORPSliderCell

- (void)orp_duzeltDegerEtiketi {
    UIView *slider = self.control;
    if (!slider) return;
    [slider layoutIfNeeded];

    UILabel *etiket = nil;
    for (UIView *sv in slider.subviews) {                 // 1. seviye
        if ([sv isKindOfClass:[UILabel class]]) { etiket = (UILabel *)sv; break; }
        for (UIView *sv2 in sv.subviews) {                // 2. seviye ★
            if ([sv2 isKindOfClass:[UILabel class]]) { etiket = (UILabel *)sv2; break; }
        }
        if (etiket) break;
    }
    if (!etiket) return;

    const CGFloat yeniGenislik = 34.0;                    // "4.00" icin pay
    CGRect ef = etiket.frame;
    if (ef.size.width >= yeniGenislik) return;            // yeterli - dokunma
    CGFloat sagKenar = ef.origin.x + ef.size.width;
    ef.origin.x   = sagKenar - yeniGenislik;              // sag kenar SABIT
    ef.size.width = yeniGenislik;
    etiket.frame = ef;
    etiket.textAlignment = NSTextAlignmentRight;
    etiket.backgroundColor = [UIColor clearColor];
    etiket.adjustsFontSizeToFitWidth = NO;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self orp_duzeltDegerEtiketi];
    // Control kendi ic layout'unu BU cagridan SONRA guncelleyebiliyor:
    // bir sonraki run-loop turunda tekrar dene. (Olculdu: ilk turda da
    // bulunuyor, ikinci kontrol emniyet.)
    dispatch_async(dispatch_get_main_queue(), ^{
        [self orp_duzeltDegerEtiketi];
    });
}

@end
