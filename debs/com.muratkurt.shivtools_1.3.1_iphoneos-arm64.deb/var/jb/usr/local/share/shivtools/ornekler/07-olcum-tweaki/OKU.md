# 07 — Ölçüm tweak'i iskeleti (YAYINLANMAZ)

Bir karar **Apple'ın** davranışına bağlıysa (Apple'ın kendi mekanizması işi
yapıyor mu, bir bayrak respring'den sağ çıkıyor mu) onu **ürün kaldırılmışken**,
bu küçük ayrı tweak'le ölç. Ürünün içinde ölçersen kendi süzgeçlerini Apple'ın
davranışıyla karışık ölçersin. KASwitcher 0.7'nin mimarisi böyle bir araçla
verildi (örnek 06, `olcum-tweaki/`). Reçete: `TWEAK.md` "A separate measuring tweak".

## Nasıl kullanılır

1. Kopyala, adları değiştir (`com.ornek.probe`, `OrnekProbe`, filtre), derle, kur, respring.
2. Komut yaz, günlüğü oku:

```
K=/var/mobile/Library/Caches            # RootHide kabuğunda: /rootfs/var/mobile/Library/Caches
echo "imza SBApplicationController runningApplications" > $K/ornekprobe-komut.txt
sleep 1; tail -5 $K/ornekprobe.txt
echo "durum" > $K/ornekprobe-komut.txt
```

| Komut | Ne yapar |
|---|---|
| `imza <Sınıf> <seçici>` | metodun varlığı + tip kodlaması (örnek ve sınıf metodu). **Çağırmaz.** Beklenen imzayı buradan al |
| `durum` | örnek salt-okur çağrı; her adım `imza()` ile korunur |
| *(senin `act`'in)* | `Tweak.m`'de işaretli yere: tek eylem, imza denetimli, öncesi/sonrası `durum` |

Tweak hiçbir şeye kendiliğinden dokunmaz; yalnız komut dosyası gelince çalışır,
dosyayı siler, sonucu yazar. İş bitince **kaldır**.

## Kurallar (kodun yorumlarında da)

- Her özel çağrı `imza()` ile: metot yoksa ya da tip kodlaması birebir tutmazsa
  çağrı yapılmaz, günlüğe `IMZA-TUTMADI` düşer. İmza tutması **gerekli ama yeterli
  değil** — yeni bir API'nin ilk çağrısı ürüne değil buraya.
- Kaynakta `@"…"` literali yok, sisteme blok verilmiyor (zamanlayıcı
  `dispatch_source_set_event_handler_f` ile fonksiyon alıyor), kendi ObjC sınıfı yok:
  kanun §7'nin üç tetikleyicisi de yok. Bunlardan birini eklersen cihaz derlemesi
  oldabi ister (kanun §7).
- Günlükte ilk iki satır `YUKLENDI` ve `SAGLAMA`; yoksa tweak hiç yüklenmemiştir,
  ölçüm geçersiz.

## Doğrulama

- Mac'te iki şema derlendi (4 Eki 2026): arm64 + arm64e, arm64e **caps 0x80**,
  `__cfstring` 0, `__objc_classlist` 0, `libroothide` yok.
- **Cihazda çalıştırıldı** (RootHide 15 Pro, iOS 17.0.3, Mac derlemesi, 4 Eki 2026):
  `YUKLENDI` + `SAGLAMA` satırları geldi; `imza SBApplicationController runningApplications`
  → `ornek=@16@0:8` (iskeletteki beklenen imzayla aynı), olmayan seçici → `-`;
  `durum` → imza denetiminden geçti, `calisan-uygulama=4`; bilinmeyen komut günlüğe
  düştü; her komuttan sonra komut dosyası silindi. Kaldırıldı, SpringBoard ayakta.
- **DOĞRULANMADI:** `IMZA-TUTMADI` dalı (bu cihazda beklenen imzalar tuttu); cihazda
  derlenen (caps 0x00) sürümün oldabi'siz çalışması — kanun §7'nin üç tetikleyicisinden
  çıkarım, ölçülmedi; rootless.
