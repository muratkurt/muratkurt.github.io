// KASwitcher 0.6.0 — gizli bolum: "ikinci switcher" (kasa).
//
// Neden ayri bir gorunum: ana switcher'in modelini "gizli mod"a cevirmek
// ise yaramadi (0.6.0~m2 olcumu): switcher kart listesini onbellekte
// tutuyor, mod degisince listeyi yeniden sormuyor (22 gecisten 2'si).
// Kasa switcher gorunumunun USTUNDE kendi kart seridini cizer; gizli
// uygulamalar orada durur. Dokununca uygulamaya gecilir, yukari atinca
// kapanir. Yalniz public UIKit.
//
// Kilit (m4): kasa ACILIR, icerik buyuk kilitle ortulu durur; panel
// yerine oturunca LAPolicyDeviceOwnerAuthentication istenir - Apple'in
// stok akisi: Face ID, sistem gerekli gorunce parola. Deneme sayaci
// sistemin; biz saymiyoruz. Ayarlar'da kapatilabilir (kasaKilit).
#import <UIKit/UIKit.h>

@interface KASKasaOge : NSObject
@property (nonatomic, copy) NSString *bid;
@property (nonatomic, copy) NSString *ad;
// Kartin son goruntusu: snapshotViewAfterScreenUpdates:NO KOPYASI (m3'te
// drawViewHierarchyInRect bos goruntu verdi - kart icerigi render
// sunucusunda). nil: yer tutucu (kilit + ad).
@property (nonatomic, strong) UIView *gorunum;
// b16: sabit (koru listesi) - kasada "Tumunu Kapat" dokunmaz, kartta igne rozeti.
@property (nonatomic) BOOL sabit;
@end

@interface KASKasa : NSObject
// v: switcher gorunumu. ac: karta dokunuldu. kapat: kart yukari atildi
// (uygulamayi kapat). kapaninca: kasa tamamen kapaninca bir kez.
// kilitli: YES ise icerik buyuk kilitle ortulu acilir; LAContext
// (Face ID, yoksa parola) basarili olunca kartlar gorunur. gunluk: tani
// satirlari (Tweak.x ka_logText).
+ (void)gosterIcinde:(UIView *)v
              ogeler:(NSArray<KASKasaOge *> *)ogeler
             kilitli:(BOOL)kilitli
                  ac:(void (^)(NSString *bid))ac
               kapat:(void (^)(NSString *bid))kapat
           kapaninca:(void (^)(void))kapaninca
              gunluk:(void (^)(NSString *satir))gunluk;
+ (void)kapat:(BOOL)animasyonlu;   // idempotent
+ (BOOL)acik;
// Dogrulama oturumu: bir kez kilit acilinca switcher kapanana kadar
// kasa yeniden sormaz. Switcher kapaninca (ka_butonGizle) oturumuKapat.
// m6: tema (Tweak.x kaPrefTema). "neon": siyah panel, isik kenarlari,
// parlayan kartlar/kilit. "cuzdan": kartlar dikey deste (Wallet gibi);
// dokunus one cikarir, ikinci dokunus acar, sola atis kapatir.
// Digerleri: varsayilan gorunum. gosterIcinde'den ONCE cagrilir.
+ (void)temaAyarla:(NSString *)tema;
+ (BOOL)dogrulandi;
// m5: Face ID/parola arayuzu acik (switcher bu sirada sistemce kapanir).
+ (BOOL)dogrulaniyor;
// m8: dogrulama sonuclaninca (basari ya da iptal; kasa hala aciksa) bir kez.
// Tweak.x burada arkada kapanmis switcher'i yeniden acar.
+ (void)dogrulamaBitince:(void (^)(BOOL ok))blok;
// m22: kasadaki kart asagi (cuzdan: saga) atildi - uygulama gizli bolumden
// cikarilsin (Tweak.x tercihten siler, switcher'a geri doner).
+ (void)gizlidenCikarinca:(void (^)(NSString *bid))blok;
+ (void)oturumuKapat;
@end
