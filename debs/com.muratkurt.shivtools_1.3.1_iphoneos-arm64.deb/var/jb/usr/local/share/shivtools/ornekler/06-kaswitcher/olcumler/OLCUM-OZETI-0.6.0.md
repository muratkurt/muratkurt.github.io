# KASwitcher 0.6.0 — ölçüm özeti (m1 → m25)

Cihaz: iPhone 15 Pro (iPhone16,1) · iOS 17.0.3 (21A360) · RootHide · 2 Ekim 2026.
Kaynak: `/var/mobile/tw/kas-log.txt` (kabuktan `/rootfs/private/var/mobile/tw/kas-log.txt`),
`shiv-sinif --tip` imza dökümleri (`belgeler/imza-dokumu-*.txt`).

Etiketler: **ÖLÇÜLDÜ** = cihazda günlükle/araçla görüldü. **DOĞRULANMADI** = çıkarım.

---

## 1. Switcher kartının iç yapısı (ÖLÇÜLDÜ, m16 ağaç dökümü)

```
SBReusableSnapshotItemContainer        393x852   (kart kabı — sistemin transform/alpha'sı)
└ _SBFActualClippingView               393x852
  └ SBFluidSwitcherTouchPassThroughScrollView 393x1278 @ y=-426   ← YUKARI ATARAK KAPATMA BUNU KAYDIRIR
    └ SBAppSwitcherPageView            393x852 @ y=426
      ├ SBAppSwitcherPageShadowView
      └ UIView
        ├ SBHitTestExtendedView        138x852  clipsToBounds=1   ← ÖRTÜŞME KIRPMASI
        └ UIView                       138x852  clipsToBounds=1
          └ SBAppSwitcherReusableSnapshotView 393x852   ← asıl görüntü
        (+ SBWallpaperEffectView / PBUIFakeBlurView / PBUIWallpaperView)
```

- **Örtüşme kırpması (ÖLÇÜLDÜ):** bir sonraki kartın altında kalan kısım 5. seviyedeki
  138 pt'lik görünümlerle kesiliyor. Kart basılı tutulunca ("kalkınca") kırpma genişliyor
  (kullanıcı gözlemi). Kaptan alınan kopya bu yüzden YARIM çıkıyordu (m15–m16).
- **Kart kabı uygulamanın kendisi olur (ÖLÇÜLDÜ, m21):** switcher'dan uygulamaya geçerken
  aynı kap büyütülüp uygulama olarak kullanılıyor. Kaba eklenen görünüm (kilit örtüsü)
  açılan uygulamanın önünde kaldı → **kart kabına kalıcı görünüm EKLEME.**
- **Kartı ortasında gizlemek switcher'ı kilitler (ÖLÇÜLDÜ, m15→m16):** dokunma sürerken
  `hidden=YES` → sonra boşluğa basınca ana ekrana dönmüyor. Maske/kopya/hidden kalktıktan
  sonra (m18) sorun bitti.
- **Kartın transform'u ve alpha'sı SİSTEMİN** (0.5.0 ölçümü, CLAUDE.md) — hâlâ geçerli.

## 2. Kartlardaki hareket tanıyıcılar (ÖLÇÜLDÜ, m19)

`UIScrollViewPanGestureRecognizer`, `UIScrollViewDelayedTouchesBeganGestureRecognizer`,
`UIScrollViewPagingSwipeGestureRecognizer`, `_UIDragLiftGestureRecognizer`,
`_UIRelationshipGestureRecognizer`, `UILongPressGestureRecognizer`,
`SBFailureNotifyingTapGestureRecognizer`, `UITapGestureRecognizer`.

## 3. Aşağı atarak gizleme — son durum (m21–m25)

- **Kartı STOK kaydırma taşır** (ÖLÇÜLDÜ, m21): kartın kaydırma görünümü aşağı yönü
  zaten destekliyor (kullanıcı: yukarı başlayınca stok aşağı da götürüyor). Bizim
  `UIPanGestureRecognizer`'ımız **eşzamanlı** (simultaneous) yalnız izler; konum YAZMAZ.
- m14–m20'de aşağıyı biz sürüyorduk + stoku bekletiyorduk → ilk anda sıçrama, titreşim.
- Bırakışta karar kartın gerçek inişine göre: `inis > 50` ya da `hiz > 800 && inis > 12`.
  Ölçülen atışlar: iniş 95–210 pt, hız 520–2252 (hepsi `at=1`); yukarı/az çekişler `at=0`.
- Gönderim animasyonu m24'ten beri `setContentOffset:animated:YES` (stok eğri).
  Kullanıcı: "hâlâ sert, değişiklik görmedim" — sertliğin kaynağı ÖLÇÜLMEDİ
  (hareket mi, kartın listeden kalkış anı mı).

## 4. Öndeki uygulamanın kartı — AÇIK SORUN

- **ÖLÇÜLDÜ (m23):** atma anında yoklamanın "öndeki uygulama"sı:
  - ana ekrandan açılıp switcher'a geçildiyse `appOnPlanda=0` → kart gider;
  - switcher'dan açılıp tekrar switcher'a geçildiyse `appOnPlanda=1 bid=<o uygulama>` → kart kalır.
- **ÖLÇÜLDÜ (m24):** süzgeç o uygulamayı listeden ÇIKARIYOR (`suzulmus` 12 → 11) ama
  kart ekranda kalıyor → **switcher öndeki uygulamanın kartını recents listesinden değil
  başka bir kaynaktan gösteriyor.** Süzgeçteki "öndeki gizli uygulamayı göster" istisnasını
  kaldırmak (m24 `kaAtilanlar`) sonucu değiştirmedi.
- **ÖLÇÜLDÜ (m25):** kartı ekran dışında bırakmak da tutmadı; kart bir süre sonra yine
  yukarı dönüyor (sistem yeniden yerleştirirken ofseti sıfırlıyor — DOĞRULANMADI).
- Kartı silmek = uygulamayı kapatmak (kasadan da düşer) → bu yol istenmiyor.
- **Sonraki ölçüm önerisi:** öndeki kartın kaynağı. Adaylar (DOĞRULANMADI):
  `SBMainSwitcherControllerCoordinator` `_appLayouts` ivar'ı, `SBAppSwitcherModel`,
  layout state'teki "active app layout". `appLayoutsIncludingHiddenAppLayouts:NO` model
  sayısı ile görünen kart sayısını öndeki uygulama varken/yokken karşılaştır.

## 5. Gizli durumun sahibi (ActionButtonFix §4b) — m23 ölçümü

| Ölçüm | Sonuç |
|---|---|
| `-[SBApplication hasHiddenTag]` kim okuyor | **30/30 çağrı `SpringBoardHome`** (simge modeli). Kancalarsak **simgeler de kaybolur** → YOL KAPALI |
| `_acquireAllowHiddenAppAssertionForBundleIdentifier:reason:` | **0 çağrı** — "geri gelme"yi iOS'un kilidi yapmıyor |
| `_setRecents:notifyForChangeDescription:` | 25 çağrı — listenin gözlemcilere yayın yolu (stok) |
| `applicationRestrictionController:didUpdateVisibleTags:hiddenTags:` | 1 çağrı |
| `_ignoresAppHiddenForDisplayItem:` | m2'de 0 çağrı |
| `recentsIncludingHiddenAppLayouts:` NO/YES | m2: 36/39 — iOS 3 uygulamayı kendisi gizliyor |
| `_rebuildAppListCache` + `_notifySwitcherControllersAppLayoutsDidChange` | liste yeniden sorgulanıyor ama öndeki kart kalıyor |

## 6. Buton titremesi (ÇÖZÜLDÜ, m23) ve kasanın kendiliğinden kapanması (AÇIK)

- **ÖLÇÜLDÜ (m22):** öndeki uygulamanın kartı silinince (`deletedDisplayItem`, sebep=1)
  SpringBoard ~5 ms sonra `yon=bos-layout gesture=0` geçiş istiyor; switcher AÇIK kalıyor
  (`isAnySwitcherVisible=1`). Kanca bunu ana ekrana dönüş sanıp butonları gizliyordu.
  m23: öndeki kart silindikten sonra 400 ms içindeki `gesture=0` istek yok sayılıyor.
- **ÖLÇÜLDÜ (m25, satır 2849):** kasadan öndeki uygulamayı yukarı atınca biz
  `_deleteAppLayoutsMatchingBundleIdentifier:` ile siliyoruz → **`deletedDisplayItem`
  ÇAĞRILMIYOR** → 400 ms penceresi açılmıyor → `bos-layout` → `ka_butonGizle` → kasa da
  kapanıyor (`kasa-kapandi gizlenirken=1`).
  **Düzeltme (UYGULANMADI):** `ka_birTaneSil` içinde, `bid` öndeki uygulamaysa
  `kaOndeSilmeMs = ka_msNow();`.

## 7. Face ID (m4–m11) — açık iş, geçici çare yayında

- Face ID SpringBoard içinde çalışıyor (`bio=1 tip=2`), Info.plist'te NSFaceIDUsageDescription yok.
- Doğrulama sırasında switcher KAPANMIYOR; penceresi geçici gizleniyor (m10: kapatma yolları
  çağrılmadı; `activateMainSwitcherNoninteractivelyWithSource:0` 10/10 `sonuc=0`).
- Çare (m11): ekranın donmuş görüntüsü kasa penceresinin altına (`UIScreen snapshotView…`).

## 8. Görüntü yakalama

- `drawViewHierarchyInRect` kart için BOŞ (m3). `snapshotViewAfterScreenUpdates:NO` çalışıyor.
- Öndeki kart: `SBAppSwitcherPageView` kopyası dolu (m21+). `SBAppSwitcherReusableSnapshotView`
  yeniden açılan uygulamada BOŞ (m19 öncesi).
- Aşağı atmada kasa görüntüsü: `SBAppSwitcherReusableSnapshotView` (kırpmanın içi) — tam.

## 9. Diğer

- Panik 2 Eki 18:50: `AMCC PLANE0 Unexpected RT traffic`, süreç `heard` — tweak'le ilgisiz
  görünüyor (kullanıcı alanı bunu üretemez). 27 Eyl'de de panik var.
- shivtools 1.3.0'dan (1 Eki 19:41) beri SpringBoard/frida çökmesi YOK.
