// AppTrackerBlock icon — PNGs for the Settings list row and the page header.
// Run: cd Prefs && node draw-icon.mjs
// Drawing: Settings-style rounded square (indigo), white shield, indigo
// check mark. 4x4 supersampling for smooth edges. No dependencies.
import fs from 'fs';
import zlib from 'zlib';

const INDIGO = [88, 86, 214];          // systemIndigo
const WHITE = [255, 255, 255];

// Shield: top edge + two curved sides (quadratic bezier samples)
function shield() {
  const p = [[0.50, 0.17], [0.78, 0.27]];
  const bez = (a, c, b, t) => [(1-t)*(1-t)*a[0] + 2*(1-t)*t*c[0] + t*t*b[0], (1-t)*(1-t)*a[1] + 2*(1-t)*t*c[1] + t*t*b[1]];
  for (let i = 1; i <= 24; i++) p.push(bez([0.78, 0.27], [0.78, 0.66], [0.50, 0.85], i / 24));
  for (let i = 1; i <= 24; i++) p.push(bez([0.50, 0.85], [0.22, 0.66], [0.22, 0.27], i / 24));
  return p;
}
const SHIELD = shield();
const inside = (x, y, poly) => {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c;
  }
  return c;
};
const segmentDistance = (x, y, a, b) => {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / (dx * dx + dy * dy)));
  return Math.hypot(x - a[0] - t * dx, y - a[1] - t * dy);
};
const CHECK = [[0.375, 0.505], [0.465, 0.600], [0.635, 0.405]];

// Rounded-square mask (Settings icon: radius ~22%)
function inRoundedSquare(x, y, r) {
  const cx = Math.min(Math.max(x, r), 1 - r), cy = Math.min(Math.max(y, r), 1 - r);
  return Math.hypot(x - cx, y - cy) <= r;
}

function draw(px, rounded) {
  const S = 4, data = Buffer.alloc(px * px * 4);
  for (let y = 0; y < px; y++) for (let x = 0; x < px; x++) {
    let a = 0, r = 0, g = 0, b = 0;
    for (let sy = 0; sy < S; sy++) for (let sx = 0; sx < S; sx++) {
      const u = (x + (sx + 0.5) / S) / px, v = (y + (sy + 0.5) / S) / px;
      if (rounded && !inRoundedSquare(u, v, 0.225)) continue;
      let c = INDIGO;
      if (inside(u, v, SHIELD)) {
        c = WHITE;
        if (segmentDistance(u, v, CHECK[0], CHECK[1]) < 0.045 || segmentDistance(u, v, CHECK[1], CHECK[2]) < 0.045) c = INDIGO;
      }
      a++; r += c[0]; g += c[1]; b += c[2];
    }
    const o = (y * px + x) * 4;
    if (a) { data[o] = r / a; data[o+1] = g / a; data[o+2] = b / a; }
    data[o+3] = Math.round(255 * a / (S * S));
  }
  return data;
}

const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c; });
const crc32 = buf => { let c = -1; for (const x of buf) c = CRC[(c ^ x) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
const chunk = (type, d) => {
  const len = Buffer.alloc(4); len.writeUInt32BE(d.length);
  const t = Buffer.concat([Buffer.from(type), d]);
  const c = Buffer.alloc(4); c.writeUInt32BE(crc32(t));
  return Buffer.concat([len, t, c]);
};
function png(px, rgba) {
  const raw = Buffer.alloc(px * (px * 4 + 1));
  for (let y = 0; y < px; y++) { raw[y * (px * 4 + 1)] = 0; rgba.copy(raw, y * (px * 4 + 1) + 1, y * px * 4, (y + 1) * px * 4); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(px, 0); ihdr.writeUInt32BE(px, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr),
                        chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

// Settings row (29 pt): the system does not mask it, so the corners are cut here.
// Header (72 pt): corners are cut in code (continuous curve), so draw a square.
const outputs = [['icon.png', 29, true], ['icon@2x.png', 58, true], ['icon@3x.png', 87, true],
                 ['header@2x.png', 144, false], ['header@3x.png', 216, false]];
for (const [name, px, rounded] of outputs) {
  fs.writeFileSync('Resources/' + name, png(px, draw(px, rounded)));
  console.log(name, px + 'px', fs.statSync('Resources/' + name).size, 'bytes');
}
