// AppTrackerBlock — definitions shared by the tweak, the prefs bundle and tools.
//
// No @"..." literals anywhere in this project: the tweak is also injected
// into arm64e processes (Safari) and the prefs bundle runs inside Settings
// (arm64e). A device-built arm64e binary has caps 0x00; a constant
// NSString in it crashes on devices without oldabi.
#pragma once

#define ATB_DOMAIN        "com.muratkurt.apptrackerblock"
#define ATB_NOTIFY        "com.muratkurt.apptrackerblock/prefs-changed"
#define ATB_PREFS_PATH    "/var/mobile/Library/Preferences/com.muratkurt.apptrackerblock.plist"
#define ATB_BLOCKLIST     "/var/mobile/Library/AppTrackerBlock/hagezi-pro.bin"   // under the jailbreak root
#define ATB_COMPANIES     "/Library/AppTrackerBlock/companies.tsv"               // under the jailbreak root
#define ATB_BLOCKED_LOG   "Library/Caches/AppTrackerBlock-blocked.log"           // relative to the app's $HOME
#define ATB_DEBUG_LOG     "AppTrackerBlock-debug.log"                            // in the app's tmp dir

#define ATB_KEY_LOGGING   "logging"               // BOOL, default NO  (developer log)
#define ATB_KEY_BLOCKING  "blocking"              // BOOL, default YES
#define ATB_KEY_EXCLUDED  "excluded"              // NSArray<NSString *>; absent = default list
#define ATB_KEY_NOBLOCK   "blockingDisabledApps"  // NSArray<NSString *>; logging continues there

// Apps the tweak never hooks unless the user edits the list. Used when
// the 'excluded' key has never been written. Banking, payment and
// crypto apps found installed on the development device (measured with
// list_apps, 1 Oct 2026), plus Apple Wallet.
static const char *const kATBDefaultExcluded[] = {
    "com.pozitron.YKB",
    "com.vakifbank.mobil",
    "com.Mobinex.Akbank-Direkt",
    "com.denizbank.mobildeniz",
    "com.ziraatbank.ZiraatMobile",
    "com.upt.money.transfer.prod",
    "com.moneytolia.wallet",
    "com.haremaltin.HaremAltin",
    "com.vizyoneks.KatilimEmeklilikCep",
    "com.apple.Passbook",
    0
};

// Safety net: if the lowercased bundle id contains any of these, the app
// is never hooked, whatever the list says. ("enpara" covers Enpara, whose
// bundle id was not available to verify.)
static const char *const kATBExcludedFragments[] = {
    "bank", "banka", "wallet", "passbook", "enpara", "finans",
    "crypto", "kripto", "coin", "binance", "borsa", "paypal",
    0
};
