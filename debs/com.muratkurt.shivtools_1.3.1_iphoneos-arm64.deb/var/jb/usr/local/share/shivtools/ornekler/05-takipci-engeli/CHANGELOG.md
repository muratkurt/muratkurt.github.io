# AppTrackerBlock — Changelog

## 1.0.0

İlk sürüm (geliştirme adı izci 0.1.0 → 0.3.0).

**Özellikler**
- Uygulamaların içinden izleme alan adlarına giden istekleri engeller (HaGeZi Multi PRO, ~231.000 alan)
- Engellenen istek uygulamada temiz bir hatayla sonuçlanır; uygulama çökmez
- Ayarlar'da "Son 7 gün" raporu: toplam engel, uygulama sayısı, uygulama ve şirket bazında döküm
- Şirket adları DuckDuckGo Tracker Blocklists ve Disconnect'ten (CC BY-NC-SA 4.0)
- Banka, ödeme ve kripto uygulamaları varsayılan olarak hariç; liste düzenlenebilir
- "Engellenmeyen uygulamalar": izleyici engellenince bozulan uygulamalar için
- `atb-update`: listeyi tek komutla indirip derler
- Ayarlar sayfası 12 dilde: İngilizce, Türkçe, Almanca, Fransızca, İspanyolca, İtalyanca, Portekizce, Rusça, Japonca, Çince, Korece, Arapça
- RootHide ve rootless

**Bilinen sınırlar**
- Safari ve uygulama içi web sayfaları kapsanmaz
- Liste kendiliğinden güncellenmez (`atb-update`)
