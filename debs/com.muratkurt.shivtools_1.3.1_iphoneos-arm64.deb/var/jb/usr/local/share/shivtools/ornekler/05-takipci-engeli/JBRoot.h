// AppTrackerBlock — jbroot() for every package scheme.
//
// RootHide: the real libroothide (the jailbreak root moves on every
// re-jailbreak, so it is resolved at run time).
// Rootless / rootful: the stock theos has no roothide.h, so jbroot() just
// prepends the install prefix passed by the Makefile (/var/jb or "").
#pragma once

#ifdef THEOS_PACKAGE_SCHEME_ROOTHIDE
#include <roothide.h>
#else
#include <stdio.h>
#ifndef ATB_JB_PREFIX
#define ATB_JB_PREFIX ""
#endif
// Thread-local buffer: the tweak may call this from network threads.
static inline const char *jbroot(const char *path) {
    static __thread char buf[1024];
    snprintf(buf, sizeof buf, "%s%s", ATB_JB_PREFIX, path ? path : "");
    return buf;
}
#endif
