# KASwitcher — Changelog

## 0.7.0

(0.6.0 hiç yayınlanmadı; değişiklikleri bu sürümde.)

**Yeni**
- Kasa: seçilen uygulamalar switcher'da görünmez, X'in yanındaki kilit butonuyla
  açılan kasada durur. Dokununca uygulamaya geçilir, yukarı atınca kapanır.
- Switcher'da bir kartı aşağı atınca kasaya taşınır (öndeki uygulama dahil, tek seferde).
- Switcher boşken de kasaya ulaşılır.
- Kasa kilidi: Face ID / parola (Apple'ın stok akışı); "switcher kapanana kadar",
  "1 dakika" ya da "her açılışta" sorar. Cihaz kilitlenince kasa kapanır.
- Sabitleme: kasadaki karta 0,8 sn basılı tut. Sabit uygulama kasadan çıkmaz,
  "Tümünü Kapat" onu atlar; tek tek yukarı atınca kapanır.
- Temalar (10): Varsayılan, Koyu, Modern, Nostalji, Aurora, Holografik, Terminal,
  Retro Oyun, Neon, Cüzdan — kasa, butonlar ve sabitleme rozeti birlikte değişir.
- Otomatik kapatma: 1/3/6/12 saat kullanılmayan uygulamalar kapanır
  (korunanlar, kasadakiler, çalan müzik ve öndeki uygulama hariç).

**Değişiklikler**
- Gizleme artık iOS'un kendi gizli kart mekanizmasıyla yapılıyor — switcher
  listesine dışarıdan dokunulmuyor (daha kararlı).
- Kasa ve geri dönen kartlar uygulamanın gerçek, tam görüntüsünü gösterir
  (yeni açılmış uygulamada da).
- X'e tek dokunuş doğrudan Tümünü Kapat (geri alınabilir); basılı tutmak menüyü açar.
- Kasa sayacı animasyonlu; butonlar birlikte, ortalı hizalanır.
- X'teki sayaç kaldırıldı; buton boyutu kasa butonunu da ölçekler.

**Bilinen kısıt**
- Öndeki uygulamanın kartı kasaya giderken uçma animasyonu yok.

## 0.5.1

**Değişiklikler**
- Kapatmayı geri alma süresi 4 saniyeden 2,5 saniyeye indi
- Ayarlar sayfasına ikon eklendi

**Düzeltmeler**
- Ayarlar'daki Sürüm satırı artık doğru sürümü gösteriyor (0.5.0'da 0.4.3 görünüyordu)

## 0.5.0

(0.4.4 hiç yayınlanmadı; değişiklikleri bu sürümde.)

**Özellikler**
- Yeni menü: X'e basılı tutunca açılan kendi menümüz — butonun yanında açılır, yatayda doğru yönde, alt menüler yerinde açılır, yazı boyutu sistem metin boyutunu izler
- X butonunu taşıma: Menü > Ayarlar > "Butonu taşı"; dikey ve yatay için ayrı konum, "Konumu sıfırla"
- Buton boyutu: Küçük / Orta / Büyük (menü ve Ayarlar)
- Yeni cam görünüm: bulanık cam daire, ince kenar, SF Symbol X

**Düzeltmeler**
- Kart kapatma animasyonları (Yukarı, Yana, Küçülerek, Solarak) artık düzgün; kartlar gidip gelmiyor, büyümüyor
- Kartlar ekranda en çok görünenden başlayarak kapanıyor
- Yatay ekranda X butonu artık kartların üstünde değil, altındaki boşlukta duruyor
- Menü açılıp kapanırken butondaki takılma ve sıçramalar giderildi

## 0.4.3

**Özellikler**
- Switcher'da tek butonla tüm uygulamaları kapatma (basılı tut)
- Kapatmayı geri alma: geri sayım sırasında X'e dokununca iptal
- Şelale animasyonu; animasyon türü ve hızı ayarlanabilir
- Kart sabitleme: sabitlenen uygulamalar kapatılmaz
- Müzik ve haritaları koruma
- Son kullanılan uygulamayı kapatmanın dışında tutma
- Korunanlar listesi: istediğin uygulamaları koru
- Haptic Touch menüsü: ayarlara switcher'dan hızlı erişim
- Ayarlar sayfası
- 12 dil: Türkçe, İngilizce, Almanca, Fransızca, İspanyolca, İtalyanca, Portekizce, Rusça, Çince (Basitleştirilmiş), Japonca, Korece, Arapça — iOS diline göre otomatik
- Ayarlar sayfasında Hakkında bölümü: geliştirici, iletişim ve sürüm

**Düzeltmeler**
- X butonu switcher'dan ana ekrana dönerken artık hemen kapanıyor
- Respring sonrası ilk açılışta X butonunun bir an görünüp kaybolması giderildi

**Uyumluluk**
- iOS 16 ve üstü, rootless ve RootHide
- "Legacy arm64e Support" (oldabi) artık gerekmiyor
