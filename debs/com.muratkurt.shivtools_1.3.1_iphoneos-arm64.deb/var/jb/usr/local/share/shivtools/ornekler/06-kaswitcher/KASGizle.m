// KASGizle — bkz. KASGizle.h. Cagrilarin tamami KASProbe 0.1-0.5 ile vphone iOS 26.6.2'de olculdu
// (REPORTS/06 §7); 16.1.1 / 17.0.3 / 18.6.2 DSC'de ayni secici ve siniflar var. Imza tutmazsa hicbir sey yapilmaz.
#import "KASGizle.h"
#import <objc/runtime.h>
#import <objc/message.h>

@interface NSObject (KASGizle)
- (NSArray *)allItems;
- (NSString *)bundleIdentifier;
- (id)contentViewController;
- (id)appLayout;
@end

static void (*kGunluk)(NSString *);
static void G(NSString *s) { if (kGunluk) kGunluk(s); }
void kas_gizleGunluk(void (*f)(NSString *)) { kGunluk = f; }

static BOOL imza(id o, BOOL sinif, const char *sel, const char *bekl) {
	if (!o) return NO;
	Class k = sinif ? (Class)o : object_getClass(o);
	Method m = sinif ? class_getClassMethod(k, sel_registerName(sel)) : class_getInstanceMethod(k, sel_registerName(sel));
	const char *t = m ? method_getTypeEncoding(m) : "yok";
	if (m && !strcmp(t, bekl)) return YES;
	G([NSString stringWithFormat:@"gizle imza-tutmadi %s = %s (beklenen %s)", sel, t, bekl]);
	return NO;
}
static BOOL icerir(id duzen, NSString *bid) {
	if (![duzen respondsToSelector:@selector(allItems)]) return NO;
	for (id it in [duzen allItems]) if ([it respondsToSelector:@selector(bundleIdentifier)] && [[it bundleIdentifier] isEqual:bid]) return YES;
	return NO;
}
static NSString *ilkBid(id duzen) {
	if (![duzen respondsToSelector:@selector(allItems)]) return nil;
	for (id it in [duzen allItems]) if ([it respondsToSelector:@selector(bundleIdentifier)] && [[it bundleIdentifier] length]) return [it bundleIdentifier];
	return nil;
}
static BOOL gizliMi(id duzen) {
	return imza(duzen, NO, "isHidden", "B16@0:8") && ((BOOL (*)(id, SEL))objc_msgSend)(duzen, sel_registerName("isHidden"));
}
static id koord(void) {
	Class k = objc_getClass("SBMainSwitcherControllerCoordinator");
	if (!imza(k, YES, "sharedInstanceIfExists", "@16@0:8")) return nil;
	return ((id (*)(id, SEL))objc_msgSend)(k, sel_registerName("sharedInstanceIfExists"));
}
static id model(id c) {
	Ivar v = c ? class_getInstanceVariable(object_getClass(c), "_mainSwitcherModel") : NULL;
	if (!v || strcmp(ivar_getTypeEncoding(v), "@\"SBAppSwitcherModel\"")) { G(@"gizle model-yok"); return nil; }
	return object_getIvar(c, v);
}
static NSArray *duzenler(id m, BOOL gizliDahil) {
	if (!imza(m, NO, "appLayoutsIncludingHiddenAppLayouts:", "@20@0:8B16")) return nil;
	return ((id (*)(id, SEL, BOOL))objc_msgSend)(m, sel_registerName("appLayoutsIncludingHiddenAppLayouts:"), gizliDahil);
}
static void rebuild(id c) {
	if (imza(c, NO, "_rebuildAppListCache", "v16@0:8")) ((void (*)(id, SEL))objc_msgSend)(c, sel_registerName("_rebuildAppListCache"));
}

void kas_yenile(void) {
	id c = koord();
	rebuild(c);
	if (imza(c, NO, "_notifySwitcherControllersAppLayoutsDidChange", "v16@0:8"))
		((void (*)(id, SEL))objc_msgSend)(c, sel_registerName("_notifySwitcherControllersAppLayoutsDidChange"));
}

NSArray<NSString *> *kas_kasaBidleri(NSSet<NSString *> *liste) {
	NSMutableArray *a = [NSMutableArray array];
	if (!liste.count) return a;
	for (id d in duzenler(model(koord()), YES)) {
		if (!gizliMi(d)) continue;
		NSString *b = ilkBid(d);
		if (b && [liste containsObject:b] && ![a containsObject:b]) [a addObject:b];
	}
	return a;
}

// b12: kasadaki (gizli) uygulamayi switcher'in kart silme hattindan GECIRMEDEN kapat. Silme hatti bos switcher'da her
// uygulama icin ayri "kart kalmadi -> ana ekran" gecisi ve kart kaldirma animasyonu baslatiyordu (RootHide 4 Eki: 5
// uygulamaya 35 ms'de 5 bos-layout); kasa solarken arkada "hayalet kart" goruluyordu. Gizli duzen modelden dogrudan
// cikar (switcher'da karti yok), surec FrontBoard'un sonlandirma cagrisiyla kapanir (16.1.1/17.0.3/26.6.2 DSC'de var).
BOOL kas_kasadanKapat(NSString *bid) {
	id c = koord(), m = model(c);
	Class kS = objc_getClass("FBSSystemService");
	const char *sT = "terminateApplication:forReason:andReport:withDescription:";
	if (!bid.length || !imza(m, NO, "remove:", "v24@0:8@16") || !imza(kS, YES, "sharedService", "@16@0:8")) return NO;
	id srv = ((id (*)(id, SEL))objc_msgSend)(kS, sel_registerName("sharedService"));
	if (!imza(srv, NO, sT, "v44@0:8@16q24B32@36")) return NO;
	NSUInteger n = 0;
	for (id d in [duzenler(m, YES) copy]) {
		if (!icerir(d, bid) || !gizliMi(d)) continue;
		((void (*)(id, SEL, id))objc_msgSend)(m, sel_registerName("remove:"), d);
		n++;
	}
	if (n) rebuild(c);
	((void (*)(id, SEL, id, long long, BOOL, id))objc_msgSend)(srv, sel_registerName(sT), bid, 1, NO, @"KASwitcher kasa");
	G([NSString stringWithFormat:@"gizle kasadan-kapat %@ duzen=%lu", bid, (unsigned long)n]);
	return YES;
}

// b30: kasa icin KENDI resmimiz - uygulamanin sahnesinden (FrontBoard), yalniz sahne ON PLANDAYKEN (ondeki canli kart).
// Apple'in kayitli resmi ondeki kartta eski/yarim (acilis ani: beyaz, Pusula ibresiz); ekran goruntusu kartin ekran disi
// yarisini alamiyordu (b23). Sahne goruntusu render sunucusundan, GPU icerigi dahil. Apple'in kendi resmine dokunulmaz.
// FBScene createSnapshot / FBSceneSnapshot capture,CGImage: 16.1.1 dizge, 17.0.3 ve 26.6.2 class-dump. Imza tutmazsa nil.
static NSMutableDictionary<NSString *, NSArray *> *kSahneGoruntu;   // b31: bid -> @[FBSceneSnapshot, FBScene]
UIImage *kas_sahneResmi(NSString *bid) {
	Class kM = objc_getClass("FBSceneManager");
	if (!bid.length || !imza(kM, YES, "sharedInstance", "@16@0:8")) return nil;
	id mgr = ((id (*)(id, SEL))objc_msgSend)(kM, sel_registerName("sharedInstance"));
	if (!imza(mgr, NO, "scenesPassingTest:", "@24@0:8@?16")) return nil;
	BOOL (^test)(id) = ^BOOL(id sc) {
		if (!imza(sc, NO, "clientProcess", "@16@0:8")) return NO;
		id pr = ((id (*)(id, SEL))objc_msgSend)(sc, sel_registerName("clientProcess"));
		if (!imza(pr, NO, "bundleIdentifier", "@16@0:8")) return NO;
		return [((id (*)(id, SEL))objc_msgSend)(pr, sel_registerName("bundleIdentifier")) isEqual:bid];
	};
	id sahneler = ((id (*)(id, SEL, id))objc_msgSend)(mgr, sel_registerName("scenesPassingTest:"), test);
	for (id sc in ([sahneler respondsToSelector:@selector(countByEnumeratingWithState:objects:count:)] ? sahneler : @[])) {
		if (!imza(sc, NO, "settings", "@16@0:8")) continue;
		id st = ((id (*)(id, SEL))objc_msgSend)(sc, sel_registerName("settings"));
		if (!imza(st, NO, "isForeground", "B16@0:8") || !((BOOL (*)(id, SEL))objc_msgSend)(st, sel_registerName("isForeground"))) continue;
		if (!imza(sc, NO, "createSnapshot", "@16@0:8")) return nil;
		id sn = ((id (*)(id, SEL))objc_msgSend)(sc, sel_registerName("createSnapshot"));
		if (!imza(sn, NO, "capture", "B16@0:8") || !imza(sn, NO, "CGImage", "^{CGImage=}16@0:8")) return nil;
		if (!((BOOL (*)(id, SEL))objc_msgSend)(sn, sel_registerName("capture"))) { G(@"gizle sahne-resmi capture=NO"); return nil; }
		CGImageRef ci = ((CGImageRef (*)(id, SEL))objc_msgSend)(sn, sel_registerName("CGImage"));
		if (!ci) return nil;
		// b31: goruntu nesnesi + sahne saklanir - Apple'in deposuna sonra kendi kayit yoluyla yazilacak (kas_appleDeposunaYaz)
		if (!kSahneGoruntu) kSahneGoruntu = [NSMutableDictionary dictionary];
		kSahneGoruntu[bid] = @[sn, sc];
		UIImage *r = [UIImage imageWithCGImage:ci scale:[UIScreen mainScreen].scale orientation:UIImageOrientationUp];
		G([NSString stringWithFormat:@"gizle sahne-resmi %@ %zux%zu", bid, CGImageGetWidth(ci), CGImageGetHeight(ci)]);
		return r;
	}
	return nil;
}

// b31: kasadan geri donuste switcher karti Apple'in KAYITLI resmini cizer; ondeki uygulama kasaya giderken Apple bu resmi
// sahne artik cizilmezken aliyor (eksik/beyaz). Apple'in kendi kayit yolu -[SBApplication saveSuspendSnapshot:forSceneHandle:]
// onceden alinmis FBSceneSnapshot'i depoya yazar (eskileri siler; DSC 17). Sahne ondeyken aldigimiz tam goruntuyu, Apple
// kendi resmini yazdiktan SONRA bu yolla yaziyoruz. Sahne tutamaci: SBSceneManagerCoordinator mainDisplaySceneManager ->
// existingSceneHandleForScene: (17/26 class-dump). Imza tutmazsa hicbir sey yazilmaz.
void kas_appleDeposunaYaz(NSString *bid) {
	NSArray *k = kSahneGoruntu[bid];
	if (k.count != 2) return;
	[kSahneGoruntu removeObjectForKey:bid];
	id sn = k[0], sc = k[1];
	Class kC = objc_getClass("SBSceneManagerCoordinator"), kA = objc_getClass("SBApplicationController");
	if (!imza(kC, YES, "mainDisplaySceneManager", "@16@0:8") || !imza(kA, YES, "sharedInstance", "@16@0:8")) return;
	id yon = ((id (*)(id, SEL))objc_msgSend)(kC, sel_registerName("mainDisplaySceneManager"));
	if (!imza(yon, NO, "existingSceneHandleForScene:", "@24@0:8@16")) return;
	id tut = ((id (*)(id, SEL, id))objc_msgSend)(yon, sel_registerName("existingSceneHandleForScene:"), sc);
	id ac = ((id (*)(id, SEL))objc_msgSend)(kA, sel_registerName("sharedInstance"));
	if (!tut || !imza(ac, NO, "applicationWithBundleIdentifier:", "@24@0:8@16")) return;
	id app = ((id (*)(id, SEL, id))objc_msgSend)(ac, sel_registerName("applicationWithBundleIdentifier:"), bid);
	if (!imza(app, NO, "saveSuspendSnapshot:forSceneHandle:", "v32@0:8@16@24")) return;
	((void (*)(id, SEL, id, id))objc_msgSend)(app, sel_registerName("saveSuspendSnapshot:forSceneHandle:"), sn, tut);
	G([NSString stringWithFormat:@"gizle apple-deposuna-yazildi %@", bid]);
}

// b8: switcher'da gorunur (gizli olmayan) kart sayisi - butonlarin gosterilip gosterilmeyecegi icin. -1 = okunamadi.
NSInteger kas_gorunurKartSayisi(void) {
	NSArray *a = duzenler(model(koord()), NO);
	return a ? (NSInteger)a.count : -1;
}

void kas_gizle(NSString *bid) {
	id c = koord(), m = model(c);
	if (!bid.length || !imza(m, NO, "hide:", "v24@0:8@16")) return;
	NSUInteger n = 0;
	for (id d in [duzenler(m, NO) copy]) {
		if (!icerir(d, bid) || gizliMi(d)) continue;
		((void (*)(id, SEL, id))objc_msgSend)(m, sel_registerName("hide:"), d);
		n++;
	}
	if (n) rebuild(c);
	G([NSString stringWithFormat:@"gizle %@ duzen=%lu", bid, (unsigned long)n]);
}

// b9: yenile=NO -> bayrak kalkar ama liste yeniden KURULMAZ (kasada kapatma: hemen ardindan silme listeyi kendisi
// kurar; arada kartin bir an gorunur olmasi ana ekrana donerken "hayalet kart cercevesi" birakiyordu - DOGRULANMADI).
static void gosterIc(NSString *bid, BOOL yenile);
static id icerikVC(id c);   // b32
void kas_goster(NSString *bid) { gosterIc(bid, YES); }
void kas_gosterSessiz(NSString *bid) { gosterIc(bid, NO); }
static void gosterIc(NSString *bid, BOOL yenile) {
	id c = koord(), m = model(c);
	if (!bid.length || !imza(m, NO, "replaceAppLayout:withAppLayout:", "v32@0:8@16@24")) return;
	NSUInteger n = 0;
	for (id d in [duzenler(m, YES) copy]) {
		if (!icerir(d, bid) || !gizliMi(d) || !imza(d, NO, "appLayoutByModifyingHiddenState:", "@20@0:8B16")) continue;
		id yeni = ((id (*)(id, SEL, BOOL))objc_msgSend)(d, sel_registerName("appLayoutByModifyingHiddenState:"), NO);
		((void (*)(id, SEL, id, id))objc_msgSend)(m, sel_registerName("replaceAppLayout:withAppLayout:"), d, yeni);
		n++;
	}
	if (n && yenile) rebuild(c);
	G([NSString stringWithFormat:@"goster %@ duzen=%lu yenile=%d", bid, (unsigned long)n, yenile]);
	if (n && yenile) {
		id vc = icerikVC(c);
		// b33: kart onbellegin listesinde degildi - gorunum, "resmi onbellege alinacak kartlar"i onbellege yalniz
		// -[SBFluidSwitcherViewController _updateSnapshotCache] ile bildiriyor (DSC 17: appLayoutsToCacheSnapshots ->
		// setCachableAppLayouts:); dokunus bunu tetikliyordu. Liste kurulduktan sonra bir kez (sonraki tur).
		if (imza(vc, NO, "_updateSnapshotCache", "v16@0:8")) {
			dispatch_async(dispatch_get_main_queue(), ^{
				((void (*)(id, SEL))objc_msgSend)(vc, sel_registerName("_updateSnapshotCache"));
				G([NSString stringWithFormat:@"goster %@ onbellek-listesi-guncellendi", bid]);
			});
		}
	}
}

// 16'da arkayi ana ekrana ceviren istek (m35; 17+'da -[SBDeckSwitcherModifier handleRemovalEvent:] kendisi yapar).
static void arkayiAnaEkran(id c, id vc) {
	Class kR = objc_getClass("SBMutableSwitcherTransitionRequest"), kA = objc_getClass("SBAppLayout");
	const char *sP = "switcherContentController:performTransitionWithRequest:gestureInitiated:";
	if (!imza(kA, YES, "homeScreenAppLayout", "@16@0:8") || !kR || !class_getInstanceMethod(kR, sel_registerName("setAppLayout:"))) return;
	id req = [(id)[kR alloc] init];
	if (!imza(req, NO, "setAppLayout:", "v24@0:8@16") || !imza(req, NO, "setUnlockedEnvironmentMode:", "v24@0:8q16")
	    || !imza(c, NO, sP, "v36@0:8@16@24B32")) return;
	((void (*)(id, SEL, id))objc_msgSend)(req, sel_registerName("setAppLayout:"),
		((id (*)(id, SEL))objc_msgSend)(kA, sel_registerName("homeScreenAppLayout")));
	((void (*)(id, SEL, long long))objc_msgSend)(req, sel_registerName("setUnlockedEnvironmentMode:"), 2);
	G(@"gizle arka-ana-ekran istegi (16)");
	((void (*)(id, SEL, id, id, BOOL))objc_msgSend)(c, sel_registerName(sP), vc, req, NO);
}

// b3: switcher'i stok gecis istegiyle ac - appLayout = nil ("switcher acilisi", 0.4.3 olcumu), unlockedEnvironmentMode = 2.
// KASProbe 0.6 ile vphone iOS 26.6.2'de olculdu: one gelen uygulamanin ustunde switcher acildi, cokme yok.
// Face ID (CoreAuthUI one gecince sistem switcher'i kapatiyor, 3 Eki RootHide olcumu) sonrasi kullanilir.
static id icerikVC(id c) {
	Ivar v = c ? class_getInstanceVariable(object_getClass(c), "_switcherControllersByWindowScene") : NULL;
	if (!v || strcmp(ivar_getTypeEncoding(v), "@\"NSMapTable\"")) return nil;
	for (id sc in [object_getIvar(c, v) objectEnumerator])
		if ([sc respondsToSelector:@selector(contentViewController)]) return [sc contentViewController];
	return nil;
}
BOOL kas_switcheriAc(void) {
	id c = koord(), vc = icerikVC(c);
	Class kR = objc_getClass("SBMutableSwitcherTransitionRequest");
	const char *sP = "switcherContentController:performTransitionWithRequest:gestureInitiated:";
	if (!vc || !kR || !imza(c, NO, sP, "v36@0:8@16@24B32")) return NO;
	id req = [(id)[kR alloc] init];
	if (!imza(req, NO, "setUnlockedEnvironmentMode:", "v24@0:8q16")) return NO;
	((void (*)(id, SEL, long long))objc_msgSend)(req, sel_registerName("setUnlockedEnvironmentMode:"), 2);
	G(@"gizle switcher-ac istegi");
	((void (*)(id, SEL, id, id, BOOL))objc_msgSend)(c, sel_registerName(sP), vc, req, NO);
	return YES;
}

// b15: uygulamanin switcher GORUNUMUNDE karti var mi (gorunumun kendi listesi - kurucunun ekledigi ondeki duzen dahil).
BOOL kas_gorunumdeVar(NSString *bid) {
	id vc = icerikVC(koord());
	if (!bid.length || !imza(vc, NO, "appLayouts", "@16@0:8")) return NO;
	for (id d in ((id (*)(id, SEL))objc_msgSend)(vc, sel_registerName("appLayouts"))) if (icerir(d, bid)) return YES;
	return NO;
}

// b13: bos switcher'i ana ekrana kapat - Apple'in "kart kalmadi -> ana ekran" istegi (-[SBDeckSwitcherModifier
// handleRemovalEvent:], 16.1.1/17.0.3/26.6.2 DSC): appLayout = homeScreenAppLayout, autoPIPDisabled = YES.
// setAutoPIPDisabled: 26'da v24@0:8q16 (b1 olcumu), 16/17'de BOOL - iki imza da kabul, digeri gonderilmez.
BOOL kas_switcheriAnaEkranaKapat(void) {
	id c = koord(), vc = icerikVC(c);
	Class kR = objc_getClass("SBMutableSwitcherTransitionRequest"), kA = objc_getClass("SBAppLayout");
	const char *sP = "switcherContentController:performTransitionWithRequest:gestureInitiated:";
	if (!vc || !kR || !imza(kA, YES, "homeScreenAppLayout", "@16@0:8") || !imza(c, NO, sP, "v36@0:8@16@24B32")) return NO;
	id req = [(id)[kR alloc] init];
	if (!imza(req, NO, "setAppLayout:", "v24@0:8@16")) return NO;
	((void (*)(id, SEL, id))objc_msgSend)(req, sel_registerName("setAppLayout:"),
		((id (*)(id, SEL))objc_msgSend)(kA, sel_registerName("homeScreenAppLayout")));
	Method mp = class_getInstanceMethod(object_getClass(req), sel_registerName("setAutoPIPDisabled:"));
	const char *tp = mp ? method_getTypeEncoding(mp) : "yok";
	if (!strcmp(tp, "v20@0:8B16")) ((void (*)(id, SEL, BOOL))objc_msgSend)(req, sel_registerName("setAutoPIPDisabled:"), YES);
	else if (!strcmp(tp, "v24@0:8q16")) ((void (*)(id, SEL, long long))objc_msgSend)(req, sel_registerName("setAutoPIPDisabled:"), 1);
	else G([NSString stringWithFormat:@"gizle autoPIP atlandi imza=%s", tp]);
	G(@"gizle bos-switcher ana-ekrana istegi");
	((void (*)(id, SEL, id, id, BOOL))objc_msgSend)(c, sel_registerName(sP), vc, req, NO);
	return YES;
}

// b5: 0 = yok, 1 = kaldirdik, BASLANGIC bekleniyor, 2 = baslangic goruldu, BITIS bekleniyor.
// b4'te tek bayrak vardi: kaldirmadan 1 ms sonra BASKA bir gecisin bitisi bayragi siliyordu (RootHide, 88 atista ~%15).
static int kBekleyenYenileme = 0;
static const long long kKaldirmaSebebi = 0;   // a3: stok gecisli kaldirma (1 = kartin biraktigin yerde kaybolmasi)

BOOL kas_kartiKaldir(UIView *kart, NSString *bid, BOOL onde) {
	id c = koord(), m = model(c);
	if (!m || !imza(m, NO, "hide:", "v24@0:8@16")) return NO;
	// Gorunumun KENDI duzeni (M1c': model nesnesi degil)
	id al = [kart respondsToSelector:@selector(appLayout)] ? [kart appLayout] : nil;
	id oge = nil;
	for (id it in [al allItems]) if ([[it bundleIdentifier] isEqual:bid]) oge = it;
	SEL sKal = sel_registerName("removeLayoutRole:inSpace:mutationBlock:reason:");
	UIResponder *vc = kart;
	while (vc && !([vc isKindOfClass:[UIViewController class]] && [vc respondsToSelector:sKal])) vc = [vc nextResponder];
	if (!oge || !vc || !imza(al, NO, "layoutRoleForItem:", "q24@0:8@16")
	    || !imza(vc, NO, "removeLayoutRole:inSpace:mutationBlock:reason:", "v48@0:8q16@24@?32q40")) {
		G([NSString stringWithFormat:@"gizle kaldir-yol-yok %@ oge=%d vc=%d", bid, oge != nil, vc != nil]);
		return NO;
	}
	long long rol = ((long long (*)(id, SEL, id))objc_msgSend)(al, sel_registerName("layoutRoleForItem:"), oge);
	// Apple'in blogu: model degisikligi + _rebuildAppListCache (DSC 26 block_invoke_2)
	void (^blok)(void) = ^{
		((void (*)(id, SEL, id))objc_msgSend)(m, sel_registerName("hide:"), al);
		rebuild(c);
	};
	// b6: "onde" (surec on planda mi) GEC/yanlis olabiliyor (RootHide: basarisiz ilk atislarin hepsi onde=0) - gecis sonrasi
	// yenileme HER kaldirmada kurulur; arka plan kartinda gecis gelmezse 1,5 sn'lik guvenlik yenilemesi zararsiz.
	{
		kBekleyenYenileme = 1;
		// guvenlik: 1,5 sn icinde baslangic gorulmezse bir kez yenile
		dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
			if (kBekleyenYenileme != 1) return;
			kBekleyenYenileme = 0;
			rebuild(koord());
			G(@"gizle gecis-yok zaman-asimi yenileme");
		});
	}
	G([NSString stringWithFormat:@"gizle kaldir %@ rol=%lld onde=%d", bid, rol, onde]);
	// Sebep 0 (a3, kullanici karari 3 Eki): -[SBRemovalSwitcherModifier visibleAppLayouts/handleRemovalEvent:] yalniz
	// "sebep == 1" diye bakiyor (DSC 26): 1'de kart gorunur listeden hemen duser; 0'da kaldirma suresince gorunur kalip
	// Apple'in kendi gecisiyle gider (vphone'da begenildi). Ondeki kartta gecis-basi yenilemesi animasyonu kesiyor (DOGRULANMADI).
	((void (*)(id, SEL, long long, id, id, long long))objc_msgSend)(vc, sKal, rol, al, blok, kKaldirmaSebebi);
	// b30: b28/b29 "once arka plan, sonra kaldir" denemesi GERI ALINDI (1 sn bekleme de eksik goruntuyu cozmedi).
	if (onde && ![[NSProcessInfo processInfo] isOperatingSystemAtLeastVersion:(NSOperatingSystemVersion){17, 0, 0}])
		arkayiAnaEkran(c, vc);
	return YES;
}

void kas_gecisBasladi(void) {
	if (kBekleyenYenileme != 1) return;
	kBekleyenYenileme = 2;
	// b21: b20'nin 0,3 sn gecikmesi GERI ALINDI (kart once yerine donup sonra animasyonla gidiyordu - kullanici).
	rebuild(koord());
	G(@"gizle gecis-basi yenileme");
}

void kas_gecisBitti(void) {
	if (kBekleyenYenileme == 1) { G(@"gizle gecis-sonu baska-gecis yok-sayildi"); return; }
	if (kBekleyenYenileme != 2) return;
	kBekleyenYenileme = 0;
	rebuild(koord());
	G(@"gizle gecis-sonu yenileme");
}

id kas_willAddDuzelt(id duzen, NSSet<NSString *> *liste) {
	NSString *b = ilkBid(duzen);
	if (!b || ![liste containsObject:b] || gizliMi(duzen) || !imza(duzen, NO, "appLayoutByModifyingHiddenState:", "@20@0:8B16")) return duzen;
	G([NSString stringWithFormat:@"gizle yeni-duzen gizli %@", b]);
	return ((id (*)(id, SEL, BOOL))objc_msgSend)(duzen, sel_registerName("appLayoutByModifyingHiddenState:"), YES);
}

void kas_esitle(NSSet<NSString *> *eski, NSSet<NSString *> *yeni) {
	for (NSString *b in yeni) if (![eski containsObject:b]) kas_gizle(b);
	for (NSString *b in eski) if (![yeni containsObject:b]) kas_goster(b);
}
