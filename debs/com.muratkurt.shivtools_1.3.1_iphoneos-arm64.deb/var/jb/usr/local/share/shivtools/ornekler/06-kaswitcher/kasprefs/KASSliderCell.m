#import "KASSliderCell.h"

// OLCUM (dosyaya loglayarak dogrulandi - bkz kas-slider-debug.txt):
// PSSegmentableSlider'in TEK subview'i _UISlideriOSVisualElement;
// deger etiketi ("2.00" vb UILabel) O'NUN icinde, slider'in KENDI
// subview'i degil. Etiketin ORIJINAL frame'i {310,9,23,15} - control
// genisligi 333 oldugundan sag kenar (333) ile CAKISIYOR, "4.00" gibi
// 5 karakter icin dar. Duzeltme: iki seviye tarayip etiketi bulup
// SOLA dogru genisletiyor (sag kenar SABIT kalir).
@implementation KASSliderCell

- (void)ka_duzeltDegerEtiketi {
    UIView *slider = self.control;
    if (!slider) return;
    [slider layoutIfNeeded];

    UILabel *degerEtiketi = nil;
    for (UIView *sv in slider.subviews) {
        if ([sv isKindOfClass:[UILabel class]]) { degerEtiketi = (UILabel *)sv; break; }
        for (UIView *sv2 in sv.subviews) {
            if ([sv2 isKindOfClass:[UILabel class]]) { degerEtiketi = (UILabel *)sv2; break; }
        }
        if (degerEtiketi) break;
    }
    if (!degerEtiketi) return;

    CGFloat yeniGenislik = 34.0; // "4.00" gibi 4 karakter icin guvenli pay
    CGRect ef = degerEtiketi.frame;
    CGFloat sagKenar = ef.origin.x + ef.size.width;
    if (ef.size.width >= yeniGenislik) return; // zaten yeterli - dokunma

    ef.origin.x = sagKenar - yeniGenislik; // sag kenar SABIT kalsin
    ef.size.width = yeniGenislik;
    degerEtiketi.frame = ef;
    degerEtiketi.textAlignment = NSTextAlignmentRight;
    degerEtiketi.backgroundColor = [UIColor clearColor];
    degerEtiketi.adjustsFontSizeToFitWidth = NO;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self ka_duzeltDegerEtiketi];
    // control kendi ic layoutu BU cagridan SONRA guncelliyor olabilir -
    // bir sonraki run-loop turunda TEKRAR dene (olculdu: ilk turda
    // bulunuyor ama guvenlik icin ikinci kontrol birakildi).
    dispatch_async(dispatch_get_main_queue(), ^{
        [self ka_duzeltDegerEtiketi];
    });
}

@end
