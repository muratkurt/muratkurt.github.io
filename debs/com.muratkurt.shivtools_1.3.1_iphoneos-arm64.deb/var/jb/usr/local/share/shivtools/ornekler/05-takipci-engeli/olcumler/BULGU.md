# Bulgu: rootless cihazda derlenen arm64e ikili Ayarlar'ı düşürdü (1 Eki 2026)

shivtools'a öğretilecek. Kök sebep henüz KESİN DEĞİL — aşağıda ölçülenle
hipotez ayrı yazıldı. Bir sonraki oturumun işi: hipotezi doğrula ya da çürüt,
sonra SHIVTOOLS.md / TWEAK.md §1.6'ya kural olarak yaz.

## Ölçülenler (ÖLÇÜLDÜ)

| | RootHide cihazı (iPhone16,1, iOS 17.0.3) | Rootless cihaz (iPhone11,2 A12, iOS 16.1.1) |
|---|---|---|
| Derleyici | Procursus-**roothide clang 14.0.0** (dcc6f12) | palera1n Procursus **clang 16.0.0** (5477f7d) |
| arm64e dilimi caps | **0x00** | **0x80** |
| Aynı prefs kaynağı, Ayarlar'da | açıldı, sorunsuz | **çöktü** |

- Çökme: `Preferences-readClass-crash.ips` — `EXC_BREAKPOINT (SIGTRAP)`,
  ana iş parçacığı: `libobjc readClass` ← `map_images_nolock` ←
  `dyld dlopen_from` ← `-[NSBundle loadAndReturnError:]` ←
  `-[PSListController lazyLoadBundle:]`. Yani bundle'ın ObjC sınıfları
  kaydedilirken, bizim kodumuz hiç çalışmadan.
- Aynı kaynak RootHide cihazının toolchain'iyle `THEOS_PACKAGE_SCHEME=rootless`
  derlenip (caps 0x00) aynı rootless cihaza kurulunca Ayarlar açıldı; Türkçe
  ve Arapça sayfa, rapor sayfası çalıştı.
- Aynı cihazda Mac'te (Apple clang) derlenen KASwitcherPrefs / iosmcpprefs da
  **0x80** ve çalışıyor → "0x80 kötü" değil; **0x80'i kimin ürettiği** önemli.
- Tweak dylib'in clang 16 derlemesi de arm64e diliminde 0x80'di. Yalnız arm64
  uygulamalarda (YouTube, X, tabii) test edildi ve çalıştı — **arm64e bir
  süreçte (Safari, Ayarlar, SpringBoard) denenmedi.**
- `__cfstring = 0` ve sisteme blok verilmiyordu; yani bu, TWEAK.md §1.6'daki
  bilinen iki tetikleyiciden (literal, blok) BİRİ DEĞİL. Yeni bir sınıf.

## Hipotez (DOĞRULANMADI)

iOS 15/16 libobjc, yeni ABI'li (caps 0x80) arm64e ikilide ObjC sınıf meta
verisinin (class_t → class_ro_t işaretçisi vb.) Apple clang'ın kurallarıyla
PAC imzalı olmasını bekliyor ve `readClass` içinde doğruluyor. Upstream LLVM
16 arm64e'yi 0x80 olarak işaretliyor ama bu meta veri imzalarını Apple ile
aynı üretmiyor → doğrulama tuzağı (SIGTRAP).

## Doğrulamak için (sonraki oturum)

1. İki deb burada: `procursus-clang16_caps80.deb` (çöken) ve
   `roothide-toolchain_caps00.deb` (çalışan). arm64e dilimlerinde
   `__objc_classlist` → class_t → `data` (class_ro) işaretçisinin chained
   fixup'ında **auth biti** var mı? (Mac'te `dyld_info -fixups` ya da
   `otool -ov`; aynı karşılaştırmayı Apple clang'ın 0x80 KASwitcherPrefs'i ile yap.)
2. clang 16 derlemesini bir arm64e uygulamada (Safari) dene: aynı `readClass`
   tuzağı → sorun prefs'e değil toolchain'e özgü demektir.
3. clang 16 ile `-fno-ptrauth-*` ya da `-mabi`/`-arch arm64e` bayrakları
   caps'i 0x00'a indirebiliyor mu? İndirirse cihazda derleme kurtulur.

## Şimdilik kural önerisi (ölçülene kadar) — BAYATLADI, aşağıdaki GÜNCELLEME geçerli

- **Rootless cihazda (Procursus clang 16) arm64e hedefini derleme.** arm64e
  dilimi olan her şey (SpringBoard tweak'i, prefs bundle'ı, Apple uygulamasına
  giren tweak) clang 14 (RootHide toolchain) ya da Mac (Apple clang) ile derlensin.
- `shiv-ortam` derleyici sürümünü ve deneme derlemesinin caps değerini
  basabilir: "clang 16 + arm64e = 0x80 (Apple dışı) → arm64e süreçte çöker".
- Kurulumdan önce caps'e bakmak yetmez: 0x80 hem doğru (Apple clang) hem
  bozuk (upstream clang 16) olabilir. Ayrıştıran şey derleyici kimliği
  (`clang --version`).

---

## GÜNCELLEME — 1 Eki 2026, 16:40 (shivtools oturumu 7f3c7e30 + bu oturum)

**Hipotez düzeltildi.** shivtools oturumunun ölçümüne göre (kaydı:
`7f3c7e30-1c8d-4b78-b260-bf6b9be0cf07.jsonl`, deney klasörü rootless'ta
`/var/jb/tmp/abi/`):
- clang 14 ve clang 16 ikilileri **aynı yerde** (`readClass`) çöküyor; fark
  yalnız **OldABI'nin devreye girip girmemesi**. "Sebep 0x80" hipotezi YANLIŞ.
- Çare: clang 16'ya **`-fno-ptrauth-abi-version`** → caps 0x80 → 0x00 →
  OldABI devreye giriyor. Bu derleme XS'e kuruldu (`1.0.0-1`, prefs UUID
  ED764EFC…, caps 0x00); kullanıcı sayfanın açıldığını doğruladı.

**Bu oturumun ölçümü (16:38):** güncel kaynak, bayraksız clang 16
(`/var/mobile/ATB-clang16`) → tweak ve prefs arm64e dilimi yine **0x80**.
Tekrarlanabilir. Kurulmadı (çökmesi zaten iki kez görüldü).

**AppTrackerBlock için sonuç (DOĞRULANMADI, ölçülmeli):** clang 14 derlemesi
de OldABI'ye dayanıyorsa, cihazda derlenen arm64e prefs bundle'ı —
`__cfstring = 0` ve blok olmasa bile — **OldABI'si olmayan cihazda Ayarlar'ı
düşürür**. TWEAK.md §1.6'nın iki tetikleyicisine (literal, blok) ek olarak
üçüncü bir aday: **arm64e ikilide tanımlı ObjC sınıfı** (prefs denetleyicileri).
Tweak dylib'i sınıf tanımlamıyor (yalnız Logos hook), o yüzden etkilenmeyebilir.

**Ölçüm önerisi (shivtools oturumu):** OldABI'yi tek değişkenli A/B ile kapat
(önce `OldABI.dylib`'in bir kopyasını al, sonra adını değiştir; bitince eski adına geri al),
Ayarlar'ı yeniden başlatıp AppTrackerBlock sayfasını aç:
1. clang 14 derlemesi (0x00) → açılıyor mu?
2. Mac / Apple clang derlemesi (0x80) → açılıyor mu?
Sonuca göre: ya `control`'e `Depends: … | oldabi` ya da yayın Mac'te.

**Yayın kararı bekliyor:** AppTrackerBlock 1.0.0'ın control'ünde oldabi
bağımlılığı YOK. Ölçüm gelene kadar yayınlanmamalı ya da bağımlılık eklenmeli.
