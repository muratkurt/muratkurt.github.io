#import "KASRootListController.h"
#import <Preferences/PSSpecifier.h>

// SURUM DORT YERDE GECER - hepsi birlikte guncellenir, yoksa paket bir
// surum, Ayarlar baska surum gosterir:
//   control                      -> Version:
//   Resources/Info.plist         -> CFBundleShortVersionString / CFBundleVersion
//   Resources/Root.plist         -> Surum satirinin value yedegi
//   buradaki kKAS_Surum          -> ekranda GORUNEN deger
static NSString * const kKAS_Surum = @"0.7.0";

@implementation KASRootListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

// HAKKINDA (0.4.3) - ActionButtonFix 2.6.1 ile ayni satirlar.
- (id)versionValue:(PSSpecifier *)spec {
    return kKAS_Surum;
}

- (void)ka_ac:(NSString *)adres {
    NSURL *url = [NSURL URLWithString:adres];
    if (url) [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
}

- (void)openGitHub {
    [self ka_ac:@"https://github.com/muratkurt"];
}

- (void)openMail {
    [self ka_ac:@"mailto:muratkurttr@outlook.com?subject=KASwitcher"];
}

// HAKKINDA satirlari PSLinkCell: ABF'deki gibi normal renkli metin + ">".
// Alt sayfa yok; dokunus burada yakalanir, super'e gitmez (push olmaz).
- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    NSString *kimlik = [[self specifierAtIndexPath:ip] identifier];
    if ([kimlik isEqualToString:@"kas-github"] || [kimlik isEqualToString:@"kas-mail"]) {
        [tv deselectRowAtIndexPath:ip animated:YES];
        if ([kimlik isEqualToString:@"kas-github"]) [self openGitHub];
        else [self openMail];
        return;
    }
    [super tableView:tv didSelectRowAtIndexPath:ip];
}

@end
