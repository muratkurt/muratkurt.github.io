# AppTrackerBlock — projeye özel talimat

> **shivtools örneği olarak okuyorsan ÖNCE `OKU.md` → "TEHLİKELER".**
> Bu tweak her uygulamaya yüklenir ve ağ isteklerini keser. VPN/DNS
> uygulamaları, hile korumalı oyunlar ve paket adı çakışması orada
> anlatılıyor. Kullanıcıya sormadan kurma.

Genel kural kitabı shivtools'un `SHIVTOOLS.md` / `TWEAK.md`'si; bu dosya
yalnız bu projeye özgü olanı söyler. Buradaki bilgiler 1 Ekim 2026'da
cihazda ölçüldü (aksi yazıyorsa DOĞRULANMADI).

## Proje

- **Paket:** `com.muratkurt.apptrackerblock` · prefs alanı aynı ad ·
  Darwin bildirimi `com.muratkurt.apptrackerblock/prefs-changed`
- **Ayar anahtarları:** `blocking` (vars. 1), `logging` (vars. 0),
  `excluded` (dizi; yoksa `Common.h` varsayılanı), `blockingDisabledApps` (dizi)
- **Dil:** kod, yorum ve kullanıcının gördüğü her şey **İngilizce**
  (kullanıcı kararı). Türkçe yalnız raporlarda ve konuşmada.
- **Klasör şeması:** `../README.md`. Yeni iş = yeni `SOURCE-x.y.z`.

## Mimari (kısa)

- Engel: `-[NSURLSessionTask resume]` → `cancel`; gerçek `getaddrinfo`
  (AI_NUMERICHOST değil) → `EAI_NONAME`. Ölçüm hook'ları
  (`nw_*`, `connect`, `DNSServiceGetAddrInfo`) YALNIZ `logging` açıkken.
- Liste: `jbroot(/var/mobile/Library/AppTrackerBlock/hagezi-pro.bin)`, mmap,
  `ATBLIST1` + sıralı FNV-1a-64 (`Blocklist.[ch]`, araçla ortak kod).
- Sayaç: uygulamanın kendi `$HOME/Library/Caches/AppTrackerBlock-blocked.log`'u.
  Sandbox jbroot'a YAZAMIYOR (EPERM); Ayarlar sandbox'sız, kapsayıcıları okur.
- Prefs dosyası tweak'te önce `jbroot()` yolunda, sonra düz yolda aranır
  (RootHide ve Dopamine ikisi de jbroot altına yazıyor).

## Kurallar (bu projede ödenmiş)

- **`@"..."` literali ve sisteme blok YOK** (`ATBS()`/`ATBL()` kullan);
  her derlemede `otool -l … | grep -c __cfstring` → 0.
- **Cihaz derlemesi yayınlanmaz:** arm64e prefs OldABI'siz Ayarlar'ı
  düşürüyor (A/B ölçüldü, `REPORTS/04`). Yayın Mac'te; değilse
  `Depends: firmware (<< 15.0) | cy+cpu.arm64v8 | oldabi`.
- **Rootless cihazda (Procursus clang 16) derleme:** bayraksız 0x80 →
  OldABI açıkken de çöker. Rootless paketini RootHide cihazında
  `THEOS_PACKAGE_SCHEME=rootless` ile derle.
- **`%orig` kendi satırında** — stok Logos `{ %orig; return; }`'da
  `return; }`'yu yutuyor.
- **`/usr/bin` aracına libroothide bağlama** (dyld errno=1); `atb-compile`
  kökü kendi exe yolundan türetiyor.
- **Çeviriler tek kaynaktan:** `Prefs/i18n/build-strings.mjs`; betik eksik
  anahtarı ve biçim belirteci uyuşmazlığını reddeder. Koddaki her
  `ATBL("…")` ve Root.plist metni tabloda olmalı.
- **Sürüm elle yazılmaz:** sayfa, Makefile'ın `control`'den yazdığı
  bundle içi `version` dosyasını okur.
- **Arayüz testinden sonra diffTerm'e dön** (`launch_app dev.diffterm.app`);
  öndeki uygulama diffTerm ise kullanıcı oradadır, ekranı sürme.
- RootHide'da Ayarlar'a frida bağlama (safe mode); çeviri testi rootless'ta.
  RootHide Ayarlar'ında 29 Eyl'den kalma `AppleLanguages=(en)` artığı var.

## Cihazlar

- Geliştirme: iPhone16,1, iOS 17.0.3, RootHide (bu cihaz).
- Rootless test: iPhone XS (iPhone11,2), iOS 16.1.1, Dopamine;
  bu telefonun hotspot'unda `172.20.10.3`, ssh `mobile`. MCP yalnız
  127.0.0.1 → `ssh -L 18090:127.0.0.1:8090` + `_zula/yedek/arac/mcp.mjs`
  (node `fetch` bu cihazlarda çalışmıyor; `http` modülü).
