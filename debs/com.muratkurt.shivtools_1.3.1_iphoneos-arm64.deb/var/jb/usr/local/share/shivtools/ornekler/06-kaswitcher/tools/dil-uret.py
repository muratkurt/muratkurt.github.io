#!/usr/bin/env python3
# KASwitcher dil üreticisi — TEK ÇEVİRİ KAYNAĞI.
#
# Anahtar = Türkçe kaynak metin (ABF 10-PREFS §7.3 ile aynı kural): Root.plist
# ve kod okunaklı kalır, çeviri eksikse metnin kendisi döner.
#
# Üretir:
#   kasprefs/Resources/<dil>.lproj/Root.strings  — stok PSListController,
#       Root.plist etiketlerini (label, footerText, validTitles, shortTitles)
#       plist adıyla aynı tablodan ("Root") kendisi çevirir.
#   KASDil.m — SpringBoard içindeki metinler (menü, ipucu, geri alma).
#       SpringBoard'da prefs bundle'ının jbroot yolu şemaya göre değiştiği için
#       .strings okumak yerine tablo koda gömülür.
#
# Kullanım (SOURCE klasöründe):  python3 tools/dil-uret.py
# Metin ekle/değiştir → bu dosyayı düzenle → çalıştır → derle.

import os

DILLER = ["tr", "en", "de", "fr", "es", "it", "pt", "ru", "zh-Hans", "ja", "ko", "ar"]

# (anahtar, {dil: çeviri}, tweak'te mi)
M = []
def m(tr, en, de, fr, es, it, pt, ru, zh, ja, ko, ar, tweak=False):
    M.append((tr, dict(tr=tr, en=en, de=de, fr=fr, es=es, it=it, pt=pt, ru=ru,
                       **{"zh-Hans": zh}, ja=ja, ko=ko, ar=ar), tweak))

# ── SpringBoard (tweak) ──────────────────────────────────────────────
m("Sabitlendi", "Pinned", "Angeheftet", "Épinglée", "Fijada", "Fissata", "Fixado",
  "Закреплено", "已固定", "固定しました", "고정됨", "تم التثبيت", tweak=True)
m("Sabitleme kaldırıldı", "Unpinned", "Nicht mehr angeheftet", "Désépinglée", "Ya no está fijada",
  "Non più fissata", "Desafixado", "Откреплено", "已取消固定", "固定を解除しました", "고정 해제됨",
  "تم إلغاء التثبيت", tweak=True)
m("Kapatmak için basılı tut", "Hold to close all", "Zum Schließen gedrückt halten",
  "Maintenir pour tout fermer", "Mantén pulsado para cerrar todo", "Tieni premuto per chiudere tutto",
  "Mantenha pressionado para fechar tudo", "Удерживайте, чтобы закрыть все", "按住以全部关闭",
  "長押しですべて閉じる", "길게 눌러 모두 닫기", "اضغط مطولاً لإغلاق الكل", tweak=True)
m("İptal edildi", "Cancelled", "Abgebrochen", "Annulé", "Cancelado", "Annullato", "Cancelado",
  "Отменено", "已取消", "キャンセルしました", "취소됨", "تم الإلغاء", tweak=True)
m("İptal et", "Cancel", "Abbrechen", "Annuler", "Cancelar", "Annulla", "Cancelar",
  "Отменить", "取消", "キャンセル", "취소", "إلغاء", tweak=True)
m("Tümünü Kapat", "Close All", "Alle schließen", "Tout fermer", "Cerrar todo", "Chiudi tutto",
  "Fechar tudo", "Закрыть все", "全部关闭", "すべて閉じる", "모두 닫기", "إغلاق الكل", tweak=True)
m("Ayarlar", "Settings", "Einstellungen", "Réglages", "Ajustes", "Impostazioni", "Ajustes",
  "Настройки", "设置", "設定", "설정", "الإعدادات", tweak=True)
m("Tüm Ayarlar…", "All Settings…", "Alle Einstellungen…", "Tous les réglages…", "Todos los ajustes…",
  "Tutte le impostazioni…", "Todos os ajustes…", "Все настройки…", "所有设置…", "すべての設定…",
  "모든 설정…", "كل الإعدادات…", tweak=True)
m("Butonu taşı", "Move Button", "Taste verschieben", "Déplacer le bouton", "Mover botón",
  "Sposta pulsante", "Mover botão", "Переместить кнопку", "移动按钮", "ボタンを移動",
  "버튼 이동", "نقل الزر", tweak=True)
m("Konumu sıfırla", "Reset Position", "Position zurücksetzen", "Réinitialiser la position",
  "Restablecer posición", "Ripristina posizione", "Redefinir posição", "Сбросить положение",
  "重置位置", "位置をリセット", "위치 재설정", "إعادة تعيين الموضع", tweak=True)
m("Buton boyutu", "Button Size", "Tastengröße", "Taille du bouton", "Tamaño del botón",
  "Dimensione pulsante", "Tamanho do botão", "Размер кнопки", "按钮大小", "ボタンのサイズ",
  "버튼 크기", "حجم الزر", tweak=True)
m("Küçük", "Small", "Klein", "Petit", "Pequeño", "Piccolo", "Pequeno",
  "Маленький", "小", "小", "작게", "صغير", tweak=True)
m("Orta", "Medium", "Mittel", "Moyen", "Mediano", "Medio", "Médio",
  "Средний", "中", "中", "보통", "متوسط", tweak=True)
m("Büyük", "Large", "Groß", "Grand", "Grande", "Grande", "Grande",
  "Большой", "大", "大", "크게", "كبير", tweak=True)
m("Buton", "Button", "Taste", "Bouton", "Botón", "Pulsante", "Botão",
  "Кнопка", "按钮", "ボタン", "버튼", "الزر")
m("Butonu taşımak için switcher'da X'e basılı tut: Ayarlar › Butonu taşı.",
  "To move the button, press and hold X in the switcher: Settings › Move Button.",
  "Zum Verschieben X im Umschalter gedrückt halten: Einstellungen › Taste verschieben.",
  "Pour déplacer le bouton, maintenez X dans le sélecteur : Réglages › Déplacer le bouton.",
  "Para mover el botón, mantén pulsada la X en el selector: Ajustes › Mover botón.",
  "Per spostare il pulsante, tieni premuta la X nel selettore: Impostazioni › Sposta pulsante.",
  "Para mover o botão, mantenha pressionado o X no seletor: Ajustes › Mover botão.",
  "Чтобы переместить кнопку, удерживайте X в переключателе: Настройки › Переместить кнопку.",
  "要移动按钮，请在切换器中按住 X：设置 › 移动按钮。",
  "ボタンを移動するには、スイッチャーで X を長押し：設定 › ボタンを移動。",
  "버튼을 옮기려면 전환기에서 X를 길게 누르세요: 설정 › 버튼 이동.",
  "لنقل الزر، اضغط مطولاً على X في مبدّل التطبيقات: الإعدادات › نقل الزر.")
m("Animasyon", "Animation", "Animation", "Animation", "Animación", "Animazione", "Animação",
  "Анимация", "动画", "アニメーション", "애니메이션", "الحركة", tweak=True)

# ── Hem menüde hem Ayarlar'da ────────────────────────────────────────
m("Son Uygulamayı hariç tut", "Keep the most recent", "Letzte App behalten", "Garder la plus récente",
  "Conservar la más reciente", "Mantieni la più recente", "Manter a mais recente",
  "Оставлять последнее", "保留最近使用的应用", "最新のAppを残す", "최근 앱 유지",
  "الإبقاء على الأحدث", tweak=True)
m("Müzik ve haritaları koru", "Protect music and maps", "Musik und Karten schützen",
  "Protéger musique et plans", "Proteger música y mapas", "Proteggi musica e mappe",
  "Proteger música e mapas", "Защищать музыку и карты", "保护音乐和地图",
  "ミュージックとマップを保護", "음악 및 지도 보호", "حماية الموسيقى والخرائط", tweak=True)
m("Animasyon yok", "No animation", "Keine Animation", "Aucune animation", "Sin animación",
  "Nessuna animazione", "Sem animação", "Без анимации", "无动画", "アニメーションなし",
  "애니메이션 없음", "بدون حركة", tweak=True)
m("Yukarı kayarak", "Slide up", "Nach oben gleiten", "Glisser vers le haut", "Deslizar hacia arriba",
  "Scorri verso l'alto", "Deslizar para cima", "Сдвиг вверх", "向上滑动", "上にスライド",
  "위로 밀기", "انزلاق للأعلى", tweak=True)
m("Solarak", "Fade", "Ausblenden", "Fondu", "Desvanecer", "Dissolvenza", "Esmaecer",
  "Затухание", "淡出", "フェード", "페이드", "تلاشٍ", tweak=True)
m("Küçülerek", "Shrink", "Verkleinern", "Réduire", "Encoger", "Rimpicciolisci", "Encolher",
  "Уменьшение", "缩小", "縮小", "축소", "تصغير", tweak=True)
m("Yana kayarak", "Slide sideways", "Seitlich gleiten", "Glisser sur le côté", "Deslizar hacia un lado",
  "Scorri di lato", "Deslizar para o lado", "Сдвиг в сторону", "向侧面滑动", "横にスライド",
  "옆으로 밀기", "انزلاق جانبي", tweak=True)

# ── Yalnız Ayarlar ───────────────────────────────────────────────────
m("Genel", "General", "Allgemein", "Général", "General", "Generali", "Geral",
  "Основные", "通用", "一般", "일반", "عام")
m("Etkin", "Enabled", "Aktiviert", "Activé", "Activado", "Attivo", "Ativado",
  "Включено", "启用", "有効", "활성화", "مُفعّل")
m("Kapatma", "Closing", "Schließen", "Fermeture", "Cierre", "Chiusura", "Fechamento",
  "Закрытие", "关闭", "終了", "닫기", "الإغلاق")
m("Bu ayarlar switcher'daki Haptic Touch menüsüyle aynıdır. Müzik ve haritalar koruma anahtarıyla yönetilir; diğer korunan uygulamalar aşağıdaki listeden.",
  "These settings match the Haptic Touch menu in the app switcher. Music and maps are handled by the protection switch; other protected apps are managed in the list below.",
  "Diese Einstellungen entsprechen dem Haptic-Touch-Menü im App-Umschalter. Musik und Karten werden über den Schutzschalter verwaltet, andere geschützte Apps über die Liste unten.",
  "Ces réglages correspondent au menu Haptic Touch du sélecteur d'apps. La musique et les plans sont gérés par le bouton de protection ; les autres apps protégées, par la liste ci-dessous.",
  "Estos ajustes coinciden con el menú Haptic Touch del selector de apps. La música y los mapas se gestionan con el interruptor de protección; las demás apps protegidas, con la lista de abajo.",
  "Queste impostazioni corrispondono al menu Haptic Touch del selettore app. Musica e mappe sono gestite dall'interruttore di protezione; le altre app protette dall'elenco qui sotto.",
  "Estes ajustes correspondem ao menu Haptic Touch do seletor de apps. Música e mapas são controlados pela chave de proteção; os outros apps protegidos, pela lista abaixo.",
  "Эти настройки совпадают с меню Haptic Touch в переключателе приложений. Музыка и карты управляются переключателем защиты, остальные защищённые приложения — списком ниже.",
  "这些设置与应用切换器中的触感触控菜单相同。音乐和地图由保护开关管理；其他受保护的应用在下方列表中管理。",
  "これらの設定はAppスイッチャーの触覚タッチメニューと同じです。ミュージックとマップは保護スイッチで、その他の保護されたAppは下のリストで管理します。",
  "이 설정은 앱 전환기의 햅틱 터치 메뉴와 같습니다. 음악과 지도는 보호 스위치로, 다른 보호된 앱은 아래 목록에서 관리합니다.",
  "تطابق هذه الإعدادات قائمة اللمس اللمسي في مبدّل التطبيقات. تتم إدارة الموسيقى والخرائط بمفتاح الحماية، وبقية التطبيقات المحمية من القائمة أدناه.")
m("Korunanlar…", "Protected Apps…", "Geschützte Apps…", "Apps protégées…", "Apps protegidas…",
  "App protette…", "Apps protegidos…", "Защищённые…", "受保护的应用…", "保護されたApp…",
  "보호된 앱…", "التطبيقات المحمية…")
m("Korunan uygulamalar", "Protected apps", "Geschützte Apps", "Apps protégées", "Apps protegidas",
  "App protette", "Apps protegidos", "Защищённые приложения", "受保护的应用", "保護されたApp",
  "보호된 앱", "التطبيقات المحمية")
# ── 0.6.0 gizli bölüm ───────────────────────────────────────────────
m("Gizli bölüm", "Hidden section", "Versteckter Bereich", "Section masquée", "Sección oculta",
  "Sezione nascosta", "Seção oculta", "Скрытый раздел", "隐藏区域", "非表示セクション",
  "숨긴 섹션", "القسم المخفي")
m("Seçilen uygulamalar switcher'da görünmez ve Hepsini kapat onlara dokunmaz. X'in yanındaki kilit butonu gizli bölümü açar. Switcher'da bir kartı aşağı atarak da gizleyebilirsin.",
  "Selected apps don't appear in the switcher and Close All leaves them alone. The lock button next to the X opens the hidden section. You can also hide an app by swiping its card down in the switcher.",
  "Ausgewählte Apps erscheinen nicht im App-Umschalter, und „Alle schließen“ lässt sie unberührt. Die Schloss-Taste neben dem X öffnet den versteckten Bereich. Du kannst eine App auch ausblenden, indem du ihre Karte im Umschalter nach unten wischst.",
  "Les apps sélectionnées n’apparaissent pas dans le sélecteur et « Tout fermer » ne les touche pas. Le bouton cadenas à côté du X ouvre la section masquée. Vous pouvez aussi masquer une app en balayant sa carte vers le bas dans le sélecteur.",
  "Las apps seleccionadas no aparecen en el selector y «Cerrar todo» no las toca. El botón del candado junto a la X abre la sección oculta. También puedes ocultar una app deslizando su tarjeta hacia abajo en el selector.",
  "Le app selezionate non compaiono nel selettore e «Chiudi tutto» non le tocca. Il pulsante con il lucchetto accanto alla X apre la sezione nascosta. Puoi anche nascondere un’app trascinando la sua scheda verso il basso nel selettore.",
  "Os apps selecionados não aparecem no seletor e “Fechar tudo” não os afeta. O botão de cadeado ao lado do X abre a seção oculta. Você também pode ocultar um app deslizando o cartão para baixo no seletor.",
  "Выбранные приложения не показываются в переключателе, и «Закрыть все» их не трогает. Кнопка с замком рядом с X открывает скрытый раздел. Приложение можно скрыть и смахнув его карточку вниз в переключателе.",
  "所选应用不会显示在应用切换器中，“全部关闭”也不会影响它们。X 旁边的锁形按钮可打开隐藏区域。也可以在应用切换器中向下轻扫卡片来隐藏应用。",
  "選択したAppはAppスイッチャーに表示されず、「すべて閉じる」の対象にもなりません。Xの横の鍵ボタンで非表示セクションが開きます。スイッチャーでカードを下にスワイプして非表示にすることもできます。",
  "선택한 앱은 앱 전환기에 표시되지 않으며 모두 닫기의 영향을 받지 않습니다. X 옆의 자물쇠 버튼을 누르면 숨긴 섹션이 열립니다. 앱 전환기에서 카드를 아래로 쓸어 앱을 숨길 수도 있습니다.",
  "لا تظهر التطبيقات المحددة في مبدّل التطبيقات ولا يغلقها «إغلاق الكل». زر القفل بجانب X يفتح القسم المخفي. يمكنك أيضًا إخفاء تطبيق بسحب بطاقته للأسفل في المبدّل.")
m("Gizli uygulamalar…", "Hidden Apps…", "Versteckte Apps…", "Apps masquées…", "Apps ocultas…",
  "App nascoste…", "Apps ocultos…", "Скрытые…", "隐藏的应用…", "非表示のApp…",
  "숨긴 앱…", "التطبيقات المخفية…")
m("Gizli uygulamalar", "Hidden apps", "Versteckte Apps", "Apps masquées", "Apps ocultas",
  "App nascoste", "Apps ocultos", "Скрытые приложения", "隐藏的应用", "非表示のApp",
  "숨긴 앱", "التطبيقات المخفية")
m("Gizli", "Hidden", "Versteckt", "Masquées", "Ocultas", "Nascoste", "Ocultos", "Скрытые",
  "隐藏", "非表示", "숨김", "المخفية", tweak=True)
m("Gizli bölümde açık uygulama yok", "No open apps in the hidden section",
  "Keine offenen Apps im versteckten Bereich", "Aucune app ouverte dans la section masquée",
  "No hay apps abiertas en la sección oculta", "Nessuna app aperta nella sezione nascosta",
  "Nenhum app aberto na seção oculta", "В скрытом разделе нет открытых приложений",
  "隐藏区域中没有打开的应用", "非表示セクションに開いているAppはありません",
  "숨긴 섹션에 열린 앱이 없습니다", "لا توجد تطبيقات مفتوحة في القسم المخفي", tweak=True)
# 0.6.0 m4: X temalari + kasa kilidi
m("Tema", "Theme", "Design", "Thème", "Tema", "Tema", "Tema", "Тема", "主题", "テーマ", "테마", "السمة")
m("Cam", "Glass", "Glas", "Verre", "Cristal", "Vetro", "Vidro", "Стекло", "玻璃", "ガラス", "유리", "زجاج")
m("Kırmızı", "Red", "Rot", "Rouge", "Rojo", "Rosso", "Vermelho", "Красный", "红色", "レッド", "빨강", "أحمر")
m("Açık", "Light", "Hell", "Clair", "Claro", "Chiaro", "Claro", "Светлая", "浅色", "ライト", "밝게", "فاتح")
m("Mor", "Indigo", "Indigo", "Indigo", "Índigo", "Indaco", "Índigo", "Индиго", "靛蓝", "インディゴ", "인디고", "نيلي")
m("Halka", "Ring", "Ring", "Anneau", "Anillo", "Anello", "Anel", "Кольцо", "光环", "リング", "링", "حلقة")
# 0.6.0 m19: zaten gizli olan karti tekrar asagi atinca
m("Zaten gizli bölümde", "Already in the hidden section", "Bereits im versteckten Bereich", "Déjà dans la section masquée",
  "Ya está en la sección oculta", "Già nella sezione nascosta", "Já está na seção oculta", "Уже в скрытом разделе",
  "已在隐藏区域中", "すでに非表示セクションにあります", "이미 숨긴 섹션에 있습니다", "موجود بالفعل في القسم المخفي", tweak=True)
# 0.6.0 m14: otomatik kapatma + kilit suresi
m("Otomatik kapatma", "Auto Close", "Automatisch schließen", "Fermeture automatique", "Cierre automático",
  "Chiusura automatica", "Fechamento automático", "Автозакрытие", "自动关闭", "自動で閉じる", "자동 닫기", "إغلاق تلقائي")
m("Bu süre boyunca kullanılmayan uygulamalar kendiliğinden kapanır. Korunanlar, gizliler ve çalan müzik kapanmaz.",
  "Apps not used for this long close on their own. Protected and hidden apps and playing music are never closed.",
  "Apps, die so lange nicht benutzt wurden, schließen sich selbst. Geschützte und versteckte Apps sowie laufende Musik bleiben offen.",
  "Les apps inutilisées pendant cette durée se ferment d’elles‑mêmes. Les apps protégées et masquées et la musique en cours ne sont jamais fermées.",
  "Las apps que no se usen durante este tiempo se cierran solas. Las apps protegidas y ocultas y la música en reproducción nunca se cierran.",
  "Le app non usate per questo tempo si chiudono da sole. App protette e nascoste e la musica in riproduzione non vengono mai chiuse.",
  "Apps não usados por esse tempo fecham sozinhos. Apps protegidos e ocultos e a música em reprodução nunca são fechados.",
  "Приложения, не используемые столько времени, закрываются сами. Защищённые и скрытые приложения и играющая музыка не закрываются.",
  "在此时间内未使用的应用会自动关闭。受保护和隐藏的应用以及正在播放的音乐不会被关闭。",
  "この時間使われていないAppは自動で閉じます。保護・非表示のAppと再生中の音楽は閉じません。",
  "이 시간 동안 사용하지 않은 앱은 자동으로 닫힙니다. 보호된 앱, 숨긴 앱, 재생 중인 음악은 닫히지 않습니다.",
  "تُغلق التطبيقات غير المستخدمة طوال هذه المدة تلقائيًا. لا تُغلق التطبيقات المحمية والمخفية والموسيقى قيد التشغيل.")
m("Kullanılmayanları kapat", "Close Unused Apps", "Unbenutzte schließen", "Fermer les apps inutilisées", "Cerrar las no usadas",
  "Chiudi app inutilizzate", "Fechar não usados", "Закрывать неиспользуемые", "关闭未使用的应用", "未使用のAppを閉じる",
  "사용하지 않는 앱 닫기", "إغلاق غير المستخدمة")
m("Kapalı", "Off", "Aus", "Désactivé", "Desactivado", "Disattivato", "Desativado", "Выкл.", "关闭", "オフ", "끔", "إيقاف")
for h in ("1", "3", "6", "12"):
    m(h + " saat sonra", "After " + h + (" hour" if h == "1" else " hours"), "Nach " + h + (" Stunde" if h == "1" else " Stunden"),
      "Après " + h + " h", "Tras " + h + (" hora" if h == "1" else " horas"), "Dopo " + h + (" ora" if h == "1" else " ore"),
      "Após " + h + (" hora" if h == "1" else " horas"), "Через " + h + " ч", h + " 小时后", h + "時間後", h + "시간 후", "بعد " + h + " ساعة")
    m(h + " saat", h + " h", h + " Std.", h + " h", h + " h", h + " h", h + " h", h + " ч", h + " 小时", h + "時間", h + "시간", h + " س")
m("Kilit süresi", "Lock Duration", "Sperrdauer", "Durée du verrouillage", "Duración del bloqueo", "Durata del blocco",
  "Duração do bloqueio", "Длительность блокировки", "锁定时长", "ロックの継続", "잠금 지속", "مدة القفل")
m("Switcher kapanana kadar", "Until Switcher Closes", "Bis der Umschalter schließt", "Jusqu’à la fermeture du sélecteur",
  "Hasta cerrar el selector", "Fino alla chiusura del selettore", "Até fechar o seletor", "До закрытия переключателя",
  "直到切换器关闭", "スイッチャーを閉じるまで", "전환기를 닫을 때까지", "حتى إغلاق المبدّل")
m("Her açılışta", "Every Time", "Jedes Mal", "À chaque ouverture", "Cada vez", "Ogni volta", "Toda vez", "Каждый раз",
  "每次打开", "毎回", "열 때마다", "في كل مرة")
# 0.7.0 b17: kilit suresi - kisa oturum
m("1 dakika", "1 Minute", "1 Minute", "1 minute", "1 minuto", "1 minuto", "1 minuto", "1 минута",
  "1 分钟", "1分", "1분", "دقيقة واحدة")
# 0.6.0 m7: 5 tema (Varsayilan = iOS acik, Koyu = iOS koyu, Aurora)
m("Varsayılan", "Default", "Standard", "Par défaut", "Predeterminado", "Predefinito", "Padrão",
  "По умолчанию", "默认", "デフォルト", "기본", "افتراضي")
m("Koyu", "Dark", "Dunkel", "Sombre", "Oscuro", "Scuro", "Escuro", "Тёмная", "深色", "ダーク", "다크", "داكن")
m("Modern", "Modern", "Modern", "Moderne", "Moderno", "Moderno", "Moderno", "Модерн", "现代", "モダン", "모던", "عصري")
m("Nostalji", "Nostalgia", "Nostalgie", "Nostalgie", "Nostalgia", "Nostalgia", "Nostalgia", "Ностальгия",
  "怀旧", "ノスタルジア", "향수", "حنين")
m("Aurora", "Aurora", "Aurora", "Aurore", "Aurora", "Aurora", "Aurora", "Аврора", "极光", "オーロラ", "오로라", "الشفق")
# 0.7.0: yeni temalar
m("Holografik", "Holographic", "Holografisch", "Holographique", "Holográfico", "Olografico", "Holográfico",
  "Голография", "全息", "ホログラム", "홀로그램", "هولوغرافي")
m("Terminal", "Terminal", "Terminal", "Terminal", "Terminal", "Terminale", "Terminal", "Терминал", "终端",
  "ターミナル", "터미널", "الطرفية")
m("Retro Oyun", "Retro Game", "Retro-Spiel", "Jeu rétro", "Juego retro", "Gioco retrò", "Jogo retrô",
  "Ретро-игра", "复古游戏", "レトロゲーム", "레트로 게임", "لعبة كلاسيكية")
# 0.6.0 m6: buyuk temalar (kasa + butonlar)
m("Neon", "Neon", "Neon", "Néon", "Neón", "Neon", "Neon", "Неон", "霓虹", "ネオン", "네온", "نيون")
m("Cüzdan", "Wallet", "Wallet", "Cartes", "Cartera", "Wallet", "Carteira", "Кошелёк", "钱包", "ウォレット", "지갑", "محفظة")
m("Kasayı kilitle", "Lock Hidden Section", "Versteckten Bereich sperren", "Verrouiller la section masquée",
  "Bloquear sección oculta", "Blocca sezione nascosta", "Bloquear seção oculta", "Блокировать скрытый раздел",
  "锁定隐藏区域", "非表示セクションをロック", "숨긴 섹션 잠금", "قفل القسم المخفي")
m("Açıkken gizli bölüm Face ID ile açılır; Face ID tanımazsa ya da kullanılamazsa iPhone parolası istenir.",
  "When on, the hidden section opens with Face ID; if Face ID fails or isn't available, your iPhone passcode is asked.",
  "Wenn aktiviert, öffnet sich der versteckte Bereich mit Face ID; schlägt Face ID fehl oder ist es nicht verfügbar, wird der iPhone-Code abgefragt.",
  "Si activé, la section masquée s’ouvre avec Face ID ; si Face ID échoue ou n’est pas disponible, le code de l’iPhone est demandé.",
  "Si está activado, la sección oculta se abre con Face ID; si Face ID falla o no está disponible, se pide el código del iPhone.",
  "Se attivo, la sezione nascosta si apre con Face ID; se Face ID non riesce o non è disponibile, viene chiesto il codice dell’iPhone.",
  "Quando ativado, a seção oculta abre com o Face ID; se o Face ID falhar ou não estiver disponível, o código do iPhone é pedido.",
  "Если включено, скрытый раздел открывается с Face ID; если Face ID не сработал или недоступен, запрашивается код-пароль iPhone.",
  "开启后，隐藏区域需通过面容 ID 打开；面容 ID 失败或不可用时将要求输入 iPhone 密码。",
  "オンにすると、非表示セクションはFace IDで開きます。Face IDが失敗したり使えない場合はiPhoneのパスコードが求められます。",
  "켜면 숨긴 섹션이 Face ID로 열립니다. Face ID가 실패하거나 사용할 수 없으면 iPhone 암호를 요청합니다.",
  "عند التشغيل، يُفتح القسم المخفي باستخدام Face ID؛ وإذا فشل Face ID أو لم يكن متاحًا يُطلب رمز iPhone.")
m("Gizli uygulamaları görmek için kimliğini doğrula", "Authenticate to see hidden apps",
  "Authentifiziere dich, um versteckte Apps zu sehen", "Authentifiez-vous pour voir les apps masquées",
  "Autentícate para ver las apps ocultas", "Autenticati per vedere le app nascoste",
  "Autentique-se para ver os apps ocultos", "Подтвердите личность, чтобы увидеть скрытые приложения",
  "验证身份以查看隐藏的应用", "非表示のAppを見るには認証してください", "숨긴 앱을 보려면 인증하세요",
  "تحقق من هويتك لرؤية التطبيقات المخفية", tweak=True)
m("Kilidi açmak için dokun", "Tap to unlock", "Zum Entsperren tippen", "Touchez pour déverrouiller",
  "Toca para desbloquear", "Tocca per sbloccare", "Toque para desbloquear", "Коснитесь, чтобы разблокировать",
  "轻点以解锁", "タップしてロック解除", "탭하여 잠금 해제", "اضغط لإلغاء القفل", tweak=True)
m("Tüm uygulamalar", "All apps", "Alle Apps", "Toutes les apps", "Todas las apps", "Tutte le app",
  "Todos os apps", "Все приложения", "所有应用", "すべてのApp", "모든 앱", "كل التطبيقات")
m("Şelale animasyonu", "Cascade animation", "Kaskadenanimation", "Animation en cascade",
  "Animación en cascada", "Animazione a cascata", "Animação em cascata", "Каскадная анимация",
  "瀑布动画", "カスケードアニメーション", "계단식 애니메이션", "حركة متتالية")
m("Kaydırıcı sola gittikçe animasyon hızlanır, sağa gittikçe yavaşlar.",
  "Move the slider left to speed up the animation, right to slow it down.",
  "Schieberegler nach links beschleunigt die Animation, nach rechts verlangsamt sie.",
  "Déplacez le curseur vers la gauche pour accélérer l'animation, vers la droite pour la ralentir.",
  "Mueve el control a la izquierda para acelerar la animación y a la derecha para ralentizarla.",
  "Sposta il cursore a sinistra per velocizzare l'animazione, a destra per rallentarla.",
  "Mova o controle para a esquerda para acelerar a animação e para a direita para desacelerar.",
  "Сдвиньте ползунок влево, чтобы ускорить анимацию, вправо — чтобы замедлить.",
  "向左拖动滑块可加快动画，向右可减慢动画。",
  "スライダーを左に動かすとアニメーションが速く、右に動かすと遅くなります。",
  "슬라이더를 왼쪽으로 옮기면 애니메이션이 빨라지고, 오른쪽으로 옮기면 느려집니다.",
  "حرّك شريط التمرير لليسار لتسريع الحركة ولليمين لإبطائها.")
m("Animasyon türü", "Animation style", "Animationsstil", "Style d'animation", "Estilo de animación",
  "Stile animazione", "Estilo de animação", "Стиль анимации", "动画样式", "アニメーションの種類",
  "애니메이션 스타일", "نمط الحركة")

# ── HAKKINDA — ActionButtonFix 2.6.1 ile birebir aynı metinler ───────
m("HAKKINDA", "ABOUT", "INFO", "À PROPOS", "ACERCA DE", "INFORMAZIONI", "SOBRE",
  "О ПРОГРАММЕ", "关于", "情報", "정보", "حول")
m("İletişim", "Contact", "Kontakt", "Contact", "Contacto", "Contatti", "Contato",
  "Связаться", "联系", "お問い合わせ", "문의", "تواصل")
m("Sürüm", "Version", "Version", "Version", "Versión", "Versione", "Versão",
  "Версия", "版本", "バージョン", "버전", "الإصدار")
m("© 2026 muratkurt · Claude Opus 5 ile geliştirildi",
  "© 2026 muratkurt · Built with Claude Opus 5", "© 2026 muratkurt · Entwickelt mit Claude Opus 5",
  "© 2026 muratkurt · Développé avec Claude Opus 5", "© 2026 muratkurt · Desarrollado con Claude Opus 5",
  "© 2026 muratkurt · Sviluppato con Claude Opus 5", "© 2026 muratkurt · Desenvolvido com Claude Opus 5",
  "© 2026 muratkurt · Разработано с Claude Opus 5", "© 2026 muratkurt · 使用 Claude Opus 5 开发",
  "© 2026 muratkurt · Claude Opus 5 で開発", "© 2026 muratkurt · Claude Opus 5로 개발",
  "© 2026 muratkurt · طُوِّر باستخدام Claude Opus 5")


def esc(s):
    return s.replace("\\", "\\\\").replace('"', '\\"')

KOK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 1) Root.strings
for d in DILLER:
    klasor = os.path.join(KOK, "kasprefs", "Resources", d + ".lproj")
    os.makedirs(klasor, exist_ok=True)
    with open(os.path.join(klasor, "Root.strings"), "w", encoding="utf-8") as f:
        f.write("/* KASwitcher — tools/dil-uret.py tarafından üretildi, elle düzenleme. */\n\n")
        for anahtar, cev, _ in M:
            f.write('"%s" = "%s";\n' % (esc(anahtar), esc(cev[d])))

# 2) KASDil.m
tw = [(a, c) for a, c, t in M if t]
with open(os.path.join(KOK, "KASDil.m"), "w", encoding="utf-8") as f:
    f.write("// KASwitcher — SpringBoard metinleri. tools/dil-uret.py tarafından üretildi,\n")
    f.write("// ELLE DÜZENLEME: metni dil-uret.py'de değiştir ve yeniden üret.\n")
    f.write("#import <Foundation/Foundation.h>\n\n")
    f.write("// Cihaz dilini desteklenen koda indirger; listede yoksa \"en\".\n")
    f.write("static NSString *ka_dilKodu(void) {\n")
    f.write("    NSString *l = [[NSLocale preferredLanguages] firstObject] ?: @\"en\";\n")
    f.write("    if ([l hasPrefix:@\"zh\"]) return @\"zh-Hans\";\n")
    f.write("    NSString *k = l.length >= 2 ? [l substringToIndex:2] : l;\n")
    f.write("    NSArray *destek = @[%s];\n" % ", ".join('@"%s"' % d for d in DILLER))
    f.write("    return [destek containsObject:k] ? k : @\"en\";\n}\n\n")
    f.write("// Anahtar = Türkçe kaynak metin. Çeviri yoksa İngilizce, o da yoksa anahtar döner.\n")
    f.write("NSString *ka_L(NSString *tr) {\n")
    f.write("    static NSDictionary<NSString *, NSDictionary<NSString *, NSString *> *> *tablo;\n")
    f.write("    static NSString *dil;\n")
    f.write("    static dispatch_once_t once;\n")
    f.write("    dispatch_once(&once, ^{\n")
    f.write("        dil = ka_dilKodu();\n")
    f.write("        tablo = @{\n")
    for d in DILLER:
        if d == "tr":
            continue
        f.write('            @"%s": @{\n' % d)
        for a, c in tw:
            f.write('                @"%s": @"%s",\n' % (esc(a), esc(c[d])))
        f.write("            },\n")
    f.write("        };\n")
    f.write("    });\n")
    f.write("    if (!tr) return @\"\";\n")
    f.write("    if ([dil isEqualToString:@\"tr\"]) return tr;\n")
    f.write("    NSString *v = tablo[dil][tr] ?: tablo[@\"en\"][tr];\n")
    f.write("    return v ?: tr;\n}\n")

print("diller:", len(DILLER), "metin:", len(M), "tweak metni:", len(tw))
