// atb-compile — turns a domain blocklist (HaGeZi etc.) into the binary
// lookup file the tweak memory-maps. Run once per list update.
//
//   atb-compile <input.txt> [output.bin]   compile (atomic write)
//   atb-compile --match <list.bin> <host>  match + measure lookup time
//
// Default output is the path the tweak reads (Common.h ATB_BLOCKLIST,
// under the jailbreak root). Format: Blocklist.h.
//
// Paths: on RootHide a shell lives in the jbroot namespace while this
// binary sees the real root, so a shell path may not exist here. Each
// path is tried as given first, then under the jailbreak root.
//
// The jailbreak root is derived from this binary's own location
// (<root>/usr/bin/atb-compile), not from libroothide: linking libroothide
// made dyld fail on RootHide with errno=1 for a tool in /usr/bin
// (measured, 1 Oct 2026). The same code gives /var/jb on rootless and ""
// on rootful.
#include "../../Blocklist.h"
#include "../../Common.h"
#include <mach-o/dyld.h>
#include <errno.h>
#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <mach/mach_time.h>

static int cmp_u64(const void *a, const void *b) {
    uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b;
    return x < y ? -1 : x > y;
}

static double ns_per_tick(void) {
    mach_timebase_info_data_t tb; mach_timebase_info(&tb);
    return (double)tb.numer / tb.denom;
}

// <root> + path, where this binary is <root>/usr/bin/<name>.
static const char *jbroot(const char *path) {
    static char root[1024];
    static int done;
    if (!done) {
        char exe[1024]; uint32_t size = sizeof exe;
        if (_NSGetExecutablePath(exe, &size) == 0) {
            char *cut = strstr(exe, "/usr/bin/");
            if (cut) { *cut = 0; strlcpy(root, exe, sizeof root); }
        }
        done = 1;
    }
    // A fresh copy per call: input and output paths are resolved one after
    // the other and must not share a buffer. (Short-lived CLI; not freed.)
    size_t n = strlen(root) + strlen(path) + 1;
    char *out = malloc(n);
    if (out) snprintf(out, n, "%s%s", root, path);
    return out ? out : path;
}

// Existing file: as given, else under the jailbreak root.
static const char *resolve_input(const char *p) {
    if (access(p, R_OK) == 0) return p;
    const char *j = jbroot(p);
    return (j && access(j, R_OK) == 0) ? j : p;
}

// Output: its directory must exist; as given, else via jbroot().
static const char *resolve_output(const char *p) {
    char tmp[1024];
    strlcpy(tmp, p, sizeof tmp);
    if (access(dirname(tmp), W_OK) == 0) return p;
    const char *j = jbroot(p);
    return j ? j : p;
}

static void make_parent(const char *path) {
    char tmp[1024];
    strlcpy(tmp, path, sizeof tmp);
    char *d = dirname(tmp);
    for (char *s = d + 1; *s; s++) if (*s == '/') { *s = 0; mkdir(d, 0755); *s = '/'; }
    mkdir(d, 0755);
}

static int compile(const char *in, const char *out) {
    uint64_t t0 = mach_absolute_time();
    FILE *f = fopen(in, "r");
    if (!f) { fprintf(stderr, "cannot read %s: %s\n", in, strerror(errno)); return 1; }
    size_t cap = 1 << 18, n = 0, skipped = 0, lines = 0;
    uint64_t *hs = malloc(cap * sizeof *hs);
    char line[512];
    while (fgets(line, sizeof line, f)) {
        lines++;
        char *s = line;
        while (*s == ' ' || *s == '\t') s++;
        if (*s == '#' || *s == '!' || *s == '\n' || *s == '\r' || !*s) continue;
        if (!strncmp(s, "0.0.0.0 ", 8)) s += 8;            // hosts format
        if (!strncmp(s, "||", 2)) s += 2;                  // adblock format
        if (!strncmp(s, "*.", 2)) s += 2;                  // wildcard format
        size_t len = strcspn(s, " \t\r\n^#");
        int ok = len > 0 && len <= 253;
        for (size_t i = 0; ok && i < len; i++) {
            char c = s[i];
            if (c >= 'A' && c <= 'Z') c = (char)(c + 32), s[i] = c;
            if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_')) ok = 0;
        }
        if (!ok) { skipped++; continue; }
        if (n == cap) { cap *= 2; hs = realloc(hs, cap * sizeof *hs); }
        hs[n++] = atb_hash(s, len);
    }
    fclose(f);
    size_t valid = n;
    qsort(hs, n, sizeof *hs, cmp_u64);
    size_t u = 0;
    for (size_t i = 0; i < n; i++) if (u == 0 || hs[i] != hs[u - 1]) hs[u++] = hs[i];

    atb_header h; memset(&h, 0, sizeof h);
    memcpy(h.magic, ATB_LIST_MAGIC, 8);
    h.count = u; h.lines = valid; h.built = (uint64_t)time(NULL);
    make_parent(out);
    char tmp[1100];
    snprintf(tmp, sizeof tmp, "%s.%d.tmp", out, (int)getpid());
    FILE *o = fopen(tmp, "wb");
    if (!o) { fprintf(stderr, "cannot write %s: %s\n", tmp, strerror(errno)); return 1; }
    int ok = fwrite(&h, sizeof h, 1, o) == 1 && fwrite(hs, sizeof *hs, u, o) == u;
    ok = (fclose(o) == 0) && ok;
    if (!ok || rename(tmp, out) != 0) { fprintf(stderr, "cannot write %s: %s\n", out, strerror(errno)); unlink(tmp); return 1; }
    double ms = (mach_absolute_time() - t0) * ns_per_tick() / 1e6;
    printf("lines=%zu valid=%zu unique=%zu duplicates=%zu skipped=%zu bytes=%zu ms=%.1f\n",
           lines, valid, u, valid - u, skipped, sizeof h + u * sizeof *hs, ms);
    printf("written: %s\n", out);
    free(hs);
    return 0;
}

static int match(const char *path, int argc, char **argv) {
    atb_list l;
    uint64_t t0 = mach_absolute_time();
    int r = atb_list_open(path, &l);
    double open_us = (mach_absolute_time() - t0) * ns_per_tick() / 1e3;
    if (r) { fprintf(stderr, "cannot open list %s (r=%d)\n", path, r); return 1; }
    printf("list count=%llu open_us=%.1f\n", (unsigned long long)l.count, open_us);
    const int N = 200000;
    for (int i = 0; i < argc; i++) {
        int m = atb_list_match(&l, argv[i]);
        volatile int sink = 0;
        uint64_t a = mach_absolute_time();
        for (int k = 0; k < N; k++) sink += atb_list_match(&l, argv[i]);
        double ns = (mach_absolute_time() - a) * ns_per_tick() / N;
        (void)sink;
        printf("%-45s %-8s %s  ns/lookup=%.0f\n", argv[i], m >= 0 ? "BLOCK" : "allow",
               m >= 0 ? argv[i] + m : "-", ns);
    }
    return 0;
}

int main(int argc, char **argv) {
    if (argc >= 4 && !strcmp(argv[1], "--match"))
        return match(resolve_input(argv[2]), argc - 3, argv + 3);
    if ((argc == 2 || argc == 3) && argv[1][0] != '-') {
        const char *out = argc == 3 ? resolve_output(argv[2]) : jbroot(ATB_BLOCKLIST);
        return compile(resolve_input(argv[1]), out);
    }
    fprintf(stderr, "usage:\n  atb-compile <input.txt> [output.bin]\n  atb-compile --match <list.bin> <host>...\n");
    return 2;
}
