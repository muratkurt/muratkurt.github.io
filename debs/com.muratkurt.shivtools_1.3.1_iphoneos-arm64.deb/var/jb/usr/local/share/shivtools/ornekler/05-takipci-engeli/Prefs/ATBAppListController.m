// AppTrackerBlock — app picker (dynamic list, stock PSSpecifier path).
// One controller serves two lists; the linking row's 'atbKey' property in
// Root.plist says which (default: 'excluded').
//   excluded              checked = the tweak hooks nothing in that app
//   blockingDisabledApps  checked = nothing is blocked there; logging continues
// No @"..." literals and no blocks handed to the system (Settings is arm64e).
#import "ATBAppListController.h"
#import <Preferences/PSSpecifier.h>
#import <notify.h>
#import "Common.h"
#import "ATBStyle.h"

@interface LSApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (NSArray *)allInstalledApplications;
@end
@interface LSApplicationProxy : NSObject
- (NSString *)localizedName;
- (NSString *)applicationIdentifier;
- (NSString *)applicationType;
@end

static NSInteger byName(id a, id b, void *ctx) {
    return [[a localizedName] localizedCaseInsensitiveCompare:[b localizedName]];
}

@interface ATBAppListController () {
    NSMutableArray<NSString *> *_checked;
    NSArray *_apps;
}
@end

@implementation ATBAppListController

- (CFStringRef)copyDomain {
    return CFStringCreateWithCString(NULL, ATB_DOMAIN, kCFStringEncodingUTF8);
}

- (NSString *)prefKey {
    id k = [self.specifier propertyForKey:ATBS("atbKey")];
    return [k isKindOfClass:[NSString class]] ? k : ATBS(ATB_KEY_EXCLUDED);
}

- (BOOL)isExclusionList {
    return [[self prefKey] isEqualToString:ATBS(ATB_KEY_EXCLUDED)];
}

// Key never written: the exclusion list starts from the defaults, the other one empty.
- (NSMutableArray *)readChecked {
    CFStringRef domain = [self copyDomain];
    CFPreferencesAppSynchronize(domain);
    id v = (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)[self prefKey], domain);
    CFRelease(domain);
    if ([v isKindOfClass:[NSArray class]]) return [v mutableCopy];
    NSMutableArray *l = [NSMutableArray array];
    if ([self isExclusionList])
        for (int i = 0; kATBDefaultExcluded[i]; i++) [l addObject:ATBS(kATBDefaultExcluded[i])];
    return l;
}

- (void)writeChecked {
    CFStringRef domain = [self copyDomain];
    CFPreferencesSetAppValue((__bridge CFStringRef)[self prefKey],
                             (__bridge CFPropertyListRef)_checked, domain);
    CFPreferencesAppSynchronize(domain);
    CFRelease(domain);
    notify_post(ATB_NOTIFY);
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _checked = [self readChecked];
    [self reloadSpecifiers];
}

- (NSArray *)installedApps {
    if (_apps) return _apps;
    NSMutableArray *l = [NSMutableArray array];
    NSString *user = ATBS("User");
    NSString *wallet = ATBS("com.apple.Passbook");
    for (LSApplicationProxy *p in [[LSApplicationWorkspace defaultWorkspace] allInstalledApplications]) {
        NSString *bid = [p applicationIdentifier];
        if (!bid.length || [p localizedName].length == 0) continue;
        // User apps + Apple Wallet (a system app).
        if (![[p applicationType] isEqualToString:user] && ![bid isEqualToString:wallet]) continue;
        [l addObject:p];
    }
    [l sortUsingFunction:byName context:NULL];
    _apps = l;
    return _apps;
}

- (NSArray *)specifiers {
    if (!_checked) _checked = [self readChecked];
    NSMutableArray *s = [NSMutableArray array];
    BOOL exclusion = [self isExclusionList];
    // The explanation goes ABOVE the list: as a footer it ended up below
    // dozens of apps where nobody reads it (seen on device).
    PSSpecifier *intro = [PSSpecifier preferenceSpecifierNamed:nil target:self set:NULL get:NULL
                                                        detail:Nil cell:PSGroupCell edit:Nil];
    [intro setProperty:(exclusion
                        ? ATBL("For sensitive apps such as banking and payment: checked apps are not touched at all — no blocking, no logging. Takes effect the next time the app opens.")
                        : ATBL("For apps that break when trackers are blocked (e.g. apps that need Firebase): nothing is blocked in checked apps, but with the developer log on their requests are still logged. Takes effect the next time the app opens."))
                forKey:ATBS("footerText")];
    [s addObject:intro];
    PSSpecifier *g = [PSSpecifier preferenceSpecifierNamed:(exclusion ? ATBL("Excluded apps") : ATBL("Apps without blocking"))
                                                    target:self set:NULL get:NULL
                                                    detail:Nil cell:PSGroupCell edit:Nil];
    [s addObject:g];

    NSString *bidKey = ATBS("atbBundleID");
    for (LSApplicationProxy *p in [self installedApps]) {
        NSString *bid = [p applicationIdentifier];
        PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:[p localizedName]
                                                         target:self set:NULL get:NULL
                                                         detail:Nil cell:PSStaticTextCell edit:Nil];
        [sp setProperty:bid forKey:bidKey];
        [sp setProperty:bid forKey:ATBS("id")];
        [sp setProperty:bid forKey:ATBS("appIDForLazyIcon")];
        [sp setProperty:@YES forKey:ATBS("useLazyIcons")];
        sp->action = @selector(toggleApp:);
        [s addObject:sp];
    }
    _specifiers = s;
    return _specifiers;
}

// The check mark is drawn from the source list, not stored in the
// specifier, so a reused cell never shows a stale state.
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *c = [super tableView:tv cellForRowAtIndexPath:ip];
    NSString *bid = [[self specifierAtIndexPath:ip] propertyForKey:ATBS("atbBundleID")];
    c.accessoryType = (bid && [_checked containsObject:bid])
        ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    return c;
}

- (void)toggleApp:(PSSpecifier *)sp {
    NSString *bid = [sp propertyForKey:ATBS("atbBundleID")];
    if (!bid) return;
    if ([_checked containsObject:bid]) [_checked removeObject:bid];
    else                               [_checked addObject:bid];
    [self writeChecked];
    [self reloadSpecifiers];
}

@end
