# 06 — Yeniden değerlendirme: gizleme, kasa, kasaya atma, sabitleme

**Tarih:** 2026-10-03 · **Durum:** KARAR BEKLİYOR — bu belge onaylanmadan kod yazılmaz.
**Neden:** 0.6.0'da her çözüm yeni bir sorun getirdi (m14 → m35). Kullanıcı kararı: "en temelden,
en doğru yere göre" yeniden kur; gerekirse switcher'ı da kendimiz yönetiriz.

Etiketler: **ÖLÇÜLDÜ** (cihazda/VM'de günlükle görüldü) · **DSC** (dyld cache disasm, canlıda
sınanmadı) · **DOĞRULANMADI** (çıkarım).

Ortamlar: RootHide iPhone16,1 iOS 17.0.3 · rootless iPhone11,2 (XS) iOS 16.1.1 ·
vphone iPhone17,3 iOS 26.6.2 · DSC: 16.1.1 (XS'ten çekildi, `HAM-VERI/dsc-16.1.1-iPhone11,2/`),
17.0.3, 18.6.2, 26.6.2, 27.0 (Mac'te bağlı).

---

## 1. Ne öğrendik — sağlam zemin

### 1.1 Switcher kartları nereden geliyor
- Görünüm listesi = `-[SBFluidSwitcherViewController _unadjustedAppLayouts]` = koordinatörün
  `appLayoutsForSwitcherContentController:` → `appLayoutsForSwitcherController:` (DSC 26).
- Kurucu, **ekranın o anki düzenindeki** (`layoutState` → `itemForLayoutRole:`) uygulamayı listede yoksa
  **kendisi ekliyor** (DSC 26). Ayrıca switcher açılırken öndeki düzeni
  `_activeAppLayoutWhenActivatingMainSwitcher` olarak saklıyor (17: koordinatör ivar'ı, 26:
  `SBSwitcherController` özelliği).
- Sonuç (ÖLÇÜLDÜ, vphone m29): kendi süzgecimiz recents'ten çıkarsa da **öndeki uygulamanın kartı
  geri eklenir** (model 9, görünüm 10).
- Görünüm listesinden kartı zorla çıkarmak SpringBoard'u düşürür (ÖLÇÜLDÜ, vphone m30:
  `-[SBDeckSwitcherModifier frameForIndex:]` NSInternalInconsistency, safe mode). **Apple'ın listesine
  dışarıdan dokunmak yasak.**

### 1.2 Apple bir kartı nasıl kaldırıyor (yukarı atma)
- `-[SBFluidSwitcherViewController removeLayoutRole:inSpace:mutationBlock:reason:]` — stok kaldırma +
  animasyon. Blok Apple'da **yalnız liste işi** (model `remove:/hide:/replace…` + `_rebuildAppListCache`);
  uygulamayı kapatma ayrı adım (`_performSceneDestructionForModelRemovalResults:`) (DSC 26; imza 17'de de var).
- Kaldırma bitince `-[SBDeckSwitcherModifier handleRemovalEvent:]` (faz 2):

| iOS | Kural (DSC) |
|---|---|
| 16.1.1 | yalnız "kart kalmadıysa → ana ekran" |
| 17.0.3 / 18.6.2 / 26.6.2 | + "kaldırılan = arkadaki düzen (`_currentAppLayout`) → arkayı ana ekrana çevir, **switcher açık kalsın**" (`homeScreenAppLayout`, `unlockedEnvironmentMode=2`) |

- 0.6.0~m31–m35 bu yolu kullanıyor ve **üç ortamda tek atışta çalışıyor** (ÖLÇÜLDÜ, kullanıcı testi:
  RootHide 20–30 denemede 1 takılma, XS "RootHide'dan da iyi", vphone). Öğrenilen tuzaklar:
  - m28 (öndeki düzen kaydını nil yapmak) Apple'ın faz-2 eşleşmesini bozuyordu → kaldırıldı (m32, ÖLÇÜLDÜ).
  - Apple'ın `bos-layout` geçişini bizim `performTransition` kancamız "ana ekrana dönüş" sanıp
    `ka_butonGizle` çalıştırıyor, `kaAtilanlar`'ı siliyordu (m34, ÖLÇÜLDÜ). Butonların ilk denemede
    farklı çizilmesinin de büyük ihtimalle sebebi (DOĞRULANMADI).
  - iOS 16'da arkayı ana ekrana çeviren isteği biz gönderiyoruz (m35).

### 1.3 Apple'ın kendi gizleme mekanizması (YENİ — hiç kullanılmadı)
- `SBAppLayout` kendi **`hidden`** bayrağını taşıyor; `appLayoutByModifyingHiddenState:` 16, 17, 26'da var (DSC).
- `-[SBRecentAppLayouts hide:al]` = `remove:al` → `addToFront:[al appLayoutByModifyingHiddenState:YES]` (DSC 17).
  `-[SBAppSwitcherModel hide:]` bunu çağırıyor. Apple kendi kaldırma bloğunda da `hide:` kullanıyor (DSC 26).
- `recentsIncludingHiddenAppLayouts:NO` gizlileri Apple'ın kuralıyla düşürüyor; `_unhiddenRecents` önbelleği var.
- Elenen yol (ÖLÇÜLDÜ, m23): `-[SBApplication hasHiddenTag]` → 30/30 çağrı `SpringBoardHome` → kancalanırsa
  **ana ekran simgeleri de kaybolur.** `hide:` bundan farklı: düzenin bayrağı, uygulamanın etiketi değil.

### 1.4 Kasa ve Face ID
- Kasa = switcher'a bağlı kendi penceremiz. Face ID (LAContext, SpringBoard içinde, `CoreAuthUI` öne gelir)
  switcher'ı gizliyor; doğrulama sonrası yoklama switcher'ı kapalı buluyor → kasa kapanıyor, son uygulama
  açılıyor (ÖLÇÜLDÜ, RootHide, 15/15).
- **Bugünkü değişikliklerden değil:** 0.6.0~m25'te de aynı (ÖLÇÜLDÜ, A/B, 3 Ekim). m14'teki "switcher
  kendiliğinden geri geliyor" ölçümü artık tutmuyor (sebebi DOĞRULANMADI).
- Kasanın ömrü switcher'ın ömrüne bağlı olduğu sürece Face ID ile kavga eder.

### 1.5 Sabitleme
- Kodda var, **teşhis için kapalı** (`kKA_Teshis = YES`). Sabit + gizli birlikteliği hiç ele alınmadı.

---

## 2. Mevcut mimarinin kırılgan noktaları

| Bileşen | Şimdi | Neden kırılgan |
|---|---|---|
| Gizleme | Kendi süzgecimiz (`recentsIncludingHiddenAppLayouts:` sonucunu süz) + istisnalar (`kaAtilanlar`, "öndeki gizli uygulama") | Apple'ın listesiyle **iki doğru** var; öndeki düzen, kurucu, geçişler bizim listemizi bilmiyor. Her istisna bir zamanlama penceresi (m23 400 ms, m24, m34) doğurdu |
| Kasa | Switcher'a bağlı kendi penceresi | Switcher kapanınca kasa kapanır; Face ID switcher'ı kapatıyor → kasa kapanıyor |
| Kasaya atma | Stok kaydırma + bizim karar + stok kaldırma (m31–m35) | Çalışıyor; ama gizleme bizim süzgecimizde olduğu için kaldırmadan sonra listeyi elle yeniliyoruz |
| Geçiş yorumu | `performTransition` kancasında yön tahmini → `ka_butonGizle` (kasa kapatma, liste silme dahil) | Apple'ın her yeni geçişi (bos-layout, iOS 16 `yon=app`) yanlış yorumlanabiliyor; tek fonksiyon çok iş yapıyor |

**Kök sebep:** gizli durumun sahibi biz değiliz ama öyleymiş gibi davranıyoruz (ABF §4b dersi: *tutan
hook'lanır*). Apple'ın gerçek sahibi `SBRecentAppLayouts` + `SBAppLayout.hidden`.

---

## 3. Seçenekler

### 3.1 Gizleme
| | Yol | Artı | Eksi |
|---|---|---|---|
| A1 | Şimdiki süzgeç | çalışıyor (m34/m35) | iki doğru, istisnalar, zamanlama pencereleri |
| **A2** | **Apple'ın `hidden` bayrağı** (`SBAppSwitcherModel hide:`); bizim tercih listemiz yalnız "hangi uygulamalar gizli olmalı" | gizli durumun sahibi Apple → kurucu, öndeki kart, animasyon, kaldırma tutarlı (DOĞRULANMADI); süzgeç + istisnalar kalkar | uygulama yeniden açılınca Apple yeni (gizli olmayan) düzen ekler → yeniden gizlemek gerekir; kalıcılık (respring) bilinmiyor; gizliden çıkarma için `hide:`'ın tersi yok (`appLayoutByModifyingHiddenState:NO` + değiştir) |
| A3 | `hasHiddenTag` | — | **ELENDİ** (simgeler kaybolur, m23) |

### 3.2 Kasa
| | Yol | Artı | Eksi |
|---|---|---|---|
| B1 | Switcher'a bağlı panel (şimdiki) | switcher içinde, hızlı | Face ID ile kavga; kapanma bağımlılığı |
| **B2** | **Switcher'dan bağımsız kasa:** butona basınca switcher stok yoldan kapanır (ana ekran), kasa kendi penceresinde açılır, Face ID o pencerenin üstünde serbest | switcher'ın ömrüyle bağ yok → Face ID sorunu yapısal olarak kalkar; kasa kendi yaşam döngüsünü yönetir | switcher'dan bir an çıkılır (görsel geçiş tasarlanmalı); uygulamayı kasadan açma = stok `launchApplicationWithIdentifier:` |
| B3 | Switcher'ın "gizli mod"u (yalnız gizli kartlar) | gerçek kartlar | Face ID sorunu B1 ile aynı |

### 3.3 Kasaya atma
| | Yol | Not |
|---|---|---|
| **C1** | Aşağı atma + stok kaldırma (m31–m35) | çalışıyor; A2 ile blok `model hide:` olur → Apple'ın kendi gizleme işi, liste yenileme gereksiz (DOĞRULANMADI) |
| C2 | Kart menüsü "Kasaya taşı" | yedek yol / erişilebilirlik; C1'in yerine değil |

### 3.4 Sabitleme kuralları (karar gerekiyor)
| Durum | Önerilen kural |
|---|---|
| Sabit + "Tümünü Kapat" | dokunma (bugünkü davranış) |
| Sabit + aşağı atma | kasaya gider, sabitliği korunur (kasada da "Tümünü Kapat" dokunmaz) |
| Kasadaki sabit + oto-kapatma | dokunma |
| Sabitleme açma | basılı tutma süresi uzatılıp geri açılır (devir notu #5) — ayrı tur |

### 3.5 Kendi switcher'ımız (D)
**Önerilmiyor.** SpringBoard switcher'ı canlı sahne görüntüleri, hareket/geçiş altyapısı, çoklu düzen ve
iOS sürümüne göre değişen kurallarla geliyor (bkz. §1.2 tablo: iki sürüm, iki kural). Kendi switcher'ımız
her iOS sürümünde ayrı bir ürün olur. Doğru yer: switcher'ı Apple'a bırakıp **gizli durumu (A2) ve kasayı (B2)
ondan bağımsızlaştırmak.**

---

## 4. Önerilen mimari (0.7)

**A2 + B2 + C1**, `performTransition` yorumu sadeleştirilir:
1. **Gizli liste (tercih)** = tek gerçek kaynak: "hangi uygulamalar gizli olmalı".
2. **Uygulama:** gizli listedeki uygulamaların switcher düzenleri Apple'ın `hidden` bayrağıyla gizlenir
   (`model hide:`). Apple yeni görünür düzen eklediğinde (uygulama yeniden açıldı) yeniden uygulanır.
   Kendi süzgecimiz, `kaAtilanlar`, m23/m34 pencereleri, m28, m33 **kalkar** (hedef).
3. **Aşağı atma:** stok `removeLayoutRole:` + blokta `model hide:`; iOS 16'da m35 isteği kalır.
4. **Kasa:** switcher'dan bağımsız pencere; açılışta switcher stok yoldan kapanır; Face ID kasa penceresinde.
   Kasadan uygulama açma = stok başlatma; kasadan çıkarma = bayrağı geri al + tercihten sil.
5. **`ka_butonGizle`** yalnız buton işi yapar; kasa ve liste işleri ondan ayrılır.

## 5. Ölçüm planı — kod yazmadan önce (sırayla, her biri küçük, yalnız-ölçüm)

| # | Soru | Nasıl | Nerede |
|---|---|---|---|
| M1 | `model hide:` ile gizlenen düzen switcher'dan düşüyor mu — **öndeki uygulama dahil** | tek seferlik deneme kancası (imza doğrulamalı), günlük | vphone → RootHide → XS |
| M2 | Gizli uygulama ana ekrandan açılınca ne olur (yeni görünür düzen mi, gizli düzen mi açılır) | günlük: `addToFront:` / `_setRecents:` | vphone |
| M3 | Gizli bayrak respring sonrası kalıcı mı | gizle → respring → `recentsIncludingHiddenAppLayouts:YES` sayısı | vphone |
| M4 | Gizliden çıkarma: `appLayoutByModifyingHiddenState:NO` ile değiştirme kart görünür mü | deneme | vphone |
| M5 | B2 prototipi: switcher kapatılıp kasa penceresinde Face ID → kasa açık kalıyor mu | ayrı küçük dal | RootHide (Face ID'li tek cihaz) |

M1 olumsuz çıkarsa A2 düşer, A1 (bugünkü m34/m35) korunur ve yalnız B2 + `ka_butonGizle` ayrıştırması yapılır.

## 6. Bugünkü durum (geri dönüş noktası)
- `SOURCE-0.6.0` = **m35**: RootHide m34, XS m35, vphone m34 kurulu. Aşağı atma üç ortamda tek atışta çalışıyor.
- Açık: Face ID ile kasa kapanıyor (m25'ten beri), iOS 26'da kasa kart köşelerinde beyazlık (tasarım),
  sabitleme kapalı, ölçüm kancaları (m27/m29/m33 günlükleri) temizlenmedi.

---

## 7. ÖLÇÜM SONUÇLARI — M1–M4 (vphone iOS 26.6.2, `PROBE-0.7/` KASProbe 0.1–0.4, KASwitcher kaldırılmış hâlde)

Araç: KASwitcher'dan bağımsız ölçüm tweak'i; yalnız komutla (`kasprobe-cmd.txt`) dokunur, her özel çağrı
imza birebir tutarsa yapılır. Bu sayede ölçülen şey Apple'ın davranışı, bizim süzgecimiz değil.

| # | Soru | Sonuç |
|---|---|---|
| M1a | Arka plandaki kart `model hide:` ile düşüyor mu | **EVET** — model 11→10, görünüm listesi **kendiliğinden** 10 (yenileme bile gerekmedi) |
| M1b | Öndeki kart yalnız `hide:` ile | **HAYIR** — model gizledi (`mobilemail(G)`), görünüm değişmedi (kurucu arkadaki düzeni ekliyor) |
| M1c | Öndeki kart: stok `removeLayoutRole:` + blokta `hide:` + `_rebuildAppListCache` (Apple'ın sırası) | Apple arkayı ana ekrana çeviren geçişi **istiyor** (`GECIS-ISTEGI duzen=[ana ekran] gesture=0`), ama kart kalıyor: Apple'ın blok-içi yenilemesi geçiş bitmeden. **Geçişten sonra bir `_rebuildAppListCache` → kart düştü** (ÖLÇÜLDÜ) |
| M1c' | Kaldırmaya model nesnesi mi görünümün nesnesi mi | görünümün kendi düzeni verilince geçiş istendi; model nesnesiyle istek görülmedi (o turda geçiş kancası yoktu — kesin karşılaştırma DOĞRULANMADI). **Kural: görünümün düzenini ver** |
| M2 | Gizli uygulama ana ekrandan açılınca | `appSwitcherModel:willAddAppLayout:replacingAppLayouts:removingAppLayouts:` **gizli olmayan** yeni düzen ekliyor, gizli düzenin yerine geçiyor → uygulama kendiliğinden gizliden çıkıyor |
| M3 | Gizli bayrak respring sonrası kalıcı mı | **EVET** — respring sonrası model `mobilemail(G), Maps(G)` |
| M4 | Gizliden çıkarma: `replaceAppLayout:withAppLayout:` + `appLayoutByModifyingHiddenState:NO` | **EVET** — kart aynı sırada geri geldi, görünüm hemen güncellendi |

### 7.1 Öndeki kartın stok tarifi (ÖLÇÜLDÜ, 26)
1. `-[SBFluidSwitcherViewController removeLayoutRole:inSpace:mutationBlock:reason:]` — `inSpace` = görünümün `appLayouts` listesindeki düzen, `reason` = 1.
2. Blok: `[model hide:al]` + `[koordinatör _rebuildAppListCache]` (Apple'ın blok-içi sırası).
3. Arkayı ana ekrana çeviren geçiş: 17+ Apple kendisi (DSC); **16'da biz** (m35, XS'te ÖLÇÜLDÜ).
4. Geçiş bitince bir kez daha `_rebuildAppListCache` (`layoutStateTransitionCoordinator:transitionDidEndWithTransitionContext:`, m33 deseni — yalnız bu kaldırmayı biz başlattıysak).

m34'ün neden çalıştığı da bu: aynı dört adımı kendi süzgecimiz + istisnalar üzerinden dolaylı yapıyordu.

### 7.2 Kasada kalıcılık (M2'nin sonucu — DENENMEDİ)
Kasadaki uygulama yeniden açılınca gizli kalmalı. Stok yer: `appSwitcherModel:willAddAppLayout:…`'un **dönüş değeri**
eklenecek düzen (`sonuc=`). Kasadaki uygulama için dönen düzeni `appLayoutByModifyingHiddenState:YES` yapmak → Apple
baştan gizli ekler. Öndeyken kartı yine görünür (kurucu arkadaki düzeni ekliyor — eski "kullanılan gizli uygulama
kaybolmasın" davranışının aynısı, bu sefer Apple'dan).

### 7.3 Sonuç
**A2 (Apple'ın gizli bayrağı) geçerli.** Kendi süzgecimiz (`recentsIncludingHiddenAppLayouts:` kancası), `kaAtilanlar`,
m23/m34 pencereleri, m28, m30 artık gereksiz. Kalan: §7.2 denemesi, iOS 17 ve 16'da M1/M2 tekrarı, M5 (bağımsız kasa + Face ID).

---

## 8. UYGULAMA — `SOURCE-0.7.0`, 0.7.0~a1 → b4 (3 Ekim 2026)

### 8.1 1. aşama — gizleme Apple'ın bayrağıyla (a1–a3)
- Yeni dosya **`KASGizle.h/.m`**: Apple'ın stok çağrıları tek yerde, her biri imza birebir tutarsa:
  `kas_gizle` (model `hide:`), `kas_goster` (`appLayoutByModifyingHiddenState:NO` + `replaceAppLayout:`),
  `kas_kartiKaldir` (stok `removeLayoutRole:` + blokta `hide:` + `_rebuildAppListCache`; 16'da arka-ana-ekran isteği),
  `kas_willAddDuzelt` (§7.2), `kas_esitle` (tercih farkı), `kas_kasaBidleri` (kasa içeriği modelden), `kas_gecisBasladi/Bitti`.
- `Tweak.x`'ten KALKANLAR: kendi süzgeç (`recentsIncludingHiddenAppLayouts:` kancası, `ka_gizliSuz`), `kaAtilanlar`,
  `ka_switcherYenile`, m28, m31/m35 yardımcıları (KASGizle'ye taşındı), ölçüm grupları `KASOlcum06`/`KASOlcumSahip`.
  3135 → ~2840 satır.
- **a2:** öndeki kartın bir an geri gelmesi — liste geçiş **başında** da yenileniyor (ÖLÇÜLDÜ: kaldırmadan ~8 ms sonra; önce ~450 ms).
- **a3:** kaldırma sebebi **0** (kullanıcı kararı): `SBRemovalSwitcherModifier` yalnız "sebep == 1" diye bakıyor (DSC 26);
  0'da kart Apple'ın kendi geçişiyle gidiyor. Öndeki kartta animasyon yok (geçiş-başı yenileme keser — DOĞRULANMADI, kabul edildi).

### 8.2 2. aşama — kasa switcher'dan bağımsız (b1–b4)
- `ka_butonGizle` artık kasaya dokunmuyor; "sahipsiz kasa" / yeniden bağlanma yamaları kalktı.
- **Güvenlik (b1):** kasa switcher'la kapanmadığı için **`com.apple.springboard.lockcomplete` → kasa kapanır + oturum biter.**
- **b1 → b2:** kasa açılınca switcher'ı kapatma denendi; imza denetimi durdurdu (`setAutoPIPDisabled:` 26'da `v24@0:8q16`,
  beklenen BOOL — yanlış tiple çağrı YAPILMADI). Kullanıcı switcher'ın arkada açık kalmasını doğru buldu → adım kaldırıldı;
  kasa uygulama seçilmeden kapanınca X ve kasa butonu geri geliyor.
- **Face ID (b3, ÖLÇÜLDÜ RootHide):** `CoreAuthUI` öne geçince **sistem** switcher'ı kapatıyor (o anda tweak'ten geçiş isteği yok)
  ve geri açmıyor (0.6.0 m14 "kendiliğinden geri geliyor" bugün tutmuyor). Başarılı doğrulamadan 0,35 sn sonra kasa açık +
  switcher kapalıysa stok istek: `SBMutableSwitcherTransitionRequest` `appLayout=nil`, `unlockedEnvironmentMode=2` →
  `switcherContentController:performTransitionWithRequest:gestureInitiated:NO` (KASProbe 0.6 ile önce vphone'da ÖLÇÜLDÜ:
  öndeki uygulamanın üstünde switcher açıldı, çökme yok). `activateMainSwitcherNoninteractively…` KULLANILMADI (m8/m10 ret, 22 Eyl çökme).
- **b4:** 0.6.0 m11 donmuş görüntü geri (b1'de yanlışlıkla kalkmıştı): okurken blurun arkasında switcher; switcher geri
  açılınca 0,5 sn sonra yumuşakça kalkar.

### 8.3 Test durumu (kullanıcı)
| Ortam | Sürüm | Sonuç |
|---|---|---|
| vphone iOS 26.6.2 | b2 (b4 kurulu) | gizleme, öndeki kart, kasa, kasadan çıkarma, kasada kalıcılık, kilit — hepsi ✓ |
| RootHide iOS 17.0.3 | b4 | aşağı atma ✓, Face ID'li kasa ✓ ("harika çalıştı istediğimiz gibi") |
| XS iOS 16.1.1 | b4 kurulu | 0.7 ile **HENÜZ TEST EDİLMEDİ** |

### 8.4 Açık
- XS (iOS 16) 0.7 testi. · Öndeki kartta kaldırma animasyonu yok. · iOS 26'da kasa kart köşelerinde beyazlık.
- Sabitleme hâlâ kapalı (`kKA_Teshis`). · 400 ms "bos-layout'u yok say" penceresi (m23/m34) duruyor — `ka_butonGizle` yön yorumu sadeleştirilmedi.
- `kilitSure` ayarı: oturum artık her kasa kapanışında bitiyor ("switcher kapanana kadar" seçeneği fiilen "her açılış").

### 8.5 b5–b7 (3–4 Ekim)
- **b5 — ilk kartın ~%15 kalması (ÖLÇÜLDÜ RootHide, 88 atış):** başarısızlarda kaldırmadan 1 ms sonra BAŞKA bir geçişin
  bitişi geliyor, tek bayrağı siliyordu → asıl geçişte yenileme yok. Bayrak iki aşamalı (başlangıç bekleniyor → bitiş
  bekleniyor), yabancı bitiş yok sayılır (39 atışta 29 kez yakalandı), 1,5 sn güvenlik yenilemesi.
- **b5 — kilit süresi ayarı:** b2'de oturum her kasa kapanışında bitiyordu (ayar işlemiyordu). "Her açılışta" → kasa
  kapanınca; "switcher kapanana kadar" → `ka_butonGizle`'de, kasa açıkken / doğrulama sürerken değil.
- **b6 — kalan 3–4/20:** başarısızların hepsinde `onde=0` (süreç durumu geç). Geçiş sonrası yenileme artık HER kaldırmada.
- **b6 — kasada kapatma/"Tümünü Kapat" geri geliyordu:** `_deleteAppLayoutsMatchingBundleIdentifier:` gizlileri bulup
  (`includingHiddenAppLayouts:YES`, DSC 17) `deleteAppLayoutForDisplayItem:` ile siliyor; gizli bayraklı düzen silinmedi
  (gözlem). Önce `kas_goster`, sonra silme.
- **b7 — boş switcher'dan kasaya erişim:** Apple boş switcher'ı açıp `SBDismissForEmptySwitcherSwitcherEventResponse`
  (tür 16) ile kapatıyor; `-[SBFluidSwitcherViewController _performEventResponse:]` (`v24@0:8@16`) kancası yalnız bu
  yanıtı, yalnız kasa doluyken uygulamıyor. vphone ✓ (kullanıcı), RootHide'da kanca kuruldu (test bekliyor).

| Ortam | Son sürüm | Durum |
|---|---|---|
| vphone 26.6.2 | b7 | ✓ |
| RootHide 17.0.3 | b7 | b6 ✓ (atış 0/24 + 20'de kalan çözüldü, kasada kapatma ✓); b7 boş switcher test bekliyor |
| XS 16.1.1 | b4 kurulu, b7 rootless hazır | kullanıcı: b2–b4 akşam testinde "ikisi de sağlam" |

### 8.6 b8–b9 (4 Ekim)
- **b8 — butonlar (ÖLÇÜLDÜ RootHide):** (1) gizle/göster yalnız X'in animasyonunu siliyordu → kasa butonu (zıplama vb.)
  ayrı iniyordu; artık ikisi birlikte. (2) kasa kapanınca butonlar koşulsuz geliyordu; Tümünü Kapat sonrası switcher boş +
  kasa boş → Apple switcher'ı kapatıyor, butonlar 1,7 sn sonra yoklamayla iniyordu. Artık göster yalnız
  "görünür kart > 0 ya da kasa dolu" iken (`kas_gorunurKartSayisi`, Apple'ın modeli). Kullanıcı: "buton sağlam".
- **b9:** kasada kapatmada bayrak liste yenilenmeden kalkar (`kas_gosterSessiz`), silme listeyi tek seferde kurar.
- **AÇIK (kozmetik, kullanıcı: "kullanıma engel değil, şimdilik atla"):** boş switcher'da Tümünü Kapat → ana ekrana
  dönerken ARA SIRA saniyelik bir kart çerçevesi ("solarak kapanan kartın son aşaması gibi", kasadakiyle ilgisiz).
  b9 çözmedi. Adaylar (DOĞRULANMADI): kasanın Tümünü Kapat animasyonunun son karesi / Apple'ın boş switcher kapanış
  animasyonu. Ayırt etme: ekran kaydından kare (`shiv-kare`).

### 8.7 b10–b15 (4 Ekim) — kasada kapatma, boş switcher, buton hizası
- **Hayalet kart (ÇÖZÜLDÜ, b12+b13):** b10 ölçümü (otomatik kapanış kapalı) → gölge elle kapatmada da çıktı; b11 (uçan
  kartları kaldır) etkisiz. Günlük: kasadaki uygulamalar switcher'ın kart silme hattıyla kapatılınca, switcher boşken
  her uygulama için ayrı "kart kalmadı → ana ekran" geçişi + kart kaldırma animasyonu (5 uygulama → 35 ms'de 5 bos-layout).
  b12: gizli düzen modelden doğrudan `remove:`, süreç `-[FBSSystemService terminateApplication:forReason:andReport:withDescription:]`
  (`v44@0:8@16q24B32@36`, 16/17/26 DSC). b13: kasa boşalıp görünür kart yoksa switcher Apple'ın "kart kalmadı" isteğiyle
  bir kez kapanır (`setAutoPIPDisabled:` 26'da q, 16/17'de B — ikisi de kabul). vphone 4/4 + RootHide ✓.
- **b15:** kasadaki uygulama switcher'da da görünür kartsa (öndeki uygulama) Apple'ın silme hattı — b12 yolunda kart kararıp
  kendiliğinden kayboluyordu (yalnız RootHide). Karar görünümün kendi listesinden (`kas_gorunumdeVar`). RootHide ✓.
- **b14 — buton hizası:** varsayılan konumda yalnız X ortalıydı, kasa butonu sağına eklenince çift sağa kayıyordu
  ("Konumu sıfırla" da). Kasa butonu görünürken X `-(hapW+12)/2` kayar; liste değişince güncellenir. vphone + RootHide (yatay dahil) ✓.

### 8.8 b16–b24 (4–5 Ekim) — sabitleme, iyileştirme, kozmetik
- **b16 sabitleme geri:** kart üzerinde 0,8 sn basılı tutma (`kKA_Teshis = NO`); sabit = koru listesi (toplu kapatmadan
  korunur, kartın yeri ayrı soru). Kasada iğne rozeti; kasada "Tümünü Kapat" sabitleri atlar (kasa açık kalır); kasada tek
  kartı yukarı atmak sabit de olsa kapatır. vphone + RootHide ✓.
- **b17 kilit süresi "1 dakika":** son doğrulamadan 60 sn içinde yeniden sormaz (12 dil, `dil-uret.py`). ✓
- **b18 400 ms penceresi yerine `env`:** geçiş isteğinin `unlockedEnvironmentMode` değeri (`q16@0:8`, imza denetimli).
  ÖLÇÜLDÜ RootHide: switcher'ı açık bırakan istekler env=2 (36 açılış + kaldırma sonrası), gerçek ana ekrana dönüşler env=0
  (17 kez, gesture 0 ve 1). Okunamazsa eski pencere yedek.
- **b19 pin rozeti temaya göre** (Varsayılan/Koyu turuncu, Neon pembe parlama, Cüzdan koyu, Aurora çivit, Nostalji raptiye,
  Modern cam). ✓
- **b20 sayaç animasyonu** (kayarak değişen rakam + büyüme) ✓; **iOS 26 kasa köşe beyazlığı** — görüntü varsa kart zemini
  saydam ✓; öndeki kart animasyonu denemesi (yenileme +0,3 sn) GERİ ALINDI (kart önce yerine dönüyordu).
- **b21–b22 kasada blur/siyah kart:** kasa görüntüsü kartın CANLI yansımasıydı. b21 ölçümü: kart yapısı
  `SBAppSwitcherReusableSnapshotView > … > SBSwitcherSnapshotImageView`; b22: `SBSwitcherSnapshotImageView.image` (UIImage,
  `@16@0:8`) sabit resim olarak kullanılıyor → "açıp başka uygulamaya geçip at" senaryosu ✓.
- **BİLİNEN KISIT (b23 denemesi geri alındı):** ÖNDEKİ (canlı) uygulama doğrudan kasaya atılınca kasa görüntüsü eksik
  (blur/siyah/beyaz; Pusula çerçeve var ibre yok, Haritalar yalnız metin). Apple'ın arka plan anlık görüntüsü GPU içeriğini
  almıyor; kasadan çıkarınca switcher'da da aynı (karta dokununca tazelenir). b23 ekran kesiti (`_UICreateScreenUIImageFromRect`,
  16/17/26'da dışa açık) öndeki kart destenin en sağında yarısı ekran dışında olduğu için yarı siyah verdi → geri alındı.
  Olası yol (yapılmadı): switcher açılırken tam ekran görüntüsünü öndeki uygulama için saklamak.

### 8.9 b25–b33 (5 Ekim) — kasa ve geri dönüş görüntüsü KENDİ kaynağımızdan ✓

Yukarıdaki BİLİNEN KISIT kapandı. İlke (kullanıcı): "Apple düzgün alamıyorsa kendimiz alalım; kopya üstüne kopya işi bozuyor."
Apple'ın resmine/görünümüne dokunulmaz; doğru resim doğru anda alınır ve Apple'ın KENDİ yollarıyla verilir.

- **Kök sebep (DSC 17 okundu):** Apple anlık görüntüyü `-[SBApplication _xbactivity_saveSnapshotForSceneHandle:…]` →
  `FBScene createSnapshotWithContext:` ile sahneden alıyor, ama uygulama arka plana geçerken. Kasaya atılan ÖNDEKİ uygulamada
  sahne o anda artık çizilmiyor → eksik/beyaz. Kartın `SBSwitcherSnapshotImageView.image`'i de bu eski kayıt (ekranda
  görünen canlı sahne değil). b28/b29 "önce arka plan, 0,4/1,0 sn bekle, sonra kaldır" işe yaramadı → GERİ ALINDI (b30).
  b27 ölçüm kancası (KASOlcumSnap) kaldırıldı.
- **b30 kasa görüntüsü:** kart sürüklenmeye başlarken sahne hâlâ öndeyken `kas_sahneResmi`: `FBSceneManager
  scenesPassingTest:` (clientProcess.bundleIdentifier, settings.isForeground) → `createSnapshot` → `capture` → `CGImage`
  (16.1.1 dizge, 17.0.3/26.6.2 class-dump, imza denetimli). Render sunucusundan, GPU içeriği dahil → Pusula ibreli ✓.
  Öncelik: sahne resmi → Apple kayıtlı resmi (b22) → canlı yansıma. Arka plandaki kartta sahne ön planda değil → b22 yolu.
- **b31 geri dönüş, depo:** aynı `FBSceneSnapshot` kaldırmadan 1,5 sn sonra (Apple kendi eksik resmini yazdıktan sonra)
  Apple'ın kayıt yoluyla `-[SBApplication saveSuspendSnapshot:forSceneHandle:]` (eskileri siler; tutamaç
  `SBSceneManagerCoordinator mainDisplaySceneManager` → `existingSceneHandleForScene:`) depoya yazılıyor. Günlük
  `apple-deposuna-yazildi`. Tek başına yetmedi: kart hâlâ beyaz, DOKUNUNCA doğru resim geliyordu.
- **b32** `SBAppSwitcherSnapshotImageCache reloadSnapshotForDisplayItem:` — etkisiz (kart önbellek listesinde değildi).
- **b33 KÖK:** kullanıcı bulgusu — birden fazla kart kasadan dönünce hepsi "perdeli", switcher'da HERHANGİ bir dokunuş
  hepsini yüklüyor. Önbellek yalnız görünümün bildirdiği kartları yüklüyor: `-[SBFluidSwitcherViewController
  _updateSnapshotCache]` (`appLayoutsToCacheSnapshots` → `setCachableAppLayouts:`). Kart modele dönünce görünüm bunu
  çağırmıyordu. `gosterIc` yenilemesinden sonraki turda bir kez çağrılıyor (günlük `onbellek-listesi-guncellendi`) ✓.
- **Test:** RootHide 17.0.3 ve vphone 26.6.2 — tüm testler geçti (sıfırdan açıp kasaya atma, çoklu geri dönüş, her
  açılışta kasa resmi tazeleniyor). XS 16.1.1 yayından önce.
- **Değerlendirilip yapılmayanlar:** kartın görüntüsünü `setImage:` ile değiştirmek (Apple görünümüne dokunur, içerik o
  arada değişebilir); kasada canlı sahne (askıdaki uygulama çizmez; zorlamaya değmez).
