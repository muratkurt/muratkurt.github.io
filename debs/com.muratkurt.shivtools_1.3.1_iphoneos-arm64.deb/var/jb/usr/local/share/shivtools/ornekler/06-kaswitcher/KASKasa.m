// KASwitcher 0.6.0 — gizli bolum "kasa". Aciklama: KASKasa.h.
// Yerlesim: switcher gorunumunun icinde (icerikle doner, yatay/dikey ayni
// kod). Panel asagidan yayli animasyonla gelir; kartlar yatay seritte,
// oran = switcher gorunumunun orani (yatayda kartlar da yatay).
#import "KASKasa.h"
#import <LocalAuthentication/LocalAuthentication.h>
#import <CoreMotion/CoreMotion.h>

NSString *ka_L(NSString *tr);   // KASDil.m

@implementation KASKasaOge
@end

static UIView *sKok;                      // tam ekran: arka bulanik + panel
static UIVisualEffectView *sArka;
static UIView *sPanel;
static UIScrollView *sSerit;
static UILabel *sSayi;
static NSMutableArray<KASKasaOge *> *sOgeler;
static NSMutableArray<UIView *> *sKartlar;
static CGSize sKartBoyu;
static void (^sAc)(NSString *);
static void (^sKapat)(NSString *);
static void (^sKapaninca)(void);
static const CGFloat kAralik = 22.0;
// m4 kilit + basliktaki "gizlileri kapat"
static void (^sGunluk)(NSString *);
static UIView *sKilit;                    // seridin ustunde: buyuk kilit + yazi
static UIImageView *sKilitIkon;
static UILabel *sKilitYazi;
static UIButton *sTumBtn;                 // sayinin hemen solu
static BOOL sDogrulandi, sDogrulaniyor;
static LAContext *sBaglam;
static void (^sBitti)(BOOL);              // m8 dogrulamaBitince
static void (^sCikar)(NSString *);        // m22 gizlidenCikarinca: kart asagi atildi
static UISwipeGestureRecognizer *sAsagiAt;   // m22: panelin "asagi at, kapan" hareketi - kart cekisini beklesin
static void kasa_log(NSString *s) { if (sGunluk) sGunluk(s); }
// m6 temalar
static NSString *sTema = @"cam";
static NSInteger sSecili = -1;            // cuzdan: one cikan kart (-1: yok)
static const CGFloat kDesteAdim = 74.0;   // cuzdan: destede kartlar arasi
static BOOL kasa_neon(void) { return [sTema isEqualToString:@"neon"]; }
static BOOL kasa_cuzdan(void) { return [sTema isEqualToString:@"cuzdan"]; }
// m7: "acik" = Varsayilan (iOS acik renkleri, beyaz kartlar);
// "cam" = Koyu (iOS koyu, 0.6.0'in ilk gorunumu);
// "mor" = Aurora (akan mor gradyan zemin + 3B atlikarinca seridi).
static BOOL kasa_gunduz(void) { return [sTema isEqualToString:@"acik"]; }
static BOOL kasa_aurora(void) { return [sTema isEqualToString:@"mor"]; }
// m9 Nostalji: iOS 6 coklu gorev cekmecesinin keten dokusu + polaroid kartlar.
static BOOL kasa_nostalji(void) { return [sTema isEqualToString:@"nostalji"]; }
// m11 Modern (iOS 26 Liquid Glass): yuzen, buyuk koseli, neredeyse saydam cam;
// kenarda kosegen boyunca parlayip sonen isik cizgisi.
static BOOL kasa_modern(void) { return [sTema isEqualToString:@"modern"]; }
// 0.7.0 yeni temalar: Holografik (gokkusagi folyo, telefon egildikce kayar), Terminal (yesil fosfor + Matrix
// yagmuru, CRT tarama), Retro Oyun (4 tonlu yesil LCD, A dugmesi kirmizisi).
static BOOL kasa_holo(void) { return [sTema isEqualToString:@"holo"]; }
static BOOL kasa_terminal(void) { return [sTema isEqualToString:@"terminal"]; }
static BOOL kasa_oyun(void) { return [sTema isEqualToString:@"oyun"]; }
static UIColor *kasa_fosfor(CGFloat a) { return [UIColor colorWithRed:0.25 green:1.0 blue:0.40 alpha:a]; }
static UIColor *kasa_gb(int i) {   // Game Boy paleti: 0 en koyu .. 3 en acik
    static const CGFloat r[4][3] = {{0.06, 0.22, 0.06}, {0.19, 0.38, 0.19}, {0.55, 0.67, 0.06}, {0.61, 0.74, 0.06}};
    return [UIColor colorWithRed:r[i][0] green:r[i][1] blue:r[i][2] alpha:1];
}
static UIColor *kasa_gbKirmizi(void) { return [UIColor colorWithRed:0.60 green:0.13 blue:0.34 alpha:1]; }   // A dugmesi
static UIFont *kasa_menlo(CGFloat b) { return [UIFont fontWithName:@"Menlo-Bold" size:b] ?: [UIFont monospacedSystemFontOfSize:b weight:UIFontWeightBold]; }
static void kasa_camKenar(UIView *v, CGFloat yaricap) {
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = v.bounds;
    g.startPoint = CGPointMake(0, 0); g.endPoint = CGPointMake(1, 1);
    g.colors = @[(id)[UIColor colorWithWhite:1 alpha:0.85].CGColor, (id)[UIColor colorWithWhite:1 alpha:0.05].CGColor,
                 (id)[UIColor colorWithWhite:1 alpha:0.45].CGColor];
    g.locations = @[@0, @0.55, @1];
    CAShapeLayer *m = [CAShapeLayer layer];
    m.frame = g.bounds; m.fillColor = nil; m.strokeColor = [UIColor blackColor].CGColor; m.lineWidth = 1.2;
    m.path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(g.bounds, 0.6, 0.6) cornerRadius:yaricap].CGPath;
    g.mask = m;
    [v.layer addSublayer:g];
}
static UIImage *kasa_keten(void) {   // bir kez cizilir; sabit tohum = her acilista ayni doku
    static UIImage *img;
    if (img) return img;
    CGSize s = CGSizeMake(96, 96);
    img = [[[UIGraphicsImageRenderer alloc] initWithSize:s] imageWithActions:^(UIGraphicsImageRendererContext *c) {
        [[UIColor colorWithRed:0.20 green:0.21 blue:0.23 alpha:1] setFill];
        UIRectFill(CGRectMake(0, 0, s.width, s.height));
        srand48(7);
        for (int i = 0; i < 280; i++) {
            [[UIColor colorWithWhite:(drand48() > 0.5 ? 1 : 0) alpha:0.03 + drand48() * 0.07] setFill];
            CGFloat x = drand48() * s.width, y = drand48() * s.height, l = 6 + drand48() * 30;
            UIRectFill(i % 2 ? CGRectMake(x, y, l, 1) : CGRectMake(x, y, 1, l));
        }
    }];
    return img;
}
static UIColor *kasa_yazi(CGFloat a) {   // temanin yazi/simge rengi
    if (kasa_terminal()) return kasa_fosfor(a);
    if (kasa_oyun()) return [kasa_gb(0) colorWithAlphaComponent:a];
    return kasa_gunduz() ? [UIColor colorWithWhite:0.08 alpha:a] : [UIColor colorWithWhite:1.0 alpha:a];
}
static NSArray *kasa_neonRenkler(void) {
    return @[(id)[UIColor systemPinkColor].CGColor, (id)[UIColor systemIndigoColor].CGColor,
             (id)[UIColor systemTealColor].CGColor, (id)[UIColor systemPinkColor].CGColor];
}
// Neon: bir gorunumun cevresine akan renkli isik cizgisi (maskeli gradyan).
static void kasa_neonCerceve(UIView *v, CGFloat yaricap, CGFloat kalinlik) {
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = v.bounds;
    g.startPoint = CGPointMake(0, 0); g.endPoint = CGPointMake(1, 1);
    g.colors = kasa_neonRenkler();
    CAShapeLayer *m = [CAShapeLayer layer];
    m.frame = g.bounds; m.fillColor = nil; m.strokeColor = [UIColor blackColor].CGColor; m.lineWidth = kalinlik;
    m.path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(g.bounds, kalinlik / 2, kalinlik / 2) cornerRadius:yaricap].CGPath;
    g.mask = m;
    CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"colors"];
    NSArray *c = g.colors;
    a.toValue = @[c[1], c[2], c[3], c[1]];
    a.duration = 2.2; a.autoreverses = YES; a.repeatCount = HUGE_VALF;
    [g addAnimation:a forKey:@"ak"];
    [v.layer addSublayer:g];
}


// ---- Holografik: folyo katmanlari egime gore kayar (jiroskop yoksa - vphone - yavas salinim) ----
static NSArray *kasa_gokkusagi(void) {
    NSMutableArray *r = [NSMutableArray array];
    for (int i = 0; i <= 6; i++) [r addObject:(id)[UIColor colorWithHue:i / 6.0 saturation:0.55 brightness:1 alpha:1].CGColor];
    return r;
}
static NSHashTable<CAGradientLayer *> *sHolo;
static CMMotionManager *sHareket;
static void kasa_holoKaydet(CAGradientLayer *g) {
    if (!sHolo) sHolo = [NSHashTable weakObjectsHashTable];
    [sHolo addObject:g];
}
static void kasa_holoEgim(double x, double y) {   // x, y ~ -1..1
    [CATransaction begin]; [CATransaction setDisableActions:YES];
    double a = M_PI_4 + (x + y * 0.6) * M_PI * 0.9;
    for (CAGradientLayer *g in sHolo) {
        if ([g.name isEqualToString:@"isilti"]) {   // parlak serit egime gore kayar
            CGFloat m = 0.5 + x * 0.65;
            g.locations = @[@(m - 0.18), @(m), @(m + 0.18)];
        } else {   // folyo: renk ekseni doner
            g.startPoint = CGPointMake(0.5 - 0.5 * cos(a), 0.5 - 0.5 * sin(a));
            g.endPoint = CGPointMake(0.5 + 0.5 * cos(a), 0.5 + 0.5 * sin(a));
        }
    }
    [CATransaction commit];
}
static void kasa_holoOtomatik(void) {
    for (CAGradientLayer *g in sHolo) {
        if ([g animationForKey:@"holo"]) continue;
        CABasicAnimation *a;
        if ([g.name isEqualToString:@"isilti"]) {
            a = [CABasicAnimation animationWithKeyPath:@"locations"];
            a.fromValue = @[@-0.3, @-0.12, @0.06]; a.toValue = @[@0.94, @1.12, @1.3]; a.duration = 3.2;
        } else {
            a = [CABasicAnimation animationWithKeyPath:@"startPoint"];
            a.fromValue = [NSValue valueWithCGPoint:CGPointMake(0, 0)]; a.toValue = [NSValue valueWithCGPoint:CGPointMake(1, 0.2)];
            a.duration = 4.0;
        }
        a.autoreverses = YES; a.repeatCount = HUGE_VALF; a.removedOnCompletion = NO;
        a.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
        [g addAnimation:a forKey:@"holo"];
    }
}
static void kasa_holoBaslat(void) {
    if (!kasa_holo() || !sHolo.count) return;
    kasa_holoEgim(0, 0);
    if (!sHareket) sHareket = [CMMotionManager new];
    if (!sHareket.deviceMotionAvailable) { kasa_holoOtomatik(); return; }
    for (CAGradientLayer *g in sHolo) [g removeAnimationForKey:@"holo"];
    sHareket.deviceMotionUpdateInterval = 1.0 / 30;
    [sHareket startDeviceMotionUpdatesToQueue:[NSOperationQueue mainQueue] withHandler:^(CMDeviceMotion *m, NSError *e) {
        if (!m) return;
        kasa_holoEgim(MAX(-1.0, MIN(1.0, m.attitude.roll / 0.8)), MAX(-1.0, MIN(1.0, (m.attitude.pitch - 0.8) / 0.8)));
    }];
}
static void kasa_holoDurdur(void) { [sHareket stopDeviceMotionUpdates]; [sHolo removeAllObjects]; }
static CAGradientLayer *kasa_folyoCerceve(UIView *v, CGFloat yaricap, CGFloat kalinlik) {
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = v.bounds;
    g.colors = kasa_gokkusagi();
    CAShapeLayer *m = [CAShapeLayer layer];
    m.frame = g.bounds; m.fillColor = nil; m.strokeColor = [UIColor blackColor].CGColor; m.lineWidth = kalinlik;
    m.path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(g.bounds, kalinlik / 2, kalinlik / 2) cornerRadius:yaricap].CGPath;
    g.mask = m;
    [v.layer addSublayer:g];
    kasa_holoKaydet(g);
    return g;
}
static CAGradientLayer *kasa_folyoDolgu(CGRect r, CGFloat yaricap, CGFloat alfa) {
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = r; g.cornerRadius = yaricap; g.cornerCurve = kCACornerCurveContinuous; g.masksToBounds = YES;
    g.colors = kasa_gokkusagi(); g.opacity = alfa;
    kasa_holoKaydet(g);
    return g;
}
static CAGradientLayer *kasa_isilti(CGRect r) {
    CAGradientLayer *g = [CAGradientLayer layer];
    g.name = @"isilti"; g.frame = r;
    g.startPoint = CGPointMake(0, 0); g.endPoint = CGPointMake(1, 1);
    g.colors = @[(id)[UIColor colorWithWhite:1 alpha:0].CGColor, (id)[UIColor colorWithWhite:1 alpha:0.30].CGColor,
                 (id)[UIColor colorWithWhite:1 alpha:0].CGColor];
    g.locations = @[@0.32, @0.5, @0.68];
    kasa_holoKaydet(g);
    return g;
}
// ---- Terminal / Retro Oyun dokulari ----
static UIImage *kasa_taramaDoku(CGFloat alfa) {   // CRT: her 3 pt'de koyu cizgi
    return [[[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(3, 3)] imageWithActions:^(UIGraphicsImageRendererContext *c) {
        [[UIColor colorWithWhite:0 alpha:alfa] setFill]; UIRectFill(CGRectMake(0, 0, 3, 1));
    }];
}
static UIImage *kasa_lcdDoku(CGFloat alfa) {   // LCD piksel izgarasi
    return [[[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(3, 3)] imageWithActions:^(UIGraphicsImageRendererContext *c) {
        [[kasa_gb(0) colorWithAlphaComponent:alfa] setFill];
        UIRectFill(CGRectMake(0, 0, 3, 1)); UIRectFill(CGRectMake(0, 1, 1, 2));
    }];
}
static UIView *kasa_doku(CGRect r, UIImage *img) {
    UIView *v = [[UIView alloc] initWithFrame:r];
    v.backgroundColor = [UIColor colorWithPatternImage:img];
    v.userInteractionEnabled = NO;
    v.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    return v;
}
static void kasa_matrixYagmur(UIView *panel, CGFloat yaricap) {   // akan yesil harf sutunlari
    UIView *kap = [[UIView alloc] initWithFrame:panel.bounds];
    kap.userInteractionEnabled = NO; kap.clipsToBounds = YES;
    kap.layer.cornerRadius = yaricap; kap.layer.maskedCorners = panel.layer.maskedCorners;
    NSString *harf = @"ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎ0123456789";
    CGFloat H = panel.bounds.size.height, satir = 14.0, sc = [UIScreen mainScreen].scale;
    for (CGFloat x = 6; x < panel.bounds.size.width - 8; x += 18) {
        NSUInteger n = 8 + arc4random_uniform(14);
        NSMutableString *yz = [NSMutableString string];
        for (NSUInteger i = 0; i < n; i++)
            [yz appendFormat:@"%@\n", [harf substringWithRange:NSMakeRange(arc4random_uniform((uint32_t)harf.length), 1)]];
        CATextLayer *t = [CATextLayer layer];
        t.string = yz; t.font = (__bridge CFTypeRef)@"Menlo-Regular"; t.fontSize = 12; t.contentsScale = sc;
        t.foregroundColor = kasa_fosfor(1).CGColor; t.alignmentMode = kCAAlignmentCenter;
        CGFloat h = n * satir;
        t.frame = CGRectMake(x, -h, 14, h);
        t.opacity = 0.16 + arc4random_uniform(30) / 100.0;
        CAGradientLayer *m = [CAGradientLayer layer];   // kuyruk soluk, bas parlak
        m.frame = t.bounds;
        m.colors = @[(id)[UIColor colorWithWhite:0 alpha:0].CGColor, (id)[UIColor colorWithWhite:0 alpha:1].CGColor];
        t.mask = m;
        CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"position.y"];
        a.fromValue = @(-h / 2); a.toValue = @(H + h / 2);
        a.duration = 4.0 + arc4random_uniform(60) / 10.0;
        a.timeOffset = arc4random_uniform(100) / 100.0 * a.duration;
        a.repeatCount = HUGE_VALF; a.removedOnCompletion = NO;
        [t addAnimation:a forKey:@"yagmur"];
        [kap.layer addSublayer:t];
    }
    [panel insertSubview:kap atIndex:0];
}

@interface KASKasaHedef : NSObject <UIGestureRecognizerDelegate, UIScrollViewDelegate>
@end
static KASKasaHedef *sHedef;

// Sayi sagda; "gizlileri kapat" hemen solunda. Kilitliyken ikisi de gizli
// (kac gizli uygulama oldugu da icerik sayilir).
static void kasa_sayiYaz(void) {
    sSayi.text = [NSString stringWithFormat:@"%lu", (unsigned long)sOgeler.count];
    [sSayi sizeToFit];
    CGFloat W = sPanel.bounds.size.width, w = MAX(12.0, sSayi.bounds.size.width);
    sSayi.frame = CGRectMake(W - 24 - w, 27, w, 22);
    CGSize bs = [sTumBtn sizeThatFits:CGSizeMake(200, 26)];
    CGFloat bw = MIN(200.0, bs.width);
    sTumBtn.frame = CGRectMake(CGRectGetMinX(sSayi.frame) - 12 - bw, 25, bw, 26);   // m6: 34 -> 26, ayni merkez
    sTumBtn.layer.cornerRadius = kasa_nostalji() ? 6 : (kasa_terminal() ? 3 : 13);   // m13: iOS 6 dugmesi kapsul degil
    if (kasa_holo() && sTumBtn) {   // 0.7.0: gokkusagi kenar, boyuta bagli - her dizilimde yeniden
        for (CALayer *l in [sTumBtn.layer.sublayers copy]) if ([l.name isEqualToString:@"folyo"]) [l removeFromSuperlayer];
        kasa_folyoCerceve(sTumBtn, 13, 1.4).name = @"folyo";
        if (!sHareket.deviceMotionActive) kasa_holoOtomatik();
    }
    BOOL kilitli = (sKilit != nil);
    sSayi.hidden = kilitli;
    sTumBtn.hidden = kilitli || sOgeler.count == 0;
}

// m7 Aurora: 3B atlikarinca - ortadan uzaklastikca kart doner ve kuculur.
// Kartin kendi transform'u yukari atma cekisine ait; burada yalniz
// sublayerTransform (cakismaz).
static void kasa_atlikarinca(void) {
    if (!kasa_aurora() || !sSerit) return;
    CGFloat w = sSerit.bounds.size.width, orta = sSerit.contentOffset.x + w / 2;
    for (UIView *k in sKartlar) {
        CGFloat d = MAX(-1.0, MIN(1.0, (k.center.x - orta) / w));
        CATransform3D t = CATransform3DIdentity;
        t.m34 = -1.0 / 900.0;
        t = CATransform3DRotate(t, -d * 0.65, 0, 1, 0);
        CGFloat s = 1.0 - fabs(d) * 0.16;
        k.layer.sublayerTransform = CATransform3DScale(t, s, s, 1);
    }
}
// Kartlari seritte sirala (silinince kalanlar kayar).
static void kasa_diz(BOOL animasyonlu) {
    if (kasa_cuzdan()) {
        // Deste: kartlar ust uste kDesteAdim arayla (her kartin ust seridi
        // gorunur). Secili kart en uste cikar, digerleri altta sikisir.
        CGFloat W = sSerit.bounds.size.width, Hs = sSerit.bounds.size.height;
        CGFloat x = round((W - sKartBoyu.width) / 2);
        NSUInteger n = sKartlar.count;
        void (^yer)(void) = ^{
            NSUInteger j = 0;
            for (NSUInteger i = 0; i < n; i++) {
                CGFloat y;
                if (sSecili < 0) y = i * kDesteAdim;
                else if ((NSInteger)i == sSecili) y = 0;
                // m7 DUZELTME: 12 pt'de en arkadaki kartin yalniz birkac
                // pikseli gorunuyordu - her kartin ad seridi (52) tam okunsun
                else y = sKartBoyu.height + 18 + (j++) * 56;
                sKartlar[i].frame = CGRectMake(x, y, sKartBoyu.width, sKartBoyu.height);
            }
        };
        if (animasyonlu) [UIView animateWithDuration:0.45 delay:0 usingSpringWithDamping:0.82 initialSpringVelocity:0
                                             options:UIViewAnimationOptionBeginFromCurrentState animations:yer completion:nil];
        else yer();
        CGFloat altBoy = sKartBoyu.height + 18 + (n > 1 ? (n - 2) * 56 : 0) + 64;   // secili + alttaki serit
        sSerit.contentSize = CGSizeMake(W, sSecili < 0 ? (n ? (n - 1) * kDesteAdim + sKartBoyu.height + 20 : Hs)
                                                       : MAX(Hs, altBoy));
        if (sSecili >= 0) [sSerit setContentOffset:CGPointZero animated:animasyonlu];
        return;
    }
    CGFloat W = sSerit.bounds.size.width;
    CGFloat kenar = MAX(16.0, (W - sKartBoyu.width) / 2.0);
    void (^yerlestir)(void) = ^{
        for (NSUInteger i = 0; i < sKartlar.count; i++) {
            UIView *k = sKartlar[i];
            k.frame = CGRectMake(kenar + i * (sKartBoyu.width + kAralik), 0, sKartBoyu.width, sKartBoyu.height + 30);
        }
    };
    if (animasyonlu) [UIView animateWithDuration:0.35 delay:0 usingSpringWithDamping:0.85 initialSpringVelocity:0
                                         options:UIViewAnimationOptionBeginFromCurrentState animations:yerlestir completion:nil];
    else yerlestir();
    NSUInteger n = sKartlar.count;
    sSerit.contentSize = CGSizeMake(2 * kenar + n * sKartBoyu.width + (n ? (n - 1) * kAralik : 0), sSerit.bounds.size.height);
    kasa_atlikarinca();
}

// b19: sabit rozeti temaya gore (kullanici istegi). Yalniz public UIKit.
static UIView *kasa_pinRozeti(CGRect f) {
    UIView *r = [[UIView alloc] initWithFrame:f];
    r.layer.cornerRadius = f.size.width / 2;
    r.userInteractionEnabled = NO;
    UIColor *zemin = [UIColor colorWithRed:1.0 green:0.62 blue:0.04 alpha:0.95], *simge = [UIColor whiteColor];
    if (kasa_gunduz()) {
        r.layer.shadowColor = [UIColor blackColor].CGColor; r.layer.shadowOpacity = 0.18;
        r.layer.shadowRadius = 3; r.layer.shadowOffset = CGSizeMake(0, 1);
    } else if (kasa_neon()) {
        zemin = [UIColor colorWithWhite:0 alpha:0.75]; simge = [UIColor systemPinkColor];
        r.layer.borderWidth = 1.2; r.layer.borderColor = [UIColor systemPinkColor].CGColor;
        r.layer.shadowColor = [UIColor systemPinkColor].CGColor; r.layer.shadowOpacity = 0.9;
        r.layer.shadowRadius = 6; r.layer.shadowOffset = CGSizeZero;
    } else if (kasa_cuzdan()) {
        zemin = [UIColor colorWithWhite:0 alpha:0.55];
    } else if (kasa_aurora()) {
        zemin = [[UIColor systemIndigoColor] colorWithAlphaComponent:0.92];
    } else if (kasa_nostalji()) {   // raptiye
        zemin = [UIColor colorWithRed:0.82 green:0.12 blue:0.10 alpha:1];
        r.layer.shadowColor = [UIColor blackColor].CGColor; r.layer.shadowOpacity = 0.45;
        r.layer.shadowRadius = 2.5; r.layer.shadowOffset = CGSizeMake(1, 2);
        r.transform = CGAffineTransformMakeRotation(0.18);
    } else if (kasa_modern()) {   // cam
        zemin = [UIColor clearColor];
        UIVisualEffectView *cam = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterial]];
        cam.frame = r.bounds; cam.layer.cornerRadius = f.size.width / 2; cam.clipsToBounds = YES;
        [r addSubview:cam];
        kasa_camKenar(r, f.size.width / 2);
    } else if (kasa_holo()) {   // donen gokkusagi folyo
        zemin = [UIColor clearColor];
        CAGradientLayer *g = [CAGradientLayer layer];
        g.type = kCAGradientLayerConic; g.startPoint = CGPointMake(0.5, 0.5); g.endPoint = CGPointMake(0.5, 0);
        g.frame = r.bounds; g.cornerRadius = f.size.width / 2; g.masksToBounds = YES; g.colors = kasa_gokkusagi();
        CABasicAnimation *d = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        d.toValue = @(2 * M_PI); d.duration = 4; d.repeatCount = HUGE_VALF; d.removedOnCompletion = NO;
        [g addAnimation:d forKey:@"don"];
        [r.layer addSublayer:g];
        r.layer.borderWidth = 1; r.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.85].CGColor;
        r.layer.shadowColor = [UIColor whiteColor].CGColor; r.layer.shadowOpacity = 0.6;
        r.layer.shadowRadius = 5; r.layer.shadowOffset = CGSizeZero;
    } else if (kasa_terminal()) {   // yesil fosfor kutu
        zemin = [UIColor colorWithWhite:0 alpha:0.85]; simge = kasa_fosfor(1);
        r.layer.cornerRadius = 4; r.layer.borderWidth = 1.2; r.layer.borderColor = kasa_fosfor(0.9).CGColor;
        r.layer.shadowColor = kasa_fosfor(1).CGColor; r.layer.shadowOpacity = 0.8;
        r.layer.shadowRadius = 6; r.layer.shadowOffset = CGSizeZero;
    } else if (kasa_oyun()) {   // piksel kare, sert golge
        zemin = kasa_gb(1); simge = kasa_gb(3);
        r.layer.cornerRadius = 0; r.layer.borderWidth = 2; r.layer.borderColor = kasa_gb(0).CGColor;
        r.layer.shadowColor = kasa_gb(0).CGColor; r.layer.shadowOpacity = 1;
        r.layer.shadowRadius = 0; r.layer.shadowOffset = CGSizeMake(2, 2);
    } else {   // Koyu ("cam" anahtari)
        zemin = [UIColor colorWithRed:0.90 green:0.50 blue:0.02 alpha:0.95];
    }
    r.backgroundColor = zemin;
    UIImageView *ig = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"pin.fill"
        withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:12 weight:UIImageSymbolWeightBold]]];
    ig.tintColor = simge;
    ig.contentMode = UIViewContentModeCenter;
    ig.frame = r.bounds;
    [r addSubview:ig];
    return r;
}

static UIView *kasa_kartKur(KASKasaOge *o) {
    UIView *k = [UIView new];
    UIView *yuz = [[UIView alloc] initWithFrame:CGRectMake(0, 0, sKartBoyu.width, sKartBoyu.height)];
    yuz.layer.cornerRadius = 22;
    yuz.layer.cornerCurve = kCACornerCurveContinuous;
    yuz.clipsToBounds = YES;
    yuz.backgroundColor = (kasa_gunduz() ? [UIColor whiteColor] : [UIColor colorWithWhite:0.16 alpha:1]);
    yuz.tag = 1;
    UIView *g = o.gorunum;
    CGSize gb = g.bounds.size;
    if (g && gb.width > 10 && gb.height > 10) {
        // Kartin kopyasi tam boy (kart konteyneri olceksiz): doldurarak
        // olcekle, ortala. Ayni kopya bir onceki kasada durduysa
        // addSubview oradan alir.
        CGFloat sc = MAX(sKartBoyu.width / gb.width, sKartBoyu.height / gb.height);
        g.transform = CGAffineTransformMakeScale(sc, sc);
        // cuzdan: kart kisa - uygulamanin USTU gorunsun (ortalama yerine)
        g.center = CGPointMake(sKartBoyu.width / 2, kasa_cuzdan() ? gb.height * sc / 2 : sKartBoyu.height / 2);
        g.userInteractionEnabled = NO;
        [yuz addSubview:g];
        // b20: goruntu varsa zemin saydam - iOS 26'da kart kopyasinin koseleri daha yuvarlak, beyaz zemin koselerden
        // tasiyordu (DOGRULANMADI). Kose sekli kopyanin kendisi; yer tutucu kartlar temanin zeminini korur.
        yuz.backgroundColor = [UIColor clearColor];
    } else {
        // Yer tutucu: henuz goruntusu alinmamis (uygulama bu oturumda hic gorulmedi)
        UIImageView *kilit = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"lock.fill"
            withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:34 weight:UIImageSymbolWeightSemibold]]];
        kilit.tintColor = kasa_yazi(0.35);
        kilit.center = CGPointMake(sKartBoyu.width / 2, sKartBoyu.height / 2 - 14);
        [yuz addSubview:kilit];
        UILabel *ad = [[UILabel alloc] initWithFrame:CGRectMake(12, sKartBoyu.height / 2 + 14, sKartBoyu.width - 24, 26)];
        ad.text = o.ad; ad.textAlignment = NSTextAlignmentCenter;
        ad.textColor = kasa_yazi(0.7);
        ad.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
        [yuz addSubview:ad];
    }
    [k addSubview:yuz];
    if (kasa_cuzdan()) {
        // Wallet: kartin ust seridi = buzlu ad cubugu (destede gorunen kisim)
        UIVisualEffectView *s = [[UIVisualEffectView alloc] initWithEffect:
            [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark]];
        s.frame = CGRectMake(0, 0, sKartBoyu.width, 52);
        UILabel *ad = [[UILabel alloc] initWithFrame:CGRectMake(18, 0, sKartBoyu.width - 36, 52)];
        ad.text = o.ad;
        ad.textColor = [UIColor whiteColor];
        ad.font = [UIFont systemFontOfSize:17 weight:UIFontWeightSemibold];
        [s.contentView addSubview:ad];
        [yuz addSubview:s];
        yuz.layer.cornerRadius = 18;
        k.layer.shadowColor = [UIColor blackColor].CGColor;
        k.layer.shadowOpacity = 0.55; k.layer.shadowRadius = 10; k.layer.shadowOffset = CGSizeMake(0, -3);
        k.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:yuz.bounds cornerRadius:18].CGPath;
    } else {
        UILabel *alt = [[UILabel alloc] initWithFrame:CGRectMake(0, sKartBoyu.height + 8, sKartBoyu.width, 20)];
        alt.text = o.ad;
        alt.textAlignment = NSTextAlignmentCenter;
        alt.textColor = kasa_yazi(1.0);
        alt.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
        [k addSubview:alt];
    }
    if (kasa_gunduz() && !kasa_cuzdan()) {
        k.layer.shadowColor = [UIColor blackColor].CGColor;
        k.layer.shadowOpacity = 0.14; k.layer.shadowRadius = 12; k.layer.shadowOffset = CGSizeMake(0, 4);
        k.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:yuz.bounds cornerRadius:22].CGPath;
    }
    if (kasa_nostalji() && !kasa_cuzdan()) {
        // Polaroid: beyaz kagit (alt seridi genis), el yazisi ad, hafif egik.
        // Egim sublayerTransform'da: kartin transform'u yukari atma cekisinin.
        CGFloat w = sKartBoyu.width, h = sKartBoyu.height;
        UIView *kagit = [[UIView alloc] initWithFrame:CGRectMake(-7, -7, w + 14, h + 7 + 34)];
        kagit.backgroundColor = [UIColor colorWithWhite:0.96 alpha:1];
        kagit.layer.cornerRadius = 3;
        [k insertSubview:kagit atIndex:0];
        yuz.layer.cornerRadius = 2;
        for (UIView *s in k.subviews) {
            if (![s isKindOfClass:[UILabel class]]) continue;
            UILabel *l = (UILabel *)s;
            l.textColor = [UIColor colorWithWhite:0.2 alpha:1];
            l.font = [UIFont fontWithName:@"Noteworthy-Bold" size:16] ?: l.font;
            l.frame = CGRectMake(0, h + 2, w, 26);
        }
        k.layer.shadowColor = [UIColor blackColor].CGColor;
        k.layer.shadowOpacity = 0.55; k.layer.shadowRadius = 6; k.layer.shadowOffset = CGSizeMake(0, 4);
        k.layer.shadowPath = [UIBezierPath bezierPathWithRect:kagit.frame].CGPath;
        CGFloat egim = ((NSInteger)(o.bid.hash % 5) - 2) * 0.014;
        k.layer.sublayerTransform = CATransform3DMakeRotation(egim, 0, 0, 1);
    }
    if (kasa_modern() && !kasa_cuzdan()) {   // m11: cam kenarli, buyuk koseli kart
        yuz.layer.cornerRadius = 26;
        yuz.backgroundColor = [UIColor colorWithWhite:1 alpha:0.06];
        kasa_camKenar(yuz, 26);
    }
    if (kasa_neon()) {
        kasa_neonCerceve(yuz, 22, 1.6);
        k.layer.shadowColor = [UIColor systemPinkColor].CGColor;
        k.layer.shadowOpacity = 0.45; k.layer.shadowRadius = 14; k.layer.shadowOffset = CGSizeZero;
        k.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:yuz.bounds cornerRadius:22].CGPath;
    }
    BOOL resimsiz = CGColorGetAlpha(yuz.backgroundColor.CGColor) > 0;   // yer tutucu kart
    if (kasa_holo()) {   // 0.7.0: gokkusagi kenar + egime gore kayan parlak serit
        [yuz.layer addSublayer:kasa_isilti(yuz.bounds)];
        kasa_folyoCerceve(yuz, 22, 2.0);
        k.layer.shadowColor = [UIColor colorWithRed:0.65 green:0.55 blue:1 alpha:1].CGColor;
        k.layer.shadowOpacity = 0.45; k.layer.shadowRadius = 16; k.layer.shadowOffset = CGSizeZero;
        k.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:yuz.bounds cornerRadius:22].CGPath;
    }
    if (kasa_terminal() || kasa_oyun()) {
        BOOL oy = kasa_oyun();
        yuz.layer.cornerRadius = oy ? 0 : 6;
        if (resimsiz) yuz.backgroundColor = oy ? kasa_gb(2) : [UIColor blackColor];
        UIView *ton = [[UIView alloc] initWithFrame:yuz.bounds];   // ekran tonu
        // b36 ISTEK: uygulama daha okunakli - kartta ton ve doku hafif (panel dokusu ayni)
        ton.backgroundColor = oy ? [kasa_gb(2) colorWithAlphaComponent:0.08] : kasa_fosfor(0.03);
        ton.userInteractionEnabled = NO;
        [yuz addSubview:ton];
        [yuz addSubview:kasa_doku(yuz.bounds, oy ? kasa_lcdDoku(0.06) : kasa_taramaDoku(0.12))];
        yuz.layer.borderWidth = oy ? 3 : 1;
        yuz.layer.borderColor = (oy ? kasa_gb(0) : kasa_fosfor(0.8)).CGColor;
        k.layer.shadowColor = (oy ? kasa_gb(1) : kasa_fosfor(1)).CGColor;
        k.layer.shadowOpacity = oy ? 1 : 0.45; k.layer.shadowRadius = oy ? 0 : 12;
        k.layer.shadowOffset = oy ? CGSizeMake(5, 5) : CGSizeZero;
        k.layer.shadowPath = (oy ? [UIBezierPath bezierPathWithRect:yuz.bounds]
                                 : [UIBezierPath bezierPathWithRoundedRect:yuz.bounds cornerRadius:6]).CGPath;
        for (UIView *v in k.subviews) {
            if (![v isKindOfClass:[UILabel class]]) continue;
            UILabel *l = (UILabel *)v;
            l.font = kasa_menlo(13);
            if (oy) l.text = [l.text uppercaseStringWithLocale:[NSLocale currentLocale]];
        }
    }
    if (o.sabit) [k addSubview:kasa_pinRozeti(CGRectMake(sKartBoyu.width - 34, 8, 26, 26))];   // b16/b19
    k.accessibilityIdentifier = o.bid;
    UITapGestureRecognizer *t = [[UITapGestureRecognizer alloc] initWithTarget:sHedef action:@selector(kartDokundu:)];
    [k addGestureRecognizer:t];
    UIPanGestureRecognizer *p = [[UIPanGestureRecognizer alloc] initWithTarget:sHedef action:@selector(kartCekildi:)];
    p.delegate = sHedef;
    [sAsagiAt requireGestureRecognizerToFail:p];   // m22: karti asagi atmak paneli kapatmasin
    [k addGestureRecognizer:p];
    return k;
}

// Kilit acildi: kilit simgesi acilir + buyuyup solar, serit belirir.
static void kasa_kilidiAc(void) {
    UIView *k = sKilit;
    sKilit = nil;
    kasa_sayiYaz();
    sKilitIkon.image = [UIImage systemImageNamed:@"lock.open.fill" withConfiguration:
        [UIImageSymbolConfiguration configurationWithPointSize:64 weight:UIImageSymbolWeightSemibold]];
    sSerit.transform = CGAffineTransformMakeScale(0.94, 0.94);
    [UIView animateWithDuration:0.45 delay:0.12 usingSpringWithDamping:0.85 initialSpringVelocity:0 options:0 animations:^{
        k.alpha = 0;
        k.transform = CGAffineTransformMakeScale(1.25, 1.25);
        sSerit.alpha = 1;
        sSerit.transform = CGAffineTransformIdentity;
    } completion:^(BOOL f) { [k removeFromSuperview]; }];
}
// Apple'in stok akisi: LAPolicyDeviceOwnerAuthentication = Face ID; sistem
// gerekli gorunce (basarisiz denemeler, Face ID kapali/yok) parola.
static void kasa_dogrula(void) {
    if (sDogrulaniyor || !sKilit) return;
    sDogrulaniyor = YES;
    LAContext *c = [LAContext new];
    sBaglam = c;
    NSError *e = nil;
    BOOL bio = [c canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&e];
    kasa_log([NSString stringWithFormat:@"kilit-can bio=%d kod=%ld tip=%ld", bio, (long)e.code, (long)c.biometryType]);
    sKilitYazi.text = @"";
    [c evaluatePolicy:LAPolicyDeviceOwnerAuthentication
      localizedReason:ka_L(@"Gizli uygulamaları görmek için kimliğini doğrula")
                reply:^(BOOL ok, NSError *err) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (c == sBaglam) sDogrulaniyor = NO;
            kasa_log([NSString stringWithFormat:@"kilit-sonuc ok=%d kod=%ld acik=%d", ok, (long)err.code, sKok != nil]);
            if (c != sBaglam || !sKilit) return;      // kasa kapandi / yeni deneme
            if (sBitti) sBitti(ok);                    // m8: switcher'i arkada yeniden ac
            if (ok) { sDogrulandi = YES; kasa_kilidiAc(); return; }
            sKilitYazi.text = ka_L(@"Kilidi açmak için dokun");
            [[UINotificationFeedbackGenerator new] notificationOccurred:UINotificationFeedbackTypeError];
            CAKeyframeAnimation *s = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
            s.values = @[@0, @-10, @10, @-6, @6, @0];
            s.duration = 0.4;
            [sKilitIkon.layer addAnimation:s forKey:@"salla"];
        });
    }];
}

@implementation KASKasaHedef
// Kartin cekisi yalniz DIKEY baskinsa baslar; yatay kaydirma seride kalir.
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)g {
    if (![g isKindOfClass:[UIPanGestureRecognizer class]]) return YES;
    CGPoint v = [(UIPanGestureRecognizer *)g velocityInView:g.view];
    // cuzdan: deste dikey kayar - kart kapatma YATAY (sola) atis
    return kasa_cuzdan() ? fabs(v.x) > fabs(v.y) : fabs(v.y) > fabs(v.x);
}
- (void)kartDokundu:(UITapGestureRecognizer *)g {
    NSString *bid = g.view.accessibilityIdentifier;
    if (!bid) return;
    if (sKilit) return;                 // kilitliyken kartlar gizli (savunma)
    NSInteger i = (NSInteger)[sKartlar indexOfObject:g.view];
    if (kasa_cuzdan() && i != sSecili) {   // Wallet: ilk dokunus one cikarir
        sSecili = i;
        [[UISelectionFeedbackGenerator new] selectionChanged];
        kasa_diz(YES);
        return;
    }
    void (^ac)(NSString *) = sAc;
    if (ac) ac(bid);                    // once: Tweak.x "uygulamaya" bayragini diker
    [KASKasa kapat:YES];
}
- (void)kilideDokundu:(UITapGestureRecognizer *)g { kasa_dogrula(); }
- (void)scrollViewDidScroll:(UIScrollView *)s { kasa_atlikarinca(); }   // m7 Aurora
// Basliktaki "gizlileri kapat": kartlar sirayla yukari ucar, sonra kapanir.
- (void)tumunuKapat:(UIButton *)b {
    if (sKilit || !sKartlar.count || !b.enabled) return;
    // b16: sabit uygulamalar toplu kapatmaya girmez (koru listesi). Kart - oge eslesmesi bid ile.
    NSMutableArray<UIView *> *kartlar = [NSMutableArray array];
    NSMutableArray<KASKasaOge *> *ogeler = [NSMutableArray array];
    for (UIView *k in sKartlar)
        for (KASKasaOge *o in sOgeler)
            if ([o.bid isEqualToString:k.accessibilityIdentifier] && !o.sabit) { [kartlar addObject:k]; [ogeler addObject:o]; }
    if (!ogeler.count) {   // hepsi sabit
        [[UINotificationFeedbackGenerator new] notificationOccurred:UINotificationFeedbackTypeWarning];
        kasa_log(@"kasa-tumunu-kapat hepsi-sabit");
        return;
    }
    BOOL hepsi = (ogeler.count == sOgeler.count);
    b.enabled = NO;                     // cift dokunus iki kez kapatmasin
    sSerit.userInteractionEnabled = NO;
    [[[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium] impactOccurred];
    void (^kapat)(NSString *) = sKapat;
    CGFloat yuk = sPanel.bounds.size.height;
    kasa_log([NSString stringWithFormat:@"kasa-tumunu-kapat n=%lu sabit-kalan=%lu", (unsigned long)ogeler.count,
              (unsigned long)(sOgeler.count - ogeler.count)]);
    for (NSUInteger i = 0; i < kartlar.count; i++) {
        UIView *k = kartlar[i];
        [UIView animateWithDuration:0.25 delay:0.05 * i options:UIViewAnimationOptionCurveEaseIn animations:^{
            k.transform = CGAffineTransformMakeTranslation(0, -yuk);
            k.alpha = 0;
        } completion:^(BOOL f) {
            // b11: kart (ve icindeki canli kopya) hiyerarsiden de kalksin
            [k removeFromSuperview];
        }];
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)((0.25 + 0.05 * kartlar.count) * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        for (KASKasaOge *o in ogeler) if (kapat) kapat(o.bid);
        if (hepsi) { [KASKasa kapat:YES]; return; }
        // b16: sabitler kaldi - kasa acik, kalanlar yeniden dizilir
        [sKartlar removeObjectsInArray:kartlar];
        [sOgeler removeObjectsInArray:ogeler];
        kasa_sayiYaz();
        kasa_diz(YES);
        b.enabled = YES;
        sSerit.userInteractionEnabled = YES;
    });
}
- (void)kartCekildi:(UIPanGestureRecognizer *)g {
    UIView *k = g.view;
    // m6: cuzdan'da eksen X (sola), digerlerinde Y (yukari)
    BOOL c = kasa_cuzdan();
    CGPoint tr = [g translationInView:sPanel];
    // m22 ISTEK: iki yon - yukari (cuzdan: sola) = uygulamayi KAPAT,
    // asagi (cuzdan: saga) = gizli bolumden CIKAR (switcher'a geri doner).
    CGFloat d = c ? tr.x : tr.y;
    CGFloat boy = c ? sKartBoyu.width : sKartBoyu.height;
    if (g.state == UIGestureRecognizerStateChanged) {
        k.transform = c ? CGAffineTransformMakeTranslation(d, 0) : CGAffineTransformMakeTranslation(0, d);
        k.alpha = 1.0 - MIN(0.6, fabs(d) / (boy * 1.5));
        return;
    }
    if (g.state != UIGestureRecognizerStateEnded && g.state != UIGestureRecognizerStateCancelled) return;
    CGPoint hz = [g velocityInView:sPanel];
    CGFloat h = c ? hz.x : hz.y;
    BOOL kapat = (d < -boy * 0.3) || h < -900;
    BOOL cikar = !kapat && ((d > boy * 0.3) || h > 900);
    if ((!kapat && !cikar) || g.state == UIGestureRecognizerStateCancelled) {
        [UIView animateWithDuration:0.3 delay:0 usingSpringWithDamping:0.8 initialSpringVelocity:0 options:0
                         animations:^{ k.transform = CGAffineTransformIdentity; k.alpha = 1; } completion:nil];
        return;
    }
    NSString *bid = k.accessibilityIdentifier;
    CGFloat yon = kapat ? -1 : 1;
    if (cikar) [[UINotificationFeedbackGenerator new] notificationOccurred:UINotificationFeedbackTypeSuccess];
    [UIView animateWithDuration:0.22 animations:^{
        k.transform = c ? CGAffineTransformMakeTranslation(yon * sPanel.bounds.size.width, 0)
                        : CGAffineTransformMakeTranslation(0, yon * sPanel.bounds.size.height);
        k.alpha = 0;
    } completion:^(BOOL f) {
        [k removeFromSuperview];
        [sKartlar removeObject:k];
        sSecili = -1;   // cuzdan: dizilim desteye doner
        for (KASKasaOge *o in [sOgeler copy]) if ([o.bid isEqualToString:bid]) [sOgeler removeObject:o];
        kasa_sayiYaz();
        if (kapat && sKapat && bid) sKapat(bid);
        if (cikar && sCikar && bid) sCikar(bid);   // m22: gizli listesinden cikar
        kasa_log([NSString stringWithFormat:@"kasa-kart %@ %@", kapat ? @"kapat" : @"cikar", bid]);
        if (!sKartlar.count) [KASKasa kapat:YES];
        else kasa_diz(YES);
    }];
}
- (void)arkayaDokundu:(UITapGestureRecognizer *)g { [KASKasa kapat:YES]; }
- (void)asagiAtildi:(UISwipeGestureRecognizer *)g { [KASKasa kapat:YES]; }
@end

@implementation KASKasa

+ (BOOL)acik { return sKok != nil; }

+ (void)temaAyarla:(NSString *)tema { if (!sKok) sTema = [tema copy] ?: @"cam"; }
+ (BOOL)dogrulandi { return sDogrulandi; }
+ (BOOL)dogrulaniyor { return sDogrulaniyor; }
+ (void)dogrulamaBitince:(void (^)(BOOL))blok { sBitti = [blok copy]; }
+ (void)gizlidenCikarinca:(void (^)(NSString *))blok { sCikar = [blok copy]; }
+ (void)oturumuKapat { sDogrulandi = NO; }

+ (void)gosterIcinde:(UIView *)v ogeler:(NSArray<KASKasaOge *> *)ogeler kilitli:(BOOL)kilitli
                  ac:(void (^)(NSString *))ac kapat:(void (^)(NSString *))kapat
           kapaninca:(void (^)(void))kapaninca gunluk:(void (^)(NSString *))gunluk {
    if (sKok || !v || !ogeler.count) return;
    if (!sHedef) sHedef = [KASKasaHedef new];
    sAc = [ac copy]; sKapat = [kapat copy]; sKapaninca = [kapaninca copy]; sGunluk = [gunluk copy];
    sOgeler = [ogeler mutableCopy];
    sKartlar = [NSMutableArray array];

    CGFloat W = v.bounds.size.width, H = v.bounds.size.height;
    BOOL yatay = W > H;
    CGFloat panelH = round(yatay ? H * 0.88 : H * (kasa_cuzdan() ? 0.78 : 0.62));   // deste daha uzun
    sSecili = -1;

    sKok = [[UIView alloc] initWithFrame:v.bounds];
    sKok.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    sArka = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterialDark]];
    sArka.frame = sKok.bounds;
    sArka.alpha = 0;
    [sArka addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:sHedef action:@selector(arkayaDokundu:)]];
    [sKok addSubview:sArka];

    sPanel = [[UIView alloc] initWithFrame:CGRectMake(0, H - panelH, W, panelH)];
    sPanel.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.92];
    sPanel.layer.cornerRadius = 30;
    sPanel.layer.cornerCurve = kCACornerCurveContinuous;
    sPanel.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;
    UISwipeGestureRecognizer *asagi = [[UISwipeGestureRecognizer alloc] initWithTarget:sHedef action:@selector(asagiAtildi:)];
    asagi.direction = UISwipeGestureRecognizerDirectionDown;
    [sPanel addGestureRecognizer:asagi];
    sAsagiAt = asagi;   // m22: kartlar kurulurken kart cekislerini bekleyecek
    [sKok addSubview:sPanel];
    if (kasa_neon()) {
        // Neon: saf siyah panel, ust kenarda akan isik, pembe parlama
        sPanel.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.97];
        kasa_neonCerceve(sPanel, 30, 1.6);
        sPanel.layer.shadowColor = [UIColor systemPinkColor].CGColor;
        sPanel.layer.shadowOpacity = 0.5; sPanel.layer.shadowRadius = 22; sPanel.layer.shadowOffset = CGSizeZero;
    }
    if (kasa_gunduz()) {
        // m7 ISTEK "Varsayilan = iOS acik": Haptic Touch menusunun dokusu
        // (kullanici ekran goruntusu) - arka koyu bulanik kalir, panel yari
        // saydam ACIK sistem malzemesi; gri duz renk DEGIL.
        // m8 ISTEK "cok gri kalmis, daha transparan": ince malzeme + hafif
        // beyaz isik (koyu arkayla karisip griye donmesin)
        UIVisualEffectView *mz = [[UIVisualEffectView alloc] initWithEffect:
            [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialLight]];
        mz.contentView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.22];
        sArka.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark];
        mz.frame = sPanel.bounds;
        mz.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        mz.layer.cornerRadius = 30; mz.layer.cornerCurve = kCACornerCurveContinuous;
        mz.layer.maskedCorners = sPanel.layer.maskedCorners;
        mz.clipsToBounds = YES;
        mz.userInteractionEnabled = NO;
        [sPanel insertSubview:mz atIndex:0];
        sPanel.backgroundColor = [UIColor clearColor];
        sPanel.layer.shadowColor = [UIColor blackColor].CGColor;
        sPanel.layer.shadowOpacity = 0.15; sPanel.layer.shadowRadius = 24; sPanel.layer.shadowOffset = CGSizeZero;
        sPanel.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:sPanel.bounds cornerRadius:30].CGPath;
    }
    if (kasa_aurora()) {
        // Aurora: koyu mor-lacivert-turkuaz gradyan, renkler yavasca akar
        CAGradientLayer *g = [CAGradientLayer layer];
        g.frame = sPanel.bounds;
        g.cornerRadius = 30; g.cornerCurve = kCACornerCurveContinuous; g.maskedCorners = sPanel.layer.maskedCorners;
        g.startPoint = CGPointMake(0, 0); g.endPoint = CGPointMake(1, 1);
        UIColor *a = [UIColor colorWithRed:0.20 green:0.08 blue:0.38 alpha:1], *b = [UIColor colorWithRed:0.06 green:0.10 blue:0.32 alpha:1],
                *c = [UIColor colorWithRed:0.03 green:0.28 blue:0.33 alpha:1];
        g.colors = @[(id)a.CGColor, (id)b.CGColor, (id)c.CGColor];
        CABasicAnimation *ak = [CABasicAnimation animationWithKeyPath:@"colors"];
        ak.toValue = @[(id)c.CGColor, (id)a.CGColor, (id)b.CGColor];
        ak.duration = 4.0; ak.autoreverses = YES; ak.repeatCount = HUGE_VALF;
        [g addAnimation:ak forKey:@"ak"];
        [sPanel.layer insertSublayer:g atIndex:0];
        sPanel.backgroundColor = [UIColor clearColor];
    }

    if (kasa_modern()) {
        // Modern: kenarlardan ayrik yuzen cam sayfa (iOS 26 sayfalari gibi),
        // 38 pt koseler, neredeyse saydam malzeme + isik kenari
        sArka.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark];
        sPanel.frame = CGRectMake(10, H - panelH - 10, W - 20, panelH);
        sPanel.layer.cornerRadius = 38;
        sPanel.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner | kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner;
        sPanel.backgroundColor = [UIColor clearColor];
        UIVisualEffectView *cam = [[UIVisualEffectView alloc] initWithEffect:
            [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterial]];
        cam.frame = sPanel.bounds;
        cam.contentView.backgroundColor = [UIColor colorWithWhite:1 alpha:0.05];
        cam.layer.cornerRadius = 38; cam.layer.cornerCurve = kCACornerCurveContinuous;
        cam.clipsToBounds = YES; cam.userInteractionEnabled = NO;
        [sPanel insertSubview:cam atIndex:0];
        kasa_camKenar(sPanel, 38);
        sPanel.layer.shadowColor = [UIColor blackColor].CGColor;
        sPanel.layer.shadowOpacity = 0.25; sPanel.layer.shadowRadius = 30; sPanel.layer.shadowOffset = CGSizeMake(0, 10);
        sPanel.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:sPanel.bounds cornerRadius:38].CGPath;
        W = sPanel.bounds.size.width;   // ic yerlesim panelin kendi genisligiyle
    }
    if (kasa_nostalji()) {
        // Nostalji: keten cekmece, donemin kucuk koseleri, ust kenarda isik
        sPanel.backgroundColor = [UIColor colorWithPatternImage:kasa_keten()];
        sPanel.layer.cornerRadius = 14;
        sPanel.clipsToBounds = NO;
        UIView *isik = [[UIView alloc] initWithFrame:CGRectMake(14, 0, W - 28, 1)];
        isik.backgroundColor = [UIColor colorWithWhite:1 alpha:0.18];
        [sPanel addSubview:isik];
        sPanel.layer.shadowColor = [UIColor blackColor].CGColor;
        sPanel.layer.shadowOpacity = 0.7; sPanel.layer.shadowRadius = 10; sPanel.layer.shadowOffset = CGSizeMake(0, -2);
        sPanel.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:sPanel.bounds cornerRadius:14].CGPath;
    }

    if (kasa_holo()) {   // 0.7.0: koyu zemin uzerinde gokkusagi folyo + parlak serit + folyo kenar
        sPanel.backgroundColor = [UIColor colorWithRed:0.04 green:0.04 blue:0.07 alpha:0.96];
        CAGradientLayer *f = kasa_folyoDolgu(sPanel.bounds, 30, 0.16);
        f.maskedCorners = sPanel.layer.maskedCorners;
        [sPanel.layer insertSublayer:f atIndex:0];
        CAGradientLayer *i = kasa_isilti(sPanel.bounds);
        i.cornerRadius = 30; i.maskedCorners = sPanel.layer.maskedCorners; i.masksToBounds = YES; i.opacity = 0.5;
        [sPanel.layer insertSublayer:i atIndex:1];
        kasa_folyoCerceve(sPanel, 30, 1.6);
        sPanel.layer.shadowColor = [UIColor colorWithRed:0.65 green:0.55 blue:1 alpha:1].CGColor;
        sPanel.layer.shadowOpacity = 0.45; sPanel.layer.shadowRadius = 26; sPanel.layer.shadowOffset = CGSizeZero;
    }
    if (kasa_terminal()) {   // siyah ekran, Matrix yagmuru, ust kenarda fosfor cizgisi
        sPanel.backgroundColor = [UIColor colorWithWhite:0 alpha:0.97];
        kasa_matrixYagmur(sPanel, 30);
        UIView *cz = [[UIView alloc] initWithFrame:CGRectMake(30, 0, W - 60, 1)];
        cz.backgroundColor = kasa_fosfor(0.7);
        cz.layer.shadowColor = kasa_fosfor(1).CGColor; cz.layer.shadowOpacity = 1; cz.layer.shadowRadius = 4; cz.layer.shadowOffset = CGSizeZero;
        [sPanel addSubview:cz];
        sPanel.layer.shadowColor = kasa_fosfor(1).CGColor;
        sPanel.layer.shadowOpacity = 0.35; sPanel.layer.shadowRadius = 22; sPanel.layer.shadowOffset = CGSizeZero;
    }
    if (kasa_oyun()) {   // acik yesil LCD, piksel izgarasi, kalin koyu cerceve
        sPanel.backgroundColor = kasa_gb(3);
        sPanel.layer.cornerRadius = 12;
        sPanel.layer.borderWidth = 4; sPanel.layer.borderColor = kasa_gb(0).CGColor;
        UIView *d = kasa_doku(sPanel.bounds, kasa_lcdDoku(0.13));
        d.layer.cornerRadius = 12; d.layer.maskedCorners = sPanel.layer.maskedCorners; d.clipsToBounds = YES;
        [sPanel insertSubview:d atIndex:0];
    }

    UIView *tutamac = [[UIView alloc] initWithFrame:CGRectMake((W - 40) / 2, 8, 40, 5)];
    tutamac.backgroundColor = kasa_yazi(kasa_gunduz() ? 0.2 : 0.35);
    tutamac.layer.cornerRadius = 2.5;
    [sPanel addSubview:tutamac];

    UIImageView *kilit = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"lock.rectangle.stack.fill"
        withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:17 weight:UIImageSymbolWeightSemibold]]];
    kilit.tintColor = kasa_neon() ? [UIColor systemPinkColor] : kasa_yazi(1.0);
    kilit.frame = CGRectMake(22, 26, 26, 24);
    kilit.contentMode = UIViewContentModeCenter;
    [sPanel addSubview:kilit];
    UILabel *baslik = [[UILabel alloc] initWithFrame:CGRectMake(54, 24, W - 140, 28)];
    baslik.text = ka_L(@"Gizli");
    baslik.textColor = kasa_yazi(1.0);
    baslik.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    if (kasa_nostalji()) {   // iOS 6 kabartma yazi: Helvetica Neue + 1 pt koyu golge
        baslik.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:22] ?: baslik.font;
        baslik.shadowColor = [UIColor colorWithWhite:0 alpha:0.8];
        baslik.shadowOffset = CGSizeMake(0, -1);
    }
    if (kasa_terminal() || kasa_oyun()) {
        baslik.font = kasa_menlo(20);
        baslik.text = kasa_terminal() ? [@"> " stringByAppendingString:baslik.text]
                                      : [baslik.text uppercaseStringWithLocale:[NSLocale currentLocale]];
    }
    if (kasa_terminal()) {   // yanip sonen imlec + fosfor parlamasi
        CGFloat bw = [baslik.text sizeWithAttributes:@{NSFontAttributeName: baslik.font}].width;
        UIView *imlec = [[UIView alloc] initWithFrame:CGRectMake(54 + bw + 4, 29, 10, 18)];
        imlec.backgroundColor = kasa_fosfor(0.9);
        CAKeyframeAnimation *y = [CAKeyframeAnimation animationWithKeyPath:@"opacity"];
        y.values = @[@1, @1, @0, @0]; y.keyTimes = @[@0, @0.5, @0.5, @1]; y.calculationMode = kCAAnimationDiscrete;
        y.duration = 1.0; y.repeatCount = HUGE_VALF; y.removedOnCompletion = NO;
        [imlec.layer addAnimation:y forKey:@"imlec"];
        [sPanel addSubview:imlec];
        baslik.layer.shadowColor = kasa_fosfor(1).CGColor; baslik.layer.shadowOpacity = 0.8;
        baslik.layer.shadowRadius = 6; baslik.layer.shadowOffset = CGSizeZero;
    }
    [sPanel addSubview:baslik];
    sSayi = [[UILabel alloc] initWithFrame:CGRectMake(W - 70, 27, 48, 22)];
    sSayi.textAlignment = NSTextAlignmentRight;
    sSayi.textColor = kasa_yazi(0.55);
    sSayi.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightSemibold];
    if (kasa_terminal() || kasa_oyun()) sSayi.font = kasa_menlo(15);
    [sPanel addSubview:sSayi];
    // m5 ISTEK "daha oturakli": simge + yazi kapsulu, ince kirmizi cerceve.
    UIButtonConfiguration *bc = [UIButtonConfiguration plainButtonConfiguration];
    // m6 ISTEK: yazi ~%30 kucuk (14 -> 10 pt), simge ve kapsul de orantili
    bc.image = [UIImage systemImageNamed:@"xmark.circle.fill" withConfiguration:
        [UIImageSymbolConfiguration configurationWithPointSize:10 weight:UIImageSymbolWeightSemibold]];
    bc.imagePadding = 5;
    bc.contentInsets = NSDirectionalEdgeInsetsMake(0, 10, 0, 12);
    bc.attributedTitle = [[NSAttributedString alloc] initWithString:ka_L(@"Tümünü Kapat") attributes:
        @{NSFontAttributeName: [UIFont systemFontOfSize:10 weight:UIFontWeightSemibold]}];
    UIColor *vurgu = kasa_neon() ? [UIColor systemPinkColor] : [UIColor systemRedColor];
    bc.baseForegroundColor = kasa_neon() ? vurgu : [UIColor colorWithRed:1.0 green:0.42 blue:0.40 alpha:1];
    sTumBtn = [UIButton buttonWithConfiguration:bc primaryAction:nil];
    sTumBtn.backgroundColor = [vurgu colorWithAlphaComponent:kasa_neon() ? 0.08 : 0.16];
    sTumBtn.layer.borderWidth = kasa_neon() ? 1.0 : 0.75;
    sTumBtn.layer.borderColor = [vurgu colorWithAlphaComponent:kasa_neon() ? 0.85 : 0.45].CGColor;
    sTumBtn.layer.cornerCurve = kCACornerCurveContinuous;
    // m12 ISTEK: Tumunu Kapat her temada temasina uysun (Koyu: yukaridaki varsayilan)
    UIColor *yazi = nil;
    if (kasa_gunduz()) {   // iOS acik menudeki "Kaldir" satiri
        sTumBtn.backgroundColor = [UIColor colorWithWhite:1 alpha:0.55];
        sTumBtn.layer.borderWidth = 0;
        yazi = [UIColor systemRedColor];
    } else if (kasa_cuzdan()) {   // Wallet'in koyu dugmeleri
        sTumBtn.backgroundColor = [UIColor colorWithWhite:0 alpha:0.35];
        sTumBtn.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.18].CGColor;
        yazi = [UIColor colorWithRed:1.0 green:0.45 blue:0.42 alpha:1];
    } else if (kasa_aurora()) {   // panel gradyaniyla uyumlu pembe-mor
        sTumBtn.backgroundColor = [[UIColor systemPurpleColor] colorWithAlphaComponent:0.22];
        sTumBtn.layer.borderColor = [[UIColor systemPinkColor] colorWithAlphaComponent:0.5].CGColor;
        yazi = [UIColor colorWithRed:1.0 green:0.62 blue:0.85 alpha:1];
    }
    if (yazi) {
        UIButtonConfiguration *tc = sTumBtn.configuration;
        tc.baseForegroundColor = yazi;
        sTumBtn.configuration = tc;
    }
    if (kasa_modern()) {   // m11 cam kapsul; m13/m14: okunakli - beyaz yazi ve simge, koyu cam
        UIButtonConfiguration *mc = sTumBtn.configuration;
        mc.baseForegroundColor = [UIColor whiteColor];
        sTumBtn.configuration = mc;
        sTumBtn.backgroundColor = [UIColor colorWithWhite:0 alpha:0.28];
        sTumBtn.layer.borderWidth = 0.8;
        sTumBtn.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.45].CGColor;
    }
    if (kasa_neon()) {   // m13: pembe parlama
        sTumBtn.layer.shadowColor = [UIColor systemPinkColor].CGColor;
        sTumBtn.layer.shadowOpacity = 0.8; sTumBtn.layer.shadowRadius = 8; sTumBtn.layer.shadowOffset = CGSizeZero;
    }
    if (kasa_nostalji()) {   // m13: iOS 6 dugmesi - 6 pt kose, parlak kirmizi gradyan, kabartma yazi
        UIButtonConfiguration *nc = sTumBtn.configuration;
        nc.baseForegroundColor = [UIColor whiteColor];
        NSShadow *g = [NSShadow new];
        g.shadowColor = [UIColor colorWithWhite:0 alpha:0.6]; g.shadowOffset = CGSizeMake(0, -1);
        nc.attributedTitle = [[NSAttributedString alloc] initWithString:ka_L(@"Tümünü Kapat") attributes:@{
            NSFontAttributeName: [UIFont fontWithName:@"HelveticaNeue-Bold" size:11] ?: [UIFont boldSystemFontOfSize:11],
            NSShadowAttributeName: g}];
        nc.background.image = [[[UIGraphicsImageRenderer alloc] initWithSize:CGSizeMake(8, 26)] imageWithActions:^(UIGraphicsImageRendererContext *c) {
            CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
            NSArray *renk = @[(id)[UIColor colorWithRed:0.90 green:0.33 blue:0.30 alpha:1].CGColor,
                              (id)[UIColor colorWithRed:0.62 green:0.06 blue:0.05 alpha:1].CGColor];
            CGGradientRef gr = CGGradientCreateWithColors(cs, (__bridge CFArrayRef)renk, NULL);
            CGContextDrawLinearGradient(c.CGContext, gr, CGPointZero, CGPointMake(0, 26), 0);
            [[UIColor colorWithWhite:1 alpha:0.28] setFill];
            UIRectFillUsingBlendMode(CGRectMake(0, 0, 8, 12), kCGBlendModeNormal);
            CGGradientRelease(gr); CGColorSpaceRelease(cs);
        }];
        nc.background.imageContentMode = UIViewContentModeScaleToFill;
        sTumBtn.configuration = nc;
        sTumBtn.backgroundColor = [UIColor clearColor];
        sTumBtn.clipsToBounds = YES;
        sTumBtn.layer.borderWidth = 1;
        sTumBtn.layer.borderColor = [UIColor colorWithWhite:0 alpha:0.55].CGColor;
    }
    if (kasa_terminal() || kasa_oyun()) {   // 0.7.0: Terminal = yesil komut kutusu; Retro Oyun = kirmizi A dugmesi
        BOOL oy = kasa_oyun();
        UIButtonConfiguration *tc = sTumBtn.configuration;
        NSString *m = ka_L(@"Tümünü Kapat");
        tc.attributedTitle = [[NSAttributedString alloc] initWithString:oy ? [m uppercaseStringWithLocale:[NSLocale currentLocale]] : m
                                                             attributes:@{NSFontAttributeName: kasa_menlo(10)}];
        tc.baseForegroundColor = oy ? [UIColor colorWithWhite:0.96 alpha:1] : kasa_fosfor(1);
        sTumBtn.configuration = tc;
        sTumBtn.backgroundColor = oy ? kasa_gbKirmizi() : [UIColor colorWithWhite:0 alpha:0.85];
        sTumBtn.layer.borderWidth = oy ? 2 : 1;
        sTumBtn.layer.borderColor = (oy ? [UIColor colorWithRed:0.25 green:0.03 blue:0.12 alpha:1] : kasa_fosfor(0.85)).CGColor;
        sTumBtn.layer.shadowColor = (oy ? kasa_gb(0) : kasa_fosfor(1)).CGColor;
        sTumBtn.layer.shadowOpacity = oy ? 1 : 0.7; sTumBtn.layer.shadowRadius = oy ? 0 : 6;
        sTumBtn.layer.shadowOffset = oy ? CGSizeMake(2, 2) : CGSizeZero;
    }
    if (kasa_holo()) {   // koyu cam, beyaz yazi; gokkusagi kenar kasa_sayiYaz'da (boyuta bagli)
        UIButtonConfiguration *hc = sTumBtn.configuration;
        hc.baseForegroundColor = [UIColor whiteColor];
        sTumBtn.configuration = hc;
        sTumBtn.backgroundColor = [UIColor colorWithWhite:0 alpha:0.35];
        sTumBtn.layer.borderWidth = 0;
        sTumBtn.layer.shadowColor = [UIColor whiteColor].CGColor; sTumBtn.layer.shadowOpacity = 0.35;
        sTumBtn.layer.shadowRadius = 6; sTumBtn.layer.shadowOffset = CGSizeZero;
    }
    [sTumBtn addTarget:sHedef action:@selector(tumunuKapat:) forControlEvents:UIControlEventTouchUpInside];
    [sPanel addSubview:sTumBtn];

    CGFloat seritY = 66, alt = yatay ? 12 : 34;
    sSerit = [[UIScrollView alloc] initWithFrame:CGRectMake(0, seritY, W, panelH - seritY - alt)];
    sSerit.showsHorizontalScrollIndicator = NO;
    sSerit.decelerationRate = UIScrollViewDecelerationRateFast;
    sSerit.alwaysBounceHorizontal = YES;
    sSerit.clipsToBounds = NO;
    // m7 DUZELTME: kaydirilan kartlar kasanin YANLARINDAN tasiyordu (serit
    // kirpmiyor - yukari atilan kart ucabilsin diye). Kap yalniz yanlardan
    // kirpar: maske dikeyde genis payli, yukari atis serbest kalir.
    UIView *kap = [[UIView alloc] initWithFrame:sSerit.frame];
    CALayer *mk = [CALayer layer];
    mk.backgroundColor = [UIColor blackColor].CGColor;
    mk.frame = CGRectMake(2, -2000, kap.bounds.size.width - 4, kap.bounds.size.height + 4000);
    kap.layer.mask = mk;
    sSerit.frame = kap.bounds;
    [kap addSubview:sSerit];
    [sPanel addSubview:kap];
    if (kasa_aurora()) sSerit.delegate = sHedef;   // 3B atlikarinca
    CGFloat kartH = sSerit.bounds.size.height - 34;
    CGFloat kartW = kartH * (W / H);
    if (kartW > W * 0.78) { kartW = W * 0.78; kartH = kartW * (H / W); }
    if (kasa_cuzdan()) {
        // Deste: genis, kisa kartlar (uygulamanin ustu), dikey kaydirma
        kartW = MIN(W - 32, 440.0);
        kartH = MIN(kartW * 1.15, sSerit.bounds.size.height - 60);
        sSerit.alwaysBounceHorizontal = NO;
        sSerit.alwaysBounceVertical = YES;
        sSerit.showsVerticalScrollIndicator = NO;
        sSerit.decelerationRate = UIScrollViewDecelerationRateNormal;
        sSerit.clipsToBounds = YES;
        // asagi atma kaydirmayla carpismasin: destede kaydirma kazanir,
        // kasa baslik bolgesinden asagi atinca kapanir
        [asagi requireGestureRecognizerToFail:sSerit.panGestureRecognizer];
    }
    sKartBoyu = CGSizeMake(round(kartW), round(kartH));
    for (KASKasaOge *o in sOgeler) {
        UIView *k = kasa_kartKur(o);
        [sSerit addSubview:k];
        [sKartlar addObject:k];
    }
    kasa_diz(NO);
    // m4 kilit: serit gizli, ustunde buyuk kilit. Dokununca yeniden dener.
    if (kilitli && !sDogrulandi) {
        sSerit.alpha = 0;
        sKilit = [[UIView alloc] initWithFrame:sSerit.superview.frame];   // m7: serit artik kabin icinde
        [sKilit addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:sHedef action:@selector(kilideDokundu:)]];
        sKilitIkon = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"lock.fill" withConfiguration:
            [UIImageSymbolConfiguration configurationWithPointSize:64 weight:UIImageSymbolWeightSemibold]]];
        sKilitIkon.tintColor = kasa_yazi(1.0);
        sKilitIkon.contentMode = UIViewContentModeCenter;
        if (kasa_neon()) {
            // Neon kilit: pembe isik, Face ID beklerken nabiz atar
            sKilitIkon.tintColor = [UIColor systemPinkColor];
            sKilitIkon.layer.shadowColor = [UIColor systemPinkColor].CGColor;
            sKilitIkon.layer.shadowRadius = 18; sKilitIkon.layer.shadowOffset = CGSizeZero;
            sKilitIkon.layer.shadowOpacity = 0.9;
            CABasicAnimation *n = [CABasicAnimation animationWithKeyPath:@"shadowRadius"];
            n.fromValue = @10; n.toValue = @26; n.duration = 1.1; n.autoreverses = YES; n.repeatCount = HUGE_VALF;
            [sKilitIkon.layer addAnimation:n forKey:@"nabiz"];
        }
        if (kasa_terminal()) {
            sKilitIkon.layer.shadowColor = kasa_fosfor(1).CGColor; sKilitIkon.layer.shadowOpacity = 0.9;
            sKilitIkon.layer.shadowRadius = 12; sKilitIkon.layer.shadowOffset = CGSizeZero;
        }
        sKilitIkon.frame = CGRectMake(0, sKilit.bounds.size.height / 2 - 60, sKilit.bounds.size.width, 90);
        [sKilit addSubview:sKilitIkon];
        sKilitYazi = [[UILabel alloc] initWithFrame:CGRectMake(20, CGRectGetMaxY(sKilitIkon.frame) + 12, sKilit.bounds.size.width - 40, 24)];
        sKilitYazi.textAlignment = NSTextAlignmentCenter;
        sKilitYazi.textColor = kasa_yazi(0.6);
        sKilitYazi.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
        [sKilit addSubview:sKilitYazi];
        [sPanel addSubview:sKilit];
    }
    kasa_sayiYaz();
    [v addSubview:sKok];
    kasa_holoBaslat();   // 0.7.0 Holografik: egim takibi kasa acikken

    sPanel.transform = CGAffineTransformMakeTranslation(0, panelH + 20);   // m11: yuzen sayfa (Modern) tam gizlensin
    [UIView animateWithDuration:0.55 delay:0 usingSpringWithDamping:0.82 initialSpringVelocity:0.4 options:0
                     animations:^{ sPanel.transform = CGAffineTransformIdentity; sArka.alpha = 1; }
                     completion:^(BOOL f) { if (sKilit) kasa_dogrula(); }];   // ISTEK: pencere acildiktan sonra
}

+ (void)kapat:(BOOL)animasyonlu {
    if (!sKok) return;
    kasa_holoDurdur();
    UIView *kok = sKok, *panel = sPanel;
    UIVisualEffectView *arka = sArka;
    void (^bitti)(void) = sKapaninca;
    sKok = nil; sPanel = nil; sArka = nil; sSerit = nil; sSayi = nil;
    sKartlar = nil; sOgeler = nil; sAc = nil; sKapat = nil; sKapaninca = nil;
    // m4: suren dogrulama varsa iptal (LAErrorAppCancel doner, yok sayilir)
    if (sDogrulaniyor) { [sBaglam invalidate]; kasa_log(@"kilit-iptal kasa-kapandi"); }
    sBaglam = nil; sDogrulaniyor = NO;
    sKilit = nil; sKilitIkon = nil; sKilitYazi = nil; sTumBtn = nil; sGunluk = nil; sAsagiAt = nil;
    if (!animasyonlu) { [kok removeFromSuperview]; if (bitti) bitti(); return; }
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
        panel.transform = CGAffineTransformMakeTranslation(0, panel.bounds.size.height + 20);
        arka.alpha = 0;
    } completion:^(BOOL f) { [kok removeFromSuperview]; if (bitti) bitti(); }];
}

@end
