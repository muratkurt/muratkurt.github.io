#import "KASProtectedListController.h"
#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import <notify.h>

static NSString * const kKA_AlanAdi   = @"com.muratkurt.kaswitcher";
static NSString * const kKA_Bildirim  = @"com.muratkurt.kaswitcher/prefs-changed";
static NSString * const kKA_KeyKoru   = @"koru";

@interface LSApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (NSArray *)allInstalledApplications;
@end

@interface LSApplicationProxy : NSObject
- (NSString *)localizedName;
- (NSString *)applicationIdentifier;
- (NSString *)applicationType;
- (BOOL)isInstalled;
- (BOOL)isDeletableIgnoringRestrictions;
- (NSData *)iconDataForVariant:(int)variant;
@end

@interface KASProtectedListController () {
    NSMutableArray<NSString *> *_protectedBids;
    NSArray<LSApplicationProxy *> *_allApps;
    BOOL _protectedSection;
}
@end

@implementation KASProtectedListController

- (instancetype)init {
    self = [super init];
    if (self) {
        _protectedBids = [[self _loadProtectedArray] mutableCopy];
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _protectedBids = [[self _loadProtectedArray] mutableCopy];
    [self reloadSpecifiers];
}

// 0.6.0: ayni sayfa iki listeyi yonetir; Root.plist'teki baglanti satirinin
// 'kaAnahtar' ozelligi hangisi oldugunu soyler ("koru" varsayilan, "gizli").
- (NSString *)_anahtar {
    id k = [self.specifier propertyForKey:@"kaAnahtar"];
    return [k isKindOfClass:[NSString class]] ? k : kKA_KeyKoru;
}

- (BOOL)_gizliListesi {
    return [[self _anahtar] isEqualToString:@"gizli"];
}

- (NSArray *)_loadProtectedArray {
    @try {
        CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)[self _anahtar],
                                                        (__bridge CFStringRef)kKA_AlanAdi);
        if (!v) return @[];
        NSArray *out = @[];
        if (CFGetTypeID(v) == CFArrayGetTypeID()) out = [(__bridge NSArray *)v copy];
        CFRelease(v);
        return out ?: @[];
    } @catch (__unused NSException *e) { return @[]; }
}

- (void)_saveProtectedArray {
    @try {
        CFPreferencesSetAppValue((__bridge CFStringRef)[self _anahtar],
                                 (__bridge CFArrayRef)[_protectedBids copy],
                                 (__bridge CFStringRef)kKA_AlanAdi);
        CFPreferencesAppSynchronize((__bridge CFStringRef)kKA_AlanAdi);
        notify_post([kKA_Bildirim UTF8String]);
    } @catch (__unused NSException *e) {}
}

- (NSArray<LSApplicationProxy *> *)_allApps {
    if (!_allApps) {
        @try {
            LSApplicationWorkspace *ws = [LSApplicationWorkspace defaultWorkspace];
            NSArray *raw = [ws allInstalledApplications];
            NSMutableArray *filtered = [NSMutableArray array];
            for (LSApplicationProxy *app in raw) {
                if (![app isInstalled]) continue;
                NSString *type = [app applicationType];
                NSString *bid = [app applicationIdentifier];
                if (![type isEqualToString:@"System"] && ![type isEqualToString:@"User"]) continue;
                if ([type isEqualToString:@"System"] &&
                    ![app isDeletableIgnoringRestrictions] &&
                    [bid hasPrefix:@"com.apple."]) continue;
                [filtered addObject:app];
            }
            [filtered sortUsingComparator:^NSComparisonResult(LSApplicationProxy *a, LSApplicationProxy *b) {
                return [[a localizedName] localizedCaseInsensitiveCompare:[b localizedName]];
            }];
            _allApps = [filtered copy];
        } @catch (__unused NSException *e) { _allApps = @[]; }
    }
    return _allApps;
}

- (LSApplicationProxy *)_appForBid:(NSString *)bid {
    if (!bid.length) return nil;
    for (LSApplicationProxy *app in [self _allApps]) {
        if ([[app applicationIdentifier] isEqualToString:bid]) return app;
    }
    return nil;
}

- (PSSpecifier *)_specifierForApp:(LSApplicationProxy *)app isProtected:(BOOL)isProtected {
    NSString *name = [app localizedName] ?: [app applicationIdentifier];
    PSSpecifier *spec = [PSSpecifier preferenceSpecifierNamed:name
                                                       target:self
                                                          set:nil
                                                          get:nil
                                                       detail:nil
                                                         cell:PSListItemCell
                                                         edit:nil];
    NSString *bid = [app applicationIdentifier];
    [spec setProperty:bid forKey:@"bundleIdentifier"];
    [spec setProperty:@(isProtected) forKey:@"checked"];
    [spec setProperty:bid forKey:@"appIDForLazyIcon"];
    [spec setProperty:@YES forKey:@"useLazyIcons"];
    [spec setProperty:@YES forKey:@"hasIcon"];
    return spec;
}

- (NSMutableArray *)specifiers {
    if (_specifiers) return _specifiers;
    _specifiers = [NSMutableArray array];

    // Grup 0: Korunan uygulamalar
    NSMutableArray<LSApplicationProxy *> *korunanlar = [NSMutableArray array];
    for (NSString *bid in _protectedBids) {
        LSApplicationProxy *app = [self _appForBid:bid];
        if (app) [korunanlar addObject:app];
    }
    if (korunanlar.count > 0) {
        NSString *baslik = [self _gizliListesi] ? @"Gizli uygulamalar" : @"Korunan uygulamalar";
        [_specifiers addObject:[PSSpecifier groupSpecifierWithName:[[NSBundle bundleForClass:[self class]] localizedStringForKey:baslik value:baslik table:@"Root"]]];
        _protectedSection = YES;
        for (LSApplicationProxy *app in korunanlar) {
            [_specifiers addObject:[self _specifierForApp:app isProtected:YES]];
        }
    } else {
        _protectedSection = NO;
    }

    // Grup 1: Tum uygulamalar
    [_specifiers addObject:[PSSpecifier groupSpecifierWithName:[[NSBundle bundleForClass:[self class]] localizedStringForKey:@"Tüm uygulamalar" value:@"Tüm uygulamalar" table:@"Root"]]];
    for (LSApplicationProxy *app in [self _allApps]) {
        if ([_protectedBids containsObject:[app applicationIdentifier]]) continue;
        [_specifiers addObject:[self _specifierForApp:app isProtected:NO]];
    }

    return _specifiers;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [super tableView:tableView cellForRowAtIndexPath:indexPath];
    PSSpecifier *spec = [self specifierAtIndexPath:indexPath];
    NSString *bid = [spec propertyForKey:@"bundleIdentifier"];
    if (bid.length) {
        BOOL korunan = [[spec propertyForKey:@"checked"] boolValue];
        if ([cell respondsToSelector:@selector(setChecked:)]) {
            [(PSTableCell *)cell setChecked:korunan];
        } else {
            cell.accessoryType = korunan ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    PSSpecifier *spec = [self specifierAtIndexPath:indexPath];
    NSString *bid = [spec propertyForKey:@"bundleIdentifier"];
    if (!bid.length) return;

    if ([_protectedBids containsObject:bid]) {
        [_protectedBids removeObject:bid];
    } else {
        [_protectedBids addObject:bid];
    }
    [self _saveProtectedArray];

    _specifiers = nil;
    [self reloadSpecifiers];
}

@end
