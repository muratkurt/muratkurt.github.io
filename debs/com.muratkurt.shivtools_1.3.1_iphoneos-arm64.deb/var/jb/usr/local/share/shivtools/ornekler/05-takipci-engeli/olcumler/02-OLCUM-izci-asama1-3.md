# izci — proje raporu

## 0.1.1 — Aşama 1 (yalnız ölçüm), 1 Eki 2026

Cihaz: iPhone16,1, iOS 17.0.3, RootHide. Kurulum turu: 2/2.

**Belirti / soru:** Uygulamalar ağ isteğini hangi noktadan yapıyor, hangi
hook alan adını güvenilir yakalıyor?

**Ölçüm:** 6 yalnız-ölçüm hook'u (`%orig` + tek satır):
`getaddrinfo`, `DNSServiceGetAddrInfo` (0.1.1), `nw_endpoint_create_host`,
`nw_connection_create`, `connect`, `-[NSURLSessionTask resume]`.
Uygulamalar: Reddit, Instagram, YouTube, Safari (her biri kapat → aç →
1 kaydırma; Safari'de cnn.com). Günlükler: `olcum/*.log` (tur 2),
`olcum/tur1/` (tur 1). Tablo: `olcum/tablo-asama1.tsv`.

**Bulgular (ÖLÇÜLDÜ):**
1. Altı hook da dört uygulamada kuruldu (`izci-basladi` satırı); sandbox
   içinden jbroot prefs plist'i `jbroot()` ile okunuyor.
2. `-[NSURLSessionTask resume]` (`v16@0:8`) taban sınıfta;
   `__NSCFLocalSessionTask` ezmiyor. Reddit'te AFNetworking `af_resume`
   takası var, hook yine tetikleniyor.
3. `getaddrinfo` çağrılarının Reddit/YouTube/Safari'de %100'ü
   `flags=0x4` (AI_NUMERICHOST), `r=8` → **DNS çözümü değil, IP-mi
   denetimi.** Yine de istekteki her alan adı ve CNAME zinciri
   (`dualstack.reddit.map.fastly.net.` gibi, sonunda nokta) buradan geçiyor.
4. `DNSServiceGetAddrInfo`: kuruldu, **0 çağrı**. Sistemin gerçek DNS
   çözümü hook'lanmamış özel bir yoldan geçiyor (hangi yol: DOĞRULANMADI).
5. `connect`: Reddit/YouTube/Safari'de **0** — NSURLSession/nw soket açmak
   için `connect` kullanmıyor. Instagram'da 40: kendi ağ yığını
   (`getaddrinfo flags=0x400` ile gerçek çözüm + `connect`).
6. Safari: cnn.com Safari sürecinde **hiç görünmedi** (2 turda 0). Sayfa
   trafiği `com.apple.WebKit.Networking` XPC sürecinde; izci yalnız
   `.app` süreçlerine giriyor. WKWebView kullanan her uygulama için aynı
   kör nokta beklenir (DOĞRULANMADI).
7. Hariç tutma: ctor'da bundle id kontrolü + parça emniyet ağı. dylib'in
   kendisi yine yükleniyor (filtre plist'i hariç tutma desteklemiyor).
   Banka uygulamasında "hiç hook kurulmadı" ayrıca ölçülmedi.

**Şüpheli (DOĞRULANMADI):** Instagram'da hiçbir hook'ta ad görülmeden
`connect` → `104.21.4.65:80` (tur 1'de `172.67.154.15:80`), Cloudflare
aralığı, düz HTTP. Ayrıca 20 adet FB IPv6/IPv4 bağlantısı `kaynak=yok`;
ama gerçek çözüm görünmediği için bu doğrudan IP/DoH KANITI değil.
Instagram'da `fouadraheb.com` ve `in.appcenter.ms` görünüyor — kurulu
Instagram değiştirilmiş bir derleme olabilir (DOĞRULANMADI).

**Sebep (Aşama 2 için):** Tek bir hook tüm uygulamaları kapsamıyor;
NSURLSession uygulamalarında `resume`, kendi yığını olanlarda
`getaddrinfo(flags≠0x4)` + `nw_endpoint_create_host` alan adını taşıyor.

**Ölçülmedi:** uzun oturum, video oynatma (googlevideo/QUIC), reklam
gösterimi anı, banka uygulamasına girilmediğinin süreç içinden kanıtı,
WebKit.Networking süreci, uygulama eklentileri (.appex).

## 0.2.0 — Aşama 2 (engelleme), 1 Eki 2026

Kurulum turu: 1/2 (0.2.0-2). Günlükler: `olcum/asama2/`.

**Liste:** HaGeZi Multi PRO, `wildcard/pro-onlydomains.txt`, sürüm
2026.1001.0851.31, 231.053 kayıt ("alt alan adları olmadan": kayıt alt
alanlarını da kapsar → sonek eşleşmesi). `izci-derle` ile sıralı
FNV-1a-64 özet dizisine derlendi: 1.848.456 bayt, 102 ms, **0 çakışma**
(tekil = geçerli). Tweak dosyayı mmap eder; istek başına metin taraması
yok, sonek başına bir ikili arama.

**Arama süresi (ÖLÇÜLDÜ):**
- Araçta (200 bin tekrar ortalaması): 94–432 ns tipik, 9 etiketli ad
  1.430 ns; liste açma 34 µs.
- Uygulama içinde (n=280, mach_absolute_time, gerçek istekler): p50
  5,9 µs, p90 17 µs, p99 1,2 ms, en kötü 9,1 ms. Yüksek değerler
  açılışa yığılmıyor; sebebi iş parçacığının o anda başka işe verilmesi
  olabilir (DOĞRULANMADI).

**Engel noktaları (Aşama 1 ölçümüne göre):**
- `-[NSURLSessionTask resume]` → `%orig` yerine public `-cancel`
  (NSURLErrorCancelled). Reddit 42, Instagram 2, YouTube 1 engel.
- `getaddrinfo` yalnız gerçek çözümde (AI_NUMERICHOST değil) →
  `EAI_NONAME`. Instagram'ın kendi yığını: 18 engel (netseer/fbcdn
  ölçüm alt alanları).
- `nw_connection_create` ölçüm amaçlı kaldı: listede olup orada
  geçen bağlantıyı `liste=EVET` diye işaretler. Engel açıkken 0 satır.

**Doğrulama (ÖLÇÜLDÜ):** Reddit akışı yüklendi, YouTube ana sayfa açıldı,
Instagram süreci ayakta; yeni çökme raporu yok. Prefs: "İzleyicileri
engelle" anahtarı ve "Engellemenin kapalı olduğu uygulamalar" sayfası
(Root.plist'teki `izciKey` specifier özelliği okunuyor). Reddit
işaretlenince `engel=0 uygKapali=1`, 0 engel, appsflyer geçti.

**Tuzaklar (ÖLÇÜLDÜ):**
- RootHide'da dpkg dışında derlenen araç exit 137 ile öldürüldü; dpkg
  ile kurulunca çalıştı.
- `izci-derle` gerçek kökü görüyor; kabuktaki `/var/mobile/...` yolu
  ona jbroot önekiyle verilmeli. (İyileştirme: araç içinde `jbroot()`.)
- Bu cihazdaki `defaults` `-array` ve `delete` desteklemiyor.
- Derleme numarası arttı (`-1` → `-2`); bir kez eski deb açıldı,
  `dm.pl` satırından düzeltildi.

**Bilinen sınırlar:** Safari ve WKWebView trafiği (WebKit.Networking)
kapsam dışı. Liste statik: HaGeZi 8 saatte bir güncelleniyor, izci
yeniden derlenene kadar eski listeyi kullanır.

## 0.3.0 — Aşama 3 (rapor ekranı), 1 Eki 2026

Kurulum turu: 1/2 (0.3.0-1).

**Ölçüm (kurulum turu harcamadan):**
- frida (yalnız Reddit'e): sandbox jbroot'u OKUYABİLİYOR ama YAZAMIYOR
  (`fopen` errno=1, iki dizinde). Arka plandaki uygulamaya attach zaman
  aşımına düştü; öne getirince bağlandı.
- Ayarlar ikilisinin yetkilerinde `com.apple.private.security.no-sandbox`
  var → sayaçlar uygulamanın KENDİ kapsayıcısına yazılır, Ayarlar oradan
  okur.

**Tasarım:** her engel `$HOME/Library/Caches/izci-engel.log` dosyasına
`unix_sn<TAB>eşleşen-alan` yazar (ilk satır `#<TAB>bundle-id`;
512 KB'ı geçince açılışta `.1`'e döner). Günlük anahtarından bağımsız.
Ayarlar › izci › Rapor › Son 7 gün: toplam, uygulama sayısı, uygulama
başına "X uygulamasında Y tarafından Z istek engellendi".

**Şirket eşlemesi:** `layout/Library/izci/sirketler.tsv`, 8.740 alan,
`liste/sirket-derle.mjs` ile: DDG Tracker Blocklists app/android-tds
(337, sürüm 1688648647512 = Tem 2023), DDG ios-tds domains (5.206),
Disconnect services.json (3.197). Üçü de CC BY-NC-SA 4.0. Sonek eşleşmesi.
`appsflyersdk.com` üç kaynakta da YOK → raporda "şirket listede yok".

**Doğrulama (ÖLÇÜLDÜ):** üç uygulama kendi kapsayıcısına yazdı; Ayarlar
3 dosyayı okudu. Rapor: 3 uygulama, 44 istek; Reddit 25 (Reddit 17,
appsflyersdk.com 6, Google 2) — kabuktaki sayımla birebir. Instagram:
Facebook 18. YouTube: Google 1. Ayarlar çökmedi.

**DOĞRULANMADI:** PSTitleValueCell değer sütunu (sayı) AX ağacında
görünmüyor; ekranda çizildiği gözle doğrulanmadı. iOS'un Caches'i
depolama baskısında silmesi (rapor sıfırlanır) ölçülmedi.
