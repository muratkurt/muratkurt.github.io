// KASwitcher 0.5.0 — kendi menumuz. Aciklama: KASMenu.h
#import "KASMenu.h"

static const CGFloat kKM_Genislik = 250.0;
static const CGFloat kKM_Satir    = 44.0;
static const CGFloat kKM_Bosluk   = 10.0;   // buton ile menu arasi
static const CGFloat kKM_Kenar    = 8.0;    // ekran kenari payi
static const CGFloat kKM_Kose     = 13.0;
static const CGFloat kKM_Kucuk    = 0.25;   // ac/kapa animasyonunun baslangic olcegi

// ─── Oge ──────────────────────────────────────────────────────────────
@implementation KASMenuOge
+ (instancetype)baslik:(NSString *)b ikon:(UIImage *)i isleyici:(void (^)(void))h {
    KASMenuOge *o = [self new];
    o.baslik = b; o.ikon = i; o.isleyici = h;
    return o;
}
+ (instancetype)altMenu:(NSString *)b ikon:(UIImage *)i uretici:(NSArray<KASMenuOge *> *(^)(void))u {
    KASMenuOge *o = [self new];
    o.baslik = b; o.ikon = i; o.altUretici = u;
    return o;
}
@end

// ─── Satir ────────────────────────────────────────────────────────────
@interface KASMenuSatir : UIControl
@property (nonatomic, strong) KASMenuOge *oge;   // nil: geri (baslik) satiri
@end
@implementation KASMenuSatir
- (void)setHighlighted:(BOOL)h {
    [super setHighlighted:h];
    self.backgroundColor = h ? [UIColor colorWithWhite:0.5 alpha:0.25] : [UIColor clearColor];
}
@end

// ─── Durum (tek menu) ─────────────────────────────────────────────────
static UIControl *kmPerde;                 // tum gorunumu kaplar, dokununca kapatir
static UIView *kmKap;                      // golge + konum/olcek (anchorPoint = butona yakin kose)
static UIVisualEffectView *kmCam;
static UIStackView *kmYigin;
static NSMutableArray<NSDictionary *> *kmYol;   // seviye yigini: @{u: uretici, b: baslik}
static void (^kmKapaninca)(void);
static __weak UIView *kmHedef;
static __weak UIView *kmKaynak;
static BOOL kmKapaniyor;

@interface KASMenuHedef : NSObject
+ (instancetype)tek;
- (void)satir:(KASMenuSatir *)s;
- (void)perde;
@end

static UIView *km_ayrac(void) {
    UIView *a = [UIView new];
    a.backgroundColor = [UIColor separatorColor];
    a.translatesAutoresizingMaskIntoConstraints = NO;
    [a.heightAnchor constraintEqualToConstant:(1.0 / [UIScreen mainScreen].scale)].active = YES;
    return a;
}

static KASMenuSatir *km_satir(KASMenuOge *o, NSString *geriBaslik) {
    KASMenuSatir *s = [KASMenuSatir new];
    s.oge = o;
    s.translatesAutoresizingMaskIntoConstraints = NO;
    [s.heightAnchor constraintEqualToConstant:kKM_Satir].active = YES;
    [s addTarget:[KASMenuHedef tek] action:@selector(satir:) forControlEvents:UIControlEventTouchUpInside];

    UIColor *renk = (o && o.kirmizi) ? [UIColor systemRedColor] : [UIColor labelColor];
    UILabel *l = [UILabel new];
    l.translatesAutoresizingMaskIntoConstraints = NO;
    l.text = o ? o.baslik : geriBaslik;
    l.textColor = renk;
    // 0.5.0-m2: sabit 17 pt degil, sistem Body (kullanicinin metin boyutu;
    // UICTContentSizeCategoryS iken 15 pt - stok menu gibi). Sigmazsa %85'e kadar kuculur.
    UIFont *govde = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    l.font = o ? govde : [UIFont systemFontOfSize:govde.pointSize weight:UIFontWeightSemibold];
    l.adjustsFontSizeToFitWidth = YES;
    l.minimumScaleFactor = 0.85;
    [s addSubview:l];

    // Sol: yalniz geri satirinda chevron.left. (m2: onay isareti SAGA tasindi -
    // solda metni itip sag tarafta harf yutuyordu.)
    UIImage *sol = o ? nil : [UIImage systemImageNamed:@"chevron.left"];
    BOOL solKolon = (!o);
    if (sol) {
        UIImageView *iv = [[UIImageView alloc] initWithImage:sol];
        iv.translatesAutoresizingMaskIntoConstraints = NO;
        iv.tintColor = renk;
        iv.preferredSymbolConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:15 weight:UIImageSymbolWeightSemibold];
        [s addSubview:iv];
        [iv.centerYAnchor constraintEqualToAnchor:s.centerYAnchor].active = YES;
        [iv.centerXAnchor constraintEqualToAnchor:s.leftAnchor constant:22].active = YES;
    }
    // Sag: alt menude chevron.right; secili ogede onay isareti; degilse ikon.
    UIImage *sag = o.ikon;
    if (o && o.altUretici) sag = [UIImage systemImageNamed:@"chevron.right"];
    else if (o && o.secili) sag = [UIImage systemImageNamed:@"checkmark"];
    if (sag) {
        UIImageView *iv = [[UIImageView alloc] initWithImage:sag];
        iv.translatesAutoresizingMaskIntoConstraints = NO;
        iv.tintColor = renk;
        if (o.secili && !o.altUretici)
            iv.preferredSymbolConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:15 weight:UIImageSymbolWeightSemibold];
        iv.contentMode = UIViewContentModeCenter;
        [s addSubview:iv];
        [iv.centerYAnchor constraintEqualToAnchor:s.centerYAnchor].active = YES;
        [iv.centerXAnchor constraintEqualToAnchor:s.rightAnchor constant:-26].active = YES;
    }
    [NSLayoutConstraint activateConstraints:@[
        [l.leftAnchor constraintEqualToAnchor:s.leftAnchor constant:(solKolon ? 42 : 16)],
        [l.rightAnchor constraintLessThanOrEqualToAnchor:s.rightAnchor constant:-50],
        [l.centerYAnchor constraintEqualToAnchor:s.centerYAnchor],
    ]];
    if (o && o.pasif) { s.enabled = NO; s.alpha = 0.35; }
    return s;
}

// Menu boyutunu olcer, butonun YANINA hizalar (buton sagdaysa menunun sag
// kenari butonun sag kenarina), ustte yer yoksa alta alir. anchorPoint
// butona en yakin kose: ac/kapa oraya dogru olur, butonun ustunden gecmez.
static void km_yerlestir(void) {
    UIView *v = kmHedef, *k = kmKaynak;
    if (!v || !k || !kmKap) return;
    CGFloat w = kKM_Genislik;
    CGFloat h = [kmYigin systemLayoutSizeFittingSize:CGSizeMake(w, 0)
                       withHorizontalFittingPriority:UILayoutPriorityRequired
                             verticalFittingPriority:UILayoutPriorityFittingSizeLevel].height;
    CGSize S = v.bounds.size;
    CGRect b = [k convertRect:k.bounds toView:v];
    BOOL sagda = CGRectGetMidX(b) > S.width / 2.0;
    CGFloat x = sagda ? CGRectGetMaxX(b) - w : CGRectGetMinX(b);
    x = MAX(kKM_Kenar, MIN(S.width - kKM_Kenar - w, x));
    // Yatayda safeAreaInsets dikey degerleri veriyor (0.4.4-m1): orada yalniz kenar payi.
    BOOL yatay = S.width > S.height;
    CGFloat ustSinir = yatay ? kKM_Kenar : MAX(kKM_Kenar, v.safeAreaInsets.top);
    BOOL ustte = (CGRectGetMinY(b) - kKM_Bosluk - h) >= ustSinir;
    CGFloat y = ustte ? CGRectGetMinY(b) - kKM_Bosluk - h : CGRectGetMaxY(b) + kKM_Bosluk;
    y = MAX(ustSinir, MIN(S.height - kKM_Kenar - h, y));
    CGPoint ap = CGPointMake(sagda ? 1.0 : 0.0, ustte ? 1.0 : 0.0);
    kmKap.layer.anchorPoint = ap;
    kmKap.bounds = CGRectMake(0, 0, w, h);
    kmKap.center = CGPointMake(x + ap.x * w, y + ap.y * h);
    kmKap.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:kmKap.bounds cornerRadius:kKM_Kose].CGPath;
    kmCam.frame = kmKap.bounds;
    kmYigin.frame = kmCam.contentView.bounds;
}

// Yiginin tepesindeki seviyeyi tazeden uretip cizer.
static void km_seviyeCiz(BOOL animasyonlu) {
    NSDictionary *d = kmYol.lastObject;
    if (!d || !kmYigin) return;
    NSArray<KASMenuOge *> *(^u)(void) = d[@"u"];
    NSArray<KASMenuOge *> *ogeler = u ? u() : @[];
    NSString *geri = (kmYol.count > 1) ? d[@"b"] : nil;
    for (UIView *e in [kmYigin.arrangedSubviews copy]) { [kmYigin removeArrangedSubview:e]; [e removeFromSuperview]; }
    if (geri) { [kmYigin addArrangedSubview:km_satir(nil, geri)]; [kmYigin addArrangedSubview:km_ayrac()]; }
    for (NSUInteger i = 0; i < ogeler.count; i++) {
        if (i > 0) [kmYigin addArrangedSubview:km_ayrac()];
        [kmYigin addArrangedSubview:km_satir(ogeler[i], nil)];
    }
    if (!animasyonlu) { km_yerlestir(); return; }
    kmYigin.alpha = 0.0;
    // m3: 0.22 -> 0.40 sn (kullanici: iOS'a gore ~2 kat hizliydi).
    [UIView animateWithDuration:0.40 delay:0 usingSpringWithDamping:0.9 initialSpringVelocity:0
                        options:UIViewAnimationOptionBeginFromCurrentState animations:^{
        km_yerlestir();
        [kmKap layoutIfNeeded];
        kmYigin.alpha = 1.0;
    } completion:nil];
}

static void km_temizle(void) {
    [kmPerde removeFromSuperview];
    [kmKap removeFromSuperview];
    kmPerde = nil; kmKap = nil; kmCam = nil; kmYigin = nil; kmYol = nil;
    kmKapaniyor = NO;
    void (^k)(void) = kmKapaninca;
    kmKapaninca = nil;
    if (k) k();
}

@implementation KASMenuHedef
+ (instancetype)tek {
    static KASMenuHedef *t;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ t = [KASMenuHedef new]; });
    return t;
}
- (void)perde { [KASMenu kapat:YES]; }
- (void)satir:(KASMenuSatir *)s {
    if (kmKapaniyor) return;
    KASMenuOge *o = s.oge;
    if (!o) {                                   // geri
        if (kmYol.count > 1) [kmYol removeLastObject];
        km_seviyeCiz(YES);
        return;
    }
    if (o.pasif) return;
    if (o.altUretici) {
        [kmYol addObject:@{@"u": [o.altUretici copy], @"b": o.baslik ?: @""}];
        km_seviyeCiz(YES);
        return;
    }
    void (^h)(void) = o.isleyici;
    if (o.acikKalsin) {
        if (h) h();
        km_seviyeCiz(NO);                       // durum (onay isareti) tazelensin
        return;
    }
    if (h) h();                                 // once is (bayraklar kapaninca'dan once dikilsin)
    [KASMenu kapat:YES];
}
@end

@implementation KASMenu
+ (BOOL)acik { return kmKap != nil; }

+ (void)gosterIcinde:(UIView *)v kaynak:(UIView *)kaynak
                 kok:(NSArray<KASMenuOge *> *(^)(void))kok
           kapaninca:(void (^)(void))kapaninca {
    if (!v || !kaynak || !kok) return;
    [self kapat:NO];
    kmHedef = v; kmKaynak = kaynak;
    kmKapaninca = [kapaninca copy];
    kmYol = [NSMutableArray arrayWithObject:@{@"u": [kok copy], @"b": @""}];

    kmPerde = [[UIControl alloc] initWithFrame:v.bounds];
    kmPerde.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    kmPerde.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.0];
    [kmPerde addTarget:[KASMenuHedef tek] action:@selector(perde) forControlEvents:UIControlEventTouchDown];
    [v addSubview:kmPerde];

    kmKap = [UIView new];
    kmKap.layer.shadowColor = [UIColor blackColor].CGColor;
    kmKap.layer.shadowOpacity = 0.22;
    kmKap.layer.shadowRadius = 24;
    kmKap.layer.shadowOffset = CGSizeMake(0, 8);
    kmCam = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterial]];
    kmCam.layer.cornerRadius = kKM_Kose;
    kmCam.clipsToBounds = YES;
    [kmKap addSubview:kmCam];
    kmYigin = [UIStackView new];
    kmYigin.axis = UILayoutConstraintAxisVertical;
    [kmCam.contentView addSubview:kmYigin];
    [v addSubview:kmKap];

    km_seviyeCiz(NO);
    kmKap.transform = CGAffineTransformMakeScale(kKM_Kucuk, kKM_Kucuk);
    kmKap.alpha = 0.0;
    [UIView animateWithDuration:0.38 delay:0 usingSpringWithDamping:0.82 initialSpringVelocity:0
                        options:UIViewAnimationOptionAllowUserInteraction animations:^{
        kmKap.transform = CGAffineTransformIdentity;
        kmKap.alpha = 1.0;
        kmPerde.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.12];
    } completion:nil];
}

+ (void)kapat:(BOOL)animasyonlu {
    if (!kmKap) return;
    if (!animasyonlu) { km_temizle(); return; }
    if (kmKapaniyor) return;
    kmKapaniyor = YES;
    kmPerde.userInteractionEnabled = NO;
    [UIView animateWithDuration:0.2 delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
        kmKap.transform = CGAffineTransformMakeScale(kKM_Kucuk, kKM_Kucuk);
        kmKap.alpha = 0.0;
        kmPerde.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.0];
    } completion:^(BOOL finished) {
        if (kmKapaniyor) km_temizle();
    }];
}
@end
