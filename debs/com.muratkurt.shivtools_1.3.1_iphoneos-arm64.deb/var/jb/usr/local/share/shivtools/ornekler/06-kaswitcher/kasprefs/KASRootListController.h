#import <Preferences/PSListController.h>

@interface KASRootListController : PSListController
@end
