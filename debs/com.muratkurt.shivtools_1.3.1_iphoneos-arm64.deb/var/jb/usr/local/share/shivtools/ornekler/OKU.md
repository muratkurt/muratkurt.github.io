# Örnekler — nasıl kullanılır

01–04 ve 07 **derlenip `.deb` üretecek** hâlde bırakıldı; bu klasördeki her
dosya Mac'te Theos ile derlenerek doğrulandı (aşağıda ne ölçüldüğü
yazıyor). Kopyala, adları değiştir, kendi hook'unu yaz.

```
01-springboard-hook/   SpringBoard tweak'i        (KASwitcher deseni)
02-prefs/              Ayarlar sayfası + tweak    (ActionButtonFix + KASwitcher)
03-uygulama-ici/       Uygulama içi, ağ süzme     (DolapClean deseni)
04-kurulum-sihirbazi/  Ayarlar'dan kurulum        (shivtools 1.1.0 deseni)
05-takipci-engeli/     Bitmiş tweak + ölçümler    (AppTrackerBlock 1.0.0; HER uygulamanın ağına karışır, önce TEHLİKELER)
06-kaswitcher/         Bitmiş SpringBoard tweak'i (KASwitcher 0.7; durumun sahibi Apple, imza denetimli çağrılar, ölçüm tweak'i)
07-olcum-tweaki/       Ölçüm tweak'i iskeleti     (YAYINLANMAZ; komutla çalışır, Apple'ın davranışını ürünsüz ölçer)
```

## Derleme

```
export THEOS=~/theos-rh            # RootHide hedefi için roothide ÇATALI
make clean package THEOS_PACKAGE_SCHEME=roothide FINALPACKAGE=1

export THEOS=~/theos               # rootless hedefi için STANDART theos
make clean package THEOS_PACKAGE_SCHEME=rootless FINALPACKAGE=1
```

Klasör adına güvenme, içine bak:
`git -C <klasör> config --get remote.origin.url`.

## Ne doğrulandı (26 Eylül 2026, Mac)

| Örnek | Sonuç |
|---|---|
| 01 | arm64+arm64e derlendi, deb üretildi; `Library/MobileSubstrate/DynamicLibraries/` içinde dylib + filtre plist'i |
| 02 | Tweak **ve** bundle ayrı ayrı derlendi; pakette `PreferenceBundles/OrnekPrefs.bundle` (Info.plist, Root.plist, ikili) **ve** `PreferenceLoader/Preferences/OrnekPrefs.plist` |
| 03 | arm64 derlendi; rootless şemasıyla `/var/jb/...` altına kuruluyor |
| 04 | iki şema da deb üretti; roothide `Library/…`+`usr/local/…`, rootless tek `var/jb/…` öneki; `@ONEK@` plist içinde şemaya göre doldu (29 Eyl 2026) |
| caps | Mac derlemesi arm64e diliminde **0x80** (`lipo -thin arm64e` + `od`) |
| 06 | Mac'te iki şema derlendi, dylib + prefs arm64e **0x80** (4 Eki 2026). Kullanıcı testi vphone 26.6.2 + RootHide 17.0.3 + XS 16.1.1, tümü geçti (yayındaki 0.7.0) |
| 07 | Mac'te iki şema derlendi, **0x80**, `__cfstring` 0, `__objc_classlist` 0 (4 Eki 2026) |
| 05 | **cihazda** derlendi, iki cihazda çalıştırıldı (RootHide 15 Pro, rootless XS; 1 Eki 2026). Mac'te derlenmedi (DOĞRULANMADI). Ayarlar sayfası oldabi gerektiriyor: `05-takipci-engeli/OKU.md` |

01–04 cihazda **çalıştırılmadılar** — iskelet oldukları için hedef sınıf
adları örnektir (`SBFluidSwitcherItemContainer`,
`Alamofire.SessionDelegate`, `com.ornek.hedefuygulama`). Kendi hedefini
koyduktan sonra cihazda ölç.

## Hangi örnek neyi gösteriyor

**01 — SpringBoard hook**
- Dosyaya ölçüm günlüğü ve **"çağrıldı" kanıtı** (MCP varsa `NSLog`
  da okunuyor — `get_syslog`; dosya günlüğü MCP'siz ve sandbox'ta yedek yol)
- Ayar okuma + Darwin bildirimi
- `%group` + `%ctor`: sınıf yoksa hook kurulmaz, günlüğe düşer
- Görünüm **kapalı doğar** (respring sonrası tek seferlik titremenin çaresi)
- Yeniden kullanılan kapta **idempotent** kurulum
- **Model ↔ ekran** ölçümü ve snapshot kopyasıyla animasyon

**02 — Ayarlar sayfası**
- `Root.plist`: grup, anahtar, **slider (`cellClass` ile)**, tekli seçim
  listesi, **alt sayfa**, salt okunur değer, bağlantı satırı
- `ORPSliderCell`: değer etiketi **iki seviye derinde** — yanlış seviyeye
  uygulanan düzeltme sessizce etkisiz kalır
- `ORPListeController`: **dinamik liste** (`PSSpecifier` + `reloadSpecifiers`),
  uygulama listesi, lazy ikon, onay işaretini kaynaktan çizme
- `Tweak.x`: prefs ile **aynı alan** + bildirim — bu bağlantı kurulmazsa
  ayar kaydolur ama tweak görmez

**03 — Uygulama içi (Swift/SwiftUI)**
- Görünüm yerine **veri** katmanı: gizlemek boşluk bırakır, silmek bırakmaz
- Parçaları biriktir → tamamlanınca süz → **kendi çağrını bayrakla** geçir
- Hata ya da çözülemeyen JSON'da **orijinali** ver
- **Beyaz liste** (akış) / kara liste (işlevsel sayfa) kararı
- Kimlik alanı yoksa metinle ayırma
- Sandbox: `NSTemporaryDirectory()` (uygulama `/var/mobile/tw`'ye yazamaz)
- **Ölçüm modu** anahtarı: önce değiştirmeden kaydet, sayıyı önceden
  hesapla, sonra süz

**04 — Kurulum sihirbazı**
- Ayarlar `mobile` çalışır ve paket kuramaz; **root LaunchDaemon**
  (`WatchPaths`) isteği işler. Yüzey dar: sabit izin listesi, tek
  kelime, argüman yok, kabuk yok
- **Durum protokolü**: bileşen olayları (`kuruluyor/tamam/basarisiz`)
  ile turun sonu (`bitti`) AYRI aşamalar; biriken `sonuc` haritası
  sayesinde ekran ne zaman açılırsa açılsın satırlar doğru
- **Tazelik ölçütü**: "dosya var" değil "yeni iz var" — ölü tur
  sonsuza kadar "sürüyor" demesin
- İsteği **sonda** sil (baştaki silme `WatchPaths`'i tetikleyip
  çalışan işi kesiyor) + deneme sayacı
- Yalnız kendi deponu `apt-get update` et (3,5 dk → 9 sn)
- İşaretleyici satırlar (varsayılan hepsi işaretli), ekranda yazan
  komut ile gönderilen isteğin **aynı listeden** üretilmesi

**06 — KASwitcher 0.7 (bitmiş tweak)**
- **Durumun sahibi Apple ise onu kullan:** kendi süzgeç yerine `SBAppLayout.hidden`
- **Veriyi doğru anda kendin al, Apple'a Apple'ın yoluyla ver** (kasa görüntüsü)
- **"Dokununca düzeliyorsa" eksik olan yenileme tetiğidir** (`_updateSnapshotCache`)
- Zaman penceresi yerine **durum değeri**, tek bayrak yerine **başla/bit eşlemesi**
- Her özel çağrı **imza denetimli** (`KASGizle.m`)
- Mimariyi veren **ayrı ölçüm tweak'i** ve sonuçları (`olcum-tweaki/`, `olcumler/`)

**07 — Ölçüm tweak'i iskeleti**
- Ürün kaldırılmışken Apple'ın davranışını ölç; komut dosyasıyla tetiklenir
- `imza` komutu: tip kodlamasını **çağırmadan** okur
- `imza()` yardımcısı: tutmazsa çağrı yok, günlükte `IMZA-TUTMADI`
- Caps tetikleyicisi yok: literal yok, sisteme blok yok, kendi sınıfı yok

## Her örnekte ortak olan disiplin

1. Sınıf **varsa** hook kur, yoksa günlüğe yaz — çökme yerine sessiz
   etkisizlik.
2. Hata yolunda **orijinali** geçir.
3. Kararı veren **değerleri** logla, yalnız eylemi değil.
4. Kurulan hook ≠ çalışan hook: ilk çağrıyı bir kez yaz.
