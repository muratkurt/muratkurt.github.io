# AppTrackerBlock — ana geliştirme raporu

**Oturum:** 1 Ekim 2026 · **Sürüm:** 1.0.0 (izci 0.1.0 → 0.3.0 → AppTrackerBlock 1.0.0)
**Paket:** `com.muratkurt.apptrackerblock` · **Kaynak:** `Documents/Tweaks-dev/AppTrackerBlock/SOURCE-1.0.0`
(eski Türkçe sürüm, geri dönüş için: `ARSIV/eski-cihaz-klasoru/izci`)

Etiketler: **ÖLÇÜLDÜ** = cihazda görüldü · **DOĞRULANMADI** = çıkarım ya da
belgeden gelen bilgi, cihazda görülmedi.

---

## 1. Özet

AppTrackerBlock, DuckDuckGo'nun Android'deki "App Tracking Protection"
özelliğinin iOS karşılığı. Uygulamaların içinden izleme alan adlarına
giden istekleri engeller. Ayarlar'da son 7 günün dökümünü uygulama ve
şirket bazında gösterir: "Reddit'te AppsFlyer 11 kez engellendi".

- Engel listesi: HaGeZi Multi PRO (231.053 alan), cihazda bir kez ikiliye
  derlenir, istek başına mikrosaniye altı arama.
- Engel noktaları ölçümle seçildi: `-[NSURLSessionTask resume]` → `cancel`,
  gerçek `getaddrinfo` → `EAI_NONAME`. İkisi de uygulamanın kendi hata
  yolunu çalıştırır, uygulama çökmez.
- Banka, ödeme ve kripto uygulamalarına hiç hook kurulmaz (liste + parça
  emniyet ağı).
- Ayarlar sayfası shivtools ev stilinde, 12 dilde.
- RootHide (iOS 17.0.3) ve rootless (iOS 16.1.1) cihazlarda test edildi.

---

## 2. Cihazlar ve ortam

| | Geliştirme cihazı | Rootless test cihazı |
|---|---|---|
| Model | iPhone16,1 (15 Pro) | iPhone11,2 (XS, A12) |
| iOS | 17.0.3 (21A360) | 16.1.1 (20B101) |
| Jailbreak | RootHide | rootless (Dopamine) |
| Derleyici | Procursus-roothide clang 14.0.0 | palera1n Procursus clang 16.0.0 |
| Theos | /var/mobile/theos-roothide | /var/jb/var/mobile/theos |
| Bağlantı | — | bu telefonun hotspot'u, 172.20.10.3, ssh mobile / *** (parola maskeli) |
| oldabi | kurulu | kurulu |

Rootless cihaza `bridge100 172.20.10.1/28` ağında port 22 taranarak
ulaşıldı. MCP'si yalnız 127.0.0.1'i dinlediği için SSH tüneliyle
(`-L 18090:127.0.0.1:8090`) ve küçük bir node istemcisiyle kullanıldı
(`olcumler/mcp-tunel-istemcisi.mjs`).

---

## 3. Mimari

```
Uygulama süreci (TweakInject, filtre: com.apple.UIKit, yalnız .app)
 ├─ ctor: bundle id → hariç mi? (liste + "bank/wallet/coin…" parçaları)
 ├─ prefs: jbroot(/var/mobile/Library/Preferences/<domain>.plist), yoksa düz yol
 ├─ liste: jbroot(/var/mobile/Library/AppTrackerBlock/hagezi-pro.bin) → mmap
 ├─ ENGEL hook'ları (engel ya da günlük açıkken)
 │    -[NSURLSessionTask resume]   listedeyse -cancel
 │    getaddrinfo                  gerçek çözümse ve listedeyse EAI_NONAME
 ├─ ÖLÇÜM hook'ları (YALNIZ geliştirici günlüğü açıkken)
 │    nw_endpoint_create_host, nw_connection_create, connect, DNSServiceGetAddrInfo
 ├─ sayaç: $HOME/Library/Caches/AppTrackerBlock-blocked.log   (rapor bunu okur)
 └─ günlük: $TMPDIR/AppTrackerBlock-debug.log                  (geliştirici)

Ayarlar (sandbox'sız) → AppTrackerBlockPrefs.bundle
 ├─ ana sayfa: başlık kartı + rozet, engel anahtarı, liste durumu, hariç/istisna listeleri, HAKKINDA
 └─ rapor: /var/mobile/Containers/Data/Application/*/Library/Caches/AppTrackerBlock-blocked.log(.1)
           + jbroot(/Library/AppTrackerBlock/companies.tsv) ile şirket adı

Araçlar
 ├─ atb-compile  metin listesi → ikili (ATBLIST1 + sıralı FNV-1a-64)
 └─ atb-update   HaGeZi'yi indirir, atb-compile'a verir
```

**Dosyalar** (`SOURCE-1.0.0/`): `Tweak.x`, `Blocklist.[ch]` (biçim +
arama, tweak ile aracın ortak kodu), `Common.h` (alan, anahtar, yollar,
varsayılan hariç listesi), `JBRoot.h` (her şemada `jbroot()`),
`Prefs/` (ATBRootListController, ATBAppListController, ATBReportController,
ATBStyle, `i18n/build-strings.mjs`, `draw-icon.mjs`),
`tools/atb-compile/`, `data/build-companies.mjs`,
`layout/Library/AppTrackerBlock/companies.tsv`, `layout/usr/bin/atb-update`.

**Kurallar (kaynakta uygulanan):** hiç `@"..."` literali yok ve sisteme blok
verilmiyor (cihazda derlenen arm64e caps 0x00; `__cfstring = 0` her derlemede
ölçüldü). Özel nesneler `%@` ile yazılmıyor. `%orig` kendi satırında.

---

## 4. Aşama 1 — ölçüm (izci 0.1.0–0.1.1)

Altı yalnız-ölçüm hook'u (`%orig` + tek satır). Reddit, Instagram, YouTube,
Safari; iki tur. Kayıtlar: `olcumler/asama1-tur1/`, `olcumler/asama1-tur2/`.

| Bulgu | Durum |
|---|---|
| Altı hook dört uygulamada kuruldu; sandbox içinden jbroot prefs okunuyor | ÖLÇÜLDÜ |
| `-[NSURLSessionTask resume]` `v16@0:8` taban sınıfta, alt sınıflar ezmiyor | ÖLÇÜLDÜ (Reddit, shiv-sinif --tip) |
| Reddit/YouTube/Safari'de `getaddrinfo` çağrılarının %100'ü `flags=0x4` (AI_NUMERICHOST), `r=8` → DNS değil IP denetimi; yine de her alan ve CNAME zinciri buradan geçiyor | ÖLÇÜLDÜ |
| `DNSServiceGetAddrInfo` kuruldu, 0 çağrı → sistemin gerçek DNS yolu başka | ÖLÇÜLDÜ (hangi yol: DOĞRULANMADI) |
| NSURLSession/nw `connect` kullanmıyor (0); Instagram kendi yığınıyla `getaddrinfo flags=0x400` + `connect` | ÖLÇÜLDÜ |
| Safari sayfa trafiği Safari sürecinde değil (cnn.com 0) → WebKit.Networking | ÖLÇÜLDÜ |
| Instagram → `104.21.4.65:80` / `172.67.154.15:80`, hiçbir hook'ta ad yok | şüpheli, DOĞRULANMADI |

Sonuç: tek bir hook her uygulamayı kapsamıyor → engel `resume` + gerçek
`getaddrinfo` ikilisinde.

---

## 5. Aşama 2 — engelleme (izci 0.2.0)

| Ölçüm | Değer |
|---|---|
| Liste | HaGeZi Multi PRO `wildcard/pro-onlydomains.txt`, sürüm 2026.1001.0851.31 |
| Kayıt / tekil / çakışma | 231.053 / 231.053 / **0** |
| İkili boyut, derleme | 1.848.456 bayt, 102 ms (RootHide), 118 ms (A12) |
| Arama (araç, 200 bin tekrar) | 94–432 ns tipik, 9 etiketli ad 1,4 µs; A12'de 249–861 ns |
| Liste açma (mmap) | 34–36 µs (RootHide), 65 µs (A12) |
| Arama (uygulama içi, n=280) | p50 5,9 µs · p90 17 µs · p99 1,2 ms · en kötü 9,1 ms |

Uygulama içi yüksek değerler açılışa yığılmıyor; iş parçacığının başka işe
verilmesi olabilir (DOĞRULANMADI). Ağ isteği onlarca–yüzlerce ms sürdüğü için
pratikte önemsiz.

Engel kanıtı (`olcumler/asama2/`): Reddit 42 (`resume`), Instagram 18
(`getaddrinfo`, netseer/fbcdn ölçüm alt alanları) + 2, YouTube 1. Uygulamanın
kendi API'leri geçti (`gql-fed.reddit.com`, `i.instagram.com`,
`youtubei.googleapis.com`). "Bu uygulamada kapat" ölçüldü: `disabledHere=1`,
0 engel, appsflyer geçti, `nw` ölçümü `listed=YES` işaretledi.

---

## 6. Aşama 3 — rapor ekranı (izci 0.3.0)

| Bulgu | Durum |
|---|---|
| Sandbox jailbreak kökünü OKUYOR, YAZAMIYOR (`fopen` errno=1, iki dizin) | ÖLÇÜLDÜ (frida, Reddit; `olcumler/sandbox-yazma-ajani.js`) |
| Arka planda askıdaki uygulamaya frida attach zaman aşımı; öne alınca bağlandı | ÖLÇÜLDÜ |
| Ayarlar ikilisinde `com.apple.private.security.no-sandbox` | ÖLÇÜLDÜ (ldid -e); çalışma anında kapsayıcıları okuduğu da ÖLÇÜLDÜ |
| Sayaç uygulamanın kendi `Library/Caches`'ine yazılıyor; Ayarlar 3 dosyayı okudu, sayılar kabuktaki sayımla birebir | ÖLÇÜLDÜ |

**Şirket eşlemesi** (`data/build-companies.mjs` → `companies.tsv`, 8.740 alan):
DuckDuckGo Tracker Blocklists `app/android-tds.json` (337, Tem 2023 sürümü),
`ios-tds.json` (5.206), Disconnect `services.json` (3.197). Üçü de
**CC BY-NC-SA 4.0**. `appsflyersdk.com` üçünde de yok → raporda
"(company not in list)"; uydurma eşleme eklenmedi.

---

## 7. AppTrackerBlock 1.0.0

**Ad ve dil.** Kullanıcı kararı: ad İngilizce, kod ve yorumlar da İngilizce
("AI eleştirilerine maruz kalmamak için tutarlılık"). Mevcut dosyaları
yeniden yazmak yerine (kırmızı çizgi 3) yeni proje klasörü açıldı, çalışan
mantık satır satır taşındı; `~/izci` dokunulmadan kaldı (şimdi `ARSIV/eski-cihaz-klasoru/izci`). Ayar anahtarları:
`blocking`, `logging`, `excluded`, `blockingDisabledApps`.

**Arayüz (shivtools ev stili, rehber §7.5b).** Başlık kartı (72 pt ikon, ad,
tanım, `Version 1.0.0` — paketleyicinin yazdığı `version` dosyasından), durum
rozeti (en kötü durumun rengi: liste yok kırmızı, engel kapalı turuncu, açık
yeşil), Ayarlar tarzı satır ikonları (SF Symbols, çalışma anında çizilir),
engel listesi durum satırı (kayıt sayısı + derleme tarihi; yoksa dokununca
`atb-update` panoya), HAKKINDA (Geliştirici, Belgeler, Sorun bildir; dipnot).
İkon: `Prefs/draw-icon.mjs`, mor zemin üzerinde beyaz kalkan + onay.

**12 dil.** en, tr, de, fr, es, it, pt, ru, ja, zh-Hans, ko, ar. Tek kaynak
`Prefs/i18n/build-strings.mjs`; betik eksik anahtarı ve biçim belirteci
uyuşmazlığını reddediyor. Rapor cümleleri konumlu biçimle
(`%1$@ %2$@ %3$lu`) her dilin sözcük sırasına uyuyor; Rusçada çoğul
eki sorunu sayıyı sona alan kalıpla önlendi. 37 anahtar × 12 dil; koddaki ve
Root.plist'teki her metin tabloda (eksik 0, kullanılmayan 0).

**Teknik değişiklikler.**
- Ölçüm hook'ları yalnız geliştirici günlüğü açıkken kuruluyor; normal
  kullanımda her uygulamaya iki hook.
- Prefs önce jbroot yolunda, sonra düz yolda aranıyor.
- `JBRoot.h`: RootHide'da libroothide, rootless/rootful'da derleme önekli stub.
- `atb-compile` kökü kendi konumundan türetiyor; yollar önce verildiği gibi,
  sonra kök altında deneniyor; varsayılan çıktı tweak'in okuduğu yol.
- `atb-update`: indir + derle tek komut.

---

## 8. Rootless

| Adım | Sonuç |
|---|---|
| Kaynak SSH ile kopyalandı, cihazda `rootless` derlendi | `roothide.h` yok → `JBRoot.h` yazıldı |
| Stok Logos | `{ %orig; return; }` tek satırda `return; }` yutuldu → `%orig` kendi satırına (ÖLÇÜLDÜ) |
| Stok theos stage | ara dizin öneksiz, `/var/jb` paketlemede ekleniyor → kendi `internal-stage` satırlarımdan önek kaldırıldı (ÖLÇÜLDÜ; önceki varsayım yanlıştı) |
| Kurulum 1 (clang 16) | YouTube 4, tabii 10 engel; iki bankacılık uygulamasında hiç kayıt yok (hariç tutma); X'te ilk anda kayıt yok |
| X | süreç **29 Eylül'den beri** açıktı (tweak'siz eski süreç); kapatıp açınca yüklendi, 1 engel |
| Ayarlar sayfası (clang 16) | **çöktü** — `libobjc readClass` EXC_BREAKPOINT |
| Kurulum 2 (RootHide toolchain, clang 14, rootless şema) | Ayarlar açıldı, **Türkçe**; rapor sayfası çalıştı; **Arapça** (sağdan sola) çalıştı |
| Bankacılık uygulaması çökmesi | tweak sürece hiç yüklenmemiş; bankanın kendi kodu (jailbreak algılama) |
| Prefs yönlendirmesi | Dopamine de tweak prefs'ini `/var/jb/var/mobile/...` altına yazıyor (ÖLÇÜLDÜ) |

### Procursus clang 16 bulgusu (shivtools'a öğretilecek)

Ayrıntı ve kanıt: `olcumler/procursus-bulgu/BULGU.md`.
- clang 16 arm64e dilimine **caps 0x80** bastı; prefs bundle Ayarlar'ı
  sınıf kaydında (bizim kodumuz çalışmadan) düşürdü. ÖLÇÜLDÜ.
- Aynı kaynak clang 14 ile **0x00** → çalıştı. ÖLÇÜLDÜ.
- Apple clang ile derlenen 0x80 (KASwitcherPrefs) aynı cihazda çalışıyor →
  sorun damga değil, derleyici. ÖLÇÜLDÜ.
- Literal/blok tetikleyicisi yok (`__cfstring = 0`) → TWEAK.md §1.6 dışında
  yeni bir sınıf.
- İlk hipotez (YANLIŞ ÇIKTI): upstream LLVM 16, iOS 16 libobjc'nin beklediği
  ObjC meta veri PAC imzasını üretmiyor.
- **Güncelleme (shivtools oturumu 7f3c7e30):** clang 14 de clang 16 da aynı
  yerde çöküyor; fark OldABI'nin devreye girmesi. Çare: clang 16'ya
  `-fno-ptrauth-abi-version` (caps 0x00, OldABI kurtarır); kullanıcı sayfanın
  açıldığını doğruladı. Bu oturumda bayraksız clang 16 yeniden derlendi: yine
  0x80 (tekrarlanabilir). Ayrıntı: BULGU.md GÜNCELLEME.
- Kural (doğrulanana kadar): rootless cihazda arm64e derleme; rootless paketi
  RootHide cihazında `THEOS_PACKAGE_SCHEME=rootless` ile derle.

---

## 9. Test matrisi (son durum)

| Test | RootHide 1.0.0-4 | Rootless 1.0.0-3 |
|---|---|---|
| Kurulum, `dpkg -l`, UUID | ✓ | ✓ |
| `__cfstring` (tweak, prefs) | 0 / 0 | 0 / 0 |
| caps arm64e (tweak, prefs) | 0x00 / 0x00 | 0x00 / 0x00 |
| `atb-update` + `atb-compile --match` | ✓ (63 ms) | ✓ (118 ms) |
| Engel, NSURLSession uygulaması | Reddit 48 | YouTube, tabii, X |
| Engel, kendi yığını | Instagram 20 | — |
| arm64e uygulama (Safari) yükleme | ✓ çökme yok | denenmedi |
| Hariç tutma | (izci'de ölçüldü) | iki bankacılık uygulaması ✓ |
| Ayarlar ana sayfa | ✓ (İngilizce*) | ✓ Türkçe, ✓ Arapça |
| Rapor sayfası (sayılar ekranda) | ✓ | ✓ |
| Diğer 9 dil | dosya denetimi ✓, ekranda görülmedi | — |

\* RootHide'da Ayarlar uygulamasında 29 Eylül'deki bir çeviri testinden
kalan `AppleLanguages = (en)` artığı var (bu oturumdan değil). Sayfa bu
yüzden İngilizce; `en.lproj` doğru seçiliyor. RootHide'da Ayarlar'a frida
bağlamak yasak olduğu için silinmedi; karar kullanıcıda.

Kurulum turları: izci Aşama 1: 2 · Aşama 2: 1 · Aşama 3: 1 ·
AppTrackerBlock RootHide: 2 · rootless: 2. Hiçbir aşamada üçüncü tura
girilmedi.

---

## 10. Bilinen sınırlar

- Safari ve WKWebView (uygulama içi web sayfaları) trafiği
  `com.apple.WebKit.Networking` sürecinde → bu yöntemle engellenmez/sayılmaz.
- Doğrudan `nw_connection_create` kullanan (NSURLSession'sız) uygulamalar
  yalnız ölçülüyor, engellenmiyor; ölçümde engel açıkken bu yoldan geçen
  listeli alan görülmedi.
- Hariç tutulan uygulamada dylib yine yükleniyor (filtre plist'i hariç tutma
  desteklemiyor); yalnız hiç hook kurulmuyor. Gerçek "hiç yükleme" için Choicy.
- Liste statik; HaGeZi 8 saatte bir güncelleniyor, `atb-update` elle.
- `Library/Caches` depolama baskısında iOS tarafından silinebilir → rapor
  sıfırlanır. ÖLÇÜLMEDİ.
- Uygulama eklentileri (.appex) kapsam dışı.

---

## 11. Yayın öncesi kontrol listesi

- [x] **OldABI bağımlılığı ölçüldü** (rootless, 16:46; `04-OLDABI-AB-1.0.0.txt`): OldABI kapalıyken cihazda derlenen prefs (clang 14 de, clang 16 + `-fno-ptrauth-abi-version` da) Ayarlar'ı `readClass`'ta düşürüyor; açıkken çalışıyor.
- [ ] **Bu yüzden yayın Mac'te derlensin** (Tweaks-dev şeması: "cihazda derlenen paket yayınlanmaz") ya da `control`'e `Depends: firmware (<< 15.0) | cy+cpu.arm64v8 | oldabi` eklensin. Mac derlemesinin OldABI'siz çalıştığı ölçülmedi.
- [ ] Yayın paketleri iki şema için de **RootHide cihazında** derlensin
      (rootless'ın clang 16'sı değil).
- [ ] Türkçe kısa etiket ("Engellenmeyen uygulamalar") rootless'a henüz
      kurulmadı — yayın derlemesiyle gidecek.
- [ ] HAKKINDA dipnotundaki "Built with Claude Opus 5.5" — kalsın mı? (kullanıcı kararı)
- [ ] GitHub `muratkurt/AppTrackerBlock` deposu (Belgeler / Sorun bildir bağlantıları açılana kadar 404).
- [ ] Şirket eşlemesi CC BY-NC-SA 4.0: ücretsiz yayın uygun, ticari kullanım izin ister; README'de atıf.
- [ ] `REPORTS/ARSIV/oturum-ham-*.jsonl` cihaz parolalarını içeriyor → depoya gönderilmesin. Depo yalnız `SOURCE-1.0.0/` olacaksa sorun yok; `REPORTS/` de gidecekse ARSIV hariç tutulsun.
- [ ] control `Version` artırılırsa sayfadaki sürüm kendiliğinden güncellenir.

---

## 12. Geri dönüş

```
sudo dpkg -r com.muratkurt.apptrackerblock                      # kaldır
sudo dpkg -i ARSIV/eski-cihaz-klasoru/izci/packages/com.muratkurt.izci_0.3.0-1+debug_iphoneos-arm64e.deb   # eski Türkçe sürüm
find /rootfs/private/var/mobile/Containers/Data/Application -maxdepth 4 -name 'AppTrackerBlock-blocked.log*' -delete   # rapor verisi
```

---

## 13. Klasör (Tweaks-dev şeması, KASwitcher ile aynı)

Yollar `Documents/Tweaks-dev/AppTrackerBlock/` köküne göre. Dizin: `REPORTS/00-OKUMA-SIRASI.md`.

| Yol | İçerik |
|---|---|
| `REPORTS/01-RAPOR.md` | bu belge |
| `REPORTS/02-OLCUM-izci-asama1-3.md` | izci aşama 1–3 raporu (belirti/ölçüm/sebep/düzeltme) |
| `REPORTS/03-SOHBET-1.0.0.md` | okunur konuşma (parolalar maskeli) |
| `REPORTS/04-OLDABI-AB-1.0.0.txt` | OldABI A/B ölçümü + shivtools oturumuna not |
| `REPORTS/ARSIV/oturum-ham-2026-10-01.jsonl` | ham oturum kaydı — **parola içerir, depoya gönderme** |
| `REPORTS/ARSIV/OKU-BENI-oturum-2026-10-01.md` | oturum sonu dizini (shivtools değerlendirme başlıkları) |
| `REPORTS/olcumler/oldabi-ab/` | A/B ekranları + iki çökme raporu (A1, A2) |
| `SOURCE-1.0.0/` | kaynak, `CHANGELOG.md`, `CLAUDE.md`, `DEBS/` (Mac yayın paketleri), `_zula/` (cihaz derlemeleri, yedekler, geçici araçlar) |
| `ARSIV/eski-cihaz-klasoru/izci/` | eski Türkçe izci kaynağı, günlükleri ve paketleri |

Ölçüm alt klasörleri (`REPORTS/` altında):

| Yol | İçerik |
|---|---|
| `olcumler/asama1-tur1/`, `asama1-tur2/` | Aşama 1 günlükleri + uygulama→alan→hook tablosu |
| `olcumler/asama2/` | engel açık/kapalı günlükleri, arama süreleri |
| `olcumler/kullanici-testi/` | kullanıcının kendi testinden günlükler |
| `olcumler/son-test-roothide/`, `son-test-rootless/` | 1.0.0 engel kayıtları |
| `olcumler/rootless-ekran/` | rootless ekran görüntüleri (ana ekran, Türkçe sayfa, rapor, Arapça) |
| `olcumler/procursus-bulgu/` | clang 16 bulgusu: BULGU.md, iki deb, çökme raporu, derleyici sürümleri |
| `olcumler/sandbox-yazma-ajani.js` | sandbox yazma ölçümü için frida ajanı |
| `olcumler/mcp-tunel-istemcisi.mjs` | SSH tüneli üzerinden MCP çağıran node istemcisi (node fetch yerine http) |
