// AppTrackerBlock — blocks tracker domains inside apps.
//
// Where requests are stopped (chosen from on-device measurement, see NOTES.md):
//   -[NSURLSessionTask resume]   NSURLSession apps: the task is cancelled
//                                instead of started (NSURLErrorCancelled).
//   getaddrinfo                  apps with their own network stack (e.g.
//                                Instagram): a real lookup of a listed name
//                                fails with EAI_NONAME. AI_NUMERICHOST calls
//                                are "is this an IP?" checks, not lookups,
//                                and are left alone.
//
// Developer log (Settings > Developer log): one line per event,
//   ms <TAB> bundle-id <TAB> hook <TAB> host/ip <TAB> details
// When it is on, four measurement-only hooks are added as well
// (nw_endpoint_create_host, nw_connection_create, connect,
// DNSServiceGetAddrInfo). They call the original and only write a line.
//
// Rules: no @"..." literals and no blocks handed to the system (the tweak
// also loads into arm64e processes such as Safari). Private objects are
// never formatted with %@; only C strings and numbers are logged.

#import <Foundation/Foundation.h>
#import <substrate.h>
#import "JBRoot.h"
#import <dlfcn.h>
#import <netdb.h>
#import <notify.h>
#import <fcntl.h>
#import <unistd.h>
#import <pthread.h>
#import <sys/stat.h>
#import <sys/time.h>
#import <sys/socket.h>
#import <netinet/in.h>
#import <arpa/inet.h>
#import <ctype.h>
#import <mach/mach_time.h>
#import "Common.h"
#import "Blocklist.h"

static NSString *S(const char *s) { return [NSString stringWithUTF8String:s]; }

// ── Blocking state. The list is mmapped once; each lookup is one binary
// search per domain suffix (Blocklist.c). No text scanning per request.
static volatile int gBlocking = 0;   // enabled && not disabled for this app && list open
static atb_list gList;
static double gNsPerTick = 1.0;

// ── Blocked-request counter for the Settings report. The sandbox cannot
// write under the jailbreak root (EPERM, measured), so each app writes to
// its OWN container: $HOME/Library/Caches/AppTrackerBlock-blocked.log
//   first line "#<TAB>bundle-id", then "unix-seconds<TAB>matched-domain"
// Settings runs without a sandbox and reads it from there. Independent of
// the developer log switch: the report is built from this file.
static int gCounterFd = -1;
static void recordBlock(const char *matched) {
    if (gCounterFd < 0 || !matched) return;
    char line[300];
    int n = snprintf(line, sizeof line, "%ld\t%s\n", (long)time(NULL), matched);
    if (n > 0 && n < (int)sizeof line) (void)write(gCounterFd, line, n);  // O_APPEND: short writes are atomic
}

// Index of the matching suffix (>= 0) or -1; *ns receives the lookup time.
static int listMatch(const char *host, unsigned *ns) {
    if (!gList.hashes || !host) return -1;
    uint64_t t0 = mach_absolute_time();
    int m = atb_list_match(&gList, host);
    if (ns) *ns = (unsigned)((double)(mach_absolute_time() - t0) * gNsPerTick);
    return m;
}

// ── Developer log state
static volatile int gLogging = 0;
static int   gLogFd = -1;
static off_t gLogSize = 0;
static int   gNotifyToken = -1;
static char  gBundleID[200] = "unknown";
static pthread_mutex_t gLock = PTHREAD_MUTEX_INITIALIZER;
static __thread int tBusy = 0;          // keeps our own calls out of our hooks
#define ATB_LOG_MAX (4 * 1024 * 1024)

// ── Preferences. A sandboxed app cannot read another domain through
// CFPreferences, so the plist is read directly. RootHide redirects tweak
// preferences under the jailbreak root (measured); other jailbreaks may
// not, so the plain path is tried second.
static NSDictionary *readPrefs(void) {
    const char *paths[2] = { jbroot(ATB_PREFS_PATH), ATB_PREFS_PATH };
    for (int i = 0; i < 2; i++) {
        if (!paths[i]) continue;
        NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:S(paths[i])];
        if ([d isKindOfClass:[NSDictionary class]]) return d;
    }
    return nil;
}

static int prefBool(NSDictionary *d, const char *key, int fallback) {
    id v = d[S(key)];
    return [v respondsToSelector:@selector(boolValue)] ? [v boolValue] : fallback;
}

// ── Developer log line (plain C; locked, size-capped)
static void logLine(const char *hook, const char *host, const char *details) {
    if (gLogFd < 0) return;
    if (gNotifyToken >= 0) {
        int changed = 0;
        if (notify_check(gNotifyToken, &changed) == NOTIFY_STATUS_OK && changed) {
            @autoreleasepool { gLogging = prefBool(readPrefs(), ATB_KEY_LOGGING, 0); }
        }
    }
    if (!gLogging) return;
    struct timeval tv; gettimeofday(&tv, NULL);
    long long ms = (long long)tv.tv_sec * 1000LL + tv.tv_usec / 1000;
    char line[700];
    int n = snprintf(line, sizeof line, "%lld\t%s\t%s\t%s\t%s\n", ms, gBundleID,
                     hook, host ? host : "no-host", details ? details : "");
    if (n <= 0) return;
    if (n >= (int)sizeof line) { n = sizeof line - 1; line[n - 1] = '\n'; }
    pthread_mutex_lock(&gLock);
    if (gLogSize + n < ATB_LOG_MAX && write(gLogFd, line, n) == n) gLogSize += n;
    pthread_mutex_unlock(&gLock);
}

static int isIPLiteral(const char *h) {
    unsigned char b[16];
    return h && (inet_pton(AF_INET, h, b) == 1 || inet_pton(AF_INET6, h, b) == 1);
}

// ── IP -> name seen in a real getaddrinfo (cross-check for connect)
#define ATB_RING 512
static char gRingIP[ATB_RING][46];
static char gRingName[ATB_RING][128];
static int  gRingNext = 0;

static void rememberIP(const char *ip, const char *name) {
    pthread_mutex_lock(&gLock);
    int i = gRingNext++ % ATB_RING;
    strlcpy(gRingIP[i], ip, sizeof gRingIP[i]);
    strlcpy(gRingName[i], name, sizeof gRingName[i]);
    pthread_mutex_unlock(&gLock);
}

static int nameForIP(const char *ip, char *name, size_t size) {
    int found = 0;
    pthread_mutex_lock(&gLock);
    for (int i = 0; i < ATB_RING; i++) {
        if (gRingIP[i][0] && strcmp(gRingIP[i], ip) == 0) { strlcpy(name, gRingName[i], size); found = 1; break; }
    }
    pthread_mutex_unlock(&gLock);
    return found;
}

static int formatSockaddr(const struct sockaddr *a, char *ip, size_t size, int *port) {
    if (!a) return 0;
    if (a->sa_family == AF_INET) {
        const struct sockaddr_in *s = (const struct sockaddr_in *)a;
        *port = ntohs(s->sin_port);
        return inet_ntop(AF_INET, &s->sin_addr, ip, (socklen_t)size) != NULL;
    }
    if (a->sa_family == AF_INET6) {
        const struct sockaddr_in6 *s = (const struct sockaddr_in6 *)a;
        *port = ntohs(s->sin6_port);
        return inet_ntop(AF_INET6, &s->sin6_addr, ip, (socklen_t)size) != NULL;
    }
    return 0;
}

// ── 1. getaddrinfo — blocks real lookups of listed names
static int (*o_getaddrinfo)(const char *, const char *, const struct addrinfo *, struct addrinfo **);
static int h_getaddrinfo(const char *node, const char *svc, const struct addrinfo *hints, struct addrinfo **res) {
    if (gBlocking && !tBusy && node && !(hints && (hints->ai_flags & AI_NUMERICHOST)) && !isIPLiteral(node)) {
        unsigned ns = 0;
        int m = listMatch(node, &ns);
        if (m >= 0) {
            if (res) *res = NULL;
            tBusy = 1;
            char details[160];
            snprintf(details, sizeof details, "BLOCK matched=%s ns=%u", node + m, ns);
            recordBlock(node + m);
            logLine("getaddrinfo", node, details);
            tBusy = 0;
            return EAI_NONAME;
        }
    }
    int r = o_getaddrinfo(node, svc, hints, res);
    if (tBusy || !gLogging || !node) return r;
    tBusy = 1;
    char details[64];
    // flags 0x4 (AI_NUMERICHOST): an IP check, not a DNS lookup.
    snprintf(details, sizeof details, "r=%d flags=0x%x%s", r, hints ? hints->ai_flags : -1,
             isIPLiteral(node) ? " ip-literal" : "");
    logLine("getaddrinfo", node, details);
    if (r == 0 && res && *res && !isIPLiteral(node)) {
        for (struct addrinfo *a = *res; a; a = a->ai_next) {
            char ip[46]; int port = 0;
            if (formatSockaddr(a->ai_addr, ip, sizeof ip, &port)) rememberIP(ip, node);
        }
    }
    tBusy = 0;
    return r;
}

// ── 2. DNSServiceGetAddrInfo (measurement only; the callback is not wrapped)
static int32_t (*o_dnssd_gai)(void *, uint32_t, uint32_t, uint32_t, const char *, void *, void *);
static int32_t h_dnssd_gai(void *ref, uint32_t flags, uint32_t ifi, uint32_t proto,
                           const char *host, void *cb, void *ctx) {
    int32_t r = o_dnssd_gai(ref, flags, ifi, proto, host, cb, ctx);
    if (tBusy || !gLogging) return r;
    tBusy = 1;
    char details[64];
    snprintf(details, sizeof details, "r=%d proto=0x%x", (int)r, proto);
    logLine("DNSServiceGetAddrInfo", host, details);
    tBusy = 0;
    return r;
}

// ── 3. nw_endpoint_create_host (measurement only; nw types kept as void* so ARC stays out)
static void *(*o_nw_ep_host)(const char *, const char *);
static void *h_nw_ep_host(const char *host, const char *port) {
    void *r = o_nw_ep_host(host, port);
    if (tBusy || !gLogging) return r;
    tBusy = 1;
    char details[64];
    snprintf(details, sizeof details, "port=%s%s", port ? port : "-", isIPLiteral(host) ? " ip-literal" : "");
    logLine("nw_endpoint_create_host", host, details);
    tBusy = 0;
    return r;
}

// ── 4. nw_connection_create (measurement only) — endpoint read with public getters
static int (*p_ep_type)(void *);
static const char *(*p_ep_host)(void *);
static const struct sockaddr *(*p_ep_addr)(void *);
static void *(*o_nw_conn)(void *, void *);
static void *h_nw_conn(void *ep, void *params) {
    void *r = o_nw_conn(ep, params);
    if (tBusy || !gLogging) return r;
    tBusy = 1;
    if (!ep || !p_ep_type) {
        logLine("nw_connection_create", "no-endpoint", "");
    } else {
        int t = p_ep_type(ep);
        if (t == 2 && p_ep_host) {                       // nw_endpoint_type_host
            // A listed host passing here unblocked shows the coverage gap.
            const char *hh = p_ep_host(ep);
            logLine("nw_connection_create", hh, listMatch(hh, NULL) >= 0 ? "type=host listed=YES" : "type=host");
        } else if (t == 1 && p_ep_addr) {                // nw_endpoint_type_address
            char ip[46], name[128], details[200]; int port = 0;
            if (formatSockaddr(p_ep_addr(ep), ip, sizeof ip, &port)) {
                int known = nameForIP(ip, name, sizeof name);
                snprintf(details, sizeof details, "type=address port=%d source=%s", port, known ? name : "none");
                logLine("nw_connection_create", ip, details);
            } else logLine("nw_connection_create", "unreadable-address", "type=address");
        } else {
            char details[32]; snprintf(details, sizeof details, "type=%d", t);
            logLine("nw_connection_create", "unknown", details);
        }
    }
    tBusy = 0;
    return r;
}

// ── 5. connect (measurement only) — was this IP resolved by a lookup we saw?
static int (*o_connect)(int, const struct sockaddr *, socklen_t);
static int h_connect(int s, const struct sockaddr *a, socklen_t l) {
    int r = o_connect(s, a, l);
    if (tBusy || !gLogging) return r;
    char ip[46]; int port = 0;
    if (!formatSockaddr(a, ip, sizeof ip, &port)) return r;   // AF_UNIX etc. out of scope
    if (strcmp(ip, "127.0.0.1") == 0 || strcmp(ip, "::1") == 0) return r;
    tBusy = 1;
    char name[128], details[200];
    int known = nameForIP(ip, name, sizeof name);
    snprintf(details, sizeof details, "port=%d source=%s", port, known ? name : "none");
    logLine("connect", ip, details);
    tBusy = 0;
    return r;
}

// ── 6. -[NSURLSessionTask resume] (v16@0:8, read from a running app)
%group SessionTask
%hook NSURLSessionTask
- (void)resume {
    // %orig on its own line: stock Logos drops the rest of a line after
    // %orig ("{ %orig; return; }" lost "return; }" — measured on rootless).
    if (tBusy || (!gLogging && !gBlocking)) {
        %orig;
        return;
    }
    tBusy = 1;
    int block = 0;
    @try {
        NSURLRequest *req = [self respondsToSelector:@selector(originalRequest)] ? self.originalRequest : nil;
        NSString *h = req.URL.host;
        NSString *scheme = req.URL.scheme;
        const char *hc = h.length ? h.UTF8String : NULL;
        unsigned ns = 0;
        int m = hc ? listMatch(hc, &ns) : -1;
        block = gBlocking && m >= 0;
        char details[200];
        if (block) { snprintf(details, sizeof details, "BLOCK matched=%s ns=%u", hc + m, ns); recordBlock(hc + m); }
        else       snprintf(details, sizeof details, "scheme=%s ns=%u", scheme.length ? scheme.UTF8String : "none", ns);
        logLine("NSURLSessionTask.resume", hc ? hc : (req ? "no-host" : "no-request"), details);
    } @catch (__unused NSException *x) {
        logLine("NSURLSessionTask.resume", "exception", "");
        block = 0;
    }
    tBusy = 0;
    // Block: public -cancel instead of resume. Allowed on a suspended task;
    // it finishes with NSURLErrorCancelled and the app's error path runs.
    if (block) { [self cancel]; return; }
    %orig;
}
%end
%end

static int hookSymbol(const char *name, void *replacement, void **original) {
    void *f = dlsym(RTLD_DEFAULT, name);
    if (!f) return 0;
    MSHookFunction(f, replacement, original);
    return *original != NULL;
}

static int isExcluded(NSDictionary *d, const char *bid) {
    char lower[200]; size_t i = 0;
    for (; bid[i] && i < sizeof lower - 1; i++) lower[i] = (char)tolower((unsigned char)bid[i]);
    lower[i] = 0;
    for (int j = 0; kATBExcludedFragments[j]; j++) if (strstr(lower, kATBExcludedFragments[j])) return 1;
    id list = d[S(ATB_KEY_EXCLUDED)];
    if ([list isKindOfClass:[NSArray class]]) return [list containsObject:S(bid)];
    for (int j = 0; kATBDefaultExcluded[j]; j++) if (strcmp(bid, kATBDefaultExcluded[j]) == 0) return 1;
    return 0;
}

%ctor {
    @autoreleasepool {
        NSBundle *mb = [NSBundle mainBundle];
        NSString *bid = mb.bundleIdentifier;
        // Apps only: the main .app binary. SpringBoard, Settings,
        // extensions (.appex) and daemons are out of scope.
        if (!bid.length || ![mb.bundlePath hasSuffix:S(".app")]) return;
        const char *b = bid.UTF8String;
        if (strcmp(b, "com.apple.springboard") == 0 || strcmp(b, "com.apple.Preferences") == 0) return;

        NSDictionary *d = readPrefs();
        // Excluded: nothing is hooked. (The dylib itself is still loaded by
        // the injector; filter plists cannot express exclusions.)
        if (isExcluded(d, b)) return;
        int logging = prefBool(d, ATB_KEY_LOGGING, 0);
        int blocking = prefBool(d, ATB_KEY_BLOCKING, 1);
        id off = d[S(ATB_KEY_NOBLOCK)];
        int disabledHere = [off isKindOfClass:[NSArray class]] && [off containsObject:bid];
        if (disabledHere) blocking = 0;          // "disable in this app": logging continues
        if (!logging && !blocking) return;       // both off: do nothing
        strlcpy(gBundleID, b, sizeof gBundleID);

        mach_timebase_info_data_t tb; mach_timebase_info(&tb);
        gNsPerTick = (double)tb.numer / tb.denom;
        const char *lp = jbroot(ATB_BLOCKLIST);
        int listResult = lp ? atb_list_open(lp, &gList) : -3;
        gBlocking = blocking && listResult == 0;
        gLogging = logging;

        if (logging) {
            char tmp[1024];
            if (confstr(_CS_DARWIN_USER_TEMP_DIR, tmp, sizeof tmp) != 0) {
                strlcat(tmp, ATB_DEBUG_LOG, sizeof tmp);
                gLogFd = open(tmp, O_WRONLY | O_CREAT | O_APPEND, 0644);
                struct stat st; if (gLogFd >= 0 && fstat(gLogFd, &st) == 0) gLogSize = st.st_size;
            }
            notify_register_check(ATB_NOTIFY, &gNotifyToken);
        }
        if (!gBlocking && gLogFd < 0) return;    // nothing to block, nowhere to log

        if (gBlocking) {
            const char *home = getenv("HOME");
            char path[1024], old[1040];
            if (home && snprintf(path, sizeof path, "%s/%s", home, ATB_BLOCKED_LOG) < (int)sizeof path) {
                struct stat st;
                if (stat(path, &st) == 0 && st.st_size > 512 * 1024) {   // rotate: keep one old copy
                    snprintf(old, sizeof old, "%s.1", path);
                    rename(path, old);
                }
                gCounterFd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0644);
                if (gCounterFd >= 0 && fstat(gCounterFd, &st) == 0 && st.st_size == 0) {
                    char head[260];
                    int n = snprintf(head, sizeof head, "#\t%s\n", b);    // Settings reads the bundle id here
                    if (n > 0 && n < (int)sizeof head) (void)write(gCounterFd, head, n);
                }
            }
        }

        // Blocking hooks: always when blocking or logging.
        int hGai = hookSymbol("getaddrinfo", (void *)h_getaddrinfo, (void **)&o_getaddrinfo);
        int hTask = objc_getClass("NSURLSessionTask") != Nil;
        if (hTask) %init(SessionTask);

        // Measurement-only hooks: only with the developer log on.
        int hDns = 0, hEp = 0, hConn = 0, hSock = 0;
        if (gLogFd >= 0) {
            p_ep_type = (int (*)(void *))dlsym(RTLD_DEFAULT, "nw_endpoint_get_type");
            p_ep_host = (const char *(*)(void *))dlsym(RTLD_DEFAULT, "nw_endpoint_get_hostname");
            p_ep_addr = (const struct sockaddr *(*)(void *))dlsym(RTLD_DEFAULT, "nw_endpoint_get_address");
            hEp   = hookSymbol("nw_endpoint_create_host", (void *)h_nw_ep_host, (void **)&o_nw_ep_host);
            hConn = hookSymbol("nw_connection_create", (void *)h_nw_conn, (void **)&o_nw_conn);
            hSock = hookSymbol("connect", (void *)h_connect, (void **)&o_connect);
            hDns  = hookSymbol("DNSServiceGetAddrInfo", (void *)h_dnssd_gai, (void **)&o_dnssd_gai);
        }

        char details[240];
        snprintf(details, sizeof details,
                 "getaddrinfo=%d resume=%d dnssd=%d nw_ep=%d nw_conn=%d connect=%d"
                 " list=%d count=%llu blocking=%d disabledHere=%d counter=%d",
                 hGai, hTask, hDns, hEp, hConn, hSock,
                 listResult, (unsigned long long)gList.count, gBlocking, disabledHere, gCounterFd >= 0);
        logLine("started", "-", details);
    }
}
