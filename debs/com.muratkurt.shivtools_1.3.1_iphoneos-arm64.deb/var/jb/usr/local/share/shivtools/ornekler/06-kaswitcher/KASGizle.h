// KASGizle — 0.7 gizleme cekirdegi. Gizli durumun sahibi Apple: SBAppLayout.hidden
// (-[SBAppSwitcherModel hide:], appLayoutByModifyingHiddenState:). Olcumler: REPORTS/06 §7 (vphone iOS 26.6.2).
// Bizim tercih listemiz yalniz "hangi uygulamalar gizli olmali". Her ozel cagri imza birebir tutarsa yapilir.
#import <UIKit/UIKit.h>

void kas_gizleGunluk(void (*f)(NSString *));
// Kasa icerigi: modelde gizli bayrakli VE listede olan uygulamalar, switcher sirasiyla.
NSArray<NSString *> *kas_kasaBidleri(NSSet<NSString *> *liste);
// Arka plandaki duzenleri gizle / gizliden cikar (M1a, M4).
void kas_gizle(NSString *bid);
void kas_goster(NSString *bid);
void kas_gosterSessiz(NSString *bid);   // b9: liste yenilemeden (hemen ardindan silinecekse)
// Switcher'daki karti stok yoldan kaldirip gizler (M1c): removeLayoutRole + blokta hide + rebuild.
// onde = arkadaki duzen bu uygulama; 16'da arkayi ana ekrana ceviren istegi biz gondeririz (m35).
// NO donerse cagiran eski yola duser.
BOOL kas_kartiKaldir(UIView *kart, NSString *bid, BOOL onde);
// Gecis bitti: kas_kartiKaldir(onde) sonrasi bekleyen yenileme varsa yapar (M1c adim 4).
void kas_gecisBasladi(void);   // a2: ayni yenileme gecis basinda (bayrak sonda temizlenir)
void kas_gecisBitti(void);
// Apple yeni duzen eklerken (M2): listedeki uygulamanin duzeni gizli donsun (§7.2).
id kas_willAddDuzelt(id duzen, NSSet<NSString *> *liste);
// Tercih listesi degisti: yalniz eklenenleri gizle, cikarilanlari goster.
void kas_esitle(NSSet<NSString *> *eski, NSSet<NSString *> *yeni);
void kas_yenile(void);
// b30: uygulamanin on plandaki sahnesinden kasa icin sabit resim (Apple'in resmine dokunmaz). Yoksa nil.
UIImage *kas_sahneResmi(NSString *bid);
// b31: kas_sahneResmi'nin aldigi tam goruntuyu Apple'in kendi kayit yoluyla deposuna yazar (geri donuste dogru kart).
void kas_appleDeposunaYaz(NSString *bid);
// b12: kasadaki uygulamayi kart silme hattina girmeden kapatir (model remove: + FBSSystemService). NO = eski yol.
BOOL kas_kasadanKapat(NSString *bid);
// b8: gorunur kart sayisi (-1 = okunamadi).
NSInteger kas_gorunurKartSayisi(void);
// b3: switcher'i stok gecis istegiyle acar (Face ID sonrasi). Imza tutmazsa NO.
BOOL kas_switcheriAc(void);
// b15: switcher gorunumunde (ondeki duzen dahil) bu uygulamanin karti var mi.
BOOL kas_gorunumdeVar(NSString *bid);
// b13: bos switcher'i Apple'in 'kart kalmadi' istegiyle ana ekrana kapatir. Imza tutmazsa NO.
BOOL kas_switcheriAnaEkranaKapat(void);
