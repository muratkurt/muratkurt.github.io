// AppTrackerBlock — blocklist lookup (see Blocklist.h). Plain C: no ObjC
// objects, no locks, no allocation; the mapping is read-only.
#include "Blocklist.h"
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

uint64_t atb_hash(const char *s, size_t n) {
    uint64_t h = 1469598103934665603ULL;
    for (size_t i = 0; i < n; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c >= 'A' && c <= 'Z') c = (unsigned char)(c + 32);
        h ^= c;
        h *= 1099511628211ULL;
    }
    return h;
}

int atb_list_open(const char *path, atb_list *l) {
    memset(l, 0, sizeof *l);
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    struct stat st;
    if (fstat(fd, &st) != 0 || st.st_size < (off_t)sizeof(atb_header)) { close(fd); return -2; }
    void *m = mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (m == MAP_FAILED) return -1;
    const atb_header *h = (const atb_header *)m;
    if (memcmp(h->magic, ATB_LIST_MAGIC, 8) != 0 ||
        sizeof(atb_header) + h->count * sizeof(uint64_t) != (uint64_t)st.st_size) {
        munmap(m, (size_t)st.st_size);
        return -2;
    }
    l->hashes = (const uint64_t *)((const char *)m + sizeof(atb_header));
    l->count = h->count;
    l->map = m;
    l->size = (size_t)st.st_size;
    return 0;
}

static int contains(const atb_list *l, uint64_t h) {
    uint64_t lo = 0, hi = l->count;
    while (lo < hi) {
        uint64_t mid = lo + (hi - lo) / 2;
        uint64_t v = l->hashes[mid];
        if (v == h) return 1;
        if (v < h) lo = mid + 1; else hi = mid;
    }
    return 0;
}

int atb_list_match(const atb_list *l, const char *host) {
    if (!l || !l->hashes || !host) return -1;
    size_t n = strlen(host);
    if (n && host[n - 1] == '.') n--;
    if (n == 0 || n > 253) return -1;
    size_t i = 0;
    for (;;) {
        if (contains(l, atb_hash(host + i, n - i))) return (int)i;
        const char *dot = memchr(host + i, '.', n - i);
        if (!dot) return -1;
        i = (size_t)(dot - host) + 1;
        if (i >= n) return -1;
    }
}
