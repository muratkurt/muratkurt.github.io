// AppTrackerBlock — compiled blocklist: binary format + lookup (plain C).
// atb-compile and the tweak share this code, so the format lives in one place.
//
// File:    [32-byte header][uint64 hash x count, ascending, unique]
// Hash:    FNV-1a 64 of the lowercased domain.
// Lookup:  "a.b.example.com" -> a.b.example.com, b.example.com,
//          example.com, com — one binary search per suffix. HaGeZi's
//          "wildcard / onlydomains" format: an entry covers its subdomains.
#pragma once
#include <stdint.h>
#include <stddef.h>

#define ATB_LIST_MAGIC "ATBLIST1"

typedef struct {
    char     magic[8];
    uint64_t count;       // number of hashes
    uint64_t lines;       // valid lines in the source file
    uint64_t built;       // build time (unix seconds)
} atb_header;

typedef struct {
    const uint64_t *hashes;
    uint64_t        count;
    const void     *map;
    size_t          size;
} atb_list;

uint64_t atb_hash(const char *s, size_t n);

// 0 = ok; -1 = cannot open/map; -2 = bad format
int atb_list_open(const char *path, atb_list *l);

// Index in 'host' where the matching suffix starts, or -1.
// A trailing dot ("example.com.") is ignored.
int atb_list_match(const atb_list *l, const char *host);
