// KASwitcher 0.5.0 — kendi menumuz (UIContextMenuInteraction yerine).
//
// Neden: sistem menusu (1) yatayda DIKEY aciliyordu (switcher penceresi
// donmuyor, 0.4.4-m1 olcumu), (2) kucuk ve ortali butonda kapanirken
// butonun ust yarisinin uzerinden geciyordu (IMG_8932-8939). Bu menu
// switcher gorunumunun ICINDE cizilir (icerikle doner) ve butonun yanina
// hizalanir; butonla hic ust uste binmez.
//
// Yalniz public UIKit. Private UIAction cagrisi YOK (handler /
// performWithSender:target: SDK'da yok - 0.5.0 olcumu); oge modeli kendi.
#import <UIKit/UIKit.h>

@interface KASMenuOge : NSObject
@property (nonatomic, copy) NSString *baslik;
@property (nonatomic, strong) UIImage *ikon;
@property (nonatomic) BOOL secili;       // solda onay isareti
@property (nonatomic) BOOL kirmizi;      // yikici eylem
@property (nonatomic) BOOL pasif;        // soluk, dokunulmaz
@property (nonatomic) BOOL acikKalsin;   // secilince menu kapanmaz, seviye tazelenir
@property (nonatomic, copy) void (^isleyici)(void);
// nil degilse bu oge bir ALT MENU: her acilista tazeden uretilir.
@property (nonatomic, copy) NSArray<KASMenuOge *> *(^altUretici)(void);
+ (instancetype)baslik:(NSString *)b ikon:(UIImage *)i isleyici:(void (^)(void))h;
+ (instancetype)altMenu:(NSString *)b ikon:(UIImage *)i uretici:(NSArray<KASMenuOge *> *(^)(void))u;
@end

@interface KASMenu : NSObject
// v: menunun cizilecegi gorunum (switcher gorunumu). kaynak: X butonu.
// kok: kok seviyeyi her cizimde tazeden ureten blok.
// kapaninca: menu tamamen kapaninca (animasyon bitince) bir kez cagrilir.
+ (void)gosterIcinde:(UIView *)v
              kaynak:(UIView *)kaynak
                 kok:(NSArray<KASMenuOge *> *(^)(void))kok
           kapaninca:(void (^)(void))kapaninca;
+ (void)kapat:(BOOL)animasyonlu;   // idempotent
+ (BOOL)acik;
@end
