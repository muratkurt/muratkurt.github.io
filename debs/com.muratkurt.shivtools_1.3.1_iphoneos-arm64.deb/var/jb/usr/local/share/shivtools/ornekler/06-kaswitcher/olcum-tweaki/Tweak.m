// KASProbe — 0.7 yeniden tasarim olcumu (YAYINLANMAZ). REPORTS/06 §5 M1-M4.
// Apple'in kendi gizleme bayragi: -[SBAppSwitcherModel hide:] (DSC 16/17/26). Bu arac yalniz komutla dokunur:
//   /private/var/mobile/Library/Caches/kasprobe-cmd.txt  ->  "gizle <bid>" | "goster <bid>" | "durum"
// Gunluk: /private/var/mobile/Library/Caches/kasprobe.txt . Her ozel metot cagrisi imza birebir tutarsa yapilir.
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <stdio.h>
@interface NSObject (KASProbe)
- (NSArray *)allItems;
- (NSString *)bundleIdentifier;
- (id)contentViewController;
- (id)appLayout;
@end

static FILE *g;
static double kaldirZaman = 0;   // GORUNUM-P penceresi
static NSMutableSet *kasa;       // 0.5 (§7.2): gizli kalmasi gereken bidler
static void L(NSString *s) {
	if (!g) g = fopen("/private/var/mobile/Library/Caches/kasprobe.txt", "a");
	if (!g) return;
	fprintf(g, "%.3f %s\n", [[NSDate date] timeIntervalSince1970], s.UTF8String); fflush(g);
}
static BOOL imza(id o, BOOL sinif, const char *sel, const char *bekl) {
	Class k = sinif ? (Class)o : object_getClass(o);
	Method m = sinif ? class_getClassMethod(k, sel_registerName(sel)) : class_getInstanceMethod(k, sel_registerName(sel));
	const char *t = m ? method_getTypeEncoding(m) : "yok";
	if (m && !strcmp(t, bekl)) return YES;
	L([NSString stringWithFormat:@"IMZA-TUTMADI %s = %s (beklenen %s)", sel, t, bekl]); return NO;
}
static NSString *bidler(id liste) {
	NSMutableArray *a = [NSMutableArray array];
	if (![liste isKindOfClass:[NSArray class]]) return @"?";
	for (id al in liste) {
		NSString *b = @"?";
		if ([al respondsToSelector:@selector(allItems)])
			for (id it in [al allItems]) if ([it respondsToSelector:@selector(bundleIdentifier)]) { b = [[[it bundleIdentifier] componentsSeparatedByString:@"."] lastObject]; break; }
		BOOL h = imza(al, NO, "isHidden", "B16@0:8") ? ((BOOL (*)(id, SEL))objc_msgSend)(al, sel_registerName("isHidden")) : NO;
		[a addObject:h ? [b stringByAppendingString:@"(G)"] : b];
	}
	return [NSString stringWithFormat:@"n=%lu [%@]", (unsigned long)a.count, [a componentsJoinedByString:@","]];
}
static id koord(void) {
	Class k = objc_getClass("SBMainSwitcherControllerCoordinator");
	return (k && [k respondsToSelector:@selector(sharedInstanceIfExists)]) ? [k performSelector:@selector(sharedInstanceIfExists)] : nil;
}
static id model(id c) {
	Ivar v = c ? class_getInstanceVariable(object_getClass(c), "_mainSwitcherModel") : NULL;
	if (!v || strcmp(ivar_getTypeEncoding(v), "@\"SBAppSwitcherModel\"")) { L(@"model-ivar-yok"); return nil; }
	return object_getIvar(c, v);
}
static void durum(NSString *neden) {
	id c = koord(), m = model(c);
	if (!m || !imza(m, NO, "appLayoutsIncludingHiddenAppLayouts:", "@20@0:8B16")) return;
	id hayir = ((id (*)(id, SEL, BOOL))objc_msgSend)(m, sel_registerName("appLayoutsIncludingHiddenAppLayouts:"), NO);
	id evet  = ((id (*)(id, SEL, BOOL))objc_msgSend)(m, sel_registerName("appLayoutsIncludingHiddenAppLayouts:"), YES);
	L([NSString stringWithFormat:@"DURUM %@ model-gizlisiz %@", neden, bidler(hayir)]);
	L([NSString stringWithFormat:@"DURUM %@ model-gizlidahil %@", neden, bidler(evet)]);
}
static void yenile(id c) {
	if (imza(c, NO, "_rebuildAppListCache", "v16@0:8")) ((void (*)(id, SEL))objc_msgSend)(c, sel_registerName("_rebuildAppListCache"));
}
static void gizle(NSString *bid) {
	id c = koord(), m = model(c);
	if (!m || !imza(m, NO, "appLayoutsForBundleIdentifier:includingHiddenAppLayouts:", "@28@0:8@16B24") || !imza(m, NO, "hide:", "v24@0:8@16")) return;
	durum(@"once");
	NSArray *ls = ((id (*)(id, SEL, id, BOOL))objc_msgSend)(m, sel_registerName("appLayoutsForBundleIdentifier:includingHiddenAppLayouts:"), bid, NO);
	if (!kasa) kasa = [NSMutableSet set];
	[kasa addObject:bid];
	L([NSString stringWithFormat:@"GIZLE %@ duzen=%lu", bid, (unsigned long)ls.count]);
	for (id al in [ls copy]) ((void (*)(id, SEL, id))objc_msgSend)(m, sel_registerName("hide:"), al);
	yenile(c);
	durum(@"sonra");
}
static void goster(NSString *bid) {
	id c = koord(), m = model(c);
	if (!m || !imza(m, NO, "appLayoutsForBundleIdentifier:includingHiddenAppLayouts:", "@28@0:8@16B24")
	    || !imza(m, NO, "replaceAppLayout:withAppLayout:", "v32@0:8@16@24")) return;
	durum(@"once");
	NSArray *ls = ((id (*)(id, SEL, id, BOOL))objc_msgSend)(m, sel_registerName("appLayoutsForBundleIdentifier:includingHiddenAppLayouts:"), bid, YES);
	NSUInteger n = 0;
	for (id al in [ls copy]) {
		if (!imza(al, NO, "isHidden", "B16@0:8") || !imza(al, NO, "appLayoutByModifyingHiddenState:", "@20@0:8B16")) return;
		if (!((BOOL (*)(id, SEL))objc_msgSend)(al, sel_registerName("isHidden"))) continue;
		id yeni = ((id (*)(id, SEL, BOOL))objc_msgSend)(al, sel_registerName("appLayoutByModifyingHiddenState:"), NO);
		((void (*)(id, SEL, id, id))objc_msgSend)(m, sel_registerName("replaceAppLayout:withAppLayout:"), al, yeni);
		n++;
	}
	[kasa removeObject:bid];
	L([NSString stringWithFormat:@"GOSTER %@ degisen=%lu", bid, (unsigned long)n]);
	yenile(c);
	durum(@"sonra");
}

// M1c: ondeki uygulama icin Apple'in kendi silme sirasi: removeLayoutRole:inSpace:mutationBlock:reason: + blokta hide:.
static void kaldir(NSString *bid) {
	id c = koord(), m = model(c);
	if (!m || !imza(m, NO, "appLayoutsForBundleIdentifier:includingHiddenAppLayouts:", "@28@0:8@16B24") || !imza(m, NO, "hide:", "v24@0:8@16")) return;
	Ivar v = class_getInstanceVariable(object_getClass(c), "_switcherControllersByWindowScene");
	if (!v || strcmp(ivar_getTypeEncoding(v), "@\"NSMapTable\"")) { L(@"KALDIR harita-yok"); return; }
	id vc = nil;
	for (id sc in [object_getIvar(c, v) objectEnumerator])
		if ([sc respondsToSelector:@selector(contentViewController)]) { vc = [sc performSelector:@selector(contentViewController)]; break; }
	if (!vc || !imza(vc, NO, "removeLayoutRole:inSpace:mutationBlock:reason:", "v48@0:8q16@24@?32q40")) { L(@"KALDIR vc-yok"); return; }
	// 0.4: gorunumun KENDI listesindeki duzen (kurucunun ekledigi kopya dahil) - model nesnesi degil
	id al = nil, oge = nil;
	if (imza(vc, NO, "appLayouts", "@16@0:8"))
		for (id x in ((id (*)(id, SEL))objc_msgSend)(vc, sel_registerName("appLayouts")))
			for (id it in [x allItems]) if ([[it bundleIdentifier] isEqual:bid]) al = x;
	L([NSString stringWithFormat:@"KALDIR gorunum-duzeni %@", al ? @"bulundu" : @"YOK"]);
	for (id it in [al allItems]) if ([[it bundleIdentifier] isEqual:bid]) oge = it;
	if (!oge || !imza(al, NO, "layoutRoleForItem:", "q24@0:8@16")) { L(@"KALDIR duzen-yok"); return; }
	long long rol = ((long long (*)(id, SEL, id))objc_msgSend)(al, sel_registerName("layoutRoleForItem:"), oge);
	durum(@"once");
	kaldirZaman = [[NSDate date] timeIntervalSince1970];
	if (!kasa) kasa = [NSMutableSet set];
	[kasa addObject:bid];
	L([NSString stringWithFormat:@"KALDIR %@ rol=%lld vc=%s", bid, rol, object_getClassName(vc)]);
	// Apple'in blogu: model degisikligi + _rebuildAppListCache (DSC 26 block_invoke_2) - birebir ayni sira
	void (^blok)(void) = ^{ ((void (*)(id, SEL, id))objc_msgSend)(m, sel_registerName("hide:"), al); yenile(c); L(@"KALDIR blok hide+rebuild"); };
	((void (*)(id, SEL, long long, id, id, long long))objc_msgSend)(vc, sel_registerName("removeLayoutRole:inSpace:mutationBlock:reason:"), rol, al, blok, 1);
	durum(@"sonra");
}

// 0.6: switcher'i stok gecis istegiyle ac: appLayout = nil (0.4.3 olcumu: "switcher acilisi"), unlockedEnvironmentMode = mod.
static void swac(long long mod) {
	id c = koord();
	Ivar v = c ? class_getInstanceVariable(object_getClass(c), "_switcherControllersByWindowScene") : NULL;
	if (!v || strcmp(ivar_getTypeEncoding(v), "@\"NSMapTable\"")) { L(@"SWAC harita-yok"); return; }
	id vc = nil;
	for (id sc in [object_getIvar(c, v) objectEnumerator]) if ([sc respondsToSelector:@selector(contentViewController)]) { vc = [sc contentViewController]; break; }
	Class kR = objc_getClass("SBMutableSwitcherTransitionRequest");
	const char *sP = "switcherContentController:performTransitionWithRequest:gestureInitiated:";
	if (!vc || !kR || !imza(c, NO, sP, "v36@0:8@16@24B32")) { L(@"SWAC yol-yok"); return; }
	id req = [(id)[kR alloc] init];
	if (!imza(req, NO, "setUnlockedEnvironmentMode:", "v24@0:8q16")) return;
	((void (*)(id, SEL, long long))objc_msgSend)(req, sel_registerName("setUnlockedEnvironmentMode:"), mod);
	L([NSString stringWithFormat:@"SWAC istek mod=%lld appLayout=nil", mod]);
	((void (*)(id, SEL, id, id, BOOL))objc_msgSend)(c, sel_registerName(sP), vc, req, NO);
	L(@"SWAC gonderildi");
}

// Gorunum listesi (m27 deseni): yalniz degisince yazar.
static id (*o_unadj)(id, SEL);
static id h_unadj(id s, SEL c) {
	id r = o_unadj(s, c);
	static NSString *son = nil;
	@try { NSString *b = bidler(r); BOOL p = [[NSDate date] timeIntervalSince1970] - kaldirZaman < 2.0;
		if (p || ![b isEqualToString:son]) { son = b; L([(p ? @"GORUNUM-P " : @"GORUNUM ") stringByAppendingString:b]); } } @catch (__unused id e) {}
	return r;
}
// M2: Apple yeni duzen eklerken (uygulama acildi) - yalniz gunluk.
static id (*o_will)(id, SEL, id, id, id, id);
static id h_will(id s, SEL c, id m, id al, id rep, id rem) {
	id r = o_will(s, c, m, al, rep, rem);
	// 0.5 (§7.2): kasadaki uygulamanin yeni duzeni gizli eklensin - Apple'in karar noktasinin donus degeri
	@try {
		BOOL kasada = NO;
		for (id it in [r allItems]) if ([kasa containsObject:[it bundleIdentifier]]) kasada = YES;
		if (kasada && imza(r, NO, "isHidden", "B16@0:8") && imza(r, NO, "appLayoutByModifyingHiddenState:", "@20@0:8B16")
		    && !((BOOL (*)(id, SEL))objc_msgSend)(r, sel_registerName("isHidden"))) {
			r = ((id (*)(id, SEL, BOOL))objc_msgSend)(r, sel_registerName("appLayoutByModifyingHiddenState:"), YES);
			L(@"WILLADD kasada -> gizli dondu");
		}
	} @catch (__unused id e) { L(@"WILLADD istisna"); }
	@try { L([NSString stringWithFormat:@"WILLADD ekle=%@ yerine=%@ cikar=%@ sonuc=%@", bidler(al ? @[al] : @[]), bidler(rep), bidler(rem), bidler(r ? @[r] : @[])]); } @catch (__unused id e) {}
	return r;
}
static void (*o_perf)(id, SEL, id, id, BOOL);
static void h_perf(id s, SEL c, id cc, id req, BOOL g) {
	@try { id al = [req respondsToSelector:@selector(appLayout)] ? [req performSelector:@selector(appLayout)] : nil;
		L([NSString stringWithFormat:@"GECIS-ISTEGI duzen=%@ gesture=%d", al ? bidler(@[al]) : @"nil", g]); } @catch (__unused id e) {}
	o_perf(s, c, cc, req, g);
}
static void kanca(Class k, const char *sel, const char *bekl, IMP n, IMP *o) {
	Method m = k ? class_getInstanceMethod(k, sel_registerName(sel)) : NULL;
	const char *t = m ? method_getTypeEncoding(m) : "yok";
	BOOL ok = m && !strcmp(t, bekl);
	L([NSString stringWithFormat:@"KANCA %s = %s -> %@", sel, t, ok ? @"kuruldu" : @"ATLANDI"]);
	if (ok) { *o = method_getImplementation(m); method_setImplementation(m, n); }
}

__attribute__((constructor)) static void kur(void) {
	L(@"--- KASProbe yuklendi");
	if ((0)) {   // 0.6: kancalar kapali - KASwitcher ile yan yana yalniz komut araci
	kanca(objc_getClass("SBFluidSwitcherViewController"), "_unadjustedAppLayouts", "@16@0:8", (IMP)h_unadj, (IMP *)&o_unadj);
	kanca(objc_getClass("SBMainSwitcherControllerCoordinator"), "switcherContentController:performTransitionWithRequest:gestureInitiated:",
	      "v36@0:8@16@24B32", (IMP)h_perf, (IMP *)&o_perf);
	kanca(objc_getClass("SBMainSwitcherControllerCoordinator"), "appSwitcherModel:willAddAppLayout:replacingAppLayouts:removingAppLayouts:",
	      "@48@0:8@16@24@32@40", (IMP)h_will, (IMP *)&o_will);
	}
	dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
	dispatch_source_set_timer(t, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC), NSEC_PER_SEC / 2, NSEC_PER_SEC / 10);
	dispatch_source_set_event_handler(t, ^{
		NSString *p = @"/private/var/mobile/Library/Caches/kasprobe-cmd.txt";
		NSString *k = [NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:nil];
		if (!k.length) return;
		[[NSFileManager defaultManager] removeItemAtPath:p error:nil];
		NSArray *a = [[k stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] componentsSeparatedByString:@" "];
		L([@"KOMUT " stringByAppendingString:k]);
		@try {
			if ([a[0] isEqual:@"gizle"] && a.count > 1) gizle(a[1]);
			else if ([a[0] isEqual:@"goster"] && a.count > 1) goster(a[1]);
			else if ([a[0] isEqual:@"kaldir"] && a.count > 1) kaldir(a[1]);
			else if ([a[0] isEqual:@"swac"]) swac(a.count > 1 ? [a[1] longLongValue] : 2);
			else durum(@"komut");
		} @catch (NSException *e) { L([@"ISTISNA " stringByAppendingString:e.reason ?: @"?"]); }
	});
	dispatch_resume(t);
	static dispatch_source_t tut; tut = t; (void)tut;
}
