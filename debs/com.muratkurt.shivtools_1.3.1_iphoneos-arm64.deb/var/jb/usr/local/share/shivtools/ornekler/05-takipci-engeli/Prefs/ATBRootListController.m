// AppTrackerBlock — main Settings page.
// Rows come from Root.plist (labels localized by <lang>.lproj/Root.strings);
// this class adds icons, the blocklist status row, the header card and
// the About links. No @"..." literals (Settings is arm64e, built on device).
#import "ATBRootListController.h"
#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import <notify.h>
#import "JBRoot.h"
#import "Common.h"
#import "Blocklist.h"
#import "ATBStyle.h"

// Row id -> Settings-style icon (looks only; an unknown id gets no icon).
static UIImage *iconForRow(NSString *rowID) {
    const char *c = rowID.UTF8String;
    if (!c) return nil;
    if (!strcmp(c, "report"))        return ATBIcon("chart.bar.fill", UIColor.systemBlueColor);
    if (!strcmp(c, "blocking"))      return ATBIcon("shield.lefthalf.filled", UIColor.systemIndigoColor);
    if (!strcmp(c, "noblock"))       return ATBIcon("hand.raised.slash.fill", UIColor.systemOrangeColor);
    if (!strcmp(c, "blocklist"))     return ATBIcon("list.bullet.rectangle.fill", UIColor.systemGreenColor);
    if (!strcmp(c, "logging"))       return ATBIcon("doc.text.magnifyingglass", UIColor.systemGrayColor);
    if (!strcmp(c, "excluded"))      return ATBIcon("building.columns.fill", UIColor.systemRedColor);
    if (!strcmp(c, "about-dev"))     return ATBIcon("person.fill", UIColor.systemGrayColor);
    if (!strcmp(c, "about-docs"))    return ATBIcon("book.fill", UIColor.systemBlueColor);
    if (!strcmp(c, "about-issues"))  return ATBIcon("exclamationmark.bubble.fill", UIColor.systemOrangeColor);
    return nil;
}

// Header of the compiled blocklist (32 bytes). NO if missing or invalid.
static BOOL readListHeader(atb_header *h) {
    const char *p = jbroot(ATB_BLOCKLIST);
    FILE *f = p ? fopen(p, "rb") : NULL;
    if (!f) return NO;
    BOOL ok = fread(h, sizeof *h, 1, f) == 1 && !memcmp(h->magic, ATB_LIST_MAGIC, 8);
    fclose(f);
    return ok;
}

@implementation ATBRootListController

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *m = [[self loadSpecifiersFromPlistName:ATBS("Root") target:self] mutableCopy];
        NSUInteger insertAt = NSNotFound;
        for (NSUInteger i = 0; i < m.count; i++) {
            PSSpecifier *sp = m[i];
            NSString *rowID = [sp identifier];
            UIImage *icon = iconForRow(rowID);
            if (icon) [sp setProperty:icon forKey:ATBS("iconImage")];   // TWEAK.md 4b: only this key works
            if ([rowID isEqualToString:ATBS("noblock")]) insertAt = i + 1;
            if ([rowID isEqualToString:ATBS("about")]) {
                NSString *v = ATBVersion() ?: ATBS("?");
                [sp setProperty:[NSString stringWithFormat:ATBL("AppTrackerBlock %@ · © 2026 muratkurt · Built with Claude Opus 5.5"), v]
                         forKey:ATBS("footerText")];
            }
        }
        if (insertAt != NSNotFound) [m insertObject:[self blocklistRow] atIndex:insertAt];
        _specifiers = m;
    }
    return _specifiers;
}

// Blocklist status: entry count + build date; if missing, tapping copies
// the update command (house style: a missing row says how to fix it).
- (PSSpecifier *)blocklistRow {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:ATBL("Blocklist") target:self set:NULL
                                                        get:@selector(blocklistValue:)
                                                     detail:Nil cell:PSTitleValueCell edit:Nil];
    [sp setProperty:ATBS("blocklist") forKey:ATBS("id")];
    [sp setIdentifier:ATBS("blocklist")];
    [sp setProperty:iconForRow(ATBS("blocklist")) forKey:ATBS("iconImage")];
    return sp;
}

- (id)blocklistValue:(PSSpecifier *)sp {
    atb_header h;
    if (!readListHeader(&h)) return ATBL("Missing · tap to copy command");
    NSDate *built = [NSDate dateWithTimeIntervalSince1970:(NSTimeInterval)h.built];
    NSString *day = [NSDateFormatter localizedStringFromDate:built dateStyle:NSDateFormatterShortStyle
                                                   timeStyle:NSDateFormatterNoStyle];
    NSString *count = [NSNumberFormatter localizedStringFromNumber:@(h.count)
                                                       numberStyle:NSNumberFormatterDecimalStyle];
    return [NSString stringWithFormat:ATBL("%@ domains · %@"), count, day];
}

// cfprefsd buffers writes (TWEAK.md 4b: ~6 s). The tweak reads the plist
// from disk, so flush first, THEN notify.
- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)spec {
    [super setPreferenceValue:value specifier:spec];
    CFStringRef domain = CFStringCreateWithCString(NULL, ATB_DOMAIN, kCFStringEncodingUTF8);
    if (domain) { CFPreferencesAppSynchronize(domain); CFRelease(domain); }
    notify_post(ATB_NOTIFY);
    [self installHeader];               // badge follows the switch
}

// The badge takes the color of the WORST state (house style).
- (void)installHeader {
    atb_header h;
    CFStringRef domain = CFStringCreateWithCString(NULL, ATB_DOMAIN, kCFStringEncodingUTF8);
    CFStringRef key = CFStringCreateWithCString(NULL, ATB_KEY_BLOCKING, kCFStringEncodingUTF8);
    id v = (domain && key) ? (__bridge_transfer id)CFPreferencesCopyAppValue(key, domain) : nil;
    if (key) CFRelease(key);
    if (domain) CFRelease(domain);
    BOOL blocking = [v respondsToSelector:@selector(boolValue)] ? [v boolValue] : YES;
    NSString *status; UIColor *color;
    if (!readListHeader(&h)) { status = ATBL("Blocklist missing"); color = UIColor.systemRedColor; }
    else if (!blocking)      { status = ATBL("Blocking off");      color = UIColor.systemOrangeColor; }
    else                     { status = ATBL("Blocking on");       color = UIColor.systemGreenColor; }
    UITableView *t = [self table];
    ATBHeaderView *header = [[ATBHeaderView alloc] initWithStatus:status color:color];
    header.frame = CGRectMake(0, 0, t.bounds.size.width ?: 320, 228);
    t.tableHeaderView = header;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self installHeader];
    [self reloadSpecifierID:ATBS("blocklist")];
}

- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    NSString *rowID = [[self specifierAtIndexPath:ip] identifier];
    const char *url = NULL;
    if ([rowID isEqualToString:ATBS("about-dev")])         url = "https://github.com/muratkurt";
    else if ([rowID isEqualToString:ATBS("about-docs")])   url = "https://github.com/muratkurt/AppTrackerBlock#readme";
    else if ([rowID isEqualToString:ATBS("about-issues")]) url = "https://github.com/muratkurt/AppTrackerBlock/issues";
    if (url) {
        [tv deselectRowAtIndexPath:ip animated:YES];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:ATBS(url)]
                                           options:[NSDictionary dictionary]
                                 completionHandler:nil];
        return;
    }
    if ([rowID isEqualToString:ATBS("blocklist")]) {
        [tv deselectRowAtIndexPath:ip animated:YES];
        atb_header h;
        if (!readListHeader(&h)) [UIPasteboard generalPasteboard].string = ATBS("atb-update");
        return;
    }
    [super tableView:tv didSelectRowAtIndexPath:ip];
}

@end
