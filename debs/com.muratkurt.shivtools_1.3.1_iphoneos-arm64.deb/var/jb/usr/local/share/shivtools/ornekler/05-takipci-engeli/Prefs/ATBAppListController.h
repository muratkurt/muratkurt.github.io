#import <Preferences/PSListController.h>
@interface ATBAppListController : PSListController
@end
