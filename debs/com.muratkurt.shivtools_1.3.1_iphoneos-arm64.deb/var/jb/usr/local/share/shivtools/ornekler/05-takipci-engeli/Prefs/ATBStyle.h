// AppTrackerBlock Settings page — visual helpers (shivtools house style).
// Public UIKit only. No @"..." literals and no blocks handed to the system:
// a device-built arm64e binary has caps 0x00.
#import <UIKit/UIKit.h>

// NSString from a C string (instead of a literal).
NSString *ATBS(const char *s);

// Localized text. The key IS the English source text; each
// <lang>.lproj/Localizable.strings translates it. Missing -> English.
// Format strings (%@, %lu) keep the same order in every language.
NSString *ATBL(const char *english);

// Settings-style icon: 29 pt rounded colored square + white SF Symbol.
UIImage *ATBIcon(const char *symbol, UIColor *color);

// Package version: the 'version' file the Makefile writes into the
// bundle. Never typed by hand. nil if missing.
NSString *ATBVersion(void);

// Header card: icon, name, tagline, version, status badge.
@interface ATBHeaderView : UIView
- (instancetype)initWithStatus:(NSString *)status color:(UIColor *)color;
@end
