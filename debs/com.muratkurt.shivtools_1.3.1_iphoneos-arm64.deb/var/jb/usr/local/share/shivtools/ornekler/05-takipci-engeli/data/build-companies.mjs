// Builds the domain -> company map from open lists.
// Run: cd data && node build-companies.mjs > ../layout/Library/AppTrackerBlock/companies.tsv
//
// Sources (in priority order; the first match wins):
//   1. DuckDuckGo Tracker Blocklists, app/android-tds.json   (app trackers)
//   2. DuckDuckGo Tracker Blocklists, ios-tds.json 'domains' -> 'entities'
//   3. Disconnect tracking protection, services.json
// All three are CC BY-NC-SA 4.0 (non-commercial, attribution, share-alike);
// the generated companies.tsv inherits that license.
//
// Inputs (download next to this script):
//   curl -sSLo ddg-android-tds.json https://raw.githubusercontent.com/duckduckgo/tracker-blocklists/main/app/android-tds.json
//   curl -sSLo ddg-ios-tds.json https://staticcdn.duckduckgo.com/trackerblocking/v6/current/ios-tds.json
//   curl -sSLo disconnect-services.json https://raw.githubusercontent.com/disconnectme/disconnect-tracking-protection/master/services.json
import fs from 'fs';

const android = JSON.parse(fs.readFileSync('ddg-android-tds.json'));
const ios = JSON.parse(fs.readFileSync('ddg-ios-tds.json'));
const disconnect = JSON.parse(fs.readFileSync('disconnect-services.json'));

const map = new Map();
const counts = { android: 0, ios: 0, disconnect: 0 };
const add = (domain, company, source) => {
  domain = String(domain).toLowerCase().trim();
  company = String(company || '').replace(/[\t\n]/g, ' ').trim();
  if (!domain || !company || map.has(domain)) return;
  map.set(domain, company); counts[source]++;
};

for (const [domain, v] of Object.entries(android.trackers))
  add(domain, v.owner && (v.owner.displayName || v.owner.name), 'android');
for (const [domain, entity] of Object.entries(ios.domains || {}))
  add(domain, (ios.entities[entity] || {}).displayName || entity, 'ios');
for (const list of Object.values(disconnect.categories))
  for (const item of list)
    for (const [name, v] of Object.entries(item))
      for (const domains of Object.values(v))
        if (Array.isArray(domains)) for (const d of domains) add(d, name, 'disconnect');

console.log('# AppTrackerBlock company map: domain<TAB>company. Matched by suffix.');
console.log(`# Source 1: DuckDuckGo Tracker Blocklists app/android-tds.json version ${android.version} (${counts.android} domains)`);
console.log(`# Source 2: DuckDuckGo Tracker Blocklists ios-tds.json (${counts.ios} domains)`);
console.log(`# Source 3: Disconnect services.json (${counts.disconnect} domains)`);
console.log('# License: CC BY-NC-SA 4.0 - https://creativecommons.org/licenses/by-nc-sa/4.0/');
console.log(`# Built: ${new Date().toISOString()}`);
for (const [domain, company] of [...map.entries()].sort()) console.log(`${domain}\t${company}`);
