# 06 — KASwitcher 0.7 (bitmiş SpringBoard tweak'i + ölçüm tweak'i)

> **UYARI: paket adı yayındaki KASwitcher ile AYNI (`com.muratkurt.kaswitcher`). Kendi işin için kopyaladıysan önce `control`'deki Package/Name'i, `KASwitcher.plist` adını ve prefs alanını değiştir; yoksa kurulu KASwitcher'ın üstüne yazar. SpringBoard'a girer: her değişiklikten sonra respring.**

App Switcher tweak'i: tek dokunuşla tümünü kapatma, kasa (seçilen uygulamalar
switcher'da görünmez, Face ID'li kendi penceresinde durur), aşağı atınca kasaya
taşıma, sabitleme, temalar, 12 dil. Burada kodundan çok **nasıl karar verildiği**
için duruyor.

## Ne gösteriyor

| Ders (kanun §8) | Nerede |
|---|---|
| **Durumun sahibi Apple ise onu kullan.** Gizli uygulamalar kendi süzgecimizden Apple'ın `SBAppLayout.hidden` bayrağına taşındı; istisnalar ve zamanlama pencereleri kalktı | `KASGizle.m` (`kas_gizle`, `kas_goster`), `olcumler/06-…` §1.3, §7, §8.1 |
| **Doğru veriyi doğru anda kendin al, Apple'a Apple'ın yoluyla ver.** Öndeki uygulamanın görüntüsü sahne hâlâ öndeyken `FBScene createSnapshot` ile alınıyor, `saveSuspendSnapshot:` ile Apple'ın deposuna yazılıyor | `KASGizle.m` (`kas_sahneResmi`), `olcumler/06-…` §8.9 |
| **Dokununca düzeliyorsa eksik olan yenileme tetiğidir** (`_updateSnapshotCache`) | `olcumler/06-…` §8.9 b33 |
| **Zaman penceresi yerine durum değeri; başla/bit eşlemesi** (`unlockedEnvironmentMode`, iki aşamalı bayrak) | `Tweak.x`, `olcumler/06-…` §8.5 b5, §8.8 b18 |
| **İmza denetimli çağrı** — her özel çağrıdan önce `method_getTypeEncoding` birebir karşılaştırılır | `KASGizle.m` `imza()`; reçete `TWEAK.md` "Signature-checked call" |
| **Ayrı ölçüm tweak'i** — mimari kararı ürün kaldırılmışken, Apple'ın davranışını ölçerek ver | `olcum-tweaki/` (PROBE-0.7), sonuçlar `olcumler/06-…` §7; genel iskelet: örnek 07 |

## Dosyalar

```
Tweak.x                X butonu, menü, aşağı atma, kasa açma/kapama, temalar
KASGizle.h/.m          Apple'ın stok çağrıları, hepsi imza denetimli
KASKasa.h/.m           kasa paneli (kendi penceresi, Face ID)
KASMenu.h/.m           kendi menü (UIContextMenuInteraction yerine; TWEAK.md §4)
KASDil.m               tweak metinleri (tools/dil-uret.py üretir, elle düzenleme)
kasprefs/              Ayarlar sayfası (12 dil, tema seçici, korunanlar listesi)
tools/dil-uret.py      12 dilin TEK kaynağı: metin ekle → çalıştır → derle
olcum-tweaki/          PROBE-0.7: komut dosyasıyla tetiklenen ölçüm aracı (YAYINLANMAZ)
olcumler/              06-YENIDEN-DEGERLENDIRME (mimari, M1–M4, b1–b33),
                       OLCUM-OZETI-0.6.0, imza dökümleri (iOS 17.0.3)
```

## Derleme

```
export THEOS=~/theos-rh;       make clean package THEOS_PACKAGE_SCHEME=roothide FINALPACKAGE=1
export THEOS=~/theos;          make clean package THEOS_PACKAGE_SCHEME=rootless FINALPACKAGE=1
```

Yayın derlemesi Mac'te (caps 0x80); `control`'de oldabi YOK.

## Durum

- Mac'te iki şema derlendi, dylib ve prefs arm64e **caps 0x80** (4 Eki 2026, bu klasörden).
- Kullanıcı testi: vphone iOS 26.6.2, RootHide iOS 17.0.3 (rapor §8) ve rootless XS iOS 16.1.1
  (son sürüm, 4 Eki 2026) — tüm testler geçti. Yayındaki sürüm: **0.7.0**.
- Bilinen kısıt: öndeki uygulamanın kartı kasaya giderken uçma animasyonu yok.

## Dışarıda bırakılanlar

Oturum kayıtları, ham günlükler, kişisel ekran görüntüleri ve projenin eski
`CLAUDE.md`'si bu örneğe girmedi. Kurallar için güncel kanun: `shiv-init --show`.
