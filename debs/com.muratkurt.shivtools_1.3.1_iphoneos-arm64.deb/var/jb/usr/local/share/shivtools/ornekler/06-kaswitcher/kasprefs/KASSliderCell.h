#import <Preferences/PSSliderTableCell.h>

@interface KASSliderCell : PSSliderTableCell
@end
