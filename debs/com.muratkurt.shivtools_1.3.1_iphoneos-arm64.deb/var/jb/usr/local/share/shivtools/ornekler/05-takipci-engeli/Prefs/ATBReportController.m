// AppTrackerBlock — "Last 7 days" report (DuckDuckGo App Tracking
// Protection style summary).
//
// Data: every app writes its blocks into its OWN container (the sandbox
// cannot write under the jailbreak root, measured):
//   /var/mobile/Containers/Data/Application/<UUID>/Library/Caches/AppTrackerBlock-blocked.log(.1)
//   first line "#<TAB>bundle-id", then "unix-seconds<TAB>matched-domain"
// Settings has no sandbox (com.apple.private.security.no-sandbox) and reads
// them directly.
// Companies: /Library/AppTrackerBlock/companies.tsv (jailbreak root),
// DuckDuckGo + Disconnect, CC BY-NC-SA 4.0. Suffix match; otherwise the
// domain itself is shown.
//
// No @"..." literals and no blocks handed to the system (Settings is arm64e).
#import "ATBReportController.h"
#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import "JBRoot.h"
#import <dirent.h>
#import <errno.h>
#import <stdio.h>
#import <stdlib.h>
#import <string.h>
#import <unistd.h>
#import "Common.h"
#import "ATBStyle.h"

#define ATB_CONTAINERS "/var/mobile/Containers/Data/Application"
#define ATB_DAYS       7

@interface LSApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (NSArray *)allInstalledApplications;
@end
@interface LSApplicationProxy : NSObject
- (NSString *)localizedName;
- (NSString *)applicationIdentifier;
@end

// Sort [name, NSNumber] pairs by count, descending.
static NSInteger byCountDesc(id a, id b, void *c) { return [b[1] compare:a[1]]; }

@interface ATBReportController () {
    NSMutableDictionary *_companies;   // domain -> company
    NSMutableDictionary *_cache;       // matched domain -> company or NSNull
}
@end

@implementation ATBReportController

- (void)loadCompanies {
    if (_companies) return;
    _companies = [NSMutableDictionary dictionary];
    _cache = [NSMutableDictionary dictionary];
    const char *path = jbroot(ATB_COMPANIES);
    FILE *f = path ? fopen(path, "r") : NULL;
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof line, f)) {
        if (line[0] == '#') continue;
        char *tab = strchr(line, '\t');
        if (!tab) continue;
        *tab = 0;
        char *name = tab + 1;
        name[strcspn(name, "\r\n")] = 0;
        NSString *k = ATBS(line), *v = ATBS(name);
        if (k && v) _companies[k] = v;
    }
    fclose(f);
}

// Suffix walk: a.b.example.com -> b.example.com -> example.com -> com
- (NSString *)companyForDomain:(NSString *)domain {
    id c = _cache[domain];
    if (c) return c == [NSNull null] ? nil : c;
    NSString *x = domain, *found = nil;
    while (x.length) {
        found = _companies[x];
        if (found) break;
        NSRange r = [x rangeOfString:ATBS(".")];
        if (r.location == NSNotFound) break;
        x = [x substringFromIndex:r.location + 1];
    }
    _cache[domain] = found ?: [NSNull null];
    return found;
}

// Reads one file into apps[bundleID][label] += 1. Returns the number of blocks read.
- (NSUInteger)readFile:(const char *)path since:(long)since into:(NSMutableDictionary *)apps bundleID:(NSString **)bidp {
    FILE *f = fopen(path, "r");
    if (!f) return 0;
    char line[400];
    NSUInteger n = 0;
    NSMutableDictionary *d = nil;
    while (fgets(line, sizeof line, f)) {
        line[strcspn(line, "\r\n")] = 0;
        char *tab = strchr(line, '\t');
        if (!tab) continue;
        if (line[0] == '#') { *bidp = ATBS(tab + 1); continue; }
        if (!*bidp) continue;
        if (atol(line) < since) continue;
        if (!d) {
            d = apps[*bidp];
            if (!d) { d = [NSMutableDictionary dictionary]; apps[*bidp] = d; }
        }
        NSString *domain = ATBS(tab + 1);
        if (!domain.length) continue;
        NSString *company = [self companyForDomain:domain];
        NSString *label = company ?: [NSString stringWithFormat:ATBL("%@ (company not in list)"), domain];
        d[label] = @([d[label] unsignedIntegerValue] + 1);
        n++;
    }
    fclose(f);
    return n;
}

- (id)rowValue:(PSSpecifier *)sp { return [sp propertyForKey:ATBS("atbValue")]; }

- (PSSpecifier *)groupNamed:(NSString *)name footer:(NSString *)footer {
    PSSpecifier *g = [PSSpecifier preferenceSpecifierNamed:name target:self set:NULL get:NULL
                                                    detail:Nil cell:PSGroupCell edit:Nil];
    if (footer) [g setProperty:footer forKey:ATBS("footerText")];
    return g;
}

- (PSSpecifier *)rowNamed:(NSString *)name value:(NSString *)value bundleID:(NSString *)bid {
    PSSpecifier *sp = [PSSpecifier preferenceSpecifierNamed:name target:self set:NULL
                                                        get:@selector(rowValue:)
                                                     detail:Nil cell:PSTitleValueCell edit:Nil];
    [sp setProperty:value forKey:ATBS("atbValue")];
    if (bid) {
        [sp setProperty:bid forKey:ATBS("appIDForLazyIcon")];
        [sp setProperty:@YES forKey:ATBS("useLazyIcons")];
    }
    return sp;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reloadSpecifiers];      // recount every time the page appears
}

- (NSArray *)specifiers {
    [self loadCompanies];
    NSMutableArray *s = [NSMutableArray array];
    NSMutableDictionary *apps = [NSMutableDictionary dictionary];   // bundleID -> {label: count}
    long since = (long)time(NULL) - ATB_DAYS * 24 * 3600;
    NSUInteger total = 0;
    int files = 0, error = 0;

    DIR *dir = opendir(ATB_CONTAINERS);
    if (!dir) error = errno;
    struct dirent *e;
    while (dir && (e = readdir(dir))) {
        if (e->d_name[0] == '.') continue;
        char path[1100];
        NSString *bid = nil;
        for (int k = 0; k < 2; k++) {
            snprintf(path, sizeof path, "%s/%s/%s%s", ATB_CONTAINERS, e->d_name, ATB_BLOCKED_LOG, k ? ".1" : "");
            if (access(path, R_OK) != 0) continue;
            files++;
            total += [self readFile:path since:since into:apps bundleID:&bid];
        }
    }
    if (dir) closedir(dir);

    // bundleID -> display name
    NSMutableDictionary *names = [NSMutableDictionary dictionary];
    for (LSApplicationProxy *p in [[LSApplicationWorkspace defaultWorkspace] allInstalledApplications]) {
        NSString *b = [p applicationIdentifier], *n = [p localizedName];
        if (b && n.length) names[b] = n;
    }

    // Apps sorted by total blocks
    NSMutableArray *ranked = [NSMutableArray array];
    for (NSString *bid in apps) {
        NSUInteger t = 0;
        for (NSNumber *v in [apps[bid] allValues]) t += v.unsignedIntegerValue;
        if (t) [ranked addObject:[NSArray arrayWithObjects:bid, @(t), nil]];
    }
    [ranked sortUsingFunction:byCountDesc context:NULL];

    NSString *summary = error
        ? [NSString stringWithFormat:ATBL("Could not read app containers (errno=%d)."), error]
        : [NSString stringWithFormat:ATBL("%1$lu requests blocked in %2$lu apps in the last 7 days. Safari and in-app web pages are not counted."),
           (unsigned long)total, (unsigned long)ranked.count];
    [s addObject:[self groupNamed:ATBL("Last 7 days") footer:summary]];
    PSSpecifier *rowTotal = [self rowNamed:ATBL("Blocked requests")
                                     value:[NSNumberFormatter localizedStringFromNumber:@(total) numberStyle:NSNumberFormatterDecimalStyle]
                                  bundleID:nil];
    [rowTotal setProperty:ATBIcon("shield.lefthalf.filled", UIColor.systemIndigoColor) forKey:ATBS("iconImage")];
    PSSpecifier *rowApps = [self rowNamed:ATBL("Apps")
                                    value:[NSNumberFormatter localizedStringFromNumber:@(ranked.count) numberStyle:NSNumberFormatterDecimalStyle]
                                 bundleID:nil];
    [rowApps setProperty:ATBIcon("square.grid.2x2.fill", UIColor.systemBlueColor) forKey:ATBS("iconImage")];
    [s addObject:rowTotal];
    [s addObject:rowApps];
    if (!ranked.count && !error)
        [s addObject:[self groupNamed:nil footer:ATBL("No blocked requests yet. They will appear here as you use your apps.")]];

    for (NSArray *app in ranked) {
        NSString *bid = app[0];
        NSString *appName = names[bid] ?: bid;
        NSMutableArray *companies = [NSMutableArray array];
        NSDictionary *d = apps[bid];
        for (NSString *k in d) [companies addObject:[NSArray arrayWithObjects:k, d[k], nil]];
        [companies sortUsingFunction:byCountDesc context:NULL];
        NSMutableArray *sentences = [NSMutableArray array];
        for (NSArray *c in companies)
            [sentences addObject:[NSString stringWithFormat:ATBL("In %1$@, %2$@ was blocked %3$lu times."),
                                  appName, c[0], [c[1] unsignedLongValue]]];
        [s addObject:[self groupNamed:nil footer:[sentences componentsJoinedByString:ATBS("\n")]]];
        [s addObject:[self rowNamed:appName
                              value:[NSString stringWithFormat:ATBL("%lu blocked"), [app[1] unsignedLongValue]]
                           bundleID:bid]];
    }

    [s addObject:[self groupNamed:ATBL("Sources")
                           footer:[NSString stringWithFormat:ATBL("Blocklist: HaGeZi Multi PRO. Company names: DuckDuckGo Tracker Blocklists and Disconnect (CC BY-NC-SA 4.0), %1$lu domains. Log files read: %2$d."),
                                   (unsigned long)_companies.count, files]]];
    _specifiers = s;
    return _specifiers;
}

@end
