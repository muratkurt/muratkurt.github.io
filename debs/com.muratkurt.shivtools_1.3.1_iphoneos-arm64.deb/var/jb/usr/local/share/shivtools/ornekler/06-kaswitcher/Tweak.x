#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import "KASGizle.h"
#include <dlfcn.h>
#import <notify.h>
#import "KASMenu.h"
#import "KASKasa.h"   // 0.6.0 gizli bolum: ikinci switcher

@interface SBDisplayItem : NSObject
- (NSString *)bundleIdentifier;
@end

@interface SBAppLayout : NSObject
- (NSArray *)allItems;
@end

@interface SBApplication : NSObject
- (NSString *)bundleIdentifier;
- (NSString *)displayName;
- (id)processState;
@end

@interface SBApplicationController : NSObject
+ (instancetype)sharedInstance;
- (SBApplication *)applicationWithBundleIdentifier:(NSString *)bid;
- (NSArray *)runningApplications;
@end

@interface SBMediaController : NSObject
+ (instancetype)sharedInstance;
- (SBApplication *)nowPlayingApplication;
@end

@interface SBApplicationProcessState : NSObject
- (BOOL)isForeground;
@end

@interface SBMainSwitcherControllerCoordinator : NSObject
+ (instancetype)sharedInstanceIfExists;
- (NSArray *)recentAppLayouts;
- (void)_deleteAppLayoutsMatchingBundleIdentifier:(NSString *)bid;
- (BOOL)isAnySwitcherVisible;
- (void)_notifySwitcherControllersAppLayoutsDidChange;   // v16@0:8 (0.6.0 imza dokumu)
- (void)_rebuildAppListCache;                            // v16@0:8 (0.6.0 imza dokumu 2)
@end

@interface SpringBoard : UIApplication
- (BOOL)launchApplicationWithIdentifier:(NSString *)bid suspended:(BOOL)s;   // B28@0:8@16B24 (imza dokumu 2)
@end

@interface SBSwitcherTransitionRequest : NSObject
- (SBAppLayout *)appLayout;
+ (id)requestForActivatingHomeScreen;
@end

@interface SBFluidSwitcherViewController : UIViewController
- (void)ka_showUndoWithBids:(NSArray<NSString *> *)bids;
- (void)ka_undoIptal;
- (void)ka_undoTimeout:(NSTimer *)t;
- (void)ka_undoHalkaTemizle;
- (void)ka_undoHalkaAdim:(CADisplayLink *)link;
- (void)ka_acAyarlar;
- (void)ka_toggleSonuncuHaric;
- (void)ka_toggleMedyaKoru;
- (void)ka_tasimaBaslat;
- (void)ka_pan:(UIPanGestureRecognizer *)gr;
- (void)ka_konumSifirla;
- (void)ka_uzunBas:(UILongPressGestureRecognizer *)gr;          // 0.5.0 kendi menu
- (void)ka_gizliTap:(UITapGestureRecognizer *)gr;               // 0.6.0 gizli bolum
- (NSArray<KASMenuOge *> *)ka_mKok;
- (NSArray<KASMenuOge *> *)ka_mAyarlar;
- (NSArray<KASMenuOge *> *)ka_mSecim:(NSString *)anahtar degerler:(NSArray *)d basliklar:(NSArray *)b;
@end

@interface SBReusableSnapshotItemContainer : UIView
- (id)appLayout;
@end

// Basli satiri: SBFluidSwitcherItemContainerHeaderView'in kendi
// titleItems'inden bagimsiz bid'i var, kartin subview'i DEGIL (sibling) -
// bkz olcum notu asagida. Rozet buraya tasiniyor (madde 3).
@interface SBFluidSwitcherItemContainerHeaderView : UIView
- (NSArray *)titleItems;
- (void)ka_rozetTazele;
@end

@interface SBFluidSwitcherSpaceTitleItem : NSObject
- (id)displayItem;
@end

@interface SBFluidSwitcherIconImageContainerView : UIView
@end

extern int SBSOpenSensitiveURLAndUnlock(NSURL *url, BOOL unlock) __attribute__((weak_import));

@interface UIApplication (KA_Ozel)
- (BOOL)applicationOpenURL:(NSURL *)url; // ozel API, tip varsayim: eski openURL: ile ayni sozlesim
@end

static NSString * const kKA_AlanAdi   = @"com.muratkurt.kaswitcher";
static NSString * const kKA_Bildirim  = @"com.muratkurt.kaswitcher/prefs-changed";
static NSString * const kKA_KeySonuncuHaric = @"sonuncuHaric";
static NSString * const kKA_KeyMedyaKoru    = @"medyaKoru";
static NSString * const kKA_KeyKoru         = @"koru";
static NSString * const kKA_KeyGizli        = @"gizli";   // 0.6.0 gizli bolum
static NSString * const kKA_KeyAnimasyonTuru = @"animasyonTuru";
static NSString * const kKA_KeyAnimasyonHizi = @"animasyonHizi";
static NSString * const kKA_KeyEtkin         = @"etkin";


static const CGFloat kKA_ShadowRadius  = 6.0;
static const CGFloat kKA_ShadowOffsetX = 0.0;
static const CGFloat kKA_ShadowOffsetY = 2.0;
static const CGFloat kKA_ShadowOpacity = 0.0;   // 0.4.4-m8: 0.3 -> 0 (cam tasarimda kenar yeterli)

static UIView *kaButton;
static UILabel *kaButtonLabel;   // X etiketi - undo sirasinda gizlenir (0.4.4: artik nil, kaXIkon)
static UIVisualEffectView *kaCam; // 0.4.4 cam zemin (butonun en altinda, yuvarlak kirpik)
static UIImageView *kaXIkon;      // 0.4.4 SF Symbol xmark, boyuta gore ka_boyutUygula'da
static NSLayoutConstraint *kaBtnY; // dikey eksen kisiti - yone gore kurulur (0.4.4)
static int kaBtnYon = -1;          // kurulu kisitin yonu: 0 dikey, 1 yatay, -1 yok
static const CGFloat kKA_YatayAltPay = 13.0; // yatay: kart alti y=329, ekran 393 - seridin ortasi
static NSLayoutConstraint *kaBtnX; // yatay eksen kisiti - varsayilan ya da ozel konum (0.4.4)
static BOOL kaKonumKirli;          // YES: konum kisitlari bir sonraki layout'ta yeniden kurulur
static BOOL kaTasimaModu;          // "Butonu tasi" modu acik mi
static BOOL kaTasimaBekliyor;      // menude secildi; menu KAPANINCA (KASMenu kapaninca) baslar
static UIPanGestureRecognizer *kaPan; // yalniz tasima modunda enabled
// m8 ISTEK: tasima modunda kasa hapi da tutulup tasinabilsin (ayni ka_pan:
// - kaydirma switcher gorunumune gore olculur, hangi gorunumden geldigi
// fark etmez; hap X'e kisitli oldugu icin birlikte gider).
static UIPanGestureRecognizer *kaPanGizli;
// Buton boyutu (0.4.4): 3 kademe. Degisiklik bir sonraki layout'ta
// uygulanir (menu aciksa menu kapaninca - bekleyenGuncelleme).
static NSString * const kKA_KeyButonBoyutu = @"butonBoyutu";
static NSString *kaPrefBoyut = @"orta";   // kucuk | orta | buyuk
static BOOL kaBoyutKirli;
static NSLayoutConstraint *kaBtnW;
static NSLayoutConstraint *kaBtnH;
static CGFloat ka_boyutPt(void) {
    if ([kaPrefBoyut isEqualToString:@"kucuk"]) return 32.0;
    if ([kaPrefBoyut isEqualToString:@"buyuk"]) return 46.0;
    return 38.0;
}
static BOOL kaInteractionAdded;   // 0.5.0: uzun basma (KASMenu) kuruldu mu
static UILongPressGestureRecognizer *kaUzunBas;      // 0.5.0: kendi menuyu acar
static UIView *kaHint;
static NSTimer *kaHintTimer;
static BOOL menuAcik = NO;
static BOOL bekleyenGuncelleme = NO;

static UIView *kaUndo;
static NSTimer *kaUndoTimer;
static NSArray<NSString *> *kaUndoBids;
// ISTEK (0.3.5): ayri "iptal" butonu KALDIRILDI - artik X BUTONUNUN
// KENDISI kapatma sirasinda iptal butonuna DONUSUYOR (ayni view,
// ayni pozisyon): X etiketi gizlenir, uzerine geri sayim halkasi
// (CAShapeLayer, kaButton.layer'a eklenir) cizilir. Tek dokunus
// (haptik YOK) iptal eder - bkz ka_tap: icindeki kaUndoAktif kontrolu.
static BOOL kaUndoAktif = NO;
static CAShapeLayer *kaUndoHalkaLayer;
static CADisplayLink *kaUndoHalkaLink;
static CFTimeInterval kaUndoBaslangicZamani;
static const NSTimeInterval kKA_UndoSuresi = 2.5;   // 0.5.1: 4.0 -> 2.5 (kullanici)

static BOOL kaPrefSonuncuHaric = NO;
static BOOL kaPrefMedyaKoru    = YES;
static NSArray<NSString *> *kaPrefKoru = nil;
// 0.6.0 GIZLI BOLUM. Olcum (olc06): switcher kartlari
// -[SBRecentAppLayouts recentsIncludingHiddenAppLayouts:NO]'dan geliyor ve
// iOS kendi gizli kartlarini TAM orada ayikliyor (NO=36, YES=39). Secilen
// uygulamalar ayni noktada suzulur: normal modda listeden cikar (bosluk
// birakmaz, ev cubugu kaydirmasinda ve "hepsini kapat"ta atlanir), gizli
// modda YALNIZ onlar kalir - switcher'in kendi kartlari, gercek goruntuler.
// Mod switcher kapaninca normale doner. Face ID sonraki is: ka_gizliModAc.
static NSSet<NSString *> *kaPrefGizli = nil;
static BOOL kaGizliMod = NO;
static UIView *kaGizliBtn;         // X'in yaninda; yalniz gizli liste doluysa
static UIImageView *kaGizliIkon;
// Suzgecin son sonucu (ayri ozel API yok - switcher'in gordugu listenin ta kendisi)
static void ka_gizliModKapat(void);      // tanim %ctor oncesinde
// 0.6.0 v2 (kasa): gizli kartlarin bid'leri (suzgecin son sonucu, sira =
// switcher sirasi) ve son goruntuleri. Goruntu, gizli uygulamanin karti
// ekranda gorundugu anda (onplan muafiyeti) kartin kendisinden alinir.
static NSArray<NSString *> *kaGizliBidler = nil;
// m4: UIImage degil snapshotViewAfterScreenUpdates:NO kopyasi (m3'te
// drawViewHierarchyInRect bos/saydam goruntu verdi - Brave karti).
static NSMutableDictionary<NSString *, UIView *> *kaGizliGorseller = nil;
// m4: X temasi (cam | kirmizi | acik | mor | halka) ve kasa kilidi
// (LAPolicyDeviceOwnerAuthentication: Face ID, sistem karar verince parola).
static NSString * const kKA_KeyTema = @"butonTema";
static NSString * const kKA_KeyKasaKilit = @"kasaKilit";
static NSString *kaPrefTema = @"acik";   // m7: Varsayilan = iOS acik
static BOOL kaPrefKasaKilit = YES;
static CAGradientLayer *kaHalka;          // "halka" temasinin renkli cercevesi
// m5: tema kasa hapina da uygulanir (ka_gizliTemaUygula)
static UIVisualEffectView *kaGizliCam;
static UIView *kaGizliTon;
// m12 ISTEK: buton boyutu kasa hapini da kapsasin. Hap 64x36 (orta = X 38),
// kaHapK = X boyutu / 38; tum hap olculeri buradan.
static CGFloat kaHapK = 1.0;
static NSLayoutConstraint *kaGizliW, *kaGizliH;
static CGFloat ka_hapW(void) { return round(64.0 * kaHapK); }
static CGFloat ka_hapH(void) { return round(36.0 * kaHapK); }
static UILabel *kaGizliYazi;
static CAGradientLayer *kaGizliHalka;
// m5: kasa kendi penceresinde (Face ID/parola arayuzu switcher'i kapatiyor
// - m4 olcumu: evaluatePolicy'den ~80 ms sonra isAnySwitcherVisible=0).
static UIWindow *kaKasaPencere;
// m17 TESHIS (kullanici istegi, kesik kopya sorununu daraltmak icin): YES iken
// karttaki basili tutma (sabitle) KURULMAZ, selale animasyonu ve kopyalari
// KAPALI (Tumunu Kapat dogrudan siler). Teshis bitince NO yap.
static const BOOL kKA_Teshis = NO;   // b16: sabitleme geri (m17 teshisi bitti; 0,8 sn basili tutma)
static long long kaOndeSilmeMs = 0;       // m23: ondeki uygulamanin karti en son ne zaman silindi
// m24 (m23 olcumu): switcher'dan acilan uygulama switcher'da da "onde" sayiliyor
// (appOnPlanda=1), ana ekrandan acilan sayilmiyor (=0). Suzgecin "ondeki gizli
// uygulamayi goster" istisnasi ilkinde karti tutuyordu. Kullanicinin ELLE asagi
// attigi uygulamalar bu istisnadan cikar; switcher kapaninca kume bosalir.
// m25 (m24 olcumu): suzgec ondeki uygulamayi listeden CIKARIYOR (12 -> 11) ama
// kart ekranda kaliyor - switcher ondeki uygulamanin kartini listeden degil
// baska kaynaktan gosteriyor. Kart silinemez (silmek = uygulamayi kapatmak).
// Cozum: asagi atilan kart ekran disinda BIRAKILIR; kap uygulamaya donusmeden
// (her gecisin basinda + switcher kapanirken) ic ofset sifirlanir.
static NSHashTable<UIView *> *kaOfsetliKartlar;
static void ka_ofsetleriSifirla(NSString *neden);   // asagida tanimli
// m14 otomatik kapatma: N saattir kullanilmayan uygulamalari kapat (0 = kapali).
// Son kullanim zamanlarini kendimiz tutariz (bid -> epoch sn), tercihlere yazilir.
static NSString * const kKA_KeyOtoKapat = @"otoKapat";
static NSString * const kKA_KeySonKullanim = @"sonKullanim";
static NSInteger kaPrefOtoSaat = 0;
static NSMutableDictionary<NSString *, NSNumber *> *kaSonKullanim;
// m14 kasa kilidi: "switcher" = switcher kapanana kadar acik (0.6.0), "her" = her acilista sor
static NSString * const kKA_KeyKilitSure = @"kilitSure";
static BOOL kaPrefKilitHer = NO;
static BOOL kaPrefKilitDakika = NO;      // b17: son dogrulamadan 60 sn sonra yeniden sor
static long long kaSonDogrulamaMs = 0;   // b17
static BOOL kaKasaUygulamaya = NO;        // kasadan uygulama aciliyor: X'i geri getirme
static NSMutableDictionary<NSString *, NSNumber *> *kaGizliGorselZaman = nil;
static void ka_gizliBtnGuncelle(void);   // 0.7: tercih yuklemede cagriliyor
// Selale animasyon turu: "yukari" (varsayilan), "solma", "kucul", "yana", "yok".
static NSString *kaPrefAnimasyonTuru = @"yukari";
// Animasyon suresi CARPANI: 0.25 (hizli) - 2.0 (yavas), varsayilan 1.0.
// Kart suresi = 0.28 * bu carpan; adimlar arasi gecikme de aynı carpanla olcekler.
static CGFloat kaPrefAnimasyonHizi = 1.0;
// Tum tweak'i devre disi birak: buton gizlenir, hic hook etkisi kalmaz
// (mevcut davranislarin HICBIRINE dokunulmaz, sadece gosterim/tetikleme
// engellenir - bu yuzden diger hook'lar aynen kalir, sadece giris
// noktalarinda erken-cikis eklenir).
static BOOL kaPrefEtkin = YES;

static NSArray<NSString *> *ka_navBids(void) {
    return @[
        @"com.apple.Maps",
        @"com.google.Maps",
        @"com.waze.iphone",
        @"ru.yandex.mobile.navigator",
    ];
}

// DIL (0.4.3): 12 dil. Tablo KASDil.m'de, tools/dil-uret.py uretir.
// Anahtar = Turkce kaynak metin; ceviri yoksa Ingilizce, o da yoksa anahtar.
NSString *ka_L(NSString *tr);

static BOOL ka_gunlukAcik(void) {
    @try {
        CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("gunluk"), (__bridge CFStringRef)kKA_AlanAdi);
        if (!v) return NO;
        BOOL out = NO;
        if (CFGetTypeID(v) == CFBooleanGetTypeID()) out = CFBooleanGetValue((CFBooleanRef)v);
        else if (CFGetTypeID(v) == CFNumberGetTypeID()) { int i = 0; CFNumberGetValue((CFNumberRef)v, kCFNumberIntType, &i); out = (i != 0); }
        CFRelease(v);
        return out;
    } @catch (__unused NSException *e) { return NO; }
}

static void ka_log(NSString *event, UIView *b) {
    if (!ka_gunlukAcik()) return;
    static NSFileHandle *fh = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *path = @"/var/mobile/tw/kas-log.txt";
        [[NSFileManager defaultManager] createFileAtPath:path contents:nil attributes:nil];
        fh = [NSFileHandle fileHandleForWritingAtPath:path];
        [fh seekToEndOfFile];
    });
    if (!fh) return;
    NSTimeInterval t = [[NSDate date] timeIntervalSince1970];
    long long ms = (long long)(t * 1000.0);
    CGRect f = b ? b.frame : CGRectZero;
    NSString *line = [NSString stringWithFormat:@"%lld %@ ptr=%p win=%d hidden=%d alpha=%.2f frame={%.1f,%.1f,%.1f,%.1f} menuAcik=%d\n",
                      ms, event, (void *)b, (b && b.window) ? 1 : 0,
                      b ? b.hidden : -1, b ? b.alpha : -1.0,
                      f.origin.x, f.origin.y, f.size.width, f.size.height,
                      menuAcik ? 1 : 0];
    @try { [fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; } @catch (__unused NSException *e) {}
}

static void ka_logText(NSString *msg) { ka_log(msg, nil); }
static long long ka_msNow(void) { return (long long)([[NSDate date] timeIntervalSince1970] * 1000.0); }

// OLCUM (0.4.2-m1): app on planda mi? SBApplicationController.
// runningApplications -> SBApplication.processState -> isForeground.
// Davranisi DEGISTIRMEZ, sadece okur ve loglar.
static BOOL ka_appOnPlanda(NSString **outBid) {
    SBApplicationController *ac = [%c(SBApplicationController) sharedInstance];
    if (!ac) return NO;
    NSArray *apps = [ac runningApplications];
    for (SBApplication *a in apps) {
        id ps = [a processState];
        if (ps && [ps respondsToSelector:@selector(isForeground)] &&
            [(SBApplicationProcessState *)ps isForeground]) {
            if (outBid) *outBid = [a bundleIdentifier];
            return YES;
        }
    }
    return NO;
}

// GORUNURLUK ANIMASYONU (0.4.2): asagidan yukari solukla gel,
// aynı yoldan solukla in. Sistemin gecis transform'una DOKUNMAZ -
// yalniz kendi katmanina translate uygular.
#define KA_ANIM_DY 40.0
#define KA_ANIM_SURE 0.22
// NIYET TAKIBI (0.4.2-m5): layout firtinasinda (ev ekranina donus,
// art arda viewDidLayoutSubviews cagrilari 10-20ms araliklarla) her
// cagri removeAllAnimations ile ONCEKI animasyonu KESIYORDU - olcum
// (OLCUM-anim) 17ms'de "tamamlandi" gosterdi, hedef 220ms'ydi. Ayni
// yone (goster/gizle) dogru zaten animasyon SURUYORSA yeni cagri
// SESSIZCE atlanir, sadece YON DEGISIRSE kesilip yeniden baslar.
static BOOL kaAnimHedefGorunur = NO;   // su an animasyonla gidilen yon
static BOOL kaAnimSuruyor = NO;
static void ka_zeminAyarla(BOOL undo);   // m6: neon nabzi gosteriste yeniden kurulur
static void ka_butonGoster(UIView *b) {
    if (!b) return;
    // m4: kasa acikken X ve kasa butonu gizli kalir (kasa kapaninca geri gelir).
    if ([KASKasa acik]) return;
    if (kaAnimSuruyor && kaAnimHedefGorunur) return;
    if (!kaAnimSuruyor && !b.hidden && b.alpha >= 0.99) return;
    // b8: switcher acik KALMAYACAKSA gosterme - gorunur kart yok VE kasa bos ise Apple bos switcher'i kapatiyor
    // (Tumunu Kapat sonrasi butonlar gorunup 1,7 sn sonra yoklamayla iniyordu, RootHide 4 Eki olcumu).
    if (kas_gorunurKartSayisi() == 0 && !kas_kasaBidleri(kaPrefGizli).count) { ka_log(@"goster-atlandi bos-switcher", b); return; }
    [b.layer removeAllAnimations];
    [kaGizliBtn.layer removeAllAnimations];   // b8: iki buton birlikte - kasa hapinin zipla animasyonu kalmasin
    if ([kaPrefTema isEqualToString:@"neon"]) ka_zeminAyarla(kaUndoAktif);   // m6: silinen nabzi geri kur
    kaAnimSuruyor = YES;
    kaAnimHedefGorunur = YES;
    b.hidden = NO;
    b.alpha = 0.0;
    b.transform = CGAffineTransformMakeTranslation(0, KA_ANIM_DY);
    // 0.6.0: gizli bolum butonu X ile birlikte (yalniz liste doluysa)
    if (kaGizliBtn) { kaGizliBtn.hidden = (kaPrefGizli.count == 0); kaGizliBtn.alpha = 0.0; kaGizliBtn.transform = b.transform; }
    [UIView animateWithDuration:KA_ANIM_SURE
                     animations:^{
        b.alpha = 1.0;
        b.transform = CGAffineTransformIdentity;
        if (kaGizliBtn) { kaGizliBtn.alpha = 1.0; kaGizliBtn.transform = CGAffineTransformIdentity; }
    } completion:^(BOOL finished) {
        kaAnimSuruyor = NO;
        ka_log([NSString stringWithFormat:@"OLCUM-m6 goster-bitti finished=%d", finished], b);
    }];
}
// "Butonu tasi" modunu kapatir (0.4.4). Idempotent: mod kapaliysa hemen
// doner. Titremeyi durdurur, pan'i kapatir, menu acan uzun basmayi acar.
// ka_butonGizle'den de cagrilir: switcher kapanirsa mod kendiliginden biter.
static void ka_tasimaBitir(void) {
    if (!kaTasimaModu) return;
    kaTasimaModu = NO;
    if (kaPan) kaPan.enabled = NO;
    if (kaPanGizli) kaPanGizli.enabled = NO;   // m8: kasa hapi da tutulabiliyordu
    [kaButton.layer removeAnimationForKey:@"ka-titre"];
    [kaGizliBtn.layer removeAnimationForKey:@"ka-titre"];
    kaUzunBas.enabled = YES;   // 0.5.0: tasirken kapatilmisti
    ka_log(@"tasima-bitti", kaButton);
}
static void ka_butonGizle(UIView *b) {
    if (!b) return;
    // 0.5.0: switcher kapaniyor - acik menu kalmasin (kapaninca blogu calisir).
    if ([KASMenu acik]) { [KASMenu kapat:NO]; ka_log(@"menu-kapat-gizlenirken", b); }
    ka_tasimaBitir();
    // b1 (0.7, 2. asama): kasa switcher'dan BAGIMSIZ - kendi kapanir (kendi kapatma, uygulama acma, kilit).
    // Switcher kapanirken kasaya dokunulmaz (0.6.0'da burada kapaniyordu: Face ID sorunu, m25 A/B).
    // b5: "switcher kapanana kadar" kilit suresi - switcher kapaninca oturum biter; kasa acikken ya da dogrulama
    // surerken BITMEZ (Face ID'de CoreAuthUI switcher'i kapatiyor, 3 Eki olcumu).
    if (!kaPrefKilitHer && !kaPrefKilitDakika && ![KASKasa acik] && ![KASKasa dogrulaniyor]) [KASKasa oturumuKapat];
    ka_ofsetleriSifirla(@"butonGizle");   // m25: ekran disinda birakilan kartlar yerine
    if (kaAnimSuruyor && !kaAnimHedefGorunur) return;
    if (!kaAnimSuruyor && b.hidden) return;
    [b.layer removeAllAnimations];
    [kaGizliBtn.layer removeAllAnimations];   // b8: iki buton ayni anda, ayni egriyle iner
    kaAnimSuruyor = YES;
    kaAnimHedefGorunur = NO;
    [UIView animateWithDuration:KA_ANIM_SURE
                     animations:^{
        b.alpha = 0.0;
        b.transform = CGAffineTransformMakeTranslation(0, KA_ANIM_DY);
        if (kaGizliBtn) { kaGizliBtn.alpha = 0.0; kaGizliBtn.transform = b.transform; }
    } completion:^(BOOL finished) {
        b.hidden = YES;
        b.transform = CGAffineTransformIdentity;
        if (kaGizliBtn) { kaGizliBtn.hidden = YES; kaGizliBtn.transform = CGAffineTransformIdentity; }
        kaAnimSuruyor = NO;
        ka_log([NSString stringWithFormat:@"OLCUM-m6 gizle-bitti finished=%d win=%d", finished, (b.window!=nil)], b);
    }];
}

static BOOL ka_prefBool(NSString *k, BOOL def) {
    @try {
        CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)k, (__bridge CFStringRef)kKA_AlanAdi);
        if (!v) return def;
        BOOL out = def;
        if (CFGetTypeID(v) == CFBooleanGetTypeID()) out = CFBooleanGetValue((CFBooleanRef)v) ? YES : NO;
        else if (CFGetTypeID(v) == CFNumberGetTypeID()) {
            int i = 0; CFNumberGetValue((CFNumberRef)v, kCFNumberIntType, &i); out = i ? YES : NO;
        }
        CFRelease(v);
        return out;
    } @catch (__unused NSException *e) { return def; }
}

static NSArray *ka_prefArray(NSString *k) {
    @try {
        CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)k, (__bridge CFStringRef)kKA_AlanAdi);
        if (!v) return @[];
        NSArray *copy = @[];
        if (CFGetTypeID(v) == CFArrayGetTypeID()) copy = [(__bridge NSArray *)v copy];
        CFRelease(v);
        return copy ?: @[];
    } @catch (__unused NSException *e) { return @[]; }
}

static NSString *ka_prefString(NSString *k, NSString *def) {
    @try {
        CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)k, (__bridge CFStringRef)kKA_AlanAdi);
        if (!v) return def;
        NSString *out = def;
        if (CFGetTypeID(v) == CFStringGetTypeID()) out = [(__bridge NSString *)v copy];
        CFRelease(v);
        return out ?: def;
    } @catch (__unused NSException *e) { return def; }
}

static CGFloat ka_prefFloat(NSString *k, CGFloat def) {
    @try {
        CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)k, (__bridge CFStringRef)kKA_AlanAdi);
        if (!v) return def;
        CGFloat out = def;
        if (CFGetTypeID(v) == CFNumberGetTypeID()) {
            double d = 0; CFNumberGetValue((CFNumberRef)v, kCFNumberDoubleType, &d); out = (CGFloat)d;
        }
        CFRelease(v);
        return out;
    } @catch (__unused NSException *e) { return def; }
}

static void ka_prefSetBool(NSString *k, BOOL val) {
    @try {
        CFPreferencesSetAppValue((__bridge CFStringRef)k,
                                 val ? kCFBooleanTrue : kCFBooleanFalse,
                                 (__bridge CFStringRef)kKA_AlanAdi);
        CFPreferencesAppSynchronize((__bridge CFStringRef)kKA_AlanAdi);
        notify_post([kKA_Bildirim UTF8String]);
    } @catch (__unused NSException *e) { ka_logText(@"prefSet-exception"); }
}

static void ka_prefSetString(NSString *k, NSString *val) {
    @try {
        CFPreferencesSetAppValue((__bridge CFStringRef)k,
                                 (__bridge CFStringRef)val,
                                 (__bridge CFStringRef)kKA_AlanAdi);
        CFPreferencesAppSynchronize((__bridge CFStringRef)kKA_AlanAdi);
        notify_post([kKA_Bildirim UTF8String]);
    } @catch (__unused NSException *e) { ka_logText(@"prefSetString-exception"); }
}

// Konum anahtarlari (0.4.4). Bildirim YOK: konum yalniz ka_konumKur'da
// okunur, prefs yeniden yuklemesi gereksiz. val < 0 -> anahtari SIL.
static void ka_prefSetKonum(NSString *k, CGFloat val) {
    @try {
        CFPreferencesSetAppValue((__bridge CFStringRef)k,
                                 val < 0 ? NULL : (__bridge CFNumberRef)@(val),
                                 (__bridge CFStringRef)kKA_AlanAdi);
        CFPreferencesAppSynchronize((__bridge CFStringRef)kKA_AlanAdi);
    } @catch (__unused NSException *e) { ka_logText(@"prefSetKonum-exception"); }
}
static NSString *ka_konumAnahtar(int yon, BOOL x) {
    if (yon) return x ? @"konumYatayX" : @"konumYatayY";
    return x ? @"konumDikeyX" : @"konumDikeyY";
}

// Butonun MERKEZINI v icinde tutar. Yatayda v.safeAreaInsets dikey
// degerleri veriyor (OLCUM-g1, 0.4.4): yan paylari ust paydan (Dynamic
// Island) turetiyoruz - DOGRULANMADI, yalniz tahmin.
static CGPoint ka_konumSinirla(UIView *v, int yon, CGPoint c) {
    CGSize s = v.bounds.size;
    UIEdgeInsets si = v.safeAreaInsets;
    UIEdgeInsets p = yon ? UIEdgeInsetsMake(8, MAX(8, si.top), 8, MAX(8, si.top))
                         : UIEdgeInsetsMake(MAX(8, si.top), 8, MAX(8, si.bottom), 8);
    CGFloat r = ka_boyutPt() / 2.0;   // bounds degil: boyut degisince henuz layout olmamis olabilir
    c.x = MAX(p.left + r, MIN(s.width - p.right - r, c.x));
    c.y = MAX(p.top + r, MIN(s.height - p.bottom - r, c.y));
    return c;
}
// Mutlak merkez kisitlari. leftAnchor: leading Arapca'da (RTL) ters doner.
static void ka_konumUygula(UIView *v, CGPoint c) {
    if (kaBtnX) kaBtnX.active = NO;
    if (kaBtnY) kaBtnY.active = NO;
    kaBtnX = [kaButton.centerXAnchor constraintEqualToAnchor:v.leftAnchor constant:c.x];
    kaBtnY = [kaButton.centerYAnchor constraintEqualToAnchor:v.topAnchor constant:c.y];
    kaBtnX.active = YES;
    kaBtnY.active = YES;
}
// Yon icin kayitli konum varsa onu, yoksa varsayilani (0.4.4-m2) kurar.
// b14: varsayilan konumda cifti ortalamak icin X'in sola kaydirmasi (kasa butonu gorunurken: ka_butonGoster'in kosulu).
static BOOL kaKonumVarsayilan = NO;
static CGFloat ka_hapW(void);
static CGFloat ka_ciftKaydirma(void) { return (kaGizliBtn && kaPrefGizli.count) ? -(ka_hapW() + 12) / 2.0 : 0; }
static void ka_konumKur(UIView *v, int yon) {
    CGFloat fx = ka_prefFloat(ka_konumAnahtar(yon, YES), -1);
    CGFloat fy = ka_prefFloat(ka_konumAnahtar(yon, NO), -1);
    CGSize s = v.bounds.size;
    if (fx >= 0 && fx <= 1 && fy >= 0 && fy <= 1 && s.width > 0 && s.height > 0) {
        ka_konumUygula(v, ka_konumSinirla(v, yon, CGPointMake(fx * s.width, fy * s.height)));
        ka_log([NSString stringWithFormat:@"konum-ozel yon=%d fx=%.3f fy=%.3f", yon, fx, fy], kaButton);
    } else {
        if (kaBtnX) kaBtnX.active = NO;
        if (kaBtnY) kaBtnY.active = NO;
        // b14: varsayilan konumda X + kasa butonu CIFT olarak ortalanir (once yalniz X ortadaydi, kasa butonu
        // sagina eklenince cift saga kayiyordu; "Konumu sifirla" da ayni). Kasa butonu yoksa X tam ortada.
        kaBtnX = [kaButton.centerXAnchor constraintEqualToAnchor:v.centerXAnchor constant:ka_ciftKaydirma()];
        kaBtnY = yon
            ? [kaButton.bottomAnchor constraintEqualToAnchor:v.bottomAnchor constant:-kKA_YatayAltPay]
            : [kaButton.bottomAnchor constraintEqualToAnchor:v.safeAreaLayoutGuide.bottomAnchor constant:-64];
        kaBtnX.active = YES;
        kaBtnY.active = YES;
        ka_log([NSString stringWithFormat:@"konum-varsayilan yon=%d kaydirma=%.1f", yon, kaBtnX.constant], kaButton);
    }
    kaKonumVarsayilan = !(fx >= 0 && fx <= 1 && fy >= 0 && fy <= 1 && s.width > 0 && s.height > 0);
    kaBtnYon = yon;
    kaKonumKirli = NO;
}

// Boyutu uygular (0.4.4): genislik/yukseklik, kose, X fontu. 38 pt'de
// eski degerler (kose 19, font 20) aynen cikar. Konum da yeniden kurulur
// (sinirlama yaricapa bagli).
// Cam zeminin tonu (0.4.4). Normal: cok hafif beyaz; geri alma surerken
// koyu (halka okunsun). Animasyon blogu icinden de cagrilabilir.
// m8 ISTEK: Aurora'nin akan renk karisimi butonlarda da (KASKasa paneliyle
// ayni renkler ve akis). Zeminin en altina; yalniz "mor" temada gorunur.
static CAGradientLayer *kaAuroraX, *kaAuroraHap;
static CAGradientLayer *ka_auroraKatman(void) {
    CAGradientLayer *g = [CAGradientLayer layer];
    g.startPoint = CGPointMake(0, 0); g.endPoint = CGPointMake(1, 1);
    UIColor *a = [UIColor colorWithRed:0.20 green:0.08 blue:0.38 alpha:1], *b = [UIColor colorWithRed:0.06 green:0.10 blue:0.32 alpha:1],
            *c = [UIColor colorWithRed:0.03 green:0.28 blue:0.33 alpha:1];
    g.colors = @[(id)a.CGColor, (id)b.CGColor, (id)c.CGColor];
    CABasicAnimation *ak = [CABasicAnimation animationWithKeyPath:@"colors"];
    ak.toValue = @[(id)c.CGColor, (id)a.CGColor, (id)b.CGColor];
    ak.duration = 4.0; ak.autoreverses = YES; ak.repeatCount = HUGE_VALF;
    ak.removedOnCompletion = NO;   // SpringBoard gorunum ciktiginda silinmesin
    [g addAnimation:ak forKey:@"ak"];
    return g;
}
// m9 Nostalji: iOS 6 parlak dugmesi - alta koyulasan gradyan, ust yarida
// beyaz parilti, ince koyu kenar. Boyut degisince yeniden kurulur.
static CAGradientLayer *kaNostX, *kaNostHap;
static CAGradientLayer *ka_parlakKatman(UIColor *ust, UIColor *alt, CGRect r, CGFloat yaricap) {
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = r; g.cornerRadius = yaricap; g.masksToBounds = YES;
    g.colors = @[(id)ust.CGColor, (id)alt.CGColor];
    g.borderWidth = 1; g.borderColor = [UIColor colorWithWhite:0 alpha:0.45].CGColor;
    CAGradientLayer *p = [CAGradientLayer layer];
    p.frame = CGRectMake(0, 0, r.size.width, r.size.height * 0.5);
    p.colors = @[(id)[UIColor colorWithWhite:1 alpha:0.55].CGColor, (id)[UIColor colorWithWhite:1 alpha:0.10].CGColor];
    [g addSublayer:p];
    return g;
}
// m11 Modern (iOS 26 Liquid Glass): neredeyse saydam cam + kenarda kosegen
// boyunca parlayip sonen isik cizgisi (isigin camin kenarinda kirilmasi).
static CAGradientLayer *kaModernX, *kaModernHap;
static CAGradientLayer *ka_camKenar(CGRect r, CGFloat yaricap) {
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = r;
    g.startPoint = CGPointMake(0, 0); g.endPoint = CGPointMake(1, 1);
    g.colors = @[(id)[UIColor colorWithWhite:1 alpha:0.9].CGColor, (id)[UIColor colorWithWhite:1 alpha:0.06].CGColor,
                 (id)[UIColor colorWithWhite:1 alpha:0.5].CGColor];
    g.locations = @[@0, @0.55, @1];
    CAShapeLayer *m = [CAShapeLayer layer];
    m.frame = g.bounds; m.fillColor = nil; m.strokeColor = [UIColor blackColor].CGColor; m.lineWidth = 1.2;
    m.path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(g.bounds, 0.6, 0.6) cornerRadius:yaricap].CGPath;
    g.mask = m;
    return g;
}
// 0.7.0 yeni temalar (X ve kasa hapi): Holografik = donen gokkusagi halka + konik folyo; Terminal = siyah zemin,
// yesil fosfor kenar ve simge; Retro Oyun = X Game Boy A dugmesi (kirmizi), hap START dugmesi (gri).
// Katmanlar her uygulamada silinip yeniden kurulur; diger temalarin ayarlarini mevcut kod her cagride geri yazar.
static CALayer *kaYeniX, *kaYeniHap;
static UIColor *ka_fosfor(CGFloat a) { return [UIColor colorWithRed:0.25 green:1.0 blue:0.40 alpha:a]; }
static NSArray *ka_gokkusagi(void) {
    NSMutableArray *r = [NSMutableArray array];
    for (int i = 0; i <= 6; i++) [r addObject:(id)[UIColor colorWithHue:i / 6.0 saturation:0.55 brightness:1 alpha:1].CGColor];
    return r;
}
static NSArray *ka_neonRenk(void) {
    return @[(id)[UIColor systemPinkColor].CGColor, (id)[UIColor systemIndigoColor].CGColor,
             (id)[UIColor systemTealColor].CGColor, (id)[UIColor systemPinkColor].CGColor];
}
static CAShapeLayer *ka_kenarKatman(CGRect r, CGFloat yaricap, UIColor *renk, CGFloat kalinlik, BOOL parlama) {
    CAShapeLayer *s = [CAShapeLayer layer];
    s.frame = r; s.fillColor = nil; s.strokeColor = renk.CGColor; s.lineWidth = kalinlik;
    s.path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(CGRectMake(0, 0, r.size.width, r.size.height), kalinlik / 2, kalinlik / 2)
                                        cornerRadius:yaricap].CGPath;
    if (parlama) { s.shadowColor = renk.CGColor; s.shadowOpacity = 0.9; s.shadowRadius = 4; s.shadowOffset = CGSizeZero; }
    return s;
}
static CAGradientLayer *ka_ustParilti(CGRect r, CGFloat yaricap) {   // A/START dugmesi: ust yarida hafif isik
    CAGradientLayer *g = [CAGradientLayer layer];
    g.frame = r; g.cornerRadius = yaricap; g.masksToBounds = YES;
    g.colors = @[(id)[UIColor colorWithWhite:1 alpha:0.30].CGColor, (id)[UIColor colorWithWhite:1 alpha:0].CGColor];
    g.locations = @[@0, @0.55];
    return g;
}
static void ka_yeniTemaX(NSString *t, CGFloat bs) {
    [kaYeniX removeFromSuperlayer]; kaYeniX = nil;
    BOOL holo = [t isEqualToString:@"holo"], term = [t isEqualToString:@"terminal"], oyun = [t isEqualToString:@"oyun"];
    if (kaHalka) kaHalka.colors = holo ? ka_gokkusagi() : ka_neonRenk();
    if (!holo) [kaHalka removeAnimationForKey:@"ka-holo-don"];
    if (!(holo || term || oyun) || !kaCam) return;
    CALayer *bl = kaButton.layer;
    CGRect r = CGRectMake(0, 0, bs, bs);
    kaYeniX = [CALayer layer];
    kaYeniX.frame = r;
    if (holo) {
        kaCam.contentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.55];
        CAGradientLayer *f = [CAGradientLayer layer];
        f.type = kCAGradientLayerConic; f.startPoint = CGPointMake(0.5, 0.5); f.endPoint = CGPointMake(0.5, 0);
        f.frame = r; f.cornerRadius = bs / 2; f.masksToBounds = YES; f.colors = ka_gokkusagi(); f.opacity = 0.35;
        CABasicAnimation *d = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        d.toValue = @(-2 * M_PI); d.duration = 6; d.repeatCount = HUGE_VALF; d.removedOnCompletion = NO;
        [f addAnimation:d forKey:@"don"];
        [kaYeniX addSublayer:f];
        kaHalka.hidden = NO;
        ((CAShapeLayer *)kaHalka.mask).lineWidth = 2.2;
        if (![kaHalka animationForKey:@"ka-holo-don"]) {
            CABasicAnimation *h = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
            h.toValue = @(2 * M_PI); h.duration = 4; h.repeatCount = HUGE_VALF; h.removedOnCompletion = NO;
            [kaHalka addAnimation:h forKey:@"ka-holo-don"];
        }
        kaXIkon.tintColor = [UIColor whiteColor];
        bl.shadowColor = [UIColor colorWithRed:0.65 green:0.55 blue:1 alpha:1].CGColor;
        bl.shadowOpacity = 0.55; bl.shadowRadius = 10;
    } else if (term) {
        kaCam.contentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.9];
        [kaYeniX addSublayer:ka_kenarKatman(r, bs / 2, ka_fosfor(0.9), 1.2, YES)];
        kaXIkon.tintColor = ka_fosfor(1);
        kaXIkon.layer.shadowColor = ka_fosfor(1).CGColor; kaXIkon.layer.shadowOffset = CGSizeZero;
        kaXIkon.layer.shadowRadius = 4; kaXIkon.layer.shadowOpacity = 0.9;
        bl.shadowColor = ka_fosfor(1).CGColor; bl.shadowOpacity = 0.5; bl.shadowRadius = 8;
    } else {
        kaCam.effect = nil;
        kaCam.contentView.backgroundColor = [UIColor colorWithRed:0.60 green:0.13 blue:0.34 alpha:1];
        [kaYeniX addSublayer:ka_ustParilti(r, bs / 2)];
        [kaYeniX addSublayer:ka_kenarKatman(r, bs / 2, [UIColor colorWithRed:0.25 green:0.03 blue:0.12 alpha:1], 1.5, NO)];
        kaXIkon.tintColor = [UIColor colorWithWhite:0.96 alpha:1];
        bl.shadowColor = [UIColor blackColor].CGColor; bl.shadowOpacity = 0.4; bl.shadowRadius = 3;
    }
    [kaCam.contentView.layer insertSublayer:kaYeniX atIndex:0];
}
// m4 temalar. Geri sayim (undo) her temada koyu cam: beyaz sayi okunsun.
static void ka_zeminAyarla(BOOL undo) {
    NSString *t = undo ? @"cam" : kaPrefTema;
    BOOL acik = [t isEqualToString:@"acik"];
    kaCam.effect = [UIBlurEffect effectWithStyle:acik ? UIBlurEffectStyleSystemThinMaterialLight
                                                      : UIBlurEffectStyleSystemUltraThinMaterialDark];
    UIColor *z = [UIColor colorWithWhite:0.06 alpha:0.92];   // m9 Koyu: kasa paneliyle ayni koyu
    if (undo) z = [UIColor colorWithWhite:0.0 alpha:0.45];
    else if ([t isEqualToString:@"kirmizi"]) z = [[UIColor systemRedColor] colorWithAlphaComponent:0.9];
    else if (acik) z = [UIColor colorWithWhite:1.0 alpha:0.5];
    else if ([t isEqualToString:@"mor"]) z = [[UIColor systemIndigoColor] colorWithAlphaComponent:0.38];
    else if ([t isEqualToString:@"halka"]) z = [UIColor colorWithWhite:0.0 alpha:0.3];
    // m6 buyuk temalar: neon = siyah + donen isik halkasi + nabiz parlamasi;
    // cuzdan = X'in kendi zemini yok, ortak dok cizer (ka_dokGuncelle).
    BOOL neon = [t isEqualToString:@"neon"], cuzdan = [t isEqualToString:@"cuzdan"];
    if (neon) z = [UIColor colorWithWhite:0.0 alpha:0.85];
    if (cuzdan) { kaCam.effect = nil; z = [UIColor clearColor]; }
    kaCam.contentView.backgroundColor = z;
    kaXIkon.tintColor = acik ? [UIColor colorWithWhite:0.1 alpha:1.0] : [UIColor whiteColor];
    // mor = kasa butonuyla ayni dil (ince beyaz cerceve)
    BOOL mor = [t isEqualToString:@"mor"];
    kaCam.layer.borderWidth = mor ? 0.75 : 0.0;
    kaCam.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.35].CGColor;
    kaHalka.hidden = !([t isEqualToString:@"halka"] || neon);
    ((CAShapeLayer *)kaHalka.mask).lineWidth = neon ? 2.6 : 2.0;
    CALayer *bl = kaButton.layer;
    // ka_butonGoster X katmaninin animasyonlarini siler: nabiz ayri denetlenir.
    if (neon && ![kaHalka animationForKey:@"ka-neon-don"]) {
        CABasicAnimation *d = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        d.toValue = @(2 * M_PI); d.duration = 3.5; d.repeatCount = HUGE_VALF;
        [kaHalka addAnimation:d forKey:@"ka-neon-don"];
    }
    if (neon && ![bl animationForKey:@"ka-neon-nabiz"]) {
        CABasicAnimation *p = [CABasicAnimation animationWithKeyPath:@"shadowOpacity"];
        p.fromValue = @0.35; p.toValue = @0.9; p.duration = 1.4; p.autoreverses = YES; p.repeatCount = HUGE_VALF;
        [bl addAnimation:p forKey:@"ka-neon-nabiz"];
    } else if (!neon) {
        [kaHalka removeAnimationForKey:@"ka-neon-don"];
        [bl removeAnimationForKey:@"ka-neon-nabiz"];
    }
    BOOL au = [t isEqualToString:@"mor"];   // m8: Aurora renk karisimi
    if (au && !kaAuroraX && kaCam) {
        kaAuroraX = ka_auroraKatman();
        [kaCam.contentView.layer insertSublayer:kaAuroraX atIndex:0];
    }
    CGFloat bs = kaBtnW ? kaBtnW.constant : 38.0;
    kaAuroraX.frame = CGRectMake(0, 0, bs, bs);
    kaAuroraX.hidden = !au;
    BOOL nos = [t isEqualToString:@"nostalji"];   // m9: kirmizi parlak iOS 6 dugmesi
    [kaNostX removeFromSuperlayer]; kaNostX = nil;
    if (nos && kaCam) {
        kaNostX = ka_parlakKatman([UIColor colorWithRed:0.93 green:0.38 blue:0.35 alpha:1],
                                  [UIColor colorWithRed:0.60 green:0.05 blue:0.04 alpha:1], CGRectMake(0, 0, bs, bs), bs / 2);
        [kaCam.contentView.layer insertSublayer:kaNostX atIndex:0];
    }
    kaXIkon.layer.shadowColor = [UIColor blackColor].CGColor;   // kabartma: 1 pt yukari koyu golge
    kaXIkon.layer.shadowOffset = CGSizeMake(0, -1); kaXIkon.layer.shadowRadius = 0;
    kaXIkon.layer.shadowOpacity = nos ? 0.55 : 0.0;
    BOOL mod = [t isEqualToString:@"modern"];   // m11: Liquid Glass
    [kaModernX removeFromSuperlayer]; kaModernX = nil;
    if (mod && kaCam) {
        kaCam.contentView.backgroundColor = [UIColor colorWithWhite:1 alpha:0.04];
        kaModernX = ka_camKenar(CGRectMake(0, 0, bs, bs), bs / 2);
        [kaButton.layer addSublayer:kaModernX];
    }
    bl.shadowColor = neon ? [UIColor systemPinkColor].CGColor : [UIColor blackColor].CGColor;
    bl.shadowRadius = neon ? 10.0 : kKA_ShadowRadius;
    bl.shadowOpacity = neon ? 0.6 : (cuzdan ? 0.0 : kKA_ShadowOpacity);
    ka_yeniTemaX(t, bs);   // 0.7.0
}
// "halka": konik gradyanli 2 pt cerceve. Boyut degisince yolu yenilenir.
static void ka_halkaKur(CGFloat s) {
    if (!kaButton) return;
    if (!kaHalka) {
        kaHalka = [CAGradientLayer layer];
        kaHalka.type = kCAGradientLayerConic;
        kaHalka.startPoint = CGPointMake(0.5, 0.5);
        kaHalka.endPoint = CGPointMake(0.5, 0.0);
        kaHalka.colors = @[(id)[UIColor systemPinkColor].CGColor, (id)[UIColor systemIndigoColor].CGColor,
                           (id)[UIColor systemTealColor].CGColor, (id)[UIColor systemPinkColor].CGColor];
        kaHalka.mask = [CAShapeLayer layer];
        [kaButton.layer addSublayer:kaHalka];
    }
    kaHalka.frame = CGRectMake(0, 0, s, s);
    CAShapeLayer *m = (CAShapeLayer *)kaHalka.mask;
    m.frame = kaHalka.bounds;
    m.fillColor = nil;
    m.strokeColor = [UIColor blackColor].CGColor;
    m.lineWidth = 2.0;
    m.path = [UIBezierPath bezierPathWithOvalInRect:CGRectInset(kaHalka.bounds, 1.0, 1.0)].CGPath;
}
static void ka_yeniTemaHap(NSString *t) {   // 0.7.0 - aciklama ka_yeniTemaX ustunde
    [kaYeniHap removeFromSuperlayer]; kaYeniHap = nil;
    BOOL holo = [t isEqualToString:@"holo"], term = [t isEqualToString:@"terminal"], oyun = [t isEqualToString:@"oyun"];
    [kaGizliHalka removeAnimationForKey:@"ka-holo-ak"];
    if (kaGizliHalka && ![t isEqualToString:@"neon"]) kaGizliHalka.colors = holo ? ka_gokkusagi() : ka_neonRenk();
    UIView *gb = kaGizliTon.superview;
    if (!(holo || term || oyun) || !gb) return;
    CGFloat w = ka_hapW(), h = ka_hapH();
    CGRect r = CGRectMake(0, 0, w, h);
    kaYeniHap = [CALayer layer];
    kaYeniHap.frame = r;
    gb.layer.borderWidth = 0;
    UIColor *on;
    if (holo) {
        kaGizliTon.backgroundColor = [UIColor colorWithWhite:0 alpha:0.55];
        CAGradientLayer *f = [CAGradientLayer layer];
        f.frame = r; f.cornerRadius = h / 2; f.masksToBounds = YES; f.colors = ka_gokkusagi(); f.opacity = 0.35;
        f.startPoint = CGPointMake(0, 0.5); f.endPoint = CGPointMake(1, 0.5);
        CABasicAnimation *k = [CABasicAnimation animationWithKeyPath:@"startPoint"];
        k.toValue = [NSValue valueWithCGPoint:CGPointMake(-1, 0.5)]; k.duration = 3; k.autoreverses = YES;
        k.repeatCount = HUGE_VALF; k.removedOnCompletion = NO;
        [f addAnimation:k forKey:@"kay"];
        [kaYeniHap addSublayer:f];
        kaGizliHalka.hidden = NO;
        NSArray *c = ka_gokkusagi();
        kaGizliHalka.colors = c;
        CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"colors"];
        a.toValue = [[c subarrayWithRange:NSMakeRange(3, c.count - 3)] arrayByAddingObjectsFromArray:[c subarrayWithRange:NSMakeRange(0, 3)]];
        a.duration = 2.5; a.autoreverses = YES; a.repeatCount = HUGE_VALF; a.removedOnCompletion = NO;
        [kaGizliHalka addAnimation:a forKey:@"ka-holo-ak"];
        on = [UIColor whiteColor];
    } else if (term) {
        kaGizliTon.backgroundColor = [UIColor colorWithWhite:0 alpha:0.9];
        [kaYeniHap addSublayer:ka_kenarKatman(r, h / 2, ka_fosfor(0.9), 1.2, YES)];
        on = ka_fosfor(1);
    } else {
        kaGizliCam.effect = nil;
        kaGizliTon.backgroundColor = [UIColor colorWithRed:0.55 green:0.55 blue:0.62 alpha:1];
        [kaYeniHap addSublayer:ka_ustParilti(r, h / 2)];
        [kaYeniHap addSublayer:ka_kenarKatman(r, h / 2, [UIColor colorWithRed:0.22 green:0.22 blue:0.28 alpha:1], 1.5, NO)];
        on = [UIColor colorWithRed:0.12 green:0.12 blue:0.16 alpha:1];
    }
    kaGizliIkon.tintColor = on;
    kaGizliYazi.textColor = on;
    if (term || oyun) kaGizliYazi.font = [UIFont fontWithName:@"Menlo-Bold" size:round(15 * kaHapK)] ?: kaGizliYazi.font;
    [kaGizliTon.layer insertSublayer:kaYeniHap atIndex:0];
}
// m5: ayni tema kasa hapina (64x36). Geri sayimdan etkilenmez.
static void ka_gizliTemaUygula(void) {
    if (!kaGizliTon) return;
    NSString *t = kaPrefTema;
    BOOL acik = [t isEqualToString:@"acik"], mor = [t isEqualToString:@"mor"], halka = [t isEqualToString:@"halka"];
    kaGizliCam.effect = [UIBlurEffect effectWithStyle:acik ? UIBlurEffectStyleSystemThinMaterialLight
                                                           : UIBlurEffectStyleSystemUltraThinMaterialDark];
    UIColor *z = [UIColor colorWithWhite:0.06 alpha:0.92];   // m9 Koyu: kasa paneli rengi
    if ([t isEqualToString:@"kirmizi"]) z = [[UIColor systemRedColor] colorWithAlphaComponent:0.9];
    else if (acik) z = [UIColor colorWithWhite:1.0 alpha:0.5];
    else if (mor) z = [[UIColor systemIndigoColor] colorWithAlphaComponent:0.38];
    else if (halka) z = [UIColor colorWithWhite:0.0 alpha:0.3];
    // m6: neon = siyah + isik cercevesi (renkler akar); cuzdan = zemin yok (dok)
    BOOL neon = [t isEqualToString:@"neon"], cuzdan = [t isEqualToString:@"cuzdan"];
    if (neon) { z = [UIColor colorWithWhite:0.0 alpha:0.85]; halka = YES; }
    if (cuzdan) { kaGizliCam.effect = nil; z = [UIColor clearColor]; }
    kaGizliTon.backgroundColor = z;
    if (mor && !kaAuroraHap) {   // m8: Aurora renk karisimi hapta da
        kaAuroraHap = ka_auroraKatman();
        kaAuroraHap.frame = CGRectMake(0, 0, ka_hapW(), ka_hapH());
        [kaGizliTon.layer insertSublayer:kaAuroraHap atIndex:0];
    }
    kaAuroraHap.hidden = !mor;
    BOOL nos = [t isEqualToString:@"nostalji"];   // m9: iOS 6 gezinme cubugu mavisi
    if (nos && !kaNostHap) {
        kaNostHap = ka_parlakKatman([UIColor colorWithRed:0.53 green:0.62 blue:0.76 alpha:1],
                                    [UIColor colorWithRed:0.22 green:0.33 blue:0.52 alpha:1], CGRectMake(0, 0, ka_hapW(), ka_hapH()), ka_hapH() / 2);
        [kaGizliTon.layer insertSublayer:kaNostHap atIndex:0];
    }
    kaNostHap.hidden = !nos;
    BOOL mod = [t isEqualToString:@"modern"];   // m11: Liquid Glass hap
    if (mod && !kaModernHap) {
        kaModernHap = ka_camKenar(CGRectMake(0, 0, ka_hapW(), ka_hapH()), ka_hapH() / 2);
        [kaGizliTon.superview.layer addSublayer:kaModernHap];
    }
    kaModernHap.hidden = !mod;
    if (mod) {
        kaGizliTon.backgroundColor = [UIColor colorWithWhite:1 alpha:0.04];
        kaGizliTon.superview.layer.borderWidth = 0;
    }
    if (nos) kaGizliCam.effect = nil;
    kaGizliTon.superview.layer.borderWidth = nos ? 0.0 : kaGizliTon.superview.layer.borderWidth;
    UIColor *on = acik ? [UIColor colorWithWhite:0.1 alpha:1.0] : [UIColor whiteColor];
    kaGizliIkon.tintColor = on;
    kaGizliYazi.textColor = on;
    UIView *gb = kaGizliTon.superview;
    gb.layer.borderWidth = (mor || [t isEqualToString:@"cam"]) ? 0.75 : 0.0;
    if (!kaGizliHalka && gb) {
        kaGizliHalka = [CAGradientLayer layer];
        kaGizliHalka.type = kCAGradientLayerConic;
        kaGizliHalka.startPoint = CGPointMake(0.5, 0.5);
        kaGizliHalka.endPoint = CGPointMake(0.5, 0.0);
        kaGizliHalka.colors = kaHalka.colors ?: @[(id)[UIColor systemPinkColor].CGColor, (id)[UIColor systemIndigoColor].CGColor,
                                                 (id)[UIColor systemTealColor].CGColor, (id)[UIColor systemPinkColor].CGColor];
        kaGizliHalka.frame = CGRectMake(0, 0, ka_hapW(), ka_hapH());
        CAShapeLayer *m = [CAShapeLayer layer];
        m.frame = kaGizliHalka.bounds;
        m.fillColor = nil; m.strokeColor = [UIColor blackColor].CGColor; m.lineWidth = 2.0;
        m.path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(kaGizliHalka.bounds, 1.0, 1.0) cornerRadius:ka_hapH() / 2 - 1].CGPath;
        kaGizliHalka.mask = m;
        [gb.layer addSublayer:kaGizliHalka];
    }
    kaGizliHalka.hidden = !halka;
    // Hap yuvarlak koseli dikdortgen: dondurmek maskeyi de dondurur -
    // neonda donme yerine renkler kayar.
    if (neon && ![kaGizliHalka animationForKey:@"ka-neon-ak"]) {
        NSArray *c = kaGizliHalka.colors;
        CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"colors"];
        a.toValue = @[c[1], c[2], c[3], c[1]];
        a.duration = 1.8; a.autoreverses = YES; a.repeatCount = HUGE_VALF;
        [kaGizliHalka addAnimation:a forKey:@"ka-neon-ak"];
    } else if (!neon) [kaGizliHalka removeAnimationForKey:@"ka-neon-ak"];
    ka_yeniTemaHap(t);   // 0.7.0
}
// m6 "cuzdan": X + kasa hapi tek buzlu dok cubugunda. Dok X'in ALT
// gorunumu (en arkada): X'in goster/gizle, tasima ve boyutunu kendiliginden
// izler. Hap X'in sagindaysa (solda=NO) dok saga, solundaysa sola uzar.
static UIVisualEffectView *kaDok;
static UIView *kaDokCizgi;
static void ka_dokGuncelle(BOOL solda) {
    BOOL cuzdan = [kaPrefTema isEqualToString:@"cuzdan"];
    if (!cuzdan) { kaDok.hidden = YES; return; }
    if (!kaButton) return;
    if (!kaDok) {
        kaDok = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterialDark]];
        kaDok.userInteractionEnabled = NO;
        kaDok.clipsToBounds = YES;
        kaDok.layer.cornerCurve = kCACornerCurveContinuous;
        kaDok.layer.borderWidth = 0.5;
        kaDok.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.28].CGColor;
        kaDok.contentView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.10];
        kaDokCizgi = [UIView new];
        kaDokCizgi.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.25];
        [kaDok.contentView addSubview:kaDokCizgi];
    }
    if (kaDok.superview != kaButton) [kaButton insertSubview:kaDok atIndex:0];
    kaDok.hidden = NO;
    CGFloat s = kaButton.bounds.size.width, p = 9, h = s + 2 * p;
    BOOL hap = kaGizliBtn && kaPrefGizli.count > 0;
    CGFloat ek = hap ? 12 + ka_hapW() : 0;
    kaDok.frame = CGRectMake(solda ? -p - ek : -p, -p, s + 2 * p + ek, h);
    kaDok.layer.cornerRadius = h / 2;
    kaDokCizgi.hidden = !hap;
    CGFloat cx = solda ? p + ek - 6 : p + s + 6;   // X ile hap arasi (dok koordinati)
    kaDokCizgi.frame = CGRectMake(cx - 0.5, h * 0.25, 1, h * 0.5);
}
// m12: hap X'in boyutuyla olceklenir. Tema katmanlari sabit boyutlu
// kuruluyor - silinip ka_gizliTemaUygula'da yeni boyutla yeniden kurulur.
static void ka_hapBoyutla(void) {
    CGFloat s = kaBtnW ? kaBtnW.constant : 38.0;
    kaHapK = s / 38.0;
    UIView *gb = kaGizliTon.superview;
    if (!gb) return;
    CGFloat w = ka_hapW(), h = ka_hapH();
    kaGizliW.constant = w; kaGizliH.constant = h;
    gb.layer.cornerRadius = h / 2;
    kaGizliIkon.frame = CGRectMake(round(8 * kaHapK), 0, round(28 * kaHapK), h);
    kaGizliIkon.image = [UIImage systemImageNamed:@"lock.rectangle.stack.fill" withConfiguration:
        [UIImageSymbolConfiguration configurationWithPointSize:round(14 * kaHapK) weight:UIImageSymbolWeightSemibold]];
    kaGizliYazi.frame = CGRectMake(round(36 * kaHapK), 0, round(20 * kaHapK), h);
    kaGizliYazi.font = [UIFont monospacedDigitSystemFontOfSize:round(15 * kaHapK) weight:UIFontWeightBold];
    for (CAGradientLayer *l in @[kaGizliHalka ?: [NSNull null], kaAuroraHap ?: [NSNull null],
                                  kaNostHap ?: [NSNull null], kaModernHap ?: [NSNull null]])
        if ([l isKindOfClass:[CALayer class]]) [l removeFromSuperlayer];
    kaGizliHalka = nil; kaAuroraHap = nil; kaNostHap = nil; kaModernHap = nil;
    ka_gizliTemaUygula();
}
static void ka_boyutUygula(void) {
    CGFloat s = ka_boyutPt();
    if (kaBtnW) kaBtnW.constant = s;
    if (kaBtnH) kaBtnH.constant = s;
    kaButton.layer.cornerRadius = s / 2.0;
    kaButton.layer.shadowPath = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, s, s)].CGPath;
    kaCam.layer.cornerRadius = s / 2.0;
    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:round(s * 0.40)
                                                                                      weight:UIImageSymbolWeightSemibold];
    kaXIkon.image = [UIImage systemImageNamed:@"xmark" withConfiguration:cfg];
    ka_halkaKur(s);                 // m4 tema: boyuta bagli cerceve
    ka_zeminAyarla(kaUndoAktif);    // m4 tema: zemin + simge rengi
    ka_hapBoyutla();                // m12: hap da boyutla olceklenir (temayi da uygular)
    kaBoyutKirli = NO;
    kaKonumKirli = YES;
    ka_log([NSString stringWithFormat:@"boyut-uygulandi %@ s=%.0f tema=%@", kaPrefBoyut, s, kaPrefTema], kaButton);
}

// Butonun ustundeki balon (ipucu / geri alma): butona ortalanir ama
// ekran kenarinda 8 pt'de durur - buton kenara tasininca tasmasin (0.4.4).
static NSArray<NSLayoutConstraint *> *ka_balonKisitlari(UIView *bg, UIView *v) {
    NSLayoutConstraint *cx = [bg.centerXAnchor constraintEqualToAnchor:kaButton.centerXAnchor];
    cx.priority = UILayoutPriorityDefaultHigh;
    return @[
        cx,
        [bg.leftAnchor constraintGreaterThanOrEqualToAnchor:v.leftAnchor constant:8],
        [bg.rightAnchor constraintLessThanOrEqualToAnchor:v.rightAnchor constant:-8],
        [bg.bottomAnchor constraintEqualToAnchor:kaButton.topAnchor constant:-8],
    ];
}

static BOOL ka_sabitliMi(NSString *bid) {
    if (!bid.length) return NO;
    @try {
        for (NSString *b in (kaPrefKoru ?: @[])) {
            if ([b isKindOfClass:[NSString class]] && [b isEqualToString:bid]) return YES;
        }
    } @catch (__unused NSException *e) {}
    return NO;
}

static void ka_sabitleToggle(NSString *bid) {
    if (!bid.length) return;
    @try {
        NSMutableArray *yeni = [(kaPrefKoru ?: @[]) mutableCopy];
        BOOL simdiSabit = NO;
        for (NSString *b in [yeni copy]) {
            if ([b isKindOfClass:[NSString class]] && [b isEqualToString:bid]) {
                [yeni removeObject:b];
                simdiSabit = YES;
            }
        }
        if (!simdiSabit) [yeni addObject:bid];
        kaPrefKoru = [yeni copy];
        CFPreferencesSetAppValue((__bridge CFStringRef)kKA_KeyKoru,
                                 (__bridge CFArrayRef)yeni,
                                 (__bridge CFStringRef)kKA_AlanAdi);
        CFPreferencesAppSynchronize((__bridge CFStringRef)kKA_AlanAdi);
        notify_post([kKA_Bildirim UTF8String]);
        ka_logText([NSString stringWithFormat:@"sabitleToggle bid=%@ simdiSabit=%d yeniSabitMi=%d",
                    bid, simdiSabit, !simdiSabit]);
    } @catch (__unused NSException *e) { ka_logText(@"sabitleToggle-exception"); }
}

static BOOL ka_migrateFromOldPrefs(void) {
    static NSString * const oldDomain = @"com.shiv.killallswitcher";
    @try {
        CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("etkin"), (__bridge CFStringRef)oldDomain);
        if (!v) return NO; // eski alan yok veya bos
        CFRelease(v);

        NSArray<NSString *> *keys = @[@"sonuncuHaric", @"medyaKoru", @"koru", @"animasyonTuru", @"animasyonHizi", @"etkin"];
        for (NSString *key in keys) {
            CFPropertyListRef val = CFPreferencesCopyAppValue((__bridge CFStringRef)key, (__bridge CFStringRef)oldDomain);
            if (!val) continue;
            CFPreferencesSetAppValue((__bridge CFStringRef)key, val, (__bridge CFStringRef)kKA_AlanAdi);
            CFRelease(val);
        }
        CFPreferencesAppSynchronize((__bridge CFStringRef)kKA_AlanAdi);
        return YES;
    } @catch (__unused NSException *e) { return NO; }
}

static void ka_prefsYukle(void) {
    @try {
        // Bir kerelik: eski com.shiv.killallswitcher alanindan ayarlari tasi.
        static BOOL migrated = NO;
        if (!migrated) {
            CFPropertyListRef v = CFPreferencesCopyAppValue(CFSTR("etkin"), (__bridge CFStringRef)kKA_AlanAdi);
            if (!v) {
                ka_migrateFromOldPrefs();
            } else {
                CFRelease(v);
            }
            migrated = YES;
        }

        kaPrefSonuncuHaric = ka_prefBool(kKA_KeySonuncuHaric, NO);
        kaPrefMedyaKoru    = ka_prefBool(kKA_KeyMedyaKoru, YES);
        kaPrefKoru         = [ka_prefArray(kKA_KeyKoru) copy];
        NSSet *eskiGizli   = kaPrefGizli;
        kaPrefGizli        = [NSSet setWithArray:(ka_prefArray(kKA_KeyGizli) ?: @[])];
        if (!kaPrefGizli.count) kaGizliMod = NO;   // liste bosaldiysa moddan cik
        // Liste degistiyse ana switcher listesini HEMEN yeniden kur (m2'de
        // gizleme ancak bir sonraki ac/kapa'da oluyordu - onbellek).
        if (eskiGizli && ![eskiGizli isEqualToSet:kaPrefGizli]) {   // 0.7: yalniz fark (KASGizle)
            NSSet *e = eskiGizli, *y = kaPrefGizli;
            dispatch_async(dispatch_get_main_queue(), ^{ kas_esitle(e, y); kaGizliBidler = kas_kasaBidleri(y); ka_gizliBtnGuncelle(); });
        }
        kaPrefEtkin        = ka_prefBool(kKA_KeyEtkin, YES);
        NSString *at = ka_prefString(kKA_KeyAnimasyonTuru, @"yukari");
        // Bilinmeyen deger gelirse (bozuk plist, eski surum) guvenli
        // varsayilana don - crash yerine sessiz duzelt.
        NSSet *gecerli = [NSSet setWithObjects:@"yukari", @"solma", @"kucul", @"yana", @"yok", nil];
        kaPrefAnimasyonTuru = [gecerli containsObject:at] ? at : @"yukari";
        NSString *bb = ka_prefString(kKA_KeyButonBoyutu, @"orta");
        if (![[NSSet setWithObjects:@"kucuk", @"orta", @"buyuk", nil] containsObject:bb]) bb = @"orta";
        if (![bb isEqualToString:kaPrefBoyut]) { kaPrefBoyut = bb; kaBoyutKirli = YES; }
        // m4: tema degisince de ka_boyutUygula (zemin + halka orada boyanir)
        // m7 ISTEK: 5 tema (acik=Varsayilan/iOS acik, cam=Koyu/iOS koyu, mor=Aurora, neon,
        // cuzdan). Renk temalari kalkti; eski kirmizi/halka -> acik.
        NSString *tm = ka_prefString(kKA_KeyTema, @"acik");
        if (![[NSSet setWithObjects:@"cam", @"acik", @"mor", @"neon", @"cuzdan", @"nostalji", @"modern", @"holo", @"terminal", @"oyun", nil] containsObject:tm]) tm = @"acik";
        if (![tm isEqualToString:kaPrefTema]) { kaPrefTema = tm; kaBoyutKirli = YES; }
        kaPrefKasaKilit = ka_prefBool(kKA_KeyKasaKilit, YES);
        kaPrefKilitHer = [ka_prefString(kKA_KeyKilitSure, @"switcher") isEqualToString:@"her"];   // m14
        kaPrefKilitDakika = [ka_prefString(kKA_KeyKilitSure, @"switcher") isEqualToString:@"dakika"];   // b17
        NSInteger saat = [ka_prefString(kKA_KeyOtoKapat, @"0") integerValue];   // m14
        kaPrefOtoSaat = (saat == 1 || saat == 3 || saat == 6 || saat == 12) ? saat : 0;
        CGFloat hiz = ka_prefFloat(kKA_KeyAnimasyonHizi, 1.0);
        // Guvenlik siniri: 0 veya negatif carpan animasyonu SIFIR sureye
        // dusurup completion'u hic tetiklemeyebilir (UIView animateWithDuration
        // suresi 0'a yakinsa bazi surumlerde davranis tanimsiz) - 0.1..3.0
        // araligina sikistirilir.
        // ISTEK: animasyon suresi daha da uzatilabilsin - ust sinir
        // 2.0'dan 4.0'a (iki kat) cikarildi. Guvenlik alt sinir (0.1)
        // AYNI kaldi.
        if (hiz < 0.1) hiz = 0.1;
        if (hiz > 4.0) hiz = 4.0;
        kaPrefAnimasyonHizi = hiz;
        ka_logText([NSString stringWithFormat:@"prefsYukle sonuncuHaric=%d medyaKoru=%d koru=%lu animasyonTuru=%@ animasyonHizi=%.2f etkin=%d",
                    kaPrefSonuncuHaric, kaPrefMedyaKoru, (unsigned long)kaPrefKoru.count, kaPrefAnimasyonTuru, kaPrefAnimasyonHizi, kaPrefEtkin]);
    } @catch (__unused NSException *e) { ka_logText(@"prefsYukle-exception"); }
}

static void ka_prefsBildirimCB(CFNotificationCenterRef c, void *o, CFNotificationName n,
                               const void *obj, CFDictionaryRef ui) {
    ka_prefsYukle();
}

static NSArray<NSString *> *ka_switcherBids(void) {
    NSMutableArray *bids = [NSMutableArray array];
    @try {
        SBMainSwitcherControllerCoordinator *c = [%c(SBMainSwitcherControllerCoordinator) sharedInstanceIfExists];
        if (!c) return @[];
        for (SBAppLayout *layout in [[c recentAppLayouts] copy]) {
            for (SBDisplayItem *item in [layout allItems]) {
                if (![item isKindOfClass:%c(SBDisplayItem)]) continue;
                NSString *bid = [item bundleIdentifier];
                if (bid.length && ![bids containsObject:bid]) [bids addObject:bid];
            }
        }
    } @catch (__unused NSException *e) { ka_logText(@"switcherBids-exception"); }
    return bids;
}

static NSSet<NSString *> *ka_protectedSet(NSString **outNowPlaying) {
    NSMutableSet *set = [NSMutableSet set];
    NSString *nowPlaying = nil;
    if (kaPrefMedyaKoru) {
        @try {
            SBMediaController *mc = [%c(SBMediaController) sharedInstance];
            SBApplication *app = [mc nowPlayingApplication];
            NSString *bid = [app bundleIdentifier];
            if (bid.length) { [set addObject:bid]; nowPlaying = bid; }
        } @catch (__unused NSException *e) { ka_logText(@"nowPlaying-exception"); }
        @try {
            SBApplicationController *ac = [%c(SBApplicationController) sharedInstance];
            for (NSString *bid in ka_navBids()) {
                SBApplication *a = [ac applicationWithBundleIdentifier:bid];
                if (a) [set addObject:bid];
            }
        } @catch (__unused NSException *e) { ka_logText(@"navProtected-exception"); }
    }
    @try {
        for (NSString *bid in (kaPrefKoru ?: @[])) {
            if ([bid isKindOfClass:[NSString class]] && bid.length) [set addObject:bid];
        }
    } @catch (__unused NSException *e) {}
    if (outNowPlaying) *outNowPlaying = nowPlaying;
    return set;
}

static NSString *ka_displayName(NSString *bid) __attribute__((unused));
static NSString *ka_displayName(NSString *bid) {
    @try {
        SBApplicationController *ac = [%c(SBApplicationController) sharedInstance];
        SBApplication *a = [ac applicationWithBundleIdentifier:bid];
        NSString *n = [a displayName];
        if (n.length) return n;
    } @catch (__unused NSException *e) {}
    return bid;
}

static NSArray<NSString *> *ka_kapatilacaklar(NSArray<NSString *> *tumSwitcher, NSSet<NSString *> *korunan, NSString *haric_bid) {
    NSMutableArray *out = [NSMutableArray array];
    for (NSString *bid in tumSwitcher) {
        if ([korunan containsObject:bid]) continue;
        if (haric_bid && [bid isEqualToString:haric_bid]) continue;
        [out addObject:bid];
    }
    return out;
}

static NSString *ka_lastUsedBid(NSArray<NSString *> *tumSwitcher) {
    if (tumSwitcher.count == 0) return nil;
    return tumSwitcher.firstObject;
}

static NSUInteger ka_kapatilacakSayi(void) {
    NSArray<NSString *> *tums = ka_switcherBids();
    NSSet<NSString *> *korunan = ka_protectedSet(NULL);
    NSString *haric = kaPrefSonuncuHaric ? ka_lastUsedBid(tums) : nil;
    return ka_kapatilacaklar(tums, korunan, haric).count;
}

static const NSInteger kKA_RozetTag = 987321;

static const void *kKA_KartBidKey = &kKA_KartBidKey;
static const void *kKA_KartLongPressKey = &kKA_KartLongPressKey;
static const void *kKA_KartLongPressAktifKey = &kKA_KartLongPressAktifKey;

// 0.3.0'da kart menusu icin UIContextMenuInteraction kullanildi. Olcum:
// SBMainSwitcherWindow (level=5), floating dock ise SXFloatingPassThroughWindow
// (level=2001, Prism.dylib'e ait pencere - farkli tweak) ya da SBHomeScreenWindow
// (level=-2, klasik dock). Menu, dock'tan DUSUK seviyeli bir pencere icinde
// render olur; kullanicinin RAPOR'da bildirdigi "Sabitle dock'un arkasinda"
// gozlemi ile tutarli - context menu KALDIRILDI, yerine dogrudan uzun basma.

// Rozet EN UST gorunume eklenir: SBReusableSnapshotItemContainer'in kendisi
// (kart), clip=0 olcumlendi (bkz kas-log agac dokum) - alt gorunumlerin
// bazilari clip=1, rozet onlarin AlTINA eklenirse kirpilirdi. Kart bounds'u
// ile ayni boyutta oldugu icin sag-ust 8pt inset kartin kendi
// cornerRadius'u ICINDE kalir (koseye yapismaz).
// OLCUM (0.3.2): rozet kartin USTUNDE durunca, kart snapshot'i
// (uygulamanin ekran goruntusu) uzerinde kaliyordu - uygulama acikken
// bile (kart hala switcher penceresinde canli oldugu icin) gorunmeye
// devam ediyordu. YENI YER: basli satiri (SBFluidSwitcherItemContainerHeaderView),
// ikon+ad ile ayni satirda, ikonun SOLUNA. Bu view kartin SIBLING'i (ayni
// _SBFActualClippingView altinda), appLayout'tan BAGIMSIZ kendi bid'ini
// tasiyor: titleItems[0].displayItem.bundleIdentifier (bkz forward-declare
// yukarida). Ikon konteynerinin sinifi SBFluidSwitcherIconImageContainerView,
// olculen frame (32,8;26,26); etiket dogrudan UILabel, font
// UICTFontTextStyleEmphasizedSubhead bold 13pt, renk beyaz (1,1,1).
static void ka_kartRozetBasligaGuncelle(UIView *header, BOOL sabitli) {
    @try {
        UIView *mevcut = [header viewWithTag:kKA_RozetTag];
        if (!sabitli) {
            if (mevcut) [mevcut removeFromSuperview];
            return;
        }

        UIView *ikonWrap = nil;
        UILabel *adEtiketi = nil;
        for (UIView *alt in header.subviews) {
            if (!ikonWrap && [alt isKindOfClass:[%c(SBFluidSwitcherIconImageContainerView) class]]) {
                ikonWrap = alt;
            } else if (!adEtiketi && [alt isKindOfClass:[UILabel class]]) {
                adEtiketi = (UILabel *)alt;
            }
        }
        if (!ikonWrap) return; // olcum aninda bulunamadi - baglama degisti, sessizce cik

        UIFont *font = adEtiketi ? adEtiketi.font : [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
        UIColor *renk = adEtiketi ? adEtiketi.textColor : [UIColor whiteColor];
        CGFloat sembolBoyut = font.pointSize * 0.9;
        CGFloat pay = 4.0;

        if (mevcut) {
            // Kart/baslik yeniden kullanildi - konumu tazele (yer tutucu
            // DEGIL, gercek frame guncellemesi - ikon/etiket kaymasin).
            CGFloat w = mevcut.bounds.size.width;
            CGRect f = ikonWrap.frame;
            mevcut.frame = CGRectMake(f.origin.x - w - pay,
                                       f.origin.y + (f.size.height - w) / 2.0,
                                       w, w);
            return;
        }

        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:sembolBoyut
                                                                                            weight:UIImageSymbolWeightRegular];
        UIImage *img = [UIImage systemImageNamed:@"pin.fill"];
        if (img) img = [img imageByApplyingSymbolConfiguration:cfg];
        CGRect f = ikonWrap.frame;
        CGFloat w = sembolBoyut + 2.0;
        UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(f.origin.x - w - pay,
                                                                          f.origin.y + (f.size.height - w) / 2.0,
                                                                          w, w)];
        iv.tag = kKA_RozetTag;
        iv.image = img;
        iv.tintColor = renk;
        iv.contentMode = UIViewContentModeCenter;
        iv.userInteractionEnabled = NO;

        [header addSubview:iv];
    } @catch (__unused NSException *e) { ka_logText(@"rozetBasligaGuncelle-exception"); }
}

static void ka_birTaneSil(NSString *bid) {
    @try {
        SBMainSwitcherControllerCoordinator *c = [%c(SBMainSwitcherControllerCoordinator) sharedInstanceIfExists];
        if (!c) return;
        // 0.6.0 sorun 1 (m25 olcumu): bu yol deletedDisplayItem cagirmiyor -> m23'un 400 ms
        // penceresi acilmiyordu, ardindan gelen bos-layout kasayi kapatiyordu. Ondeyse pencereyi burada ac.
        NSString *ondeBid = nil;
        if (bid && ka_appOnPlanda(&ondeBid) && [ondeBid isEqualToString:bid]) kaOndeSilmeMs = ka_msNow();
        @try { [c _deleteAppLayoutsMatchingBundleIdentifier:bid]; }
        @catch (__unused NSException *e) { ka_logText([NSString stringWithFormat:@"delete-exception %@", bid]); }
    } @catch (__unused NSException *e) { ka_logText(@"kapat-exception"); }
}

// m14 otomatik kapatma. Son kullanim: uygulamaya gecis + switcher acilisinda
// ondeki uygulama. Ilk kez gorulen uygulamaya "simdi" yazilir (kurulumda
// hicbir sey birden kapanmasin). Korunan/sabit/calan medya/gizli/onde: dokunma.
static void ka_kullanimYukle(void) {
    if (kaSonKullanim) return;
    NSDictionary *d = nil;
    CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)kKA_KeySonKullanim, (__bridge CFStringRef)kKA_AlanAdi);
    if (v) { id o = CFBridgingRelease(v); if ([o isKindOfClass:[NSDictionary class]]) d = o; }
    kaSonKullanim = d ? [d mutableCopy] : [NSMutableDictionary dictionary];
}
static void ka_kullanimKaydet(void) {
    CFPreferencesSetAppValue((__bridge CFStringRef)kKA_KeySonKullanim, (__bridge CFDictionaryRef)kaSonKullanim,
                             (__bridge CFStringRef)kKA_AlanAdi);
    CFPreferencesAppSynchronize((__bridge CFStringRef)kKA_AlanAdi);   // bildirim YOK: ayar degil, kayit
}
static void ka_kullanimYaz(NSString *bid) {
    if (!bid.length || [bid isEqualToString:@"com.apple.springboard"]) return;
    ka_kullanimYukle();
    kaSonKullanim[bid] = @([NSDate date].timeIntervalSince1970);
    ka_kullanimKaydet();
}
static void ka_otoKapatKontrol(NSString *neden) {
    if (kaPrefOtoSaat <= 0 || !kaPrefEtkin) return;
    @try {
        ka_kullanimYukle();
        NSTimeInterval simdi = [NSDate date].timeIntervalSince1970, sinir = kaPrefOtoSaat * 3600.0;
        NSSet *korunan = ka_protectedSet(NULL);
        NSString *onde = nil; ka_appOnPlanda(&onde);
        BOOL degisti = NO; NSUInteger kapanan = 0;
        for (NSString *bid in ka_switcherBids()) {
            if ([korunan containsObject:bid] || [kaPrefGizli containsObject:bid] || [bid isEqualToString:onde]) continue;
            NSNumber *t = kaSonKullanim[bid];
            if (!t) { kaSonKullanim[bid] = @(simdi); degisti = YES; continue; }
            if (simdi - t.doubleValue < sinir) continue;
            ka_birTaneSil(bid);
            [kaSonKullanim removeObjectForKey:bid]; degisti = YES; kapanan++;
            ka_logText([NSString stringWithFormat:@"oto-kapat %@ bosta=%.0fdk", bid, (simdi - t.doubleValue) / 60]);
        }
        if (degisti) ka_kullanimKaydet();
        ka_logText([NSString stringWithFormat:@"oto-kontrol %@ saat=%ld kapanan=%lu", neden, (long)kaPrefOtoSaat, (unsigned long)kapanan]);
    } @catch (__unused NSException *e) { ka_logText(@"oto-kapat-exception"); }
}

// bid -> kart (weak) eslemesi. Kart hook'unda (layoutSubviews) her cagrida
// guncellenir. NSMapTable weak-to-strong: kart bellekten dusunce anahtar
// otomatik silinir, dangling pointer riski yok.
static NSMapTable<NSString *, UIView *> *kaKartEslemesi(void) {
    static NSMapTable<NSString *, UIView *> *t = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        t = [NSMapTable strongToWeakObjectsMapTable];
    });
    return t;
}

static void ka_kartEslemesiGuncelle(NSString *bid, UIView *kart) {
    if (!bid.length || !kart) return;
    [kaKartEslemesi() setObject:kart forKey:bid];
}

static UIView *ka_kartBul(NSString *bid) {
    if (!bid.length) return nil;
    return [kaKartEslemesi() objectForKey:bid];
}

// bid -> header (weak). Uzun basinca rozeti ANINDA guncellemek icin -
// bir sonraki setTitleItems:/layoutSubviews'i beklemeden.
static NSMapTable<NSString *, UIView *> *kaHeaderEslemesi(void) {
    static NSMapTable<NSString *, UIView *> *t = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        t = [NSMapTable strongToWeakObjectsMapTable];
    });
    return t;
}

static void ka_headerEslemesiGuncelle(NSString *bid, UIView *header) {
    if (!bid.length || !header) return;
    [kaHeaderEslemesi() setObject:header forKey:bid];
}

static UIView *ka_headerBul(NSString *bid) {
    if (!bid.length) return nil;
    return [kaHeaderEslemesi() objectForKey:bid];
}

// Su an selalede (animasyonu suren) bid'lerin kumesi. Kart hook'u
// (layoutSubviews) bu kumede OLMAYAN bir kart icin transform/alpha'yi
// sifirlar - kumede olana DOKUNMAZ (yari yolda kesilmesin).
static NSMutableSet<NSString *> *kaSelaledekiBidler(void) {
    static NSMutableSet<NSString *> *s = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [NSMutableSet new]; });
    return s;
}

// Selale: kartlar switcher gorsel sirasina (soldan saga) gore, aralarinda
// kisa gecikmeyle kapanir. Aralik = min(70ms, 1500ms / adet); toplam sure
// 1.5 sn'yi gecmez. Sabitli/korunan kartlar zaten bids icinde YOK
// (ka_kapatilacaklar korunanlari eledi), bu yuzden yerinde kalirlar.
//
// OLCUM (0.3.0): SpringBoard'un _deleteAppLayoutsMatchingBundleIdentifier:
// cagrisi kart bazinda animasyon TETIKLEMIYOR - kartlar hepsi ayni anda
// kayboluyor (varsayim yanlisti). Bu yuzden animasyonu KENDIMIZ oynatiyoruz:
// her kart icin transform (yukari, kendi yuksekliginin 1.1 kati) + alpha 0,
// 0.28 sn; animasyon TAMAMLANINCA o bid silinir. Kart bulunamazsa (bid icin
// canli kart yok) dogrudan silinir, animasyonsuz. Switcher kapanirsa
// (kartin window'u kalkar) kalan adimlar ANIMASYONSUZ devam eder - kontrol
// her adimda kartin hala ekranda olup olmadigina bakar.

// m18 ISTEK: kart kopyasi (ka_kopyaKur / ka_kopyaHedef, 0.5.0-m4) kaldirildi.
// Kopya, kirpilmis karti (m16-m17 olcumu) ve komsu kart sirasini tasiyordu.

// 0.5.0-m5: selalenin bir sonraki karti = kalanlar icinde O AN ekranin
// ortasina en yakin (en cok gorunen). OLCUM: sabit "son kullanilan" sirasi
// ilk olarak sag kenardaki, cogu ekran disindaki karti (x=430/393)
// kapatiyordu - animasyon "ortadan basliyor" gibi gorunuyordu.
// Canli kart yoksa listedeki ilk bid. Secileni kalan'dan cikarir.
static NSString *ka_siradaki(NSMutableArray<NSString *> *kalan) {
    if (!kalan.count) return nil;
    NSString *en = kalan.firstObject;
    CGFloat enIyi = CGFLOAT_MAX;
    UIView *ev = kaButton.superview;
    if (ev) {
        CGPoint orta = CGPointMake(CGRectGetMidX(ev.bounds), CGRectGetMidY(ev.bounds));
        for (NSString *b in kalan) {
            UIView *k = ka_kartBul(b);
            if (!k || !k.window || !k.superview) continue;
            CGPoint c = [k.superview convertPoint:k.center toView:ev];
            CGFloat d = hypot(c.x - orta.x, c.y - orta.y);
            if (d < enIyi) { enIyi = d; en = b; }
        }
    }
    [kalan removeObject:en];
    ka_logText([NSString stringWithFormat:@"siradaki bid=%@ uzaklik=%.0f kalan=%lu",
                en, enIyi, (unsigned long)kalan.count]);
    return en;
}

static void ka_dogrudanKapat(NSArray<NSString *> *bids) {
    NSUInteger n = bids.count;
    if (n == 0) return;
    // OLCUM (0.3.3): giris kaydi - kac bid, hangi sirada.
    ka_logText([NSString stringWithFormat:@"OLCUM dogrudanKapat-giris n=%lu bids=%@",
                (unsigned long)n, bids]);
    // ISTEK (0.3.4): animasyon hizi carpani (0.1..3.0) hem kartlar
    // arasi gecikmeye hem de tek kartin animasyon suresine uygulanir -
    // boylece tum selale ORANTILI hizlanir/yavaslar, sadece tek kart
    // degil.
    CGFloat hiz = kaPrefAnimasyonHizi > 0 ? kaPrefAnimasyonHizi : 1.0;
    BOOL animasyonsuz = YES;   // m18 ISTEK: selale animasyonu kaldirildi - hepsi ayni anda silinir
    // NOT: adet==1 icin KISAYOL YOK (madde 4) - tek kart da ayni
    // dispatch_after + transform/alpha yoluyla kapaniyor.
    double araligMs = 70.0 * hiz;
    if (n > 0) {
        double sinirli = (1500.0 * hiz) / (double)n;
        if (sinirli < araligMs) araligMs = sinirli;
    }
    ka_logText([NSString stringWithFormat:@"selale-baslangic adet=%lu araligMs=%.1f hiz=%.2f animasyonsuz=%d",
                (unsigned long)n, araligMs, hiz, animasyonsuz]);
    NSUInteger idx = 0;
    NSMutableArray<NSString *> *kalan = [bids mutableCopy];   // m5: adim adim ka_siradaki secer
    for (NSString *bid in bids) {
        NSTimeInterval gecikme = animasyonsuz ? 0 : (araligMs * (double)idx / 1000.0);
        [kaSelaledekiBidler() addObject:[bid copy]];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(gecikme * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            // m5: bu adimin karti sabit degil - o an en cok gorunen.
            NSString *bidCopy = ka_siradaki(kalan);
            if (!bidCopy) return;
            @try {
                UIView *kart = ka_kartBul(bidCopy);
                BOOL canli = kart && kart.window;
                // OLCUM (0.3.3): kart bulundu mu, adres, frame, window.
                ka_log([NSString stringWithFormat:@"OLCUM kart-bulundu bid=%@ canli=%d",
                        bidCopy, canli], kart);
                ka_logText([NSString stringWithFormat:@"selale-adim bid=%@ animasyonlu=%d",
                            bidCopy, canli]);
                // m18 ISTEK: animasyon (kopya + selale) TAMAMEN kaldirildi - dogrudan sil.
                [kaSelaledekiBidler() removeObject:bidCopy];
                ka_birTaneSil(bidCopy);
                (void)canli;
            } @catch (__unused NSException *e) {
                [kaSelaledekiBidler() removeObject:bidCopy];
                ka_logText(@"selale-sil-exception");
            }
        });
        idx++;
    }
}

// Karta basili tutunca dock'un ustunde de her yerde gorunecek uctaki
// kapsul bildirim: guvenli alanin 24pt ALTINDA (ustte), 1.2 sn sonra kaybolur.
static UIView *kaKartBildirim;
static NSInteger kaKartBildirimNesil = 0;

static void ka_kartBildirimGizle(NSInteger nesil) {
    if (nesil != kaKartBildirimNesil) return; // yeni bildirim geldi, eskisini gizleme
    UIView *cap = kaKartBildirim;
    if (!cap) return;
    [UIView animateWithDuration:0.25 animations:^{ cap.alpha = 0; }
        completion:^(BOOL fin) {
            [cap removeFromSuperview];
            if (kaKartBildirim == cap) kaKartBildirim = nil;
        }];
}

static void ka_kartBildirimGoster(UIView *ankor, NSString *text) {
    @try {
        UIWindow *win = ankor.window;
        if (!win) return;
        if (kaKartBildirim) { [kaKartBildirim removeFromSuperview]; kaKartBildirim = nil; }
        NSInteger nesil = ++kaKartBildirimNesil;

        UIVisualEffectView *bg = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark]];
        bg.translatesAutoresizingMaskIntoConstraints = NO;
        bg.layer.masksToBounds = YES;
        bg.alpha = 0;

        UILabel *lbl = [UILabel new];
        lbl.text = text;
        lbl.textColor = [UIColor whiteColor];
        lbl.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
        lbl.translatesAutoresizingMaskIntoConstraints = NO;
        [bg.contentView addSubview:lbl];
        [NSLayoutConstraint activateConstraints:@[
            [lbl.leadingAnchor  constraintEqualToAnchor:bg.contentView.leadingAnchor  constant:12],
            [lbl.trailingAnchor constraintEqualToAnchor:bg.contentView.trailingAnchor constant:-12],
            [lbl.topAnchor      constraintEqualToAnchor:bg.contentView.topAnchor      constant:6],
            [lbl.bottomAnchor   constraintEqualToAnchor:bg.contentView.bottomAnchor   constant:-6],
        ]];

        [win addSubview:bg];
        [NSLayoutConstraint activateConstraints:@[
            [bg.centerXAnchor constraintEqualToAnchor:win.centerXAnchor],
            [bg.topAnchor constraintEqualToAnchor:win.safeAreaLayoutGuide.topAnchor constant:24],
        ]];
        [win layoutIfNeeded];
        bg.layer.cornerRadius = bg.bounds.size.height / 2.0;
        bg.transform = CGAffineTransformMakeTranslation(0, -4);
        kaKartBildirim = bg;

        [UIView animateWithDuration:0.2 animations:^{
            bg.alpha = 1.0;
            bg.transform = CGAffineTransformIdentity;
        }];

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            ka_kartBildirimGizle(nesil);
        });
    } @catch (__unused NSException *e) { ka_logText(@"kartBildirimGoster-exception"); }
}

// Kart menusu KALDIRILDI (bkz olcum notu yukarida): dogrudan basili-tutma
// ile sabitleme aninda degisir. UIGestureRecognizerDelegate ile kartin
// KENDI tap/pan hareketlerini engellemez (shouldRecognizeSimultaneously = YES).
// OLCUM (0.3.2): karta basili tutunca "Sabitlendi" cikiyor ama parmak
// HEMEN kalkarsa uygulama aciliyordu. Sebep: kartin KENDI tap tanimasi
// (action=_handlePageViewTap: - SBFailureNotifyingTapGestureRecognizer VE
// bir UITapGestureRecognizer, biri numberOfTapsRequired=2 - kart 13
// gesture recognizer tasiyor, bkz olcum) bizim uzun basmamiz Began'a
// gecince de calismayi surduruyordu; kaldirista "dokundu" sayiliyordu.
// Ikisine de requireGestureRecognizerToFail: eklendi.
@interface KAKartLongPressHandler : NSObject <UIGestureRecognizerDelegate>
@end

@implementation KAKartLongPressHandler

- (void)ka_longPress:(UILongPressGestureRecognizer *)gr {
    if (gr.state != UIGestureRecognizerStateBegan) return;
    UIView *kart = gr.view;
    NSString *bid = kart ? objc_getAssociatedObject(kart, kKA_KartBidKey) : nil;
    if (!bid.length) return;
    @try {
        // Bayrak: acma yolunu 0.6 sn engeller - requireGestureRecognizerToFail
        // yetersiz kalirsa (baska bir tanimlanmamis tap yolu varsa) ikinci hat.
        objc_setAssociatedObject(kart, kKA_KartLongPressAktifKey, @YES, OBJC_ASSOCIATION_RETAIN);
        __weak UIView *weakKart = kart;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            UIView *k = weakKart;
            if (k) objc_setAssociatedObject(k, kKA_KartLongPressAktifKey, nil, OBJC_ASSOCIATION_RETAIN);
        });

        ka_sabitleToggle(bid);
        BOOL sabitliYeni = ka_sabitliMi(bid);
        UIView *header = ka_headerBul(bid);
        if (header) ka_kartRozetBasligaGuncelle(header, sabitliYeni);

        UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [g impactOccurred];

        NSString *msg = sabitliYeni ? (ka_L(@"Sabitlendi"))
                                     : (ka_L(@"Sabitleme kaldırıldı"));
        ka_kartBildirimGoster(kart, msg);
        ka_logText([NSString stringWithFormat:@"kartLongPress bid=%@ sabitliYeni=%d", bid, sabitliYeni]);
    } @catch (__unused NSException *e) { ka_logText(@"kartLongPress-exception"); }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES; // kaydirarak kapatma/yatay kaydirma BOZULMASIN
}

@end

// m14 ISTEK: switcher'da karti ASAGI atinca gizli bolume tasi. Kartin
// transform/alpha'si sistemin (0.5.0) - surukenen kartin KOPYASI; birakinca
// kopya kasa hapina ucup kuculur. Liste Ayarlar'daki ayni tercihe yazilir
// (prefs-changed -> ka_prefsYukle -> ka_switcherYenile).
static const void *kKA_KartAsagiKey = &kKA_KartAsagiKey;
// m15 DUZELTME: gizledigimiz kart kabi isaretlenir; prepareForReuse'da acilir.
// m14'te 0,9 sn sonra KORLEMESINE hidden=NO yapiliyordu - kap o arada havuza
// alindiysa gorunur kalip dokunmayi yutuyor / karartma yapiyor olabilir
// (kullanici: bos alana basinca ana ekrana donmuyor, ana ekrana geciste karartma).
static const void *kKA_KartAsagiGizliKey = &kKA_KartAsagiGizliKey;
static NSString *ka_kartinBid(UIView *sv);   // asagida tanimli
// (m15-m16 agac olcumu kaldirildi; sonucu ka_sayfaBul yorumunda)
// m16: kopya kabin degil icerigin (SBAppSwitcherPageView, olcum m15 agaci 3. seviye)
// - kirpma ustteki _SBFActualClippingView'deyse icerigin kopyasi tam cikar
// (DOGRULANMADI). Bulunamazsa kabin kendisi.
// m17 OLCUM (m16 agaci): kirpma 5. seviyede - SBHitTestExtendedView ve bir
// UIView 138 pt genis, c=1 (sonraki kartin altinda kalan kisim kesiliyor);
// asil goruntu bunlarin ICINDE: SBAppSwitcherReusableSnapshotView 393x852.
// Basili tutunca kart "kalkiyor", kirpma genisliyor (kullanici gozlemi).
// Kopya artik kirpmanin icindeki bu goruntu gorunumunden; yoksa sayfa, o da yoksa kap.
// b22: kasa icin SABIT resim. Kart goruntusu SBSwitcherSnapshotImageView'in UIImage'i (DSC 17 `image`, b21 olcumu:
// kart yapisi ...ReusableSnapshotView > ... > SBSwitcherSnapshotImageView). snapshotViewAfterScreenUpdates CANLI yansima:
// yeni acilmis uygulamanin karti sonra degisince kasada blur/siyah kaliyordu (kullanici, RootHide). Resim yoksa ya da
// imza tutmazsa canli yansimaya dusulur.
static UIView *ka_kartResmi(UIView *kart) {
    NSMutableArray<UIView *> *q = [NSMutableArray arrayWithObject:kart];
    for (int adim = 0; q.count && adim < 160; adim++) {
        UIView *v = q.firstObject; [q removeObjectAtIndex:0];
        if ([NSStringFromClass([v class]) isEqualToString:@"SBSwitcherSnapshotImageView"]) {
            Method m = class_getInstanceMethod(object_getClass(v), @selector(image));
            if (!m || strcmp(method_getTypeEncoding(m), "@16@0:8")) break;
            id r = ((id (*)(id, SEL))objc_msgSend)(v, @selector(image));
            if (![r isKindOfClass:[UIImage class]]) break;
            UIImageView *iv = [[UIImageView alloc] initWithFrame:v.bounds];
            iv.image = r;
            iv.contentMode = UIViewContentModeScaleAspectFill;
            iv.clipsToBounds = YES;
            return iv;
        }
        [q addObjectsFromArray:v.subviews];
    }
    return nil;
}
static UIView *ka_sayfaBul(UIView *kart) {
    UIView *sayfa = nil;
    NSMutableArray<UIView *> *kuyruk = [NSMutableArray arrayWithObject:kart];
    for (int adim = 0; kuyruk.count && adim < 96; adim++) {
        UIView *v = kuyruk.firstObject; [kuyruk removeObjectAtIndex:0];
        NSString *ad = NSStringFromClass([v class]);
        if (v != kart && [ad isEqualToString:@"SBAppSwitcherReusableSnapshotView"]) return v;
        if (v != kart && !sayfa && [ad isEqualToString:@"SBAppSwitcherPageView"]) sayfa = v;
        [kuyruk addObjectsFromArray:v.subviews];
    }
    return sayfa ?: kart;
}
// m18: gercek kartin ic kaydirma ofsetini surukleme oncesine dondur (kayitli
// NSValue, kKA_KartAsagiGizliKey). m16'nin maskesi ve m15'in hidden'i kalkti:
// karta artik gorunurluk olarak hic dokunulmuyor.
static UIScrollView *ka_kaydirmaBul(UIView *kart);   // asagida tanimli
static void ka_kartOfsetGeri(UIView *kart, BOOL animasyonlu) {
    NSValue *v = kart ? objc_getAssociatedObject(kart, kKA_KartAsagiGizliKey) : nil;
    if (![v isKindOfClass:[NSValue class]]) return;
    objc_setAssociatedObject(kart, kKA_KartAsagiGizliKey, nil, OBJC_ASSOCIATION_RETAIN);
    [ka_kaydirmaBul(kart) setContentOffset:v.CGPointValue animated:animasyonlu];
}
static void ka_ofsetleriSifirla(NSString *neden) {
    if (!kaOfsetliKartlar.count) return;
    NSUInteger n = 0;
    for (UIView *k in [kaOfsetliKartlar allObjects]) { ka_kartOfsetGeri(k, NO); n++; }
    [kaOfsetliKartlar removeAllObjects];
    ka_logText([NSString stringWithFormat:@"ofset-sifirlandi %@ n=%lu", neden, (unsigned long)n]);
}
// 0.7: yalniz tercih listesi. Gizleme isi tercih degisince kas_esitle'de (Apple'in bayragi, KASGizle.m);
// 0.6.0'in m28/m31/m35 yardimcilari KASGizle.m'ye tasindi (kas_kartiKaldir).
static void ka_gizliyeEkle(NSString *bid) {
    NSMutableArray *l = [(ka_prefArray(kKA_KeyGizli) ?: @[]) mutableCopy];
    if (!bid.length || [l containsObject:bid]) return;
    [l addObject:bid];
    CFPreferencesSetAppValue((__bridge CFStringRef)kKA_KeyGizli, (__bridge CFArrayRef)l, (__bridge CFStringRef)kKA_AlanAdi);
    CFPreferencesAppSynchronize((__bridge CFStringRef)kKA_AlanAdi);
    notify_post([kKA_Bildirim UTF8String]);
    ka_logText([NSString stringWithFormat:@"asagi-gizlendi %@ liste=%lu", bid, (unsigned long)l.count]);
}
// m22 ISTEK: kasadan karti asagi atinca gizli bolumden cikar (ayni tercih yolu).
static void ka_gizlidenCikar(NSString *bid) {
    NSMutableArray *l = [(ka_prefArray(kKA_KeyGizli) ?: @[]) mutableCopy];
    if (!bid.length || ![l containsObject:bid]) return;
    [l removeObject:bid];
    CFPreferencesSetAppValue((__bridge CFStringRef)kKA_KeyGizli, (__bridge CFArrayRef)l, (__bridge CFStringRef)kKA_AlanAdi);
    CFPreferencesAppSynchronize((__bridge CFStringRef)kKA_AlanAdi);
    notify_post([kKA_Bildirim UTF8String]);
    ka_logText([NSString stringWithFormat:@"gizliden-cikti %@ liste=%lu", bid, (unsigned long)l.count]);
}
@interface KAKartAsagi : NSObject <UIGestureRecognizerDelegate>
// m18: KOPYA YOK - gercek kart. Kartin icindeki kaydirma gorunumu
// (SBFluidSwitcherTouchPassThroughScrollView, olcum m16: 393x1278, sayfa 426'da;
// sistemin yukari atarak kapatmasi bunu kaydiriyor) ters yone kaydirilir.
@property (nonatomic, weak) UIScrollView *kaydirma;
@property (nonatomic, assign) CGPoint basOfset;
@property (nonatomic, assign) BOOL olculdu;          // ilk degisimde sistem ofseti geri yaziyor mu
@property (nonatomic, assign) NSInteger adim;        // m20 olcum: ilk adimlar
@property (nonatomic, strong) UIView *kasaGorseli;   // kasadaki kart icin (kirpmanin icinden, m17)
@end
static UIScrollView *ka_kaydirmaBul(UIView *kart) {
    NSMutableArray<UIView *> *kuyruk = [NSMutableArray arrayWithObject:kart];
    UIScrollView *herhangi = nil;
    for (int adim = 0; kuyruk.count && adim < 64; adim++) {
        UIView *v = kuyruk.firstObject; [kuyruk removeObjectAtIndex:0];
        if ([v isKindOfClass:[UIScrollView class]]) {
            if ([NSStringFromClass([v class]) isEqualToString:@"SBFluidSwitcherTouchPassThroughScrollView"]) return (UIScrollView *)v;
            if (!herhangi) herhangi = (UIScrollView *)v;
        }
        [kuyruk addObjectsFromArray:v.subviews];
    }
    return herhangi;
}
@implementation KAKartAsagi
// m21 YON DEGISIKLIGI (kullanici gozlemi): kartin kaydirma gorunumu asagiyi
// ZATEN destekliyor (yukari baslayinca stok hem yukari hem asagi goturuyor).
// m14-m20'de asagiyi kendimiz surup stoku bekletiyorduk: ilk anda sicrama ve
// titresim. Artik KARTI STOK TASIR (yay/ivme stok); biz yalniz eszamanli
// izleriz ve birakista karar veririz. Her dikey cekiste baslariz (yukari
// baslayip asagi inen de yakalansin); stoku HICBIR SEY beklemez.
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)g {
    if (kaTasimaModu || [KASMenu acik] || [KASKasa acik] || kaUndoAktif) return NO;
    CGPoint v = [(UIPanGestureRecognizer *)g velocityInView:g.view];
    return fabs(v.y) > fabs(v.x);
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)g shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)o {
    return YES;
}
- (void)asagi:(UIPanGestureRecognizer *)g {
    UIView *kart = g.view, *ev = kaButton.superview;
    NSString *bid = kart ? objc_getAssociatedObject(kart, kKA_KartBidKey) : nil;
    if (g.state == UIGestureRecognizerStateBegan) {
        UIScrollView *k = ka_kaydirmaBul(kart);
        self.kaydirma = k; self.basOfset = k.contentOffset; self.olculdu = NO;
        // b24: b23 ekran kesiti GERI ALINDI - ondeki kart destenin en saginda, yarisi ekran disinda (kesit yarisi siyah).
        {   // b30: once uygulamanin on plandaki SAHNESINDEN kendi resmimiz (ondeki canli kart), sonra Apple'in kayitli
            // resmi (b22), son care canli yansima.
            UIImage *sr = kas_sahneResmi(bid);
            UIImageView *sv = nil;
            if (sr) { sv = [[UIImageView alloc] initWithFrame:kart.bounds]; sv.image = sr; sv.contentMode = UIViewContentModeScaleAspectFill; sv.clipsToBounds = YES; }
            self.kasaGorseli = sv ?: ka_kartResmi(kart) ?: [ka_sayfaBul(kart) snapshotViewAfterScreenUpdates:NO];
        }
        if (k) objc_setAssociatedObject(kart, kKA_KartAsagiGizliKey, [NSValue valueWithCGPoint:k.contentOffset], OBJC_ASSOCIATION_RETAIN);
        self.adim = 0;
        ka_logText([NSString stringWithFormat:@"asagi-basladi %@ kaydirma=%@ ofset=%.0f,%.0f izliyor=%d",
                    bid, k ? NSStringFromClass([k class]) : @"YOK", k.contentOffset.x, k.contentOffset.y, k.isTracking]);
        return;
    }
    UIScrollView *k = self.kaydirma;
    if (!k) return;
    CGFloat ty = [g translationInView:ev].y;   // m21: isaretli (yukari eksi)
    if (g.state == UIGestureRecognizerStateChanged) {   // m21: karti STOK tasir - biz yalniz olceriz
        if (self.adim++ < 3)
            ka_logText([NSString stringWithFormat:@"asagi-adim %ld ty=%.0f ofset=%.0f izliyor=%d", (long)self.adim, ty, k.contentOffset.y, k.isTracking]);
        return;
    }
    if (g.state != UIGestureRecognizerStateEnded && g.state != UIGestureRecognizerStateCancelled) return;
    self.kaydirma = nil;
    CGPoint bas = self.basOfset;
    // m21: karar KARTIN konumuna gore (stok yay nedeniyle kart parmaktan az iner).
    // Esikler ilk deneme - degerler loglanir (DOGRULANMADI).
    CGFloat inis = bas.y - k.contentOffset.y, hiz = [g velocityInView:ev].y;
    BOOL at = g.state == UIGestureRecognizerStateEnded && (inis > 50 || (hiz > 800 && inis > 12));
    ka_logText([NSString stringWithFormat:@"asagi-birakti %@ inis=%.0f hiz=%.0f ty=%.0f at=%d", bid, inis, hiz, ty, at]);
    if (!at || !bid.length) {   // vazgecti: stok karti kendi yayiyla yerine dondurur
        objc_setAssociatedObject(kart, kKA_KartAsagiGizliKey, nil, OBJC_ASSOCIATION_RETAIN);
        return;
    }
    // 0.7: kart stok yoldan kaldirilir ve Apple'in bayragiyla gizlenir (KASGizle, REPORTS/06 §7.1).
    // Ondeki uygulamada Apple arkayi ana ekrana ceviriyor; o bos-layout "ana ekrana donus" sayilmasin (m34).
    if (self.kasaGorseli) {   // kasada gercek icerik gorunsun
        if (!kaGizliGorseller) { kaGizliGorseller = [NSMutableDictionary dictionary]; kaGizliGorselZaman = [NSMutableDictionary dictionary]; }
        kaGizliGorseller[bid] = self.kasaGorseli;
    }
    NSString *ondeBid = nil;
    BOOL onde = ka_appOnPlanda(&ondeBid) && [ondeBid isEqualToString:bid];
    kaOndeSilmeMs = ka_msNow();   // b6: her kaldirmada (onde tahmini gec kalabiliyor) - ardindan gelen bos-layout ana ekran sayilmaz
    BOOL stok = kas_kartiKaldir(kart, bid, onde);
    // b31: sahneden alinan tam goruntu (varsa), Apple kendi resmini yazdiktan sonra Apple'in deposuna
    { NSString *b31 = [bid copy];
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ kas_appleDeposunaYaz(b31); }); }
    ka_gizliyeEkle(bid);   // tercih listesi (zaten listedeyse dokunmaz)
    if (stok) {
        objc_setAssociatedObject(kart, kKA_KartAsagiGizliKey, nil, OBJC_ASSOCIATION_RETAIN);
        UIView *hap = kaGizliBtn;
        if (hap) { hap.hidden = NO; hap.alpha = kaButton.alpha; }
        CAKeyframeAnimation *z = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];
        z.values = @[@1, @1.25, @0.94, @1]; z.duration = 0.4;
        [hap.layer addAnimation:z forKey:@"ka-zipla"];
        [[UINotificationFeedbackGenerator new] notificationOccurred:UINotificationFeedbackTypeSuccess];
        return;
    }
    kas_gizle(bid);   // yedek yol (stok imza tutmadi): yalniz Apple'in bayragi; kart liste yenilenince gider
    UIView *hap = kaGizliBtn;
    if (hap) { hap.hidden = NO; hap.alpha = kaButton.alpha; }
    // gercek kart asagi kayip ekrandan cikar; liste yenilenince sistem karti kaldirir.
    // m21: stokun birakis isi (geri yaylanma) bizden sonra baslayabilir - bir
    // sonraki turda once onu durdur (ayni konuma animasyonsuz), sonra asagi gonder.
    dispatch_async(dispatch_get_main_queue(), ^{
        // m24 ISTEK "hala sert" (m23 yayi fark edilmedi): kendi animasyonumuz
        // yerine kaydirma gorunumunun KENDI animasyonu - stok egri (stoku oynat,
        // taklit etme: ActionButtonFix 4b). Bitis zamani stok ~0,3 sn.
        [k setContentOffset:CGPointMake(bas.x, bas.y - ev.bounds.size.height) animated:YES];
        (void)inis; (void)hiz;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            ka_logText(@"asagi-bitti stok-animasyon");
            CAKeyframeAnimation *z = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];
            z.values = @[@1, @1.25, @0.94, @1]; z.duration = 0.4;
            [hap.layer addAnimation:z forKey:@"ka-zipla"];
            [[UINotificationFeedbackGenerator new] notificationOccurred:UINotificationFeedbackTypeSuccess];
        });
    });
    // m15: kap normalde prepareForReuse'da acilir. Yalniz kart HALA ekranda ve
    // ayni uygulamayi gosteriyorsa (gizleme olmadi, or. ondeki uygulama) burada ac.
    // Havuzdaki kaba (pencere yok) DOKUNMA.
    __weak UIView *zk = kart;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UIView *kk = zk;
        if (!kk || !objc_getAssociatedObject(kk, kKA_KartAsagiGizliKey)) return;
        BOOL ayni = [ka_kartinBid(kk) isEqualToString:bid];
        ka_logText([NSString stringWithFormat:@"asagi-kontrol %@ pencere=%d ayni=%d", bid, kk.window != nil, ayni]);
        // m25: kart kalmis = ondeki uygulama (switcher listeden degil baska kaynaktan
        // gosteriyor). Uygulama kasada; kart ekran disinda BIRAKILIR (geri kaydirma yok).
        if (kk.window && ayni) {
            if (!kaOfsetliKartlar) kaOfsetliKartlar = [NSHashTable weakObjectsHashTable];
            [kaOfsetliKartlar addObject:kk];
            ka_logText([NSString stringWithFormat:@"ondeki-kart-ekran-disinda %@", bid]);
        }
    });
}
@end

static void ka_kartInteractionKur(UIView *kart, NSString *bid) {
    @try {
        objc_setAssociatedObject(kart, kKA_KartBidKey, bid, OBJC_ASSOCIATION_COPY);
        // m14: asagi atarak gizle - kart yeniden kullanilir, bir kez kurulur
        if (!objc_getAssociatedObject(kart, kKA_KartAsagiKey)) {
            KAKartAsagi *a = [KAKartAsagi new];
            UIPanGestureRecognizer *p = [[UIPanGestureRecognizer alloc] initWithTarget:a action:@selector(asagi:)];
            p.delegate = a;
            [kart addGestureRecognizer:p];
            objc_setAssociatedObject(kart, kKA_KartAsagiKey, @[a, p], OBJC_ASSOCIATION_RETAIN);
        }
        if (kKA_Teshis) return;   // m17 teshis: karttaki basili tutma (sabitle) kurulmaz
        if (objc_getAssociatedObject(kart, kKA_KartLongPressKey)) return; // zaten eklenmis
        KAKartLongPressHandler *h = [KAKartLongPressHandler new];
        UILongPressGestureRecognizer *lp = [[UILongPressGestureRecognizer alloc]
            initWithTarget:h action:@selector(ka_longPress:)];
        lp.minimumPressDuration = 0.8;  // b16: 0.55 -> 0.8 (asagi atma suruklemeyle baslar; 10 pt kayma basili tutmayi iptal eder)
        lp.delegate = h;
        lp.cancelsTouchesInView = YES;
        lp.delaysTouchesEnded = YES;
        [kart addGestureRecognizer:lp];

        // Kartin KENDI tap tanimalarini (action=_handlePageViewTap:) bul,
        // bizim uzun basmamiz basarisiz olana kadar beklet.
        NSUInteger bulunan = 0;
        for (UIGestureRecognizer *diger in kart.gestureRecognizers) {
            if (diger == lp) continue;
            if ([diger isKindOfClass:[UITapGestureRecognizer class]]) {
                [diger requireGestureRecognizerToFail:lp];
                bulunan++;
            }
        }
        ka_logText([NSString stringWithFormat:@"kartInteractionKur tapBulundu=%lu", (unsigned long)bulunan]);

        // h VE lp gesture ile hayatta tutulur (target zayif referans);
        // birlikte tek associated object olarak kalmalari icin dizi kullan.
        objc_setAssociatedObject(kart, kKA_KartLongPressKey, @[h, lp], OBJC_ASSOCIATION_RETAIN);
    } @catch (__unused NSException *e) { ka_logText(@"kartInteractionKur-exception"); }
}

// 0.6.0 ka_switcherYenile KALDIRILDI (0.7): liste yenileme KASGizle.m'de (kas_yenile / Apple'in rebuild'i).
// Kasa butonu: kilitli kart yigini + acik gizli uygulama sayisi.
static UILabel *kaGizliSayiEtiket;
static void ka_gizliBtnGuncelle(void) {
    kaGizliBidler = kas_kasaBidleri(kaPrefGizli);   // 0.7: kasa icerigi Apple'in modelinden (gizli bayrakli + listede)
    if (!kaGizliIkon) return;
    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:round(14 * kaHapK)
                                                                                      weight:UIImageSymbolWeightSemibold];   // m12
    kaGizliIkon.image = [UIImage systemImageNamed:@"lock.rectangle.stack.fill" withConfiguration:cfg];
    NSUInteger n = kaGizliBidler.count;
    NSString *yeniSayi = n ? [NSString stringWithFormat:@"%lu", (unsigned long)n] : @"";
    // b20: sayi DEGISINCE rakam kayarak degisir + hafif buyuyup oturur (yalniz gorunurken; public CATransition)
    if (kaGizliSayiEtiket.text.length && ![kaGizliSayiEtiket.text isEqualToString:yeniSayi] && kaGizliSayiEtiket.window && !kaGizliBtn.hidden) {
        CATransition *gc = [CATransition animation];
        gc.type = kCATransitionPush;
        gc.subtype = (yeniSayi.integerValue > kaGizliSayiEtiket.text.integerValue) ? kCATransitionFromTop : kCATransitionFromBottom;
        gc.duration = 0.25;
        gc.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
        [kaGizliSayiEtiket.layer addAnimation:gc forKey:@"ka-sayi"];
        CAKeyframeAnimation *bz = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];
        bz.values = @[@1, @1.3, @1]; bz.duration = 0.3;
        [kaGizliSayiEtiket.layer addAnimation:bz forKey:@"ka-sayi-buyu"];
    }
    kaGizliSayiEtiket.text = yeniSayi;
}
// Kartin su anki bid'i (kart hook'undaki yolun aynisi).
static NSString *ka_kartinBid(UIView *sv) {
    id al = [sv respondsToSelector:@selector(appLayout)] ? [sv performSelector:@selector(appLayout)] : nil;
    if (!al || ![al respondsToSelector:@selector(allItems)]) return nil;
    for (id item in [al allItems])
        if ([item respondsToSelector:@selector(bundleIdentifier)] && [[item bundleIdentifier] length]) return [item bundleIdentifier];
    return nil;
}
// Gizli kartin goruntusu (m4): snapshotViewAfterScreenUpdates:NO kopyasi,
// 0,4 sn sonra (ilk layout'ta icerik henuz cizilmemis olabilir), en fazla
// 1 sn'de bir. Kart yeniden kullanilir: ateslenince bid hala ayni mi bak.
// m21: kartin icerik gorunumu (SBAppSwitcherPageView) - kilit ortusu kabin
// dogrudan alt gorunumu oldugu icin bunun kopyasina girmez.
static UIView *ka_sayfaGorunumu(UIView *kart) {
    NSMutableArray<UIView *> *kuyruk = [NSMutableArray arrayWithObject:kart];
    for (int adim = 0; kuyruk.count && adim < 64; adim++) {
        UIView *v = kuyruk.firstObject; [kuyruk removeObjectAtIndex:0];
        if (v != kart && [NSStringFromClass([v class]) isEqualToString:@"SBAppSwitcherPageView"]) return v;
        [kuyruk addObjectsFromArray:v.subviews];
    }
    return kart;
}
// (m21 kilit ortusu GERI ALINDI - m22: kart kabi uygulamaya gecerken uygulamanin
// kendisi olarak buyutuluyor; kaba eklenen ortu acilan uygulamanin onunde kaldi)
static void ka_gizliGorselYakala(NSString *bid, UIView *kart) {
    if (!bid || !kart.window || kart.bounds.size.width < 10) return;
    if (!kaGizliGorseller) { kaGizliGorseller = [NSMutableDictionary dictionary]; kaGizliGorselZaman = [NSMutableDictionary dictionary]; }
    double simdi = CACurrentMediaTime();
    if (simdi - [kaGizliGorselZaman[bid] doubleValue] < 1.0) return;
    kaGizliGorselZaman[bid] = @(simdi);
    __weak UIView *zk = kart;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        @try {
            UIView *k = zk;
            if (!k.window || k.alpha < 0.5) { ka_logText([NSString stringWithFormat:@"gizli-gorsel-atla %@ pencere=%d", bid, k.window != nil]); return; }
            if (![ka_kartinBid(k) isEqualToString:bid]) { ka_logText(@"gizli-gorsel-atla yeniden-kullanim"); return; }
            UIView *g = ka_kartResmi(k) ?: [ka_sayfaGorunumu(k) snapshotViewAfterScreenUpdates:NO];   // b22: once sabit resim; m21 yedek
            if (g) kaGizliGorseller[bid] = g;
            ka_logText([NSString stringWithFormat:@"gizli-gorsel %@ ok=%d %.0fx%.0f", bid, g != nil, g.bounds.size.width, g.bounds.size.height]);
        } @catch (__unused NSException *e) { ka_logText(@"gizli-gorsel-exception"); }
    });
}
// m5: kasanin konagi kendi penceresinde, switcher penceresinin bir ustunde.
// Konak = switcher gorunumunun boyu + acisi (yatayda pencere donmuyor,
// icerik transform ile donuyor - 0.4.4 olcumu). rootViewController yok:
// SpringBoard'da kendi basina donmeye kalkmasin.
static UIView *ka_kasaKonak(UIView *v) {
    UIWindowScene *sc = v.window.windowScene;
    if (!sc) return nil;
    if (!kaKasaPencere) {
        kaKasaPencere = [[UIWindow alloc] initWithWindowScene:sc];
        kaKasaPencere.backgroundColor = [UIColor clearColor];
    }
    kaKasaPencere.windowLevel = v.window.windowLevel + 1;
    kaKasaPencere.frame = v.window.frame;
    CGPoint o = [v convertPoint:CGPointZero toView:nil];
    CGPoint x = [v convertPoint:CGPointMake(1, 0) toView:nil];
    CGPoint c = [v convertPoint:CGPointMake(CGRectGetMidX(v.bounds), CGRectGetMidY(v.bounds)) toView:nil];
    UIView *h = [[UIView alloc] initWithFrame:CGRectMake(0, 0, v.bounds.size.width, v.bounds.size.height)];
    h.transform = CGAffineTransformMakeRotation(atan2(x.y - o.y, x.x - o.x));
    h.center = c;
    [kaKasaPencere addSubview:h];
    kaKasaPencere.hidden = NO;
    ka_logText([NSString stringWithFormat:@"kasa-pencere seviye=%.0f %.0fx%.0f aci=%.2f", kaKasaPencere.windowLevel,
                v.bounds.size.width, v.bounds.size.height, atan2(x.y - o.y, x.x - o.x)]);
    return h;
}
static void ka_kasaPencereKapat(void) {
    for (UIView *s in [kaKasaPencere.subviews copy]) [s removeFromSuperview];
    kaKasaPencere.hidden = YES;
}
static void ka_kasaAc(void) {
    kaGizliBidler = kas_kasaBidleri(kaPrefGizli);   // 0.7
    if (!kaGizliBidler.count) {
        ka_kartBildirimGoster(kaGizliBtn ?: kaButton, ka_L(@"Gizli bölümde açık uygulama yok"));
        ka_logText(@"kasa bos");
        return;
    }
    NSMutableArray *ogeler = [NSMutableArray array];
    for (NSString *bid in kaGizliBidler) {
        KASKasaOge *o = [KASKasaOge new];
        o.bid = bid;
        o.ad = ka_displayName(bid) ?: bid;
        o.gorunum = kaGizliGorseller[bid];
        o.sabit = ka_sabitliMi(bid);   // b16
        [ogeler addObject:o];
    }
    ka_logText([NSString stringWithFormat:@"kasa-ac n=%lu gorselli=%lu kilit=%d dogrulandi=%d", (unsigned long)ogeler.count,
                (unsigned long)kaGizliGorseller.count, kaPrefKasaKilit, [KASKasa dogrulandi]]);
    UIView *kb = kaButton, *gb = kaGizliBtn;
    // m14: "her acilista sor" - onceki dogrulama sayilmaz (donmus goruntu
    // karari asagida dogrulandi'ya bakar: once oturum kapanmali)
    if (kaPrefKilitHer) [KASKasa oturumuKapat];
    if (kaPrefKilitDakika && ka_msNow() - kaSonDogrulamaMs > 60000) [KASKasa oturumuKapat];   // b17
    // b1: donmus goruntu (m11) ve "sahipsiz kasa" (m5/m14) KALDIRILDI - kasa switcher'dan bagimsiz: switcher'in
    // kapanmasi (Face ID dahil) kasayi kapatmaz (ka_butonGizle kasaya dokunmuyor).
    // b4: 0.6.0 m11 cozumu GERI (b1'de yanlislikla kalkmisti): Face ID okurken CoreAuthUI switcher'i kapatiyor, blurun
    // arkasinda son uygulama / ana ekran gorunuyordu. Dogrulama gerekecekse ekranin donmus goruntusu kasa penceresinin
    // en altina; switcher yeniden acilinca (b3) ya da kasa kapaninca / uygulama acilinca kalkar. Acik API.
    UIView *donmus = (kaPrefKasaKilit && ![KASKasa dogrulandi]) ? [[UIScreen mainScreen] snapshotViewAfterScreenUpdates:NO] : nil;
    UIView *konak = ka_kasaKonak(kaButton.superview);
    if (!konak) { ka_logText(@"kasa-konak-yok"); return; }
    if (donmus && kaKasaPencere) {
        donmus.frame = kaKasaPencere.bounds;
        donmus.userInteractionEnabled = NO;
        [kaKasaPencere insertSubview:donmus atIndex:0];
    }
    __weak UIView *zDonmus = donmus;
    ka_logText([NSString stringWithFormat:@"kasa-donmus %d", donmus != nil]);
    [KASKasa temaAyarla:kaPrefTema];   // m6: neon / cuzdan kasanin yapisini da degistirir
    [KASKasa gizlidenCikarinca:^(NSString *bid) { ka_gizlidenCikar(bid); }];   // m22
    // b3: Face ID / parola arayuzu (CoreAuthUI) one gecince sistem switcher'i kapatiyor ve geri acmiyor (3 Eki RootHide
    // olcumu; 0.6.0 m14'teki "kendiliginden geri geliyor" artik tutmuyor). Basarili dogrulamadan sonra kasa hala acik ve
    // switcher kapaliysa switcher stok istekle yeniden acilir (kasa kendi penceresinde ustte kalir).
    [KASKasa dogrulamaBitince:^(BOOL ok) {
        ka_logText([NSString stringWithFormat:@"kasa-dogrulama ok=%d", ok]);
        if (!ok) return;
        kaSonDogrulamaMs = ka_msNow();   // b17
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            SBMainSwitcherControllerCoordinator *co = [%c(SBMainSwitcherControllerCoordinator) sharedInstanceIfExists];
            BOOL gorunur = co && [co isAnySwitcherVisible];   // yoklamanin kullandigi ayni cagri (OLCUM-m3)
            ka_logText([NSString stringWithFormat:@"kasa-dogrulama-sonrasi kasa=%d switcher=%d", [KASKasa acik], gorunur]);
            if ([KASKasa acik] && !gorunur) kas_switcheriAc();
            // b4: canli switcher geri geldi - donmus goruntu yumusakca kalkar
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                UIView *d = zDonmus;
                [UIView animateWithDuration:0.25 animations:^{ d.alpha = 0; } completion:^(BOOL f) { [d removeFromSuperview]; }];
            });
        });
    }];
    [KASKasa gosterIcinde:konak ogeler:ogeler kilitli:kaPrefKasaKilit ac:^(NSString *bid) {
        kaKasaUygulamaya = YES;
        BOOL ok = NO;
        @try { ok = [(SpringBoard *)[UIApplication sharedApplication] launchApplicationWithIdentifier:bid suspended:NO]; }
        @catch (__unused NSException *e) {}
        ka_logText([NSString stringWithFormat:@"kasa-uygulama-ac %@ ok=%d", bid, ok]);
    } kapat:^(NSString *bid) {
        // b6: gizli bayrakli duzeni deleteAppLayoutForDisplayItem: silmiyor (uygulama kasaya geri donuyordu) - once bayrak
        // kalkar, sonra silinir. Tercih listesi degismez; yeniden acilirsa willAdd yine gizli ekler.
        // b15: kart switcher'da GORUNURSE (ondeki uygulama) Apple'in silme hatti - kart Apple'in animasyonuyla gider
        // (b12 yolunda surec olunce kart kararip kendiliginden kayboluyordu, RootHide). Gorunur karti yoksa b12 yolu.
        if (kas_gorunumdeVar(bid) || !kas_kasadanKapat(bid)) {
            kas_gosterSessiz(bid);   // b9: arada yenileme yok - kart hic gorunur olmaz
            ka_birTaneSil(bid);
        }
        ka_logText([NSString stringWithFormat:@"kasa-kapat %@", bid]);
    } kapaninca:^{
        ka_logText([NSString stringWithFormat:@"kasa-kapandi uygulamaya=%d", kaKasaUygulamaya]);
        ka_kasaPencereKapat();
        // b2: switcher kasanin arkasinda acik kalir (kullanici karari 3 Eki) - uygulama secilmeden kapandiysa X ve
        // kasa butonu geri gelir. Kilit oturumu kasa kapaninca biter.
        if (!kaKasaUygulamaya) ka_butonGoster(kaButton);
        // b13: kasa bos + switcher'da gorunur kart yok -> b7 bos switcher'i acik tutmustu, Apple'in kapatma istegi
        // b12'den beri (silme hatti yok) gelmiyor: switcher'i Apple'in "kart kalmadi" istegiyle bir kez kapat.
        if (!kaKasaUygulamaya && kas_gorunurKartSayisi() == 0 && !kas_kasaBidleri(kaPrefGizli).count) kas_switcheriAnaEkranaKapat();
        if (kaPrefKilitHer) [KASKasa oturumuKapat];   // b5: "her acilista"; "switcher kapanana kadar" ka_butonGizle'de
        kaKasaUygulamaya = NO;
    } gunluk:^(NSString *satir) { ka_logText(satir); }];
    if (![KASKasa acik]) { ka_kasaPencereKapat(); return; }
    // m4: kasa acikken X ve kasa butonu gorunmez (ka_butonGoster da bekler).
    [kb.layer removeAllAnimations];
    kaAnimSuruyor = NO;
    [UIView animateWithDuration:0.2 animations:^{ kb.alpha = 0; gb.alpha = 0; }
                     completion:^(BOOL f) { if ([KASKasa acik]) { kb.hidden = YES; gb.hidden = YES; } }];
}
static void ka_gizliModDegistir(void) { ka_kasaAc(); }   // kasa butonu
// Idempotent kasa kapatma (0.7: switcher kapanisi artik kasaya dokunmuyor).
static void ka_gizliModKapat(void) {
    if ([KASKasa acik]) [KASKasa kapat:NO];
}

// b1 GUVENLIK: kasa artik switcher'la kapanmiyor - cihaz kilitlenince kasa kapanir ve dogrulama oturumu biter
// (0.6.0'da bunu switcher'in kapanmasi dolayli yapiyordu). SpringBoard'un kilit bildirimi.
static void ka_kilitCB(CFNotificationCenterRef c, void *o, CFStringRef n, const void *x, CFDictionaryRef u) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([KASKasa acik]) ka_logText(@"kasa-kilitte-kapandi");
        ka_gizliModKapat();
        [KASKasa oturumuKapat];
    });
}

static void ka_kancalariKur(void);   // 0.6.0 - dosyanin sonunda (Logos %init sirasi)

%ctor {
    @try {
        ka_prefsYukle();
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                        NULL,
                                        ka_prefsBildirimCB,
                                        (__bridge CFStringRef)kKA_Bildirim,
                                        NULL,
                                        CFNotificationSuspensionBehaviorDeliverImmediately);
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, ka_kilitCB,
                                        CFSTR("com.apple.springboard.lockcomplete"), NULL,
                                        CFNotificationSuspensionBehaviorDeliverImmediately);   // b1
    } @catch (__unused NSException *e) {}
    // 0.6.0: tum %init'ler dosyanin sonunda (ka_kancalariKur)
    ka_kancalariKur();
}

%hook SBFluidSwitcherViewController

- (void)viewDidLayoutSubviews {
    %orig;

    // ISTEK (0.3.4): genel etkin/devre disi anahtari. Butonu VARSA gizle
    // ve cik - yeni buton OLUSTURMA, diger hook'lara (kart selale/sabitleme)
    // DOKUNMA. Boylece kapatilinca sadece gorunur buton kaybolur, tweak'in
    // digger davranislari (0.3.2'den kalan) etkilenmez.
    if (!kaPrefEtkin) {
        if (kaButton && !kaButton.hidden) kaButton.hidden = YES;
        return;
    }

    // Menu acikken (KASMenu) layout'u beklet; menu kapaninca bekleyen
    // guncelleme yapilir (ka_uzunBas kapaninca). 0.5.0: sistem menusu ve
    // onun "buyume" bayragi (kaKaldirma) kalkti.
    if (menuAcik) {
        bekleyenGuncelleme = YES;
        ka_log(@"layout-atlandi", kaButton);
        return;
    }

    if (!kaButton) {
        UIView *kap = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 38, 38)];
        // 0.4.4 cam: zemin rengi kaCam'in tonunda, kapta yalniz kenar + golge.
        kap.backgroundColor = [UIColor clearColor];
        kap.layer.borderWidth = 0.5;
        kap.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.25].CGColor;
        kap.layer.cornerRadius = 19;
        kap.layer.masksToBounds = NO;
        kap.layer.shadowColor = [UIColor blackColor].CGColor;
        kap.layer.shadowOpacity = kKA_ShadowOpacity;
        kap.layer.shadowRadius = kKA_ShadowRadius;
        kap.layer.shadowOffset = CGSizeMake(kKA_ShadowOffsetX, kKA_ShadowOffsetY);
        kap.translatesAutoresizingMaskIntoConstraints = NO;
        kap.userInteractionEnabled = YES;
        // DUZELTME (0.4.3): respring sonrasi ilk acilista buton, switcher
        // gorunumu kaydirma baslarken yuklendigi icin GORUNUR olusuyor,
        // ilk yoklama (isAnySwitcherVisible=0) onu hemen gizliyordu -
        // tek seferlik "gelip gitme". Gizli basla; gercek acilista
        // ka_butonGoster her zamanki gibi getirir.
        kap.hidden = YES;
        kap.alpha = 0.0;

        // 0.4.4: cam zemin (en altta) + SF Symbol xmark. Boyut, kose ve
        // simge ka_boyutUygula'da; ton ka_zeminAyarla'da.
        UIVisualEffectView *cam = [[UIVisualEffectView alloc] initWithEffect:
            [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark]];
        cam.userInteractionEnabled = NO;
        cam.clipsToBounds = YES;
        cam.layer.cornerRadius = 19;
        cam.translatesAutoresizingMaskIntoConstraints = NO;
        [kap addSubview:cam];
        UIImageView *ikon = [UIImageView new];
        ikon.tintColor = [UIColor whiteColor];
        ikon.contentMode = UIViewContentModeCenter;
        ikon.userInteractionEnabled = NO;
        ikon.translatesAutoresizingMaskIntoConstraints = NO;
        [kap addSubview:ikon];
        [NSLayoutConstraint activateConstraints:@[
            [cam.topAnchor constraintEqualToAnchor:kap.topAnchor],
            [cam.bottomAnchor constraintEqualToAnchor:kap.bottomAnchor],
            [cam.leftAnchor constraintEqualToAnchor:kap.leftAnchor],
            [cam.rightAnchor constraintEqualToAnchor:kap.rightAnchor],
            [ikon.centerXAnchor constraintEqualToAnchor:kap.centerXAnchor],
            [ikon.centerYAnchor constraintEqualToAnchor:kap.centerYAnchor],
        ]];
        kaCam = cam;
        kaXIkon = ikon;
        ka_zeminAyarla(NO);

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
            initWithTarget:self action:@selector(ka_tap:)];
        [kap addGestureRecognizer:tap];

        kaButton = kap;
        ka_log(@"buton-oluşturuldu", kaButton);
    }

    UIView *v = self.view;
    if (kaButton.superview != v) {
        [v addSubview:kaButton];
        kaBtnW = [kaButton.widthAnchor constraintEqualToConstant:38];
        kaBtnH = [kaButton.heightAnchor constraintEqualToConstant:38];
        [NSLayoutConstraint activateConstraints:@[kaBtnW, kaBtnH]];
        kaBtnX = nil;
        kaBtnY = nil;
        kaBtnYon = -1;
        kaBoyutKirli = YES;   // kayitli boyutu asagida uygula
        ka_log(@"buton-eklendi", kaButton);
    }

    // 0.4.4: boyut degistiyse (prefs ya da ilk ekleme) once boyut, sonra
    // konum (ka_boyutUygula kaKonumKirli'yi kaldirir). Tasirken bekler.
    if (kaBoyutKirli && !kaTasimaModu) ka_boyutUygula();

    // m4 ISTEK: X'teki sayac rozeti kaldirildi (kaSayac artik olusmuyor;
    // fonksiyonu da silindi).

    // 0.6.0: gizli bolum butonu - X'in sagi (sag kenara yakinsa solu), X'e kisitli
    static NSLayoutConstraint *kaGizliSag, *kaGizliSol;
    if (!kaGizliBtn) {
        // v2: "kasa" hapi 64x36 - cam + civit tonu, solda simge, sagda sayi
        UIView *gb = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 64, 36)];
        gb.translatesAutoresizingMaskIntoConstraints = NO;
        gb.layer.cornerRadius = 18;
        gb.layer.cornerCurve = kCACornerCurveContinuous;
        gb.layer.borderWidth = 0.75;
        gb.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.35].CGColor;
        gb.clipsToBounds = YES;
        gb.hidden = YES;   // X gibi GIZLI dogar (0.4.3 dersi)
        gb.alpha = 0.0;
        UIVisualEffectView *c = [[UIVisualEffectView alloc] initWithEffect:
            [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark]];
        c.frame = gb.bounds;
        c.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        c.userInteractionEnabled = NO;
        [gb addSubview:c];
        UIView *ton = [[UIView alloc] initWithFrame:gb.bounds];
        ton.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        ton.backgroundColor = [[UIColor systemIndigoColor] colorWithAlphaComponent:0.38];
        ton.userInteractionEnabled = NO;
        [gb addSubview:ton];
        UIImageView *ik = [[UIImageView alloc] initWithFrame:CGRectMake(8, 0, 28, 36)];
        ik.contentMode = UIViewContentModeCenter;
        ik.tintColor = [UIColor whiteColor];
        [gb addSubview:ik];
        UILabel *sy = [[UILabel alloc] initWithFrame:CGRectMake(36, 0, 20, 36)];
        sy.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightBold];
        sy.textColor = [UIColor whiteColor];
        sy.textAlignment = NSTextAlignmentCenter;
        [gb addSubview:sy];
        kaGizliSayiEtiket = sy;
        [gb addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ka_gizliTap:)]];
        kaGizliBtn = gb;
        kaGizliIkon = ik;
        kaGizliCam = c; kaGizliTon = ton; kaGizliYazi = sy;   // m5 tema
        ka_hapBoyutla();   // m12: kayitli buton boyutuna gore (temayi da uygular)
        ka_gizliBtnGuncelle();
    }
    if (kaGizliBtn.superview != v) {
        [v addSubview:kaGizliBtn];
        kaGizliSag = [kaGizliBtn.leftAnchor constraintEqualToAnchor:kaButton.rightAnchor constant:12];
        kaGizliSol = [kaGizliBtn.rightAnchor constraintEqualToAnchor:kaButton.leftAnchor constant:-12];
        kaGizliW = [kaGizliBtn.widthAnchor constraintEqualToConstant:ka_hapW()];    // m12: boyutla olceklenir
        kaGizliH = [kaGizliBtn.heightAnchor constraintEqualToConstant:ka_hapH()];
        [NSLayoutConstraint activateConstraints:@[kaGizliW, kaGizliH,
            [kaGizliBtn.centerYAnchor constraintEqualToAnchor:kaButton.centerYAnchor], kaGizliSag]];
    }
    BOOL solda = CGRectGetMaxX(kaButton.frame) + 12 + ka_hapW() > v.bounds.size.width - 8;
    if (solda != kaGizliSol.active) { kaGizliSag.active = !solda; kaGizliSol.active = solda; }
    ka_dokGuncelle(solda);   // m6 cuzdan temasi (diger temalarda gizler)
    ka_gizliBtnGuncelle();   // sayi suzgecle degisir; ucuz (yalniz metin)

    // DUZELTME (0.4.4): yatayda switcher PENCERESI donmuyor (393x852),
    // icerigi bir transform donduruyor; v.safeAreaInsets yatayda da
    // DIKEY degerleri veriyor (t59 b34, OLCUM-g1). "safe alt -64"
    // yatayda butonu kartlarin (y 55-329) ustune koyuyordu. Yatayda
    // safeArea'ya degil v'nin altina bagla; kisit yalniz yon
    // DEGISINCE yeniden kurulur (layout dongusu olusmaz).
    // 0.4.4: kayitli ozel konum da ka_konumKur'da; tasima modu surerken
    // pan kisitlari yonetir, burada DOKUNULMAZ.
    int yon = (v.bounds.size.width > v.bounds.size.height) ? 1 : 0;
    if (yon != kaBtnYon) ka_tasimaBitir();   // tasirken dondu: modu kapat
    if ((yon != kaBtnYon || kaKonumKirli) && !kaTasimaModu) {
        ka_konumKur(v, yon);
    } else if (kaKonumVarsayilan && !kaTasimaModu && kaBtnX && kaBtnX.constant != ka_ciftKaydirma()) {
        kaBtnX.constant = ka_ciftKaydirma();   // b14: kasa butonu gelip gidince cift yeniden ortalanir
    }

    // 0.5.0: sistem menusu (UIContextMenuInteraction) yerine kendi menumuz -
    // basili tutma KASMenu'yu acar. Eski delegate metotlari yerinde ama
    // artik cagrilmiyor (temizlik m3).
    if (!kaInteractionAdded) {
        UILongPressGestureRecognizer *lp = [[UILongPressGestureRecognizer alloc]
            initWithTarget:self action:@selector(ka_uzunBas:)];
        lp.minimumPressDuration = 0.35;
        [kaButton addGestureRecognizer:lp];
        kaUzunBas = lp;
        kaInteractionAdded = YES;
    }

    [v bringSubviewToFront:kaButton];
    // m7 DUZELTME: cuzdan dok'u X'in alt gorunumu; X one gelince dok hapin
    // ustune cikip onu ortuyordu ("once ciziliyor sonra kayboluyor").
    if (kaGizliBtn.superview == v) [v bringSubviewToFront:kaGizliBtn];

    ka_log([NSString stringWithFormat:@"OLCUM-m6 ustview alpha=%.2f hidden=%d win=%d", v.alpha, v.hidden, (v.window!=nil)], nil);
    SBMainSwitcherControllerCoordinator *c = [%c(SBMainSwitcherControllerCoordinator) sharedInstanceIfExists];
    NSString *obid = nil;
    BOOL appOnPlanda = ka_appOnPlanda(&obid);
    BOOL sisVisible = (c && [c isAnySwitcherVisible]);
    ka_log([NSString stringWithFormat:@"OLCUM-m3 ms=%lld isAnySwitcherVisible=%d appOnPlanda=%d bid=%@",
            ka_msNow(), sisVisible, appOnPlanda, obid ?: @"-"], nil);

    // DUZELTME (0.4.2-m3): olcum m2'de appOnPlanda'nin SWITCHER
    // ACIKKEN de YES kaldigi gorulmus (bir app UZERINDE switcher
    // acildiginda altindaki app suspend edilmiyor, isForeground
    // hala YES). appOnPlanda'yi bu durumda ES GECIYORUZ - yalniz
    // sistem switcher'i GORMEDIGI zaman (sisVisible==NO) tek basina
    // otorite: gercek bir app one gectiginde butonu kesin gizler,
    // ama switcher gorunumunu ASLA gecersiz kilmaz.
    if (!sisVisible && appOnPlanda) {
        ka_butonGizle(kaButton);
    } else if (sisVisible) {
        ka_butonGoster(kaButton);
    } else {
        ka_butonGizle(kaButton);
    }
}

// 0.5.0: basili tutma -> kendi menumuz. menuAcik ayni anlamda kalir
// (layout bekletme); kapaninca = eski willEnd completion'in isi.
%new
- (void)ka_uzunBas:(UILongPressGestureRecognizer *)gr {
    if (gr.state != UIGestureRecognizerStateBegan) return;
    if (kaTasimaModu || [KASMenu acik] || !kaButton.superview) return;
    UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
    [g impactOccurred];
    menuAcik = YES;
    ka_log(@"menu-ac", kaButton);
    __weak __typeof(self) weakSelf = self;
    [KASMenu gosterIcinde:kaButton.superview
                   kaynak:kaButton
                      kok:^NSArray<KASMenuOge *> *{ return [weakSelf ka_mKok]; }
                kapaninca:^{
        __strong __typeof(weakSelf) s = weakSelf;
        menuAcik = NO;
        ka_log(@"menu-kapandi", kaButton);
        if (kaTasimaBekliyor) { kaTasimaBekliyor = NO; [s ka_tasimaBaslat]; }
        if (bekleyenGuncelleme) { bekleyenGuncelleme = NO; [s.view setNeedsLayout]; }
    }];
}

// 0.5.0 menu icerigi - eski ka_kokCocuklari ile ayni mantik, KASMenuOge.
%new
- (NSArray<KASMenuOge *> *)ka_mKok {
    __weak __typeof(self) weakSelf = self;
    NSUInteger n = ka_kapatilacakSayi();
    NSString *t = [NSString stringWithFormat:@"%@ (%lu)", ka_L(@"Tümünü Kapat"), (unsigned long)n];
    KASMenuOge *tumu = [KASMenuOge baslik:t ikon:[UIImage systemImageNamed:@"xmark.circle.fill"] isleyici:^{
        __strong __typeof(weakSelf) s = weakSelf;
        if (!s) return;
        @try {
            NSArray<NSString *> *tums = ka_switcherBids();
            NSString *haric = kaPrefSonuncuHaric ? ka_lastUsedBid(tums) : nil;
            NSArray *snap = [ka_kapatilacaklar(tums, ka_protectedSet(NULL), haric) copy];
            if (snap.count) [s ka_showUndoWithBids:snap];
        } @catch (__unused NSException *e) { ka_logText(@"mTumu-exception"); }
    }];
    tumu.kirmizi = YES;
    tumu.pasif = (n == 0);
    KASMenuOge *ayar = [KASMenuOge altMenu:ka_L(@"Ayarlar") ikon:[UIImage systemImageNamed:@"gearshape"]
                                   uretici:^NSArray<KASMenuOge *> *{ return [weakSelf ka_mAyarlar]; }];
    return @[tumu, ayar];
}

%new
- (NSArray<KASMenuOge *> *)ka_mAyarlar {
    __weak __typeof(self) weakSelf = self;
    KASMenuOge *son = [KASMenuOge baslik:ka_L(@"Son Uygulamayı hariç tut") ikon:nil isleyici:^{ [weakSelf ka_toggleSonuncuHaric]; }];
    son.secili = kaPrefSonuncuHaric; son.acikKalsin = YES;
    KASMenuOge *med = [KASMenuOge baslik:ka_L(@"Müzik ve haritaları koru") ikon:nil isleyici:^{ [weakSelf ka_toggleMedyaKoru]; }];
    med.secili = kaPrefMedyaKoru; med.acikKalsin = YES;
    // m18 ISTEK: animasyon secimi kaldirildi (selale animasyonu yok)
    KASMenuOge *boy = [KASMenuOge altMenu:ka_L(@"Buton boyutu") ikon:[UIImage systemImageNamed:@"circle.circle"] uretici:^NSArray<KASMenuOge *> *{
        return [weakSelf ka_mSecim:kKA_KeyButonBoyutu degerler:@[@"kucuk", @"orta", @"buyuk"] basliklar:@[@"Küçük", @"Orta", @"Büyük"]];
    }];
    KASMenuOge *tasi = [KASMenuOge baslik:ka_L(@"Butonu taşı") ikon:[UIImage systemImageNamed:@"arrow.up.and.down.and.arrow.left.and.right"] isleyici:^{
        kaTasimaBekliyor = YES;             // menu kapaninca baslar (ka_uzunBas kapaninca)
        ka_log(@"tasi-secildi", kaButton);
    }];
    NSMutableArray<KASMenuOge *> *a = [NSMutableArray arrayWithObjects:son, med, boy, tasi, nil];
    CGSize vb = self.view.bounds.size;
    int yonSimdi = (vb.width > vb.height) ? 1 : 0;
    if (ka_prefFloat(ka_konumAnahtar(yonSimdi, YES), -1) >= 0)
        [a addObject:[KASMenuOge baslik:ka_L(@"Konumu sıfırla") ikon:[UIImage systemImageNamed:@"arrow.uturn.backward"] isleyici:^{ [weakSelf ka_konumSifirla]; }]];
    [a addObject:[KASMenuOge baslik:ka_L(@"Tüm Ayarlar…") ikon:nil isleyici:^{ [weakSelf ka_acAyarlar]; }]];
    return a;
}

%new
- (NSArray<KASMenuOge *> *)ka_mSecim:(NSString *)anahtar degerler:(NSArray *)d basliklar:(NSArray *)b {
    BOOL boyutMu = [anahtar isEqualToString:kKA_KeyButonBoyutu];
    NSString *simdi = boyutMu ? kaPrefBoyut : kaPrefAnimasyonTuru;
    NSMutableArray<KASMenuOge *> *a = [NSMutableArray new];
    for (NSUInteger i = 0; i < d.count; i++) {
        NSString *deger = d[i];
        KASMenuOge *o = [KASMenuOge baslik:ka_L(b[i]) ikon:nil isleyici:^{
            ka_prefSetString(anahtar, deger);
            if (boyutMu) { kaPrefBoyut = deger; kaBoyutKirli = YES; bekleyenGuncelleme = YES; }
            else kaPrefAnimasyonTuru = deger;
        }];
        o.secili = [simdi isEqualToString:deger];
        o.acikKalsin = YES;
        [a addObject:o];
    }
    return a;
}

%new
- (void)ka_tasimaBaslat {
    if (!kaButton || kaTasimaModu || kaUndoAktif) {
        ka_log([NSString stringWithFormat:@"tasima-atlandi buton=%d mod=%d undo=%d",
                kaButton != nil, kaTasimaModu, kaUndoAktif], kaButton);
        return;
    }
    kaTasimaModu = YES;
    if (!kaPan) {
        kaPan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(ka_pan:)];
        [kaButton addGestureRecognizer:kaPan];
    }
    kaPan.enabled = YES;
    if (kaGizliBtn && kaPanGizli.view != kaGizliBtn) {
        kaPanGizli = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(ka_pan:)];
        [kaGizliBtn addGestureRecognizer:kaPanGizli];
    }
    kaPanGizli.enabled = YES;
    kaUzunBas.enabled = NO;   // tasirken basili tutma menu acmasin (ka_tasimaBitir geri acar)
    CABasicAnimation *t = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    t.fromValue = @(-0.06);
    t.toValue = @(0.06);
    t.duration = 0.12;
    t.autoreverses = YES;
    t.repeatCount = HUGE_VALF;
    [kaButton.layer addAnimation:t forKey:@"ka-titre"];
    [kaGizliBtn.layer addAnimation:t forKey:@"ka-titre"];   // m8: ne tasindigi belli olsun
    ka_log(@"tasima-basladi", kaButton);
}

%new
- (void)ka_pan:(UIPanGestureRecognizer *)gr {
    if (!kaTasimaModu || !kaButton) return;
    UIView *v = kaButton.superview;
    if (!v) return;
    int yon = (v.bounds.size.width > v.bounds.size.height) ? 1 : 0;
    CGPoint d = [gr translationInView:v];
    CGPoint c = ka_konumSinirla(v, yon, CGPointMake(kaButton.center.x + d.x, kaButton.center.y + d.y));
    ka_konumUygula(v, c);
    // b37 DUZELTME: tasima kisiti SOL kenara bagli; "varsayilan konum" bayragi acik kalirsa b14'un cift-ortalama
    // satiri kaBtnX.constant'i -38 yapiyor -> X ekran disi (x=-57), kasa butonu kenarda (kullanici 4 Eki, iki cihaz;
    // log: konum-sifirlandi -> tasima -> goster frame x=-57). Tasinan konum varsayilan degildir.
    kaKonumVarsayilan = NO;
    [v layoutIfNeeded];
    [gr setTranslation:CGPointZero inView:v];
    if (gr.state == UIGestureRecognizerStateEnded || gr.state == UIGestureRecognizerStateCancelled) {
        CGSize s = v.bounds.size;
        if (s.width > 0 && s.height > 0) {
            ka_prefSetKonum(ka_konumAnahtar(yon, YES), c.x / s.width);
            ka_prefSetKonum(ka_konumAnahtar(yon, NO), c.y / s.height);
        }
        ka_log([NSString stringWithFormat:@"tasima-kaydedildi yon=%d fx=%.3f fy=%.3f", yon,
                c.x / MAX(1.0, s.width), c.y / MAX(1.0, s.height)], kaButton);
    }
}

%new
- (void)ka_konumSifirla {
    UIView *v = kaButton.superview;
    int yon = (v && v.bounds.size.width > v.bounds.size.height) ? 1 : 0;
    ka_prefSetKonum(ka_konumAnahtar(yon, YES), -1);
    ka_prefSetKonum(ka_konumAnahtar(yon, NO), -1);
    kaKonumKirli = YES;
    [v setNeedsLayout];
    [self.view setNeedsLayout];
    ka_log([NSString stringWithFormat:@"konum-sifirlandi yon=%d", yon], kaButton);
}

%new
- (void)ka_gizliTap:(UITapGestureRecognizer *)gr {
    // 0.6.0: gizli bolum ac/kapa. Menu acikken yok say.
    // m8: tasima modunda dokunus X'teki gibi modu bitirir.
    if (kaTasimaModu) { ka_tasimaBitir(); return; }
    if ([KASMenu acik] || kaUndoAktif || [KASKasa acik]) return;
    UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [g impactOccurred];
    ka_gizliModDegistir();
}

%new
- (void)ka_tap:(UITapGestureRecognizer *)gr {
    // 0.4.4: tasima modunda tek dokunus modu bitirir (konum pan
    // bitisinde zaten kaydedildi).
    if (kaTasimaModu) {
        ka_tasimaBitir();
        return;
    }
    // ISTEK (0.3.5): undo aktifken (kart kapatma "N sn" geri sayimi
    // surerken) X BUTONU ARTIK IPTAL BUTONUNUN KENDISI - tek dokunus
    // (haptik YOK), ekstra buton yok.
    if (kaUndoAktif) {
        [self ka_undoIptal];
        return;
    }
    // 0.6.0 ISTEK: tek dokunus = Tumunu Kapat (menudeki ile ayni yol,
    // geri alinabilir); basili tutma (haptik) = menu. Eski "Kapatmak icin
    // basili tut" ipucu kalkti.
    if ([KASMenu acik] || [KASKasa acik]) return;
    @try {
        NSArray<NSString *> *tums = ka_switcherBids();
        NSString *haric = kaPrefSonuncuHaric ? ka_lastUsedBid(tums) : nil;
        NSArray *snap = [ka_kapatilacaklar(tums, ka_protectedSet(NULL), haric) copy];
        ka_logText([NSString stringWithFormat:@"tap-tumunu-kapat n=%lu", (unsigned long)snap.count]);
        if (snap.count) { [self ka_showUndoWithBids:snap]; return; }
    } @catch (__unused NSException *e) { ka_logText(@"tap-exception"); return; }
    // Kapatilacak uygulama yok: kisa sallanma (yazi yok).
    CAKeyframeAnimation *sal = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation.x"];
    sal.values = @[@0, @-6, @6, @-4, @4, @0];
    sal.duration = 0.35;
    [kaButton.layer addAnimation:sal forKey:@"ka-salla"];
}

%new
- (void)ka_hintFadeOut {
    UIView *bg = kaHint;
    if (!bg) return;
    [UIView animateWithDuration:0.3 animations:^{ bg.alpha = 0; }
        completion:^(BOOL fin) {
            [bg removeFromSuperview];
            if (kaHint == bg) kaHint = nil;
        }];
}

%new
- (void)ka_undoHalkaTemizle {
    [kaUndoHalkaLink invalidate];
    kaUndoHalkaLink = nil;
    if (kaUndoHalkaLayer) { [kaUndoHalkaLayer removeFromSuperlayer]; kaUndoHalkaLayer = nil; }
    // Arka (soluk) halka onHalka'dan AYRI bir katman - isimle bulup
    // birlikte kaldir, yoksa X'e donulunce kaButton.layer'da kalir.
    if (kaButton) {
        for (CALayer *sub in [kaButton.layer.sublayers copy] ?: @[]) {
            if ([sub.name isEqualToString:@"kaUndoArkaHalka"] ||
                [sub.name isEqualToString:@"kaUndoOnHalka"]) {
                [sub removeFromSuperlayer];
            }
        }
    }
}

%new
- (void)ka_undoHalkaAdim:(CADisplayLink *)link {
    CAShapeLayer *layer = kaUndoHalkaLayer;
    if (!layer) { [link invalidate]; return; }
    CFTimeInterval gecen = CACurrentMediaTime() - kaUndoBaslangicZamani;
    CGFloat kalan = 1.0 - (CGFloat)(gecen / kKA_UndoSuresi);
    if (kalan < 0) kalan = 0;
    layer.strokeEnd = kalan;
    if (kalan <= 0) [self ka_undoHalkaTemizle];
}

// ISTEK (0.3.5): X butonu KENDISI iptal butonuna donusuyor - ayri buton
// yok. Iptal: X etiketini geri getir, halkayi kaldir, kaButton'in
// KENDI renginе don, ustundeki "Iptal edildi" balonunu kisa sure
// goster. HAPTIK YOK (istek: "titresim olmadan").
%new
- (void)ka_undoIptal {
    [kaUndoTimer invalidate];
    kaUndoTimer = nil;
    kaUndoBids = nil;
    kaUndoAktif = NO;
    [self ka_undoHalkaTemizle];

    if (kaButtonLabel) kaButtonLabel.alpha = 1.0;
    [UIView animateWithDuration:0.2 animations:^{
        ka_zeminAyarla(NO);
    }];

    UIView *cap = kaUndo;
    if (cap) {
        for (UIView *sv in cap.subviews) {
            if ([sv isKindOfClass:[UIVisualEffectView class]]) {
                UIVisualEffectView *ev = (UIVisualEffectView *)sv;
                for (UIView *c in ev.contentView.subviews) {
                    if ([c isKindOfClass:[UILabel class]]) {
                        UILabel *l = (UILabel *)c;
                        l.text = ka_L(@"İptal edildi");
                    }
                }
            }
        }
        cap.userInteractionEnabled = NO;
    }
    ka_logText(@"undo-iptal");

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        UIView *c = kaUndo;
        if (!c) return;
        [UIView animateWithDuration:0.3 animations:^{ c.alpha = 0; }
            completion:^(BOOL fin) {
                [c removeFromSuperview];
                if (kaUndo == c) kaUndo = nil;
            }];
    });
}

%new
- (void)ka_undoTimeout:(NSTimer *)t {
    NSArray *bids = kaUndoBids ? [kaUndoBids copy] : @[];
    ka_logText([NSString stringWithFormat:@"undo-timeout n=%lu", (unsigned long)bids.count]);
    kaUndoTimer = nil;
    kaUndoBids = nil;
    kaUndoAktif = NO;
    [self ka_undoHalkaTemizle];
    if (kaButtonLabel) kaButtonLabel.alpha = 1.0;
    ka_zeminAyarla(NO);
    UIView *c = kaUndo;
    if (c) {
        [UIView animateWithDuration:0.2 animations:^{ c.alpha = 0; }
            completion:^(BOOL fin) {
                [c removeFromSuperview];
                if (kaUndo == c) kaUndo = nil;
            }];
    }
    if (bids.count) ka_dogrudanKapat(bids);
}

// ISTEK (0.3.5): "N uygulama kapaniyor" ibaresi ve ayri iptal butonu
// KALDIRILDI. Artik: (1) X BUTONUNUN KENDISI iptal butonu olur - etiketi
// gizlenir, uzerine geri sayim halkasi (CAShapeLayer) cizilir, tek
// dokunus (haptiksiz) iptal eder; (2) ustunde SADECE kisa "İptal et"
// metni olan minik bir balon var - IKON YOK, uzun cumle YOK.
//
// ICI PENCERE UYARISI (rapor): 0.2.0'da ic ice menu katmanlari birikme
// sorunu vardi (bkz asagidaki "0.2.1" notu, updateVisibleMenuWithBlock:
// duzeltmesi) - BU KOD O SORUNA DOKUNMUYOR, ayri bir UIView agacidir
// (context menu degil), o yuzden aym risk burada YOK; sadece not
// dusuldu cunku kullanici ic pencere gecmisini hatirlatti.
%new
- (void)ka_showUndoWithBids:(NSArray<NSString *> *)bids {
    if (kaUndoTimer) { [kaUndoTimer invalidate]; kaUndoTimer = nil; kaUndoBids = nil; }
    [self ka_undoHalkaTemizle];
    if (kaUndo) { [kaUndo removeFromSuperview]; kaUndo = nil; }
    if (bids.count == 0) return;

    kaUndoBids = [bids copy];
    kaUndoAktif = YES;
    NSString *altMetin = ka_L(@"İptal et");

    // --- Ust balon: SADECE kisa metin (ikon yok, blur arka plan) ---
    UIVisualEffectView *bg = [[UIVisualEffectView alloc]
        initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemThinMaterialDark]];
    bg.translatesAutoresizingMaskIntoConstraints = NO;
    bg.layer.masksToBounds = YES;
    bg.alpha = 0;

    UILabel *lbl = [UILabel new];
    lbl.textColor = [UIColor whiteColor];
    lbl.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    lbl.text = altMetin;
    lbl.translatesAutoresizingMaskIntoConstraints = NO;
    [bg.contentView addSubview:lbl];
    [NSLayoutConstraint activateConstraints:@[
        [lbl.leadingAnchor  constraintEqualToAnchor:bg.contentView.leadingAnchor  constant:12],
        [lbl.trailingAnchor constraintEqualToAnchor:bg.contentView.trailingAnchor constant:-12],
        [lbl.topAnchor      constraintEqualToAnchor:bg.contentView.topAnchor      constant:6],
        [lbl.bottomAnchor   constraintEqualToAnchor:bg.contentView.bottomAnchor   constant:-6],
    ]];

    // Balon KENDI BASINA X butonunu KAPSAMASIN, sadece bilgi amacli -
    // gercek iptal dokunusu ASIL BUTONA (kaButton, X'in yerine gecen)
    // gider, bu yuzden balona tap eklenmiyor (dokununca kafa karisikligi
    // yaratmasin - tek gecerli dokunus alani kaButton).
    UIView *v = self.view;
    [v addSubview:bg];
    [NSLayoutConstraint activateConstraints:ka_balonKisitlari(bg, v)];
    [v layoutIfNeeded];
    bg.layer.cornerRadius = bg.bounds.size.height / 2.0;
    bg.transform = CGAffineTransformMakeTranslation(0, 4);
    kaUndo = bg;

    // DUZELTME (0.3.5-2): X etiketi ARTIK GIZLENMIYOR - istek: "icinde
    // cizgi (X) olsun, bos daire olmasin". Halka X'in ETRAFINA (r=15,
    // buton yaricapi 19) ciziliyor, X (font 20, merkezde) ile CAKISMAZ.
    [UIView animateWithDuration:0.15 animations:^{
        ka_zeminAyarla(YES);
    }];

    // 0.4.4: boyuta bagli (38 pt'de eskisi gibi merkez 19,19 r=15).
    CGFloat yc = ka_boyutPt() / 2.0;
    CGFloat r = yc - 4.0;
    UIBezierPath *yol = [UIBezierPath bezierPathWithArcCenter:CGPointMake(yc, yc)
                                                         radius:r
                                                     startAngle:-M_PI_2
                                                       endAngle:(2 * M_PI) - M_PI_2
                                                      clockwise:YES];
    CAShapeLayer *arkaHalka = [CAShapeLayer layer];
    arkaHalka.path = yol.CGPath;
    arkaHalka.fillColor = [UIColor clearColor].CGColor;
    arkaHalka.strokeColor = [UIColor colorWithWhite:1.0 alpha:0.25].CGColor;
    arkaHalka.lineWidth = 2.5;
    arkaHalka.name = @"kaUndoArkaHalka";
    [kaButton.layer addSublayer:arkaHalka];

    CAShapeLayer *onHalka = [CAShapeLayer layer];
    onHalka.path = yol.CGPath;
    onHalka.fillColor = [UIColor clearColor].CGColor;
    onHalka.strokeColor = [UIColor whiteColor].CGColor;
    onHalka.lineWidth = 2.5;
    onHalka.strokeEnd = 1.0;
    onHalka.lineCap = kCALineCapRound;
    onHalka.name = @"kaUndoOnHalka";
    [kaButton.layer addSublayer:onHalka];

    kaUndoHalkaLayer = onHalka;
    kaUndoBaslangicZamani = CACurrentMediaTime();

    [UIView animateWithDuration:0.2 animations:^{
        bg.alpha = 1.0;
        bg.transform = CGAffineTransformIdentity;
    }];
    ka_logText([NSString stringWithFormat:@"undo-goster n=%lu", (unsigned long)bids.count]);

    kaUndoHalkaLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(ka_undoHalkaAdim:)];
    [kaUndoHalkaLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];

    kaUndoTimer = [NSTimer scheduledTimerWithTimeInterval:kKA_UndoSuresi
                                                    target:self
                                                  selector:@selector(ka_undoTimeout:)
                                                  userInfo:nil
                                                   repeats:NO];
    [[NSRunLoop mainRunLoop] addTimer:kaUndoTimer forMode:NSRunLoopCommonModes];
}

// --- 0.2.0: Anahtar tikleyicileri ---

%new
- (void)ka_toggleSonuncuHaric {
    @try {
        BOOL yeni = !kaPrefSonuncuHaric;
        ka_prefSetBool(kKA_KeySonuncuHaric, yeni);
        kaPrefSonuncuHaric = yeni;
        ka_logText([NSString stringWithFormat:@"toggle-sonuncuHaric=%d", yeni]);
    } @catch (__unused NSException *e) { ka_logText(@"toggle-sonuncuHaric-exception"); }
}

%new
- (void)ka_toggleMedyaKoru {
    @try {
        BOOL yeni = !kaPrefMedyaKoru;
        ka_prefSetBool(kKA_KeyMedyaKoru, yeni);
        kaPrefMedyaKoru = yeni;
        ka_logText([NSString stringWithFormat:@"toggle-medyaKoru=%d", yeni]);
    } @catch (__unused NSException *e) { ka_logText(@"toggle-medyaKoru-exception"); }
}

%new
- (void)ka_acAyarlar {
    long long t0 = ka_msNow();
    ka_logText([NSString stringWithFormat:@"acAyarlar-basildi t=%lld", t0]);
    // Menu/switcher kapanmasindan SONRA calissin: SpringBoard kendi
    // kendine senkron IPC atmasin (SBSOpenSensitiveURLAndUnlock burada
    // KULLANILMIYOR - donmenin sebebiydi). applicationOpenURL: SpringBoard'un
    // KENDI yolu, IPC yok.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        @try {
            NSURL *url = [NSURL URLWithString:@"prefs:root=KASwitcher"];
            UIApplication *app = [UIApplication sharedApplication];
            long long t1 = ka_msNow();
            ka_logText([NSString stringWithFormat:@"acAyarlar-url-baslangic t=%lld dt=%lld", t1, t1 - t0]);
            if ([app respondsToSelector:@selector(applicationOpenURL:)]) {
                BOOL ok = [app applicationOpenURL:url];
                long long t2 = ka_msNow();
                ka_logText([NSString stringWithFormat:@"acAyarlar-applicationOpenURL-sonuc=%d t=%lld dt=%lld", ok, t2, t2 - t1]);
            } else if ([app respondsToSelector:@selector(openURL:options:completionHandler:)]) {
                ka_logText(@"acAyarlar-openURL-fallback");
                [app openURL:url options:@{} completionHandler:^(BOOL success) {
                    long long t2 = ka_msNow();
                    ka_logText([NSString stringWithFormat:@"acAyarlar-openURL-sonuc=%d t=%lld dt=%lld", success, t2, t2 - t1]);
                }];
            } else {
                ka_logText(@"acAyarlar-yolyok");
            }
        } @catch (__unused NSException *e) { ka_logText(@"acAyarlar-exception"); }
    });
}

// 0.5.0 temizlik: eski sistem menusu (UIMenu kimlikleri, ka_*Cocuklari,
// ka_buildMenu, ka_menuGuncelle, UIContextMenuInteraction delegate'i)
// KALDIRILDI - yerine KASMenu (ka_uzunBas, ka_mKok, ka_mAyarlar, ka_mSecim).
%end

%hook SBFluidSwitcherItemContainer

// Madde 2 ikinci savunma hatti: requireGestureRecognizerToFail: dogru
// tap tanimasini bulamamis olabilir (private API, kesin degil) - bu
// hook, uzun basma "aktif" bayragi kalkikken tap'i SESSIZCE yutar
// (orig cagrilmaz). Bayrak sadece longPress Began oldugunda 0.6 sn
// kalkar (bkz KAKartLongPressHandler). Kart pan/swipe (kapatma) BU
// metoda DOKUNMAZ - sadece _handlePageViewTap: (acma).
- (void)_handlePageViewTap:(id)gestureRecognizer {
    @try {
        BOOL aktif = [objc_getAssociatedObject(self, kKA_KartLongPressAktifKey) boolValue];
        if (aktif) {
            ka_logText(@"tap-yutuldu (longpress-aktif)");
            return;
        }
    } @catch (__unused NSException *e) {}
    %orig;
}

// OLCUM (0.3.1->0.3.2): switcher acilirken bir kart bir anlik buyuyup
// yerine oturuyordu. Sebep: SpringBoard kart gorunumlerini YENIDEN
// KULLANIYOR, biz eski transform/alpha'yi sadece layoutSubviews icinde
// (frame degisiminden SONRA) sifirliyorduk - reuse ile yeni appLayout
// atanmasi arasindaki karede eski (selale'den kalmis kucuk/saydam)
// durum bir kare gorunuyordu. prepareForReuse EN ERKEN nokta - burada
// kosulsuz sifirlamak o kareyi ortadan kaldirir (kart yeni bir
// appLayout alacagi icin zaten baslangic durumuna donmesi gerekir).
- (void)prepareForReuse {
    %orig;
    @try {
        UIView *sv = (UIView *)self;
        // m15: asagi atarak gizledigimiz kap yeniden kullaniliyor - simdi ac
        if (objc_getAssociatedObject(sv, kKA_KartAsagiGizliKey)) {
            ka_kartOfsetGeri(sv, NO);   // m18: asagi kaydirdigimiz ic ofset geri (kap yeni karta)
            ka_logText(@"asagi-kap-acildi prepareForReuse");
        }
        // OLCUM (0.3.3): reuse anindaki bid (onceki kartInteractionKur'dan
        // kalan associated object), selale kumesinde mi, o an transform/alpha
        // ne, ve SIFIRLIYOR MUYUZ.
        NSString *eskiBid = objc_getAssociatedObject(sv, kKA_KartBidKey);
        BOOL selalede = eskiBid.length && [kaSelaledekiBidler() containsObject:eskiBid];
        // OLCUM (0.3.3-b): scale bilesenleri (a,d) de eklendi - buyume
        // sadece translate/alpha ile yakalanmiyor, CGAffineTransform'un
        // scale kismi (a,d) 1.0 disinda kalirsa kart buyuk/kucuk gorunur.
        ka_logText([NSString stringWithFormat:
            @"OLCUM prepareForReuse ptr=%p bid=%@ selalede=%d tx=%.2f ty=%.2f a=%.2f d=%.2f alpha=%.2f sifirlaniyor=%d",
            (void *)sv, eskiBid, selalede, sv.transform.tx, sv.transform.ty,
            sv.transform.a, sv.transform.d, sv.alpha, !selalede]);
        if (selalede) {
            // DUZELTME (0.3.3): selale kumesindeki karta DOKUNMA - yari
            // yoldaki animasyon kesilmesin.
            return;
        }
        sv.transform = CGAffineTransformIdentity;
        sv.alpha = 1.0;
    } @catch (__unused NSException *e) { ka_logText(@"kartPrepareForReuse-exception"); }
}

- (void)layoutSubviews {
    %orig;
    @try {
        UIView *sv = (UIView *)self;
        id al = [sv respondsToSelector:@selector(appLayout)] ? [sv performSelector:@selector(appLayout)] : nil;
        NSString *bid = nil;
        if (al && [al respondsToSelector:@selector(allItems)]) {
            for (id item in [al allItems]) {
                if ([item respondsToSelector:@selector(bundleIdentifier)]) {
                    NSString *b = [item bundleIdentifier];
                    if (b.length) { bid = b; break; }
                }
            }
        }
        if (bid.length) {
            ka_kartInteractionKur(sv, bid);
            ka_kartEslemesiGuncelle(bid, sv);
            if ([kaPrefGizli containsObject:bid]) ka_gizliGorselYakala(bid, sv);   // 0.6.0 kasa
            // Kart yeniden kullanildiginda onceki selale animasyonu artik
            // gecersiz - AMA sadece bu bid su an selalede DEGILSE sifirla
            // (yari yolda kesme). prepareForReuse ARTIK kosulsuz sifirlamiyor
            // (bkz DUZELTME yukarida) - bu kontrol tek sifirlama noktasi.
            if (![kaSelaledekiBidler() containsObject:bid]) {
                // REGRESYON 2 (0.3.3-3) OLCUMLE BULUNDU: "alpha != 1.0"
                // tetikleyicisi de guvensizdi - sistemin KENDI switcher
                // ACILIS fade-in'i (scale 0.66->1.0 ile ES ZAMANLI alpha
                // 0->1) surerken layoutSubviews HER karede cagriliyor;
                // alpha o an dogal olarak <1.0 oluyor, biz bunu "eski
                // selale kalintisi" sanip ZORLA alpha=1+identity'e
                // sicratiyorduk - o KARTIN scale/fade'ini ortasinda
                // kesiyordu (rastgele bir kart buyup kuculuyor gibi
                // gorunmesinin sebebi budur). Translate (tx/ty) ise
                // SADECE bizim selalemizde kullanilir (sistem hic
                // translate kullanmiyor, olculdu) - bu yuzden TEK
                // guvenilir tetikleyici tx/ty. alpha bunun YANINDA
                // (translate kirliyse) sifirlanir, TEK BASINA degil.
                CGAffineTransform t = sv.transform;
                BOOL anormal = (t.tx != 0 || t.ty != 0);
                if (anormal) {
                    ka_logText([NSString stringWithFormat:
                        @"OLCUM layoutSubviews-sifirla ptr=%p bid=%@ tx=%.2f ty=%.2f a=%.2f d=%.2f alpha=%.2f",
                        (void *)sv, bid, t.tx, t.ty, t.a, t.d, sv.alpha]);
                    sv.transform = CGAffineTransformIdentity;
                    sv.alpha = 1.0;
                }
            }
        }
    } @catch (__unused NSException *e) { ka_logText(@"kartLayout-exception"); }
}
%end

%hook SBFluidSwitcherItemContainerHeaderView

// bid degisince (yeni bir sayfa/kart bu header'i kullanmaya baslayinca)
// VE her layoutSubviews'ta (kart resize/reuse) rozeti tazele.
%new
- (void)ka_rozetTazele {
    @try {
        UIView *self_ = (UIView *)self;
        id items = [self_ respondsToSelector:@selector(titleItems)]
            ? [self_ performSelector:@selector(titleItems)] : nil;
        if (![items isKindOfClass:[NSArray class]] || [(NSArray *)items count] == 0) return;
        id titleItem = [(NSArray *)items firstObject];
        NSString *bid = nil;
        if ([titleItem respondsToSelector:@selector(displayItem)]) {
            id di = [titleItem performSelector:@selector(displayItem)];
            if ([di respondsToSelector:@selector(bundleIdentifier)]) {
                bid = [di performSelector:@selector(bundleIdentifier)];
            }
        }
        if (!bid.length) return;
        ka_headerEslemesiGuncelle(bid, self_);
        ka_kartRozetBasligaGuncelle(self_, ka_sabitliMi(bid));
    } @catch (__unused NSException *e) { ka_logText(@"headerRozetTazele-exception"); }
}

- (void)setTitleItems:(NSArray *)items {
    %orig;
    [self ka_rozetTazele];
}

- (void)layoutSubviews {
    %orig;
    [self ka_rozetTazele];
}

%end

%hook SBMainSwitcherControllerCoordinator

- (void)switcherContentController:(id)arg1
    performTransitionWithRequest:(SBSwitcherTransitionRequest *)arg2
                gestureInitiated:(BOOL)arg3 {
    @try {
        NSString *yon = @"bilinmiyor";
        SBAppLayout *al = nil;
        if ([arg2 respondsToSelector:@selector(appLayout)]) al = [arg2 appLayout];
        if (!al) {
            yon = @"anaekran-veya-nil";
        } else if ([al respondsToSelector:@selector(allItems)]) {
            NSArray *items = [al allItems];
            if (!items.count) {
                yon = @"bos-layout";
            } else {
                BOOL springboardVar = NO;
                for (id item in items) {
                    if (![item respondsToSelector:@selector(bundleIdentifier)]) continue;
                    NSString *bid = [item bundleIdentifier];
                    if ([bid isEqualToString:@"com.apple.springboard"]) { springboardVar = YES; break; }
                }
                yon = springboardVar ? @"anaekran" : @"app";
            }
        }
        ka_log([NSString stringWithFormat:@"OLCUM-m7 ms=%lld yon=%@ gesture=%d butonHidden=%d",
                ka_msNow(), yon, arg3, kaButton ? kaButton.hidden : -1], nil);
        // m14 otomatik kapatma: son kullanim kaydi; switcher acilisinda kontrol
        // (%orig'den once - eskiyen kartlar switcher gorunmeden kalkar).
        if (kaPrefOtoSaat > 0) {
            if ([yon isEqualToString:@"app"]) {
                for (id it in [al allItems])
                    if ([it respondsToSelector:@selector(bundleIdentifier)]) ka_kullanimYaz([it bundleIdentifier]);
            } else if ([yon isEqualToString:@"anaekran-veya-nil"]) {
                NSString *onde = nil;
                if (ka_appOnPlanda(&onde)) ka_kullanimYaz(onde);
                ka_otoKapatKontrol(@"switcher");
            }
        }
        // (m21 "ondeki gizli karti acilistan sonra cikar" GERI ALINDI - m22:
        // olcumde liste yeniden kurulmadi, kart kalmadi; bkz. m2 onbellek olcumu)
        // DUZELTME (0.4.3): olcum m7'de ana ekrana donus = appLayout VAR
        // ama allItems BOS ("bos-layout"); com.apple.springboard hic
        // gelmedi. Switcher acilisi = appLayout nil. Ana ekran yolunda
        // appOnPlanda gibi erken otorite yok, isAnySwitcherVisible
        // yoklamasi ~680 ms gec geliyordu - butonu burada HEMEN kapat.
        // App yonu ve nil (acilis): dokunma. Yoklama emniyet agi kalir.
        // m25: switcher acilisi disindaki her gecisten (app / ana ekran) ONCE ekran
        // disinda birakilan kartlarin ic ofseti sifirlanir - kap uygulamaya donusmeden.
        if (![yon isEqualToString:@"anaekran-veya-nil"]) ka_ofsetleriSifirla(@"gecis");
        // m23 DUZELTME (m22 olcumu): ondeki uygulamanin karti silinince SpringBoard
        // ~5 ms sonra gesture=0 bir "bos-layout" istiyor (arkadaki duzen ana ekrana
        // doner) - switcher ACIK kaliyor. Bunu ana ekrana donus sanip butonlari
        // gizliyorduk; yoklama geri getiriyordu (iki kez gidip gelme).
        // b18: once istegin KENDISINE bak - Apple switcher'i acik birakan isteklerde unlockedEnvironmentMode = 2
        // kullaniyor (-[SBDeckSwitcherModifier handleRemovalEvent:], DSC 17/18/26). Okunabiliyorsa karar buna gore;
        // okunamazsa m23'un 400 ms penceresi yedek olarak kalir.
        long long envMod = -1;
        Method mEnv = class_getInstanceMethod(object_getClass(arg2), @selector(unlockedEnvironmentMode));
        if (mEnv && !strcmp(method_getTypeEncoding(mEnv), "q16@0:8"))
            envMod = ((long long (*)(id, SEL))objc_msgSend)(arg2, @selector(unlockedEnvironmentMode));
        BOOL silmeSonrasi = (envMod == 2) || (envMod < 0 && !arg3 && (ka_msNow() - kaOndeSilmeMs) < 400);
        if (!silmeSonrasi) ka_logText([NSString stringWithFormat:@"gecis %@ env=%lld gesture=%d", yon, envMod, arg3]);   // b18 olcum
        if (silmeSonrasi) ka_logText([NSString stringWithFormat:@"%@ yok-sayildi (switcher acik kaliyor) env=%lld", yon, envMod]);
        else if ([yon isEqualToString:@"bos-layout"] || [yon isEqualToString:@"anaekran"]) {
            ka_butonGizle(kaButton);
        }
    } @catch (__unused NSException *e) {
        ka_logText(@"m7-performTransition-exception");
    }
    %orig;
}

// OLCUM m22 (yalniz log, davranis DEGISMEZ): kasadaki uygulama switcher'dan
// kapatilinca butonlar iki kez gidip geliyor (kullanici). Kart silinme ani
// gunlukte gorunsun; ardindan gelen gizle/goster sirasi oradan okunur.
// Imza: v48@0:8@16@24@32q40 (shiv-sinif --tip, 2 Eki 2026).
- (void)switcherContentController:(id)c deletedDisplayItem:(id)item inAppLayout:(id)al forReason:(long long)sebep {
    @try {
        NSString *b = [item respondsToSelector:@selector(bundleIdentifier)] ? [item bundleIdentifier] : nil;
        BOOL onde = NO;
        NSString *ondeBid = nil;
        if (ka_appOnPlanda(&ondeBid) && b && [ondeBid isEqualToString:b]) onde = YES;
        if (onde) kaOndeSilmeMs = ka_msNow();   // m23: ardindan gelen bos-layout yok sayilir
        ka_logText([NSString stringWithFormat:@"OLCUM-m22 kart-silindi %@ sebep=%lld gizli=%d onde=%d butonHidden=%d",
                    b ?: @"?", sebep, b ? [kaPrefGizli containsObject:b] : 0, onde, kaButton ? kaButton.hidden : -1]);
    } @catch (__unused NSException *e) { ka_logText(@"m22-silindi-exception"); }
    %orig;
}

%end

// 0.7 GIZLEME: gizli durumun sahibi Apple (SBAppLayout.hidden, KASGizle.m; olcum REPORTS/06 §7).
// 0.6.0'in kendi suzgeci (recentsIncludingHiddenAppLayouts: kancasi, ka_gizliSuz, istisnalar) KALDIRILDI.
// Apple yeni duzen eklerken (uygulama yeniden acildi) kasadaki uygulamanin duzeni gizli doner (§7.2).
// Imza @48@0:8@16@24@32@40 calisan surecte dogrulanmadan kurulmaz.
%group KASGizli
%hook SBMainSwitcherControllerCoordinator
- (id)appSwitcherModel:(id)m willAddAppLayout:(id)al replacingAppLayouts:(id)rep removingAppLayouts:(id)rem {
    id r = %orig;
    @try { return kas_willAddDuzelt(r, kaPrefGizli); }
    @catch (__unused NSException *e) { ka_logText(@"willAdd-istisna"); }
    return r;
}
%end
%end

// Ondeki karti stok yoldan kaldirdiktan sonra Apple arkayi ana ekrana ceviriyor; liste gecis bitince
// bir kez daha kurulmali (M1c adim 4). Yalniz kaldirmayi biz baslattiysak (kas_gecisBitti icinde bayrak).
// Imza v32@0:8@16@24 calisan surecte dogrulanir.
%group KASGecisSonu
%hook SBMainSwitcherControllerCoordinator
- (void)layoutStateTransitionCoordinator:(id)lc transitionDidBeginWithTransitionContext:(id)ctx {
    %orig;
    // a2: kartin bir an geri gelmesini kisaltmak icin gecis BASINDA da yenile (arkadaki duzen bu anda
    // ana ekran mi - DOGRULANMADI, gunluk gosterecek). Bayrak sonda temizlenir.
    @try { kas_gecisBasladi(); } @catch (__unused NSException *e) { ka_logText(@"gecis-basi-istisna"); }
}
- (void)layoutStateTransitionCoordinator:(id)lc transitionDidEndWithTransitionContext:(id)ctx {
    %orig;
    @try { kas_gecisBitti(); } @catch (__unused NSException *e) { ka_logText(@"gecis-sonu-istisna"); }
}
%end
%end

// b7: kasada uygulama varken switcher bos olsa da acik kalsin (kasaya ulasmak icin). Apple bos switcher'i acip
// SBDismissForEmptySwitcherSwitcherEventResponse (tur 16) ile kapatiyor (DSC 26; ureticiler ana ekran / switcher hareket
// modifier'lari). Yalniz O yanit, yalniz kasa doluyken uygulanmaz; baska yanita dokunulmaz. Imza v24@0:8@16 dogrulanir.
%group KASBosSwitcher
%hook SBFluidSwitcherViewController
- (void)_performEventResponse:(id)yanit {
    @try {
        Class k = objc_getClass("SBDismissForEmptySwitcherSwitcherEventResponse");
        if (k && [yanit isKindOfClass:k] && kas_kasaBidleri(kaPrefGizli).count) {
            ka_logText(@"bos-switcher kapanmasi atlandi (kasa dolu)");
            return;
        }
    } @catch (__unused NSException *e) { ka_logText(@"bos-switcher-istisna"); }
    %orig;
}
%end
%end


// Tum %init'ler burada, grup tanimlarindan SONRA. Olculdu (0.6.0):
// Logos tanimsiz gruba %init'e izin vermiyor, ve dosyada herhangi bir
// %init varsa ungrouped hook'lar da ACIKCA kurulmak zorunda - yoksa
// "non-initialized hook group: _ungrouped" (0.5.1'de %init hic yoktu,
// Logos ungrouped'i kendisi kuruyordu).

// m14 TEMIZLIK: Face ID olcum grubu (KASOlcumFid, m7-m10) kaldirildi.
// Sonuclari REPORTS/01-RAPOR.md 0.6.0 bolumunde; imzalar belgeler/.

static void ka_kancalariKur(void) {
    %init;
    kas_gizleGunluk(ka_logText);
    {   // b7: bos switcher kapanmasini kasa doluyken atla - imza calisan surecte birebir tutarsa
        Method m = class_getInstanceMethod(objc_getClass("SBFluidSwitcherViewController"), @selector(_performEventResponse:));
        const char *t = m ? method_getTypeEncoding(m) : NULL;
        if (t && !strcmp(t, "v24@0:8@16")) { %init(KASBosSwitcher); ka_logText(@"bos-switcher kuruldu"); }
        else ka_logText([NSString stringWithFormat:@"bos-switcher KURULMADI imza=%s", t ?: "yok"]);
    }
    {   // 0.7: Apple'in yeni duzen karar noktasi - imza calisan surecte birebir tutarsa
        Method m = class_getInstanceMethod(objc_getClass("SBMainSwitcherControllerCoordinator"),
                                           @selector(appSwitcherModel:willAddAppLayout:replacingAppLayouts:removingAppLayouts:));
        const char *t = m ? method_getTypeEncoding(m) : NULL;
        if (t && !strcmp(t, "@48@0:8@16@24@32@40")) { %init(KASGizli); ka_logText(@"gizle willAdd kuruldu"); }
        else ka_logText([NSString stringWithFormat:@"gizle willAdd KURULMADI imza=%s", t ?: "yok"]);
    }
    {   // m33: imza calisan surecte birebir tutarsa
        Method m = class_getInstanceMethod(objc_getClass("SBMainSwitcherControllerCoordinator"), @selector(layoutStateTransitionCoordinator:transitionDidEndWithTransitionContext:));
        const char *t = m ? method_getTypeEncoding(m) : NULL;
        Method mb = class_getInstanceMethod(objc_getClass("SBMainSwitcherControllerCoordinator"), @selector(layoutStateTransitionCoordinator:transitionDidBeginWithTransitionContext:));
        const char *tb = mb ? method_getTypeEncoding(mb) : NULL;
        if (t && tb && !strcmp(t, "v32@0:8@16@24") && !strcmp(tb, "v32@0:8@16@24")) { %init(KASGecisSonu); ka_logText(@"m33 kuruldu (bas+son)"); }
        else ka_logText([NSString stringWithFormat:@"m33 KURULMADI imza=%s", t ?: "yok"]);
    }
    // m14: otomatik kapatma zamanlayicisi - 10 dk'da bir (ayar kapaliysa hemen doner)
    static dispatch_source_t zam;
    zam = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(zam, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(600 * NSEC_PER_SEC)),
                              (uint64_t)(600 * NSEC_PER_SEC), (uint64_t)(30 * NSEC_PER_SEC));
    dispatch_source_set_event_handler(zam, ^{ ka_otoKapatKontrol(@"zamanlayici"); });
    dispatch_resume(zam);
    // 0.7: acilista tercih listesi Apple'in bayragiyla esitlenir (0.6.0'dan gelen liste dahil; bayrak respring'den
    // sag cikiyor - M3). Koordinator henuz yoksa kas_* sessizce hicbir sey yapmaz; ilk switcher acilisinda tekrar.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        kas_esitle([NSSet set], kaPrefGizli ?: [NSSet set]);
    });
}
