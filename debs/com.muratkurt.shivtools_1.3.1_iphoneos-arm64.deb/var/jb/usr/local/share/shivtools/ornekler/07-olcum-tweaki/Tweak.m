// OrnekProbe — ayri olcum tweak'i iskeleti (YAYINLANMAZ)
//
// NEDEN AYRI BIR TWEAK: bir karar Apple'in davranisina bagliysa (Apple'in
// kendi mekanizmasi isi yapiyor mu? bir bayrak respring'den sag cikiyor
// mu?) onu URUN KALDIRILMISKEN olc. Urunun icinde olcersen kendi
// suzgeclerini ve yamalarini Apple'in davranisiyla karisik olcersin.
// KASwitcher 0.7'nin butun mimarisi boyle bir aracla (PROBE-0.7) dort
// soruya verilen olculmus cevaplarla kuruldu. Recete: TWEAK.md
// "A separate measuring tweak".
//
// NASIL CALISIR
//   Hicbir seye dokunmaz; yarim saniyede bir komut dosyasina bakar.
//   Komut gelince dosyayi siler, komutu calistirir, gunluge yazar.
//
//   komut dosyasi  /var/mobile/Library/Caches/ornekprobe-komut.txt
//   gunluk         /var/mobile/Library/Caches/ornekprobe.txt
//   (RootHide kabugundan: basina /rootfs ekle — SpringBoard GERCEK
//    yolu goruyor, kabuk jbroot'u. TWEAK.md §6.)
//
//   imza <Sinif> <secici>   varlik + tip kodlamasi, CAGIRMAZ
//   durum                   ornek salt-okur cagri, imza denetimli
//   (act ...)               kendi eylemin — asagidaki yere ekle
//
// CAPS: kaynakta @"..." literali YOK, sisteme blok verilmiyor, kendi ObjC
// sinifi yok -> kanun §7'ye gore cihazda derlenen (caps 0x00) surum de oldabi
// istemez (kuraldan cikarim; cihaz derlemesi ayrica OLCULMEDI).
// Bir NSString literali ya da ^{ } blogu eklersen bu ozellik gider.

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <dispatch/dispatch.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

#define KOMUT_YOLU  "/var/mobile/Library/Caches/ornekprobe-komut.txt"
#define GUNLUK_YOLU "/var/mobile/Library/Caches/ornekprobe.txt"

// ─────────────────────────────────────────────────────────────
// 1. GUNLUK — ms damgasi + ETIKET + alanlar (TWEAK.md §5b)
//    cut -d' ' -f2 | sort | uniq -c  ile etiketler sayilir.
static FILE *gunluk;
static void L(const char *bicim, ...) {
	if (!gunluk) gunluk = fopen(GUNLUK_YOLU, "a");
	if (!gunluk) return;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	fprintf(gunluk, "%ld.%03d ", (long)tv.tv_sec, (int)(tv.tv_usec / 1000));
	va_list ap;
	va_start(ap, bicim);
	vfprintf(gunluk, bicim, ap);
	va_end(ap);
	fputc('\n', gunluk);
	fflush(gunluk);
}

// ─────────────────────────────────────────────────────────────
// 2. IMZA DENETIMI — kirmizi cizgi 2'nin calisma anindaki karsiligi
//    (TWEAK.md "Signature-checked call"). 1 yalniz metot VARSA ve tip
//    kodlamasi BIREBIR beklenenle ayniysa. Tutmazsa cagri YAPILMAZ.
//    Beklenen dizeyi ezberden yazma: once 'imza' komutuyla olc.
static int imza(id o, int sinif, const char *sel, const char *bekl) {
	if (!o) return 0;
	Class k = sinif ? (Class)o : object_getClass(o);
	SEL s = sel_registerName(sel);
	Method m = sinif ? class_getClassMethod(k, s) : class_getInstanceMethod(k, s);
	const char *t = m ? method_getTypeEncoding(m) : "yok";
	if (m && strcmp(t, bekl) == 0) return 1;
	L("IMZA-TUTMADI %s = %s (beklenen %s)", sel, t, bekl);
	return 0;
}

// ─────────────────────────────────────────────────────────────
// 3. KOMUTLAR

// imza <Sinif> <secici> — CAGIRMAZ, yalniz okur. Yeni bir API'nin
// beklenen imzasini buradan al.
static void komut_imza(const char *sinifAdi, const char *sel) {
	Class k = objc_getClass(sinifAdi);
	if (!k) { L("IMZA %s sinif-yok", sinifAdi); return; }
	SEL s = sel_registerName(sel);
	Method mo = class_getInstanceMethod(k, s);
	Method ms = class_getClassMethod(k, s);
	L("IMZA %s %s ornek=%s sinif=%s", sinifAdi, sel,
	  mo ? method_getTypeEncoding(mo) : "-", ms ? method_getTypeEncoding(ms) : "-");
}

// durum — ORNEK salt-okur cagri. Her adim imza denetimli; biri tutmazsa
// gunluge IMZA-TUTMADI duser ve zincir orada durur (cokme yerine bilgi).
static void komut_durum(void) {
	Class k = objc_getClass("SBApplicationController");
	if (!k) { L("DURUM sinif-yok SBApplicationController"); return; }
	if (!imza((id)k, 1, "sharedInstance", "@16@0:8")) return;
	id ac = ((id (*)(id, SEL))objc_msgSend)((id)k, sel_registerName("sharedInstance"));
	if (!imza(ac, 0, "runningApplications", "@16@0:8")) return;
	id liste = ((id (*)(id, SEL))objc_msgSend)(ac, sel_registerName("runningApplications"));
	unsigned long n = [liste isKindOfClass:[NSArray class]] ? (unsigned long)[(NSArray *)liste count] : 0;
	L("DURUM calisan-uygulama=%lu", n);
}

// act ... — KENDI EYLEMIN BURAYA. Kural: her ozel cagri imza() ile
// korunur, bir komut TEK bir eylem yapar, oncesi ve sonrasi 'durum'
// ile olculur. Dogrulanan cagri urune imza denetimiyle birlikte tasinir.

// ─────────────────────────────────────────────────────────────
// 4. ZAMANLAYICI — komut gelene kadar hicbir sey yapmaz
static void tik(void *baglam) {
	(void)baglam;
	FILE *f = fopen(KOMUT_YOLU, "r");
	if (!f) return;
	char satir[256] = {0};
	if (!fgets(satir, sizeof satir, f)) satir[0] = 0;
	fclose(f);
	unlink(KOMUT_YOLU);   // ONCE sil: ayni komut iki kez calismasin
	satir[strcspn(satir, "\r\n")] = 0;
	char a[64] = {0}, b[128] = {0}, c[128] = {0};
	int n = sscanf(satir, "%63s %127s %127s", a, b, c);
	L("KOMUT %s", satir);
	if (n >= 1 && strcmp(a, "durum") == 0) komut_durum();
	else if (n == 3 && strcmp(a, "imza") == 0) komut_imza(b, c);
	else L("KOMUT bilinmiyor");
}

__attribute__((constructor)) static void kur(void) {
	L("YUKLENDI pid=%d", getpid());
	// SAGLAMA satiri: bu yoksa kurulum hic calismamistir, olcum gecersiz.
	L("SAGLAMA NSObject=%s", objc_getClass("NSObject") ? "var" : "YOK");
	static dispatch_source_t zaman;
	zaman = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
	dispatch_source_set_timer(zaman, dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC),
	                          NSEC_PER_SEC / 2, NSEC_PER_SEC / 10);
	dispatch_source_set_event_handler_f(zaman, tik);   // BLOK DEGIL, fonksiyon
	dispatch_resume(zaman);
}
