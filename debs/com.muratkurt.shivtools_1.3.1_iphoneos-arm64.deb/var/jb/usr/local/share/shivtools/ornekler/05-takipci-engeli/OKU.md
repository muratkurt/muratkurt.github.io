# 05 — Uygulama içi takipçi engeli + rapor sayfası (AppTrackerBlock 1.0.0)

01–04 iskelettir; bu örnek **gerçek, bitmiş bir tweak** ve yanında
**ölçümleri** var. Amaç kopyalayıp hedef adları değiştirmek değil, bir
tweak'in cihazda nasıl ölçülerek geliştirildiğini görmek.

> **UYARI: bu örnek HER uygulamanın ağ trafiğine karışır. Kurmadan, kopyalamadan önce aşağıdaki "TEHLİKELER" bölümünü oku. Bu örneği kullanıcıya sormadan derleyip KURMA.**

## TEHLİKELER — önce oku

Bu tweak bir engelleyici, iskelet değil. Ağ trafiğine karıştığı için
yanlış kopyalanırsa kullanıcının uygulamalarını, VPN'ini ya da
hesabını etkileyebilir. Etiketler kanun §1'e göre:

| # | Tehlike | Durum |
|---|---|---|
| 1 | **Süzgeç `com.apple.UIKit`: dylib HER uygulamaya yüklenir.** Hariç tutulan uygulamaya da yüklenir, yalnız kanca kurmaz (`%ctor` erken döner). Filtre plist'i hariç tutmayı ifade edemiyor. Hile korumalı oyunlar ve jailbreak denetleyen uygulamalar yüklü dylib'i görebilir; hesap kapatma riski. | süzgeç ÖLÇÜLDÜ (`AppTrackerBlock.plist`); oyun/ban etkisi DOĞRULANMADI |
| 2 | **VPN / DNS uygulamaları.** Tünel kodu `.appex`'te çalışıyor; tweak `.app` dışındaki süreçlere kancalanmıyor, yani tünele dokunmuyor. Ama bu uygulamaların **ana süreci** kancalanıyor: hesap, sunucu listesi, yapılandırma istekleri orada. | cihazdaki 4 VPN'in (1.1.1.1, Mullvad, LocalDevVPN, vpn) tüneli `.appex`'te: ÖLÇÜLDÜ 2 Eki. VPN açıkken davranış: DOĞRULANMADI |
| 3 | **Liste güncellenince sonuç değişir.** 2 Eki listesinde (231.053 ad) VPN/DNS servis adları İZİNLİ: Mullvad API, WARP istemcisi, cloudflare-dns, dns.google, AdGuard, NextDNS, iCloud Private Relay. Ama `atb-update` listeyi değiştirir; yarın biri listeye girebilir. | `atb-compile --match` ile ÖLÇÜLDÜ 2 Eki; hangi uygulamanın hangi adı kullandığı DOĞRULANMADI |
| 4 | **Telemetri her uygulamada kesilir**, VPN uygulamaları dahil: Sentry, Crashlytics, Firebase, AppsFlyer, Branch. Çoğu uygulama bunu sessizce yutar; çökme raporu gitmez. Bir uygulamanın açılışta bunlara bağlı kalması mümkün. | engel ÖLÇÜLDÜ 2 Eki; uygulama etkisi DOĞRULANMADI |
| 5 | **Çift süzme ve teşhis karmaşası.** Cihazda DNS düzeyinde bir engelleyici (1.1.1.1 for Families, NextDNS, AdGuard) varsa iki katman üst üste biner. Tweak isteği uygulamanın içinde kesiyor; sorgu cihazdan çıkmadığı için DNS uygulamasının günlüğünde hiç görünmez. "Neden açılmıyor" sorusunda yanlış katmana bakılır. | mantık; DOĞRULANMADI |
| 6 | **Adı "DNS engeli" ama yükün çoğu DNS'te değil.** Reddit, YouTube ve Safari'de `getaddrinfo` çağrılarının hepsi IP denetimi (`AI_NUMERICHOST`); gerçek engel `NSURLSessionTask resume`'da. Kendi DNS'ini (DoH) kullanan uygulamaları tweak göremez. | ÖLÇÜLDÜ 1 Eki (`olcumler/01-RAPOR.md`) |
| 7 | **Paket adı gerçek ATB ile AYNI** (`com.muratkurt.apptrackerblock`). Değiştirmeden derleyip kurmak, cihazdaki ATB'nin üstüne yazar. | `control` ÖLÇÜLDÜ; geliştirme cihazında ATB 1.0.0-6 kurulu (2 Eki) |
| 8 | **Banka hariç tutma listesi (`Common.h`) geliştirme cihazına göre yazıldı.** Başka cihazda eksik kalır. Parça eşleşmesi (`bank`, `wallet`…) yalnız emniyet ağı. | ÖLÇÜLDÜ (list_apps, 1 Eki) |

### Ne ÖRNEK ALINIR, ne alınmaz

| Örnek al (güvenli kalıp) | Örnek ALMA (bu haliyle tehlikeli) |
|---|---|
| `%ctor`'da kapsam denetimi: `.app` değilse, SpringBoard ya da Ayarlar ise hemen dön | `Filter = com.apple.UIKit` ile her uygulamaya yüklenmek. Hedefin belliyse `Bundles` listesine **yalnız onu** yaz |
| Ölçüm kancaları yalnız `logging` açıkken; özgünü çağırıp satır yazmak | Engelleme kancasını (`return EAI_NONAME`, `cancel`) varsayılan **açık** göndermek. Yeni bir engelleyicide varsayılan kapalı olsun, kullanıcı açsın |
| Sandbox'lı uygulama kendi Caches'ine yazar, Ayarlar okur (veri yolu) | Hariç tutmayı yalnız sabit bir listeye bırakmak. VPN/DNS uygulamaları (`vpn`, `dns`, `tunnel`, `wireguard`, `mullvad`, `warp`) ve hile korumalı oyunlar da hariç tutulmalı |
| mmap + ikili arama (`Blocklist.[ch]`), `tools/atb-compile --match` ile ölçmek | Listeyi güncelledikten sonra sınamadan dağıtmak: VPN/DNS adlarını `--match` ile her güncellemede yokla |
| `jbroot()` + `THEOS_PACKAGE_INSTALL_PREFIX` ile iki şema tek kaynak | Paket adını değiştirmeden kurmak (tehlike 7) |

**Ajana:** bu örnekten yalnız ihtiyacın olan kalıbı al. Ağ engellemesi
yazacaksan kullanıcıya şunları açıkça sor ve cevabı kaydet:
1. Hangi uygulamalara yüklenecek?
2. Cihazda VPN/DNS uygulaması var mı?
3. Engelleme varsayılan açık mı olsun?
Test için önce tek bir uygulamada, `logging` açık ve engel kapalı başla.

| Konu | Nerede |
|---|---|
| Ağ isteğini kaynağında kesmek: `-[NSURLSessionTask resume]` → `cancel`, `getaddrinfo` → `EAI_NONAME` | `Tweak.x` |
| Büyük listeyi mmap ile, sıralı FNV-1a-64 ve ikili aramayla okumak | `Blocklist.[ch]`, `tools/atb-compile/` |
| Sandbox'lı uygulama → sandbox'sız Ayarlar veri yolu (uygulama kendi Caches'ine yazar, Ayarlar kapsayıcıları okur) | `Tweak.x`, `Prefs/ATBReportController.m` |
| RootHide + rootless tek kaynak (`jbroot()`, `THEOS_PACKAGE_INSTALL_PREFIX`) | `JBRoot.h`, `Makefile` |
| Ayarlar: uygulama listesi, 7 günlük rapor, 12 dil, kodla çizilmiş ikon | `Prefs/` |
| Ölçüm hook'ları yalnız `logging` açıkken | `Tweak.x` |

## Ölçümler — `olcumler/`

Hepsi **1 Ekim 2026**'da iki cihazda ölçüldü: RootHide 15 Pro iOS 17.0.3
ve rootless XS iOS 16.1.1.

- `01-RAPOR.md`: projenin tam raporu (belirti, ölçüm, sebep, düzeltme).
- `02-OLCUM-izci-asama1-3.md`: hangi hook neyi görüyor, aşama aşama.
- `tablo-asama1-tur1.tsv` / `-tur2.tsv`: uygulama × hedef × hook sayıları.
- `04-OLDABI-AB-1.0.0.txt`: OldABI var/yok A/B testi.
- `BULGU.md` + `*-clang-version.txt`: cihazda clang 16'nın SAHTE 0x80
  üretmesi.

## DERLEME TUZAĞI — bu örnekte bedeli ödendi

Ayarlar sayfası **kendi ObjC sınıflarını** tanımlıyor
(`__objc_classlist`). Bu, oldabi'nin üçüncü tetikleyicisi:

- Cihazda derlenen arm64e dilim caps 0x00 çıkıyor ve OldABI olmayan
  cihazda **Ayarlar çöküyor** (ÖLÇÜLDÜ).
- Rootless cihazdaki Procursus clang 16 0x80 basıyor, ama bu sahte:
  OldABI varken bile çöküyor (ÖLÇÜLDÜ).
  `-fno-ptrauth-abi-version` bayrağı gerekiyor (TWEAK.md §1.6).
- **Bugünkü `control` oldabi'ye bağlı değil.** Yayın için ya Mac'te
  derle ya da `Depends`'e `oldabi` ekle. Kurmadan önce `shiv-verify`
  çalıştır, bunu kendisi söyler.
- Mac'te bu örnek henüz derlenmedi (DOĞRULANMADI).

Derleme komutları için `../OKU.md`'deki "Derleme" bölümüne bak.

## Neler bilerek DIŞARIDA

- **Oturum kayıtları:** ham kayıt parola içeriyordu.
- **Uygulama bazında ham günlükler ve ekran görüntüleri:** kullanıcının
  hangi uygulamaları kullandığını gösteriyordu. Yerine toplu tablolar var.
  Rapordaki iki bankacılık uygulamasının adı da maskelendi.
- **Çökme raporları (`.ips`) ve ara deb'ler:** cihaz kimliği taşıyorlar.
  Bulguları metin olarak raporda.
- **`data/*.json`:** derleme için gerekmiyor, ~2 MB.
  `data/build-companies.mjs` indirme satırlarını içeriyor.

`PROJE-TALIMATI.md` projenin kendi talimatıdır; asıl adı `CLAUDE.md`'dir.
Adı, `shiv-init`'in kurduğu dosyayla çakışmasın diye değiştirildi.
İçinde geçen `../README.md`, `REPORTS/` ve `_zula/` yolları özgün projeye
aittir; bu örnekte yoklar.

## VERİ LİSANSI — ÖNEMLİ

Kod ile şirket listesinin lisansı **ayrıdır**. Şirket listesi için:

- `layout/Library/AppTrackerBlock/companies.tsv` (alan adı → şirket adı)
  DuckDuckGo Tracker Blocklists ve Disconnect verisinden üretilmiştir.
- Bu veri **CC BY-NC-SA 4.0** lisanslıdır: ticari kullanım yasak, atıf
  zorunlu, aynı lisansla paylaşılır.
  https://creativecommons.org/licenses/by-nc-sa/4.0/
- Kaynaklar dosyanın başında ve `data/build-companies.mjs`'te yazıyor.
- Ticari bir pakette kullanacaksan bu dosyayı çıkar. O zaman engel çalışır,
  yalnız rapor sayfasında şirket adları görünmez.

Engel listesi (HaGeZi Multi PRO) pakete girmez. Kullanıcının cihazında
`atb-update` ile indirilir. Lisansı bu örnekte doğrulanmadı.
