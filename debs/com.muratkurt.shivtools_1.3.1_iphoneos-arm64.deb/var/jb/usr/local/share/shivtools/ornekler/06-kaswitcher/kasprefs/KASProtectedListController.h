#import <Preferences/PSListController.h>

@interface KASProtectedListController : PSListController
@end
