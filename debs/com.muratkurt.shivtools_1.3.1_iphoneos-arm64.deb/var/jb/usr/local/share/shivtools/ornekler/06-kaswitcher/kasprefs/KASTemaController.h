// KASwitcher 0.6.0 m14 — tema secim listesi, her satirda kucuk onizleme.
// Stok PSListItemsController (secim/onay/kaydetme ayni); yalniz hucreye
// resim eklenir. Satir -> tema eslemesi ozel API'siz: hucre yazisi paketin
// kendi cevirisiyle (Root.strings) karsilastirilir.
#import <Preferences/PSListItemsController.h>

@interface KASTemaController : PSListItemsController
@end
