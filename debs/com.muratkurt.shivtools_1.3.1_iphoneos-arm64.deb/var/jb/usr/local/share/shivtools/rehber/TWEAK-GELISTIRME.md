# Tweak geliştirme — birikmiş rapor

**Kapsam:** ActionButtonFix 2.1 → 2.7.0 · KASwitcher 0.0.1 → 0.5.1 ·
DolapClean 0.1.0 (Ağustos–26 Eylül 2026)
**Ortam:** iPhone 15 Pro (iPhone16,1) iOS 17.0.3 RootHide · iPhone XS
iOS 16.1.1 rootless (Dopamine) · Theos (RootHide çatalı + standart) ·
frida 16.1.4 → 17.19.0 (27 Eyl'den beri taban 17) · shivtools · iOS MCP

Bu belge üç projenin raporlarını tek yerde toplar. İçinde yalnız
**ölçülmüş** şeyler var; ölçülmeyenler açıkça öyle işaretli. Amacı,
bunu okuyan bir ajanın aynı duvarlara ikinci kez toslamaması.

> **Etiket kuralı.** Başlık dökümünden, GitHub'dan ya da hafızadan gelen
> bilgi, cihazda görülene kadar **DOĞRULANMADI**'dır. Ölçülmüş bilgiyle
> doğrulanmamış bilgi aynı cümlede durursa, sonraki oturum ikisini
> ayırt edemez.

**Bu belge ile kardeşleri:**

| Belge | İşi |
|---|---|
| **Bu belge** | Üç projenin ortak birikimi: yöntem, duvarlar, bilgi tabanı. Okunur, uygulanmaz. |
| `SHIVTOOLS.md` | Kanun: kırmızı çizgiler, çalışma döngüsü, araç listesi. Her oturumda uygulanır. |
| `TWEAK.md` | Reçete kitabı: çalışan kod, komut satırları. Gerektiğinde açılır. |
| `MAC-TWEAK-GELISTIRME.md` | Aynı bilgi, **shivtools olmadan** Mac'te çalışacaklar için. |

---

## 1. İşleyen süreç modeli

Dört adım, sırayla. Biri atlandığında tur boşa gitti — istisnasız.

1. **ÖLÇ** — belirtinin sebebini tahmin etme, cihazdan veri al.
2. **SEBEP** — ölçümden çıkan **tek cümlelik** sebep.
3. **DÜZELT** — yalnız o sebebi hedefleyen **en küçük** değişiklik.
4. **DOĞRULA** — önce derlenen ürünün *içinde* izini ara, sonra cihazda.

**En fazla iki kurulum turu.** Üçüncüye girme: dur, ölçtüğünü yaz, geri
dönüş komutunu ver. Üç projede de üçüncü tur hiçbir zaman işe yaramadı.
KASwitcher'da "elle kapatınca da animasyon" iki turda tutmadı, durduruldu
ve kod geri alındı — doğru karar buydu.

**Bir yol tıkanırsa aynı yolu ikinci kez deneme.** Yön değiştir: görünüm
katmanı tutmuyorsa veri katmanına in (DolapClean), sistem menüsü
tutmuyorsa kendi menünü çiz (KASwitcher), standart yükleyici çalışmıyorsa
kendi yükleyicini yaz (ActionButtonFix).

**Kullanıcı ölçüm aletidir.** Üç projede de kilit bulguların bir kısmı
kullanıcının gözlemiyle geldi ("boşluk sonradan yükleniyor", "gelip
gidiyor", "hepsi gitti"). Numaralı, **en fazla 5 adımlık** test betiği
ver; "bir dene" deme.

---

## 2. Ölçüm yöntemleri — hangi soru, hangi ölçüm

### 2.1 Önce logla, sonra düzelt
Ölçüm hook'u `%orig`'i olduğu gibi çağırır, yalnızca satır yazar:
**ms damgası + olay adı + ilgili alanlar**. KASwitcher'ın son iki hatası
da (680 ms gecikme, respring sonrası tek seferlik titreme) araçla değil
bu yöntemle bulundu.

- Ölçüm için **yeni API getirme**; tweak'in zaten kullandığı yolu kullan.
  Yoksa ölçtüğün şey ürünün davranışı olmaz.
- Her adımda `respondsToSelector:`; boş/nil değer çökme yerine **ayrı
  etiketle** loglanır — "yok" da veridir.
- Tamamı `@try`, `@catch`'te ayrı satır. Ölçüm kodu ürünü düşürmez.
- Private objeyi `%@` ile yazma; yalnız string etiket ve sayı.
- **Animasyonun bitiş bayrağını da logla** (`finished=0` = yarıda
  kesildi). "Kapandı sanılan" animasyon çoğu zaman kesilmiş animasyondur.

### 2.2 Kurulan hook ≠ çalışan hook
DolapClean'de CleverTap hook'u kuruldu ama oturum boyunca **hiç
çağrılmadı**. `%ctor`'da her grup için "kuruldu/YOK" yaz; ayrıca her
hook'un **ilk çağrısını** bir kez yaz. "Kuruldu var, çağrıldı yok" bir
eksiklik değil, ölçümün kendisidir.

### 2.3 Sessiz çıkış yolu ölçüm kaybıdır
KASwitcher m7: fonksiyon `fitting=0` görüp sessizce çıktı, günlükte sebep
yoktu, bir tur ona gitti. m8'de karar **girdileri** loglanınca
(`degisim yok yigin=250 fit=250`) sebep ilk bakışta göründü.
**Erken dönen her dalda kararı veren değerleri yaz.** Eylemi loglamak
yetmiyor; kararı loglamak gerekiyor.

### 2.4 Model mi, ekran mı?
Kendi animasyonun tutmuyorsa `view.transform`/`alpha` (model) ile
`layer.presentationLayer` (ekran) ayrı ayrı loglanır — önce ve sürenin
¼/½/¾'ünde. KASwitcher 0.5.0: model hep sistemin 0.685 ölçeği, ekran
alfası hep 1.00 → **sistem bu özellikleri her karede geri yazıyor.**
Çare: sistemin sahiplendiği görünüme dokunma;
`snapshotViewAfterScreenUpdates:NO` kopyasını canlandır, aslını kendi
yolundan kaldır.

### 2.5 Önce say, sonra süz
DolapClean: yanıt **değiştirilmeden** `tmp/`'ye kaydedildi, beklenen sayı
Mac'te önceden hesaplandı, sonra tweak'in günlüğüyle karşılaştırıldı:
47→26 (sponsorlu 6), 41→24, discover 8→0 — birebir tuttu. Bir süzgecin
doğruluğu "ekran temiz görünüyor"dan değil **önceden hesaplanmış
sayıdan** anlaşılır.

### 2.6 Kare kare ekran görüntüsü
Görsel hatalar (titreme, tek karelik yeniden çizim, yanlış konum, kesik
metin) **günlükte görünmez**. Kullanıcı ekran kaydını Fotoğraflar >
Düzenle'de kare kare ilerletip görüntü alır, ajan kareyi doğrudan okur.
KASwitcher 0.4.4 ve DolapClean'in kilit bulguları bu yoldan geldi.
Gizlilik: yalnız işaretten sonraki kareler açılır.

### 2.7 Kayıt modu (geometri işi)
Tek atış yerine kayıt: her düzen değişiminde numaralı döküm + titreşim.
Kullanıcı hangi anın yakalandığını titreşimden anlar, ajanla
eşzamanlama gerekmez. Yatay switcher'ın hiç ölçülmemiş olduğu böyle
ortaya çıktı (KASwitcher 0.0.1'den beri).

### 2.8 Tanı sürümü
Belirti tekrar edilemiyorsa ya da uzaktaki bir kullanıcıdaysa: davranışı
değiştirmeyen, yalnız log yazan bir **tanı sürümü** kurulur
(ActionButtonFix 2.6.1~diag1). Tek log satırı, disassembly'de kurulan
bütün anlatıyı bitirdi.

### 2.9 İki iOS sürümünü karşılaştırma (statik)
IPSW indir → sistem/cryptex DMG mount → `dyld_shared_cache_arm64e` →
`ipsw dsc disass`. ActionButtonFix 2.6.1'de 17.0.3 ile 17.3 böyle
karşılaştırıldı.
**Ama tek başına yanıltır:** en güçlü görünen aday (`hostBundleRequires
Validation`) ölçümde **0** çıktı; belirtiyi açıklayan şey disassembly'de
aranmayan bir gözlemci metodunun varlığıydı. *İkili karşılaştırma "ne
değişmiş"i verir, "neden bozuldu"yu vermez.*

### 2.10 Ölçüm dosyası arşivlenmeden silinmez
2.6.1 turunda sağlıklı taban log'u `rm -f` ile silindi ve karşılaştırma
kayboldu; oturum dökümünden geri yazıldı.

---

## 3. Ortam: namespace, ABI, dağıtım

### 3.1 RootHide namespace tuzağı
Kabuk **jbroot** içinde, SpringBoard ve sistem süreçleri **gerçek** yolda
çalışır. Aynı yol iki süreç için aynı yeri göstermez.

| Belirti | Gerçek durum |
|---|---|
| Tweak `/var/mobile/tw/x.txt` yazıyor, kabukta yok | `/rootfs/var/mobile/tw/...` altına bak |
| `node /mutlak/yol/x.mjs` → MODULE_NOT_FOUND | `cd` edip **göreli** adla çalıştır |
| Betik PATH'ten çözülmüyor | uzun jbroot yoluyla çağır |
| Ajanın dosya aracı yanlış yere yazdı | Dosya araçları **gerçek kökte**, kabuk **jbroot'ta**: araca `/private/var/...` ver |
| Uygulama tweak'i `/var/mobile/tw`'ye yazamıyor | Sandbox. `NSTemporaryDirectory()`'ye yaz, kabuktan `/rootfs/var/mobile/Containers/Data/Application/<UUID>/tmp/` oku |

jbroot adı **yeniden başlatmada değişir** — sabit yazma, `glob` kullan.
Kurulumdan sonra da değişebiliyor (ActionButtonFix 13 §6).

**Yeniden jailbreak'te AI CLI geçmişi de "kaybolur"** (27–28 Eyl,
ÖLÇÜLDÜ, iki kez): Claude Code oturumları, otomatik hafıza ve
`--scope local` MCP kaydı proje yolunun MUTLAK hâline bağlı; yol jbroot
kimliğini içerdiği için yeni jailbreak'te yeni, boş bir proje açılır.
Hiçbir şey silinmez. Çare: yeni proje anahtarını eskisine **symlink**
(ikinci jailbreak'te ölçüldü: hafıza ve oturum geri geldi); MCP kaydı
`--scope user`. Anahtarı `jbroot /` çıktısından türetme — o Bundle
yolunu verir, anahtar AppGroup yolundan türer; yalnız `<ID>` al.

### 3.2 caps / OldABI — kuralın bugünkü hâli
- **caps 0x00 tek başına zararsız.** Kusur değil, bağımlılık.
- Belirleyici **iki tetikleyici**: bir `@"..."` literali, ya da sisteme
  verilen bir blok (`[block copy]`). İkisi de yoksa cihazda derlenen
  arm64e tweak `oldabi` olmadan da çalışır (7 örnek, sıfır istisna).
- Sınav: `otool -l <dylib> | grep -c __cfstring` → **0** olmalı.
  arm64 (uygulama) hedeflerinde bu konu **hiç** geçerli değil.
- Tetikleyici varsa iki dürüst yol: `control`'e
  `Depends: firmware (<< 15.0) | cy+cpu.arm64v8 | oldabi`, **ya da**
  Mac'te derle (caps 0x80) ve hiçbir şeye bağımlı olma.
- **ÖLÇÜM TUZAĞI:** derleme cihazında `oldabi` kuruluysa tetikleyicili
  paket de "çalışıyor" görünür. Gerçeği görmek için `OldABI.dylib`'i
  adından taşıyıp tek değişkenli A/B yap.

**caps'i doğru araçla oku (26 Eylül'de bir kez yanlış okundu).** Tweak
dylib'i genelde **fat**; `od` fat dosyada fat başlığını gösterir.
Doğrusu:
```
lipo <dylib> -thin arm64e -output /tmp/s && od -A n -t x1 -N 12 /tmp/s
   → 12. bayt: 80 yeni ABI · 00 eski
otool -f <dylib>   → capabilities 0x80
```
`file` çıktısındaki **`PAC00` caps baytı DEĞİLDİR** — 0x80 ve 0x00 ikilide
aynı görünebiliyor. Ayrıca **"cihazda derlenen hep 0x00" artık doğru
değil**: 26 Eylül'de bu cihazda derlenen bir paket `capabilities 0x80`
çıktı. Varsayma, her pakette ölç.

### 3.3 Şema ve klasör adı tuzağı
Şemayı **hedef** jailbreak belirler, derleme cihazı değil.
```
make THEOS=<theos> clean package THEOS_PACKAGE_SCHEME=roothide|rootless FINALPACKAGE=1
```
Mac'te iki theos kurulu ve **adları yanıltıyor** (ölçüldü,
`.git/config`'ten):
```
~/theos-rh          → roothide ÇATALI      (roothide/theos)   → roothide şeması
~/theos-roothide    → STANDART theos       (theos/theos)      → rootless şeması
```
Ada bakıp seçersen ikisini de yanlış şemayla derlersin.

### 3.4 Derleme ve kurulum doğrulaması — altı adım
Her kurulum turu pahalı (respring + kullanıcı testi). Turu harcamadan
önce hepsi geçmeli:

1. **Kaynak farkı:** son yedekle `diff` — değişen yalnız beklediğin yer mi?
2. **Bozuk yorum:** `grep -n '^[[:space:]]*/[^/*]' <dosya>` boş dönmeli.
3. **Derleme geçti mi — `ls -t`'ye ASLA güvenme.** Çıktıdaki
   `dm.pl: building package '...' in './packages/<ad>.deb'` satırını ara.
   Satır yoksa deb arama: başarısız derlemede **eski deb yerinde duruyor**
   ve sessizce kurulur.
4. **Ürünün içinde iz:** `dpkg-deb -x` ile aç. `strings` çıplak ikilide
   yanıltır — kesin olan `LC_UUID`: derlenen ile kurulanı karşılaştır.
5. **Kurulum:** `dpkg -i` → `exit=0`, ardından `dpkg -l` ile **sürümü
   gözle doğrula**. "Tamamlandı" denip `exit=2` döndüğü oldu.
6. **Respring'i kullanıcıdan iste** — dylib değişikliği çalışan süreci
   etkilemez.

3. ve 4. adım en çok tur yiyen yer: bir turda **dört test bayat deb
üzerinde** yapıldı. Prefs bundle'ı AYRI bir ikilidir, onu da doğrula.

### 3.6 Kurulum ritüeli — iki ölçülmüş tuzak

- **RootHide kurulumdan SONRA dylib'i değiştiriyor.** `cmp` ile ölçüldü:
  41 bayt fark (8 bayt `__TEXT` padding, kalanı imza bölgesi), boyut
  aynı. Yani md5 karşılaştırmasını **kurulumun hemen ardından** yap; bir
  süre sonra bakıldığında ana dylib'in farklı çıkması normaldir.
  (Prefs bundle'da ve ikinci dylib'de bu fark görülmedi.) `LC_UUID`
  karşılaştırması bu yüzden md5'ten daha güvenilir.
- **Kurulum yarışı.** `dpkg -i … ; (nohup sbreload &)` aynı komutta
  çalıştırıldığında kurulum bir kez **hiç gerçekleşmedi** (sürüm eski
  kaldı, hash tutmadı). Kurulum ve respring **ayrı** çalıştırılır.
  Ve `dpkg -i` çıktısının tamamı okunur: yalnız `grep Setting`
  hatayı gizler.
- **Referans başlıkları kalıcı tut.** Bir turda oturum scratchpad'i
  silinince cihazdan çıkarılan header'lar kayboldu; bir daha çıkarmak
  gerekti. `REFERANS/headers-<iOS sürümü>/` gibi kalıcı bir yere koy.
- **Hız/başarım iddiasını doğru tabanla kıyasla:** "daha hızlı" demek
  için bir önceki **yayınlanmış** sürümle karşılaştır, ara ölçümle değil.

### 3.5 Dağıtım
- Yayın paketi **Mac'te** derlenir (caps 0x80), cihaz derlemesi ölçüm
  içindir.
- `control`: `Author`/`Maintainer` tek isim (`muratkurt`), depo alanları
  (`Icon`, `Depiction`, `SileoDepiction`, `Homepage`) **eksik olursa
  Sileo ikonu ve açıklamayı hiç göstermez**.
- Depo indeksi: `dpkg-scanpackages` **bilinmeyen alanları atar** —
  `SileoDepiction` onunla kaybolur ve Sileo sessizce HTML depiction'a
  düşer. Alanları koruyan bir üretici kullan ve üretimden sonra alan
  sayısını **denetle**.
- Banner 1200×400, içerik kenarlardan **%15 içeride** (Sileo kırpıyor).
  İkon köşeleri **saydam ve yuvarlak** olmalı: Sileo yuvarlıyor, Ayarlar
  yuvarlamıyor — hazır yuvarlatılmış PNG ikisinde de doğru görünür.

---

## 4. Keşif — hangi sınıf, hangi metot

**Sıra:** cache'ten sınıf ara → metot adları → **imza** → hook.
İmzayı görmeden çağırma; dönüş tipi bilinmeyen bir metodu çağırıp dönen
değeri tutmak `objc_retain` çökmesi ve safe mode demektir (iki kez
yaşandı).

- **İmza = tip kodlaması**, ad değil. `-nowPlayingApplication @16@0:8`:
  önce DÖNÜŞ (`@` nesne), sonra `self`(@) ve `sel`(:); sayılar bayt
  ofseti. `v`=void `B`=BOOL `i`=int `q`=long `d`=double `^v`=pointer
  `{CGRect=...}`=yapı. Dönüş `?` ise **çağırma**.
- Tip **dyld cache'ten okunamıyor**: relative method list'ten çıkarma
  denendi, hesaplanan adres komşu dizeye düştü (beklenen `v24@0:8@16`
  yerine `q24@0:8@16`). Tip **çalışan süreçten** okunur
  (`class_getInstanceMethod` + `method_getTypeEncoding`).
- **Public mi private mi?** SDK başlığında ara — ama sınıfın **kendi**
  başlığı, **üst sınıf zinciri** ve **protokolleri** içinde. Başka
  sınıfın başlığındaki aynı ad "public" demek değildir: `UIAction
  -handler` tüm SDK'da arandığında `CMFallDetectionManager.h` eşleşti ve
  private bir getter public sanıldı. Ayrıca çok parçalı seçici başlıkta
  **tam hâliyle geçmez** (`performWithSender:target:` yerine
  `- (void)performWithSender:(id)sender target:(id)target;`), tek parçalı
  seçici de argüman adı olarak geçebilir (`handler`).
- **Sınıfın adı ne yaptığını söylemez.** `SBFluidSwitcherViewController`
  switcher değil, app ve ana ekran geçişlerini de barındıran kap;
  `dolap.VerificationView` aslında Menü'deki resim banner'ı.
  **Metotlar için de geçerli:** isimden tahmin edilen üç metodun ikisi
  yanlış çıktı (`containerDidEndSwipingToKill:` yalnız *vazgeçilen*
  çekişte geliyor, `_removeAppLayout:forReason:` elle kapatmada hiç
  gelmiyor). Hook yazmadan önce yalnız-ölçüm kurulumuyla **zinciri
  çıkar**.
- **Swift sınıfları** modül önekiyle kayıtlı (`dolap.Foo`,
  `UIComponents.Bar`). `%hook Takma` + `%init(Grup, Takma =
  objc_getClass("dolap.Foo"))`; sınıf yoksa `%init` çağrılmaz, yani nil
  sınıfa hook kurulmaz. `%init`/`%orig` **`#define` içine konmaz**
  (Logos önişlemciden önce genişletir).
- Uygulama ikilisinde sınıf/uç nokta ararken `strings` işe yarar: tip
  adları, uç noktalar, enum değerleri oradan çıktı (DolapClean).

---

## 4b. Hook noktasını seçmek — tetikleyici → sahip → stok yol

ActionButtonFix'in tamamı bu üç adımın hikâyesidir. Sırayı bilmeyen,
her adımda birkaç tur harcar.

### Adım 1 — Tetikleyiciyi hook'la, ama EN DAR noktayı
İlk akla gelen sınıf genelde yanlıştır, çünkü **paylaşılan altyapıdır**.
Ölçülen eleme:

| Aday | Sonuç |
|---|---|
| `SBHardwareButtonGestureParameters.longPressTimeInterval` | **Tüm** butonları etkiliyor — elendi |
| `SBPressGestureRecognizer` / `SBHBLongPressGestureRecognizer` | Metot adları çıkmadı — elendi |
| `SBRingerHardwareButtonSettings.longPressTime` | Seçildi, sonra terk edildi (yan etki) |
| **`performActionsForButtonDown:/Up:/LongPress:`** | **Final** — yalnız o butonun kendi yolu |

**Kural:** olayı taşıyan **en dar** noktayı seç. Paylaşılan bir parametre
ya da zamanlayıcı üzerinden çözüm, başka her şeyi de değiştirir.

### Adım 2 — Davranış yapışmıyorsa DURUMUN SAHİBİNİ bul
Tetikleyiciyi yakalamak, sonucu değiştirmeye yetmez. ABF'de eylemi
belirleyen şey butonda değil, **veri kaynağındaydı**:
`SBSystemActionDefaultsDataSource` / `…AbstractOverridableDataSource`
ve onun `_selectedSystemAction` alanı.

Yapılan (ölçüldü, M): tıklama anında sahibin `_selectedSystemAction`
alanına **Apple'ınkiyle birebir** bir eylem yazılır, stok akış oynatılır,
**1,5 sn sonra eski değer geri konur.** Böylece iOS ayarı "Sessiz Mod"
iken bile bizim eylemimiz çalışır ve kullanıcının ayarı bozulmaz.

**Kural:** "gösteren/ kullanan" değil, **tutan** hook'lanır. Bir şeyi
değiştirip geri koyuyorsan, geri koymayı da ölç (ABF'de geri yükleme
süresi 1,5 → 6 sn denendi, fark etmedi — yani sorun zamanlama değildi).

### Adım 3 — Stok davranış isteniyorsa ORİJİNALİ OYNAT
"Tek tıkta iOS'un kendi eylemi çalışsın" istendiğinde iki yol denendi:

- **Apple'ın executor'ını dışarıdan sürmek** → *her durumda* Safe Mode
  (`EXC_BREAKPOINT`, `-[SBAbstractSystemActionExecutor
  executeWithContext:completion:]` içinde `isExecuting` assertion'ı).
  **Kapalı yol.**
- **Orijinal IMP'leri sırayla oynatmak** (`Down → LongPress → Up`) →
  çalıştı. Sistemin kendi zincirini kendi sırasıyla çalıştırıyorsun;
  hiçbir şeyi yeniden yazmıyorsun.

**Kural:** stok davranışı **taklit etme, oynat**. Sistemin iç
yürütücüsünü dışarıdan sürmek assertion'a çarpar.

### Adım 4 — "Bazı durumlarda çalışmıyor" ise kapıyı ara
Ekran kapalıyken hiç tetiklenmiyordu. Sırayla elendi: tür farkı (✗),
zamanlama (✗), basışın bize ulaşması (✓ ulaşıyor, sorun Apple tarafında).
Sonra Apple'ın kodu okunup durum bayrakları loglandı: `_inhibitActions`
hep 0, ama **suppression** ekran kapalıyken 1, açıkken 2. Çare: Down'dan
**önce** ekranı uyandır, suppression 1'den çıkana kadar bekle
(250–300 ms), sonra zinciri oynat. Her durumda çalıştı.

**Kural:** "çoğunlukla çalışıyor" bir çözüm değildir. Çalışmayan durumda
**sistemin kendi durum bayraklarını** logla; fark oradadır.

### Yöntem: tek değişkenli ölçüm zinciri
Bu iş A'dan N6'ya **her satırı tek değişken** olan bir tabloyla
yürütüldü: hipotez → değişiklik → sonuç → ders. Tablo tutmanın iki
faydası ölçüldü:
1. Elenen yol bir daha denenmiyor (aynı duvara ikinci kez toslamak
   pahalı).
2. "Neden A ve B boşa gitti" satırı, ajanın kendi hatasını da kaydediyor
   — ABF'de iki kez **kod okunmadan ölçüme girildi** ve iki tur gitti.

> **Yan ders (iki kez yaşandı):** hook yazmadan önce **kendi kodunu**
> oku. `cameraMode` parametresi intent'e eklendi ve iki tur denendi;
> sonra görüldü ki bizim blok o intent'i **hiç okumuyordu**.

---

## 5. SpringBoard — bilgi tabanı (KASwitcher)

**Switcher iç yapısı**
- Kart: `SBFluidSwitcherItemContainer` → `SBReusableSnapshotItemContainer`
- Bundle id: kart `.appLayout` → `allItems` → `SBDisplayItem.bundleIdentifier`
- Başlık: `SBFluidSwitcherItemContainerHeaderView` (kartın kardeşi)
- Silme: `_deleteAppLayoutsMatchingBundleIdentifier:`
- Silme bildirimi: `-[SBMainSwitcherControllerCoordinator switcherContent
  Controller:deletedDisplayItem:inAppLayout:forReason:]` (v48@0:8@16@24@32q40)
- Pencere seviyeleri: `SBMainSwitcherWindow` 5 · `SBHomeScreenWindow` −2

**Switcher görünürlüğü — ölçüldü, tekrar deneme**
- `isAnySwitcherVisible` **geç ve yanlış**: geçişten 600–1000 ms sonra
  dönüyor, switcher'dan açılan app ön plandayken hâlâ YES diyor.
- `transitionDidBegin` iki yönde de tetikleniyor, **yön taşımıyor**.
- Yönü taşıyan çağrı: `-[SBMainSwitcherControllerCoordinator switcher
  ContentController:performTransitionWithRequest:gestureInitiated:]`.
  `SBSwitcherTransitionRequest.appLayout` argümanı yönü verir:
  `nil` → switcher açılışı · `allItems` boş → ana ekran · dolu → app.
  `com.apple.springboard` bundle id'si HİÇ gelmez.

**Genel dersler**
- **Görünürlüğü durum makinesine bağlı her view, makinenin "kapalı"
  durumunda doğmalı** (`hidden=YES, alpha=0`). Görünür doğan view ilk
  karara kadar yanlış durumda kalır: respring sonrası **ilk** açılışta
  tek seferlik titreme olarak görünür ve sonraki denemelerde kaçar.
- Switcher görünümü **kaydırma başlar başlamaz** yükleniyor, gerçek
  açılıştan ~1,5 sn önce. "Görünüm yüklendi" ≠ "kullanıcı görüyor".
- Kart/hücre görünümleri **yeniden kullanılır**: rozet ve etkileşim
  idempotent kurulmalı; `prepareForReuse` animasyon sürerken
  transform/alpha sıfırlarsa animasyonu öldürür. Yeniden kullanım
  yüzünden **"görünüm → bid" ters eşlemesi bayatlar**; kimlik için
  görünümün kendi `appLayout`'unu oku.
- **Sistemin geçişte kullandığı transform bileşenine dokunma** (scale).
- **Yoklamaya dayalı görünürlük geç kalır**; erken ve yön taşıyan bir
  çağrı ara, yoklamayı emniyet ağı olarak bırak.
- **Emniyet supabı hatanın kendisi olabilir**: "10 tur uyuşmazsa sistemi
  kabul et" türü sayaç iki ayrı belirtinin doğrudan sebebi oldu.
- **Pencere DÖNMEZ, içerik döner.** Yatayda `SBMainSwitcherWindow` hâlâ
  393x852; dönüşü `BSUIOrientationTransformWrapperView` transform ile
  yapıyor. İki sonucu: o görünümün `safeAreaInsets`'i yatayda da DİKEY
  değerleri veriyor, ve `UIContextMenuInteraction` menüsü **pencere
  yönünde** açılıyor. Arayüz yönünün tek güvenilir sinyali **içerik
  görünümünün boyutu** (`sbo`/`scene` yatayda da 1 kalıyor, `dev`
  cihazın fiziksel duruşu).
- **Ekrana view koyan her tweak dikey VE yatay ölçülür.** KASwitcher
  0.0.1→0.4.3 boyunca yatay hiç ölçülmemişti; ilk ölçümde X butonunun
  yatayda kartların üstünde kaldığı görüldü.

**Overlay'de kendi menün** — `UIContextMenuInteraction` switcher'da üç
ayrı kusur üretti: yatayda dikey açılma, önizleme cam/gölge sıçraması,
küçük ve ortalı kaynakta menünün butonun üstüne oturması (konum için
public API yok). İçerik görünümünün **içinde** çizilen kendi menün
(basılı tutma + `UIImpactFeedbackGenerator`) üçünü birden kaldırdı.
Tuzaklar: punto **sabit 17 pt olmaz** (`preferredFontForTextStyle:
UIFontTextStyleBody`; kullanıcının metin boyutu `UICTContentSize
CategoryS` iken stok menü 15 pt), onay işareti sağa (solda metni itip
harf yutuyor), `UIAction`'ın `-handler` getter'ı yok → kendi öğe
modelini kur. (`-[UIMenuLeaf performWithSender:target:]` 16.5 SDK'sında
**public**.)

---

## 6. Uygulama içi tweak — Swift/SwiftUI (DolapClean)

Swift'le yazılmış bir uygulamada reklam/tanıtım kaldırmanın **doğru yeri
görünüm katmanı değil, veri katmanıdır.**

- **Görünümü gizlemek delik bırakır, veriyi silmek bırakmaz** — ikisi de
  ölçüldü: `products=[]` dönen bölüm ekranda **hiç çizilmedi**; buna
  karşılık Menü banner'ı gizlenince yerinde **~160 pt boşluk** kaldı
  (yığın yüksekliği banner gizliyken de 250, 6 ölçüm).
  **Kural:** kaldırmadan önce "veriyi susturursam bölüm doğar mı" diye
  ölç. Uygulama alanı veriden bağımsız ayırıyorsa görünüm tarafı zaten
  yetmeyecek.
- **Ağ katmanı reçetesi.** `Alamofire.SessionDelegate` Swift ama ObjC'den
  görünür: `URLSession:dataTask:didReceiveData:` (v40) parçaları biriktir
  ve **iletme**; `URLSession:task:didCompleteWithError:` (v40) anında
  JSON'u süz, kendi `didReceiveData:` çağrını **bir bayrakla** geçir,
  sonra `%orig`. Hata ya da çözülemeyen JSON'da **orijinali** ver.
- Tampon ayrıntısı: görev başına `NSMapTable weakToStrongObjectsMapTable`
  + `@synchronized`; görev bitince tampon silinir. Zayıf anahtar,
  görev serbest kalınca tamponun düşmesini sağlar.
- **Beyaz liste / kara liste kararı:** akış (feed) → **beyaz** liste
  (yalnız `type == PRODUCT` kalır; yeni tanıtım türü kendiliğinden
  düşer). İşlevsel sayfa → **kara** liste (bileşenlerin çoğu işlevsel,
  yalnız tanıtım türleri silinir).
- **Kimlik alanı yoksa metinle ayır:** sponsorlu ürünün rozetinde kimlik
  yok, yalnız `bottomLeftBadges[].title == "Sponsorlu"`. Karşılaştırmayı
  büyük/küçük harf duyarsız ve içerik-arar yap.
- **Sandbox:** uygulama tweak'i `/var/mobile/tw`'ye yazamaz.
  `NSTemporaryDirectory()` kullan.
- Uygulama güncellenince sınıf adları, uç noktalar ve `type` değerleri
  değişebilir. Sınıf yoksa grup kurulmaz; JSON çözülemezse orijinal
  geçer — ikisi de tweak'i güncellemeye karşı **sessizce güvenli** yapar.
- **Ölçüm confound'u:** aynı uygulamaya giren başka tweak'ler ölçümü
  kirletir (cihazda iki eski test tweak'i daha Dolap'a giriyordu).
  Ölçüme başlamadan "bu uygulamada benden başka kim var" diye bak.

---

## 7. Ayarlar sayfası (prefs) — en çok tur yiyen alan

> ActionButtonFix'te en çok tur harcanan yer kamera değil **prefs** oldu.
> **Prefs'te hiçbir hata ses çıkarmaz:** derleme geçer, tweak yüklenir,
> sayfa boş gelir ya da seçim kaydolmaz. Bir hücrenin görünmesi, onun
> eyleminin çalıştığını **kanıtlamaz**. Her katmanı ayrı kanıtla.

### 7.1 Önce stok yolu dene
`PSListController` + `Root.plist` + PreferenceLoader çalışıyorsa hiçbir
şey icat etme. Stok yolun kuralları:
- Ayarlar'ın push ettiği detay sınıfı **`PSViewController` soyundan
  olmak zorunda** (düz `UIViewController` → `setRootController:` çökmesi).
- `specifiers` **gerçek bir dizi** olmalı (boş/nil → `NSRangeException`).
- Tekli seçim: `PSListItemsController` + `validValues`, `validTitles`,
  `shortTitles` — yanlış anahtar Ayarlar'ı çökertir.
- Dinamik liste **stok yoldan**: dinamik `PSSpecifier` +
  `reloadSpecifiers`. Kendi `UITableView`'ini kurma.
- Uygulama listesi: `LSApplicationWorkspace defaultWorkspace →
  allInstalledApplications`; ikonlar `PSTableCell` lazy icon
  (`appIDForLazyIcon`, `useLazyIcons`). Hazırı varsa **AltList**
  (`ATLApplicationListSelectionController`).
- Slider `PSSliderCell`/`PSSegmentableSlider`: **asıl alt görünüm iki
  seviye derinde**, genişlik düzeltmesi yanlış seviyeye uygulanırsa
  etkisiz kalır.
- Örnek almak için Apple'ın kendi bundle'ları:
  `/System/Library/PreferenceBundles/*.bundle` (jbroot'ta `/rootfs/...`).

### 7.2 Stok yol çalışmıyorsa — kendi yükleyicin (ABF deseni)
ActionButtonFix'te `loadSpecifiersFromPlistName:target:` **count=0**
döndü: sınıf çalışma anında kuruluyor (`objc_allocateClassPair`),
`bundleForClass:` nil, Root.plist bulunamıyor. Kendi yükleyici yazıldı:
bundle'ı ID ile bul → `Root.plist`'i `fopen` ile oku →
`NSPropertyListSerialization` → her dict için
`preferenceSpecifierNamed:target:set:get:detail:cell:edit:` → `copyKeys`
listesini specifier'a kopyala.

> **Bedeli:** PreferenceLoader'ın bedava verdiği her şey (hücre tipleri,
> `set`, `cellClass`, yerelleştirme) tek tek eklenir. ABF'deki prefs
> sorunlarının neredeyse hepsi bu bedelin taksitleridir. Bu yola **ancak
> stok yol ölçülüp elendiğinde** gir.

Hücre tipleri (`cell` → tip): `PSGroupCell` 0 · `PSLinkCell` 1 ·
`PSLinkListCell` 2 · `PSTitleValueCell` 4 · `PSSwitchCell` 6 ·
`PSStaticTextCell` 7 · `PSButtonCell` 12 · diğerleri
`+[PSTableCell cellTypeFromString:]` — **tahmin edilmez**.
(Eylem listesinde `PSLinkCell` kullanılınca 12 metin kutusu ve 5 slider
çıktı; doğrusu `PSStaticTextCell` idi.)

### 7.3 ★ TEK YAZICI kuralı
En pahalı prefs hatası buydu: switch `setPreferenceValue:` ile
CFPreferences'a, eylem ise kendi yazıcımızla dosyaya yazıyordu.
**cfprefsd bizim yazdığımızı görmedi ve eski önbelleğini dosyaya geri
yazdı** — kullanıcı titreşimi kapattı, eylem kendiliğinden flaşa döndü.
`CFPreferencesAppSynchronize` ile yamama denendi, **anlık kopya ölçümüyle
çürüdü**.

**Kural: prefs dosyasına tek bir yazıcı yazar.** Ya tamamen CFPreferences
ya tamamen kendi yazıcın; ikisi bir arada olmaz. Switch'ler de dahil her
yol o tek yazıcıya bağlanır (`super` çağrılmaz).

**Kanıt yöntemi — yazıcı parmak izi:** CFPreferences aynı değerleri
dedup eder ve kendi sırasıyla yazar; elle yazıcı dedup yapmaz, `keys[]`
sırasıyla yazar. Dosyada iki ayrı `09` görmek "bunu bizim yazıcı yazdı"
demektir.

### 7.4 Elle binary plist yazmak (gerekirse)
SpringBoard tarafında CFPreferences kullanılamadığında (ctor'da crash,
yazmada Safe Mode) tweak minimal bir **parser**, prefs minimal bir
**yazıcı** taşır; ikisi aynı alt kümeyi konuşur: bool `0x08/0x09`, ASCII
string `0x5X`, dict `0xDX`.
- **Dosya baştan yazılır:** yeni anahtar eklerken *okuma, değiştirme ve
  yazma* üçüne birden eklenmeli. Okumaya eklenmezse kullanıcı başka bir
  ayarı değiştirdiği anda o anahtar **silinir**.
- Sabit indeksli serileştirme yerine **tablo tabanlı** yaz: yeni anahtar
  tabloya bir satır olur. Sınır: dict işareti tek bayt → **N < 15**.
- Uzun string sınırı: `0x5F` genişletilmiş uzunluk yolu; `offSize` 1 iken
  toplam 256 bayt sessiz sınırı vardır, uzun bundle ID'lerle **offSize 2**
  gerekir. Okuyucular `offSize`'ı trailer'dan okuduğu için bu değişim
  tweak tarafını etkilemedi (doğrulandı).
- **Kurmadan önce Mac'te sına:** yazıcı bloğunu küçük bir C dosyasına
  kopyala, örnek değerlerle çalıştır, `plutil -lint` + `plutil -p`.
  Aynı yöntemle okuyucuyu cihazdan çekilen gerçek dosyaya karşı çalıştır.
- Cihazda `xxd` yok: `od -A d -t x1`.

### 7.5 Prefs ↔ tweak bağlantısı
- İkisi **aynı alanı** okumalı; ayar değişince `PostNotification` +
  Darwin observer.
- Dosya yolu jbroot tarafına yazılıp rootfs'ten okunabiliyor: önce
  rootfs, yoksa `glob("/var/containers/Bundle/Application/.jbroot-*/...")`.
- Paket kimliği değişse bile **prefs alanını taşıma**: ABF'de paket
  `com.muratkurt.actionbuttonfix` oldu, prefs alanı `com.kimi.
  actionbuttonfix` kaldı ve çalışıyor. Toplu yeniden adlandırma
  yapılmadı — bilinçli karar.
- Yedek/geçici dosya `Resources/` içine konmaz: theos paketler.
  Her derlemeden sonra `dpkg-deb -c <deb> | grep -c 'bundle/'` beklenen
  sayıyı vermeli.
- Dil: `Resources/<dil>.lproj/Localizable.strings`. Çevirileri sınamak
  için **sistem dilini değiştirme**: uygulamanın kendi `AppleLanguages`
  tercihini süreç içinden yaz, oku, sonra **geri al**.

### 7.5b Sayfa tasarımı — EV STİLİ (kullanıcı kararı, 28 Eyl 2026)

Bütün tweak'lerimizin prefs sayfası bu düzende. Karar projeler arası
olduğu için **stilin kanonik yeri burası**; iOS'a bunu yaptıran kod ve
metot imzaları reçetede (`TWEAK.md` §4b "Page design"). Çalışan örnek:
`shivtools/SOURCE-1.2.0/prefs/` — `ShivStil.m` (görseller),
`ShivAracCell.m` (hücre), `ShivRootListController.m` (hangi satırlar).

**Yukarıdan aşağı düzen**

1. **Başlık kartı** — `[self table].tableHeaderView`: 72 pt uygulama
   ikonu (sürekli köşe), ad 28 pt kalın, tek satır tanım, `Sürüm X`,
   ve bir **durum rozeti** (nokta + yazı, durum renginin %14 alfasında
   zemin). Rozet **en kötü** durumun rengini alır: yeşil bir sayfada
   turuncu tek satır varsa rozet turuncudur.
2. **Bölüm ikonları — Ayarlar tarzı**: 29 pt yuvarlatılmış kare
   (yarıçap 6.5), üstünde beyaz SF Symbol, altında renk. Çalışma anında
   `UIGraphicsImageRenderer` ile çizilir — **pakete tek PNG girmez**,
   boyut maliyeti sıfır. SF Symbols Apple'ın sistem kümesi; iOS'ta
   lisans sorunu yok.
3. **Satırlar**: başlık + alt yazı (`UITableViewCellStyleSubtitle`).
   Sağ taraf ya **durum işareti** (`checkmark.circle.fill` yeşil ·
   `exclamationmark.triangle.fill` turuncu · `xmark.circle.fill`
   kırmızı) ya da **eylem ipucu** (`doc.on.doc` = dokun, panoya
   kopyalanır · `arrow.up.right` = dokun, açılır).
4. **Özel adlar kendi yazımıyla**: iOS, SDK, OldABI, Theos, Frida,
   Node.js, TweakInject. **Veri anahtarlarına dokunma** — yalnız
   GÖSTERİLEN adı eşle. Anahtarı düzeltmek ölçümü bozar.
5. **En altta HAKKINDA** (desen ActionButtonFix'ten): Geliştirici
   (GitHub profili — depo orada görünür) · Belgeler (deponun README'si)
   · Sorun bildir (GitHub Issues) · İletişim. Altında grup dipnotu:
   `<tweak> <sürüm> · © 2026 muratkurt · Claude Opus 5.5 ile geliştirildi`.
   **Ayrı "Sürüm" ya da "GitHub" satırı koyma** — ikisi de yukarıdakini
   tekrarlar.
6. **Sürüm ELLE YAZILMAZ.** Paketleyici bir dosyaya yazar, sayfa onu
   **kendi bundle yoluna göreli** okur. Böylece `/var/jb`,
   `.jbroot-<ID>` ve rootful'da aynı kod çalışır. Elle yazılan sürüm ilk
   unutmada yalan söyler.

**Eksik satır ne yapılacağını SÖYLESİN.** Ölçüm satırı boşsa `-` yazma;
o satıra dokununca eksiği gideren komut panoya kopyalansın. Metin
ölçümün kendi "öneri" alanından gelir, sayfada elle yazılmaz — elle
yazılan öneri araç değişince bayatlar.

**Açıklamalar elle yazılmaz.** Her satırın alt yazısı aracın kendi
kaynağından üretilen künyeden gelir. (shivtools'ta iki kez ödendi:
node aday listesi ve "shivfrida 16.x ister" satırı, ikisi de bayattı.)

**Dört sessiz tuzak — hepsi cihazda ölçüldü, her biri bir tur yedi**

| Tuzak | Belirti | Çare |
|---|---|---|
| `PSTableCell` ikonu | Sol ikon hiç çizilmiyor; `shiv-ekran` sol `UIImageView`'in **hiç oluşmadığını** gösterdi | İkon YALNIZ specifier'ın `iconImage` anahtarından alınır: `[spec setProperty:img forKey:@"iconImage"]`. `imageView.image` ve `setIcon:` hücrenin kendi tazelemesinde **eziliyor** |
| `enabled=NO` | Satır soluk görünüyor (başlık **ve** ikon gri) | Salt okunur ölçüm satırlarında `layoutSubviews`'ta geri aç: `textLabel.enabled = YES; detailTextLabel.enabled = YES; imageView.alpha = 1` |
| Yazı tipi | Metin kırpılıyor (`shiv-or…`) | `layoutSubviews`'ta konan yazı tipi geç kalıyor — etiket eski tiple ölçülmüş oluyor. Yazı tipini `setSpecifier:`'da koy |
| Buton satırı | Başlık tint rengine boyanıyor | `PSButtonCell` + `setButtonAction:` + kendi `cellClass`'ın; `textColor`'ı `layoutSubviews`'ta geri koy |

Kullanılan imzalar **çalışan Ayarlar'dan** okundu
(`shiv-sinif --tip --bid com.apple.Preferences`) — kırmızı çizgi 2.
Tamamı ve kod: `TWEAK.md` §4b.

> Prefs bundle'ı cihazda derlenince **caps 0x00** çıkıyor ve kendi ObjC
> sınıflarını (denetleyiciler) tanımlıyor → `oldabi` ister — `@"…"`
> literali OLMASA bile (1 Eki 2026, ÖLÇÜLDÜ: OldABI tek değişkenli A/B,
> `__cfstring = 0`, Ayarlar `readClass`'ta düştü; `TWEAK.md §1.6`
> 3. tetikleyici). Cihazda geliştir, **Mac derlemesini yayınla** (§3.2).

**Sayfanı frida ile okuma** (28 Eyl 2026, ÖLÇÜLDÜ — bir kez):
`shiv-ekran com.apple.Preferences` RootHide'da cihazı safe mode'a
düşürdü. Ayarlar sıradan bir uygulama değil — preferenceloader ve
cihazdaki **her** prefs bundle onun içinde; SpringBoard'dan sonra en
çok hook'lanan süreç, yani frida 17 + RootHide kusurunun tarifine
birebir uyuyor. Sayfayı **MCP'nin AX ağacıyla** oku
(`describe_screen` → `get_ui_elements`): hiç enjekte etmez ve
`PSTitleValueCell` gibi AX'te görünmeyen bir şey ararken zaten
`ocr_screen`'e düşeceksin.

### 7.5c Ayarlar'dan KURULUM SİHİRBAZI (shivtools 1.1.0, 29 Eyl 2026)

Ayarlar sayfası paket kuramaz: `mobile` olarak çalışır, `apt` root
ister (cihazda ölçüldü — *"apt-get'i gerçekten çalıştırmak için root
haklarına ihtiyaç vardır"*). Buna rağmen kurulumu sayfadan yaptırmak
mümkün; çalışan düzen şu. Örnek kod: `shivtools/SOURCE-1.1.0/`
(`prefs/ShivKurulumController.m`, `paket/kurd/`, `bin/shiv-kur`).

**Zincir — dört parça, hepsi dosya üzerinden konuşur**

```
Ayarlar sayfası (mobile)
   │  seçilen bileşen adlarını yazar
   ▼
<Preferences>/shivtools-kur-istek        ← tek satır: "node frida"
   │  launchd WatchPaths ile uyanır
   ▼
shivtools-kurd (root LaunchDaemon)       ← sabit listeye karşı doğrular
   │  exec
   ▼
shiv-kur <bileşenler> --yap              ← motor; apt'i o çalıştırır
   │  yazar
   ▼
shivtools-kur.json  +  shivtools-kurd.log
   ▲
   │  sayfa 0,5 sn'de bir okur, ilerlemeyi ve ham günlüğü çizer
```

**Neden dosya, neden soket değil:** sayfanın o dizine yazabildiği ve
`posix_spawn` yapabildiği ZATEN ölçülmüştü (sayfa kendi
`shivtools-yenile.log`'unu oraya yazıyor). Çalışan yol dururken yeni
bir taşıma katmanı kurmak, sınanmamış bir bağımlılık eklemektir.

**Durum protokolü — tek terminal aşama, biriken sonuç haritası**

Motor her adımda tek satırlık JSON yazar; arayüzün bütün kararları
buradan çıkar. Aşama adlarını ayırmak şart:

| `asama` | Anlamı | Arayüz ne yapar |
|---|---|---|
| `kuruluyor` | O **bileşen** işleniyor | Satırda dönen gösterge, başlık o bileşen, alt yazı `ileti` (o anki adım) |
| `tamam` | O **bileşen** kuruldu | Satır yeşil tik; **tur sürer** |
| `basarisiz` | O **bileşen** kurulamadı | Satır kırmızı çarpı; **tur sürer** |
| `bitti` | **Tur** bitti, tek ve son | Sonucu SAYILARDAN yaz: hepsi tamam → "Kuruldu"; bir kısmı → "Kısmen kuruldu, X kuruldu · Y kurulamadı"; hiçbiri → "Kurulamadı" |

> **En pahalı tasarım hatası buydu.** Başta bileşen hatası da tur
> hatası da `hata` diye yazılıyordu. Arayüz ilkini görüp turu bitmiş
> sayıyor, "Kurulum tamamlanamadı" yazıp ilerleme çubuğunu
> kaldırıyordu — oysa motor bir sonraki bileşene geçmiş çalışıyordu.
> **Bir kelimeyi iki anlamda kullanmak, arayüzü yanlış bilgilendirir.**

Alanlar:

- `bilesen` — o anki bileşen (terminal satırda istenenlerin tamamı)
- `biten` / `toplam` — **işlenen** bileşen sayısı. Başarıya göre
  saymak yanlış: hata olunca çubuk takılı kalır. Kaç tanesinin
  başarılı olduğu `sonuc` haritasından çıkar.
- `altadim` — bulunulan bileşenin **içindeki** yüzde (0–100). Bileşen
  başına tek sıçrama, uzun adımda donmuş görünür. Çubuk
  `(biten + altadim/100) / toplam`.
- `sonuc` — `"node=tamam frida=basarisiz mcp=bekliyor"`. **Biriken
  harita**; durum dosyası yalnız son olayı taşısaydı, ekran geri
  gelindiğinde hangi satırın ne olduğunu bilemezdi ve bilgi sadece ham
  günlükte kalırdı. Arayüz satır durumlarını olaylardan değil
  **haritadan** çizer — o zaman ekranın ne zaman açıldığı önemsizleşir.
- `ileti`, `zaman` — insan okuyacak metin ve damga.

Gerçek bir turun izi (ölçüldü, üçü de başarısız):

```
kuruluyor  node   0/3  alt=25   node=kuruluyor frida=bekliyor  mcp=bekliyor
basarisiz  node   1/3  alt=0    node=basarisiz frida=bekliyor  mcp=bekliyor
kuruluyor  frida  1/3  alt=25   node=basarisiz frida=kuruluyor mcp=bekliyor
basarisiz  frida  2/3  alt=0    node=basarisiz frida=basarisiz mcp=bekliyor
kuruluyor  mcp    2/3  alt=25   node=basarisiz frida=basarisiz mcp=kuruluyor
basarisiz  mcp    3/3  alt=0    node=basarisiz frida=basarisiz mcp=basarisiz
bitti      …      3/3  alt=100  node=basarisiz frida=basarisiz mcp=basarisiz
```

**Sıra da tasarımın parçası:** uzun ve engelli olan sona. Ama sabit
bir sıra listesi tek başına bırakılmaz — listede adı geçmeyen yeni bir
bileşen sessizce hiç kurulmaz. Sıralamadan sonra "listede olmayanları
sona ekle" adımı şart.

**Güvenlik — yüzeyi dar tut, kabul ettiğini yaz**

- Yardımcı tek girdi alır: istek dosyasındaki **kelimeler**. Her kelime
  **sabit listeye** karşı doğrulanır; biri bile listede yoksa isteğin
  **tamamı** reddedilir (kısmen çalıştırmak, kullanıcının görmediği bir
  iş yapmaktır).
- Süzgeç önce: `tr -dc 'a-z \n'`. ÖLÇÜLDÜ — `mcp; rm -rf /tmp/xyz`
  girdisi `mcprmrftmpxyz` olup listeye takıldı; noktalı virgül, boşluk,
  eğik çizgi hiç geçmedi.
- Kullanıcıdan argüman, yol, paket adı, bayrak **alınmaz**. Kabuk
  açılmaz, `eval` edilmez.
- **Kabul edilen risk yazılır:** istek dosyası `mobile`'ın yazabildiği
  bir dizinde. Yani mobile olarak çalışan bir şey, o sabit listedeki
  bir kurulumu tetikleyebilir. Başka paket seçemez, komut çalıştıramaz.
  Yazılı olsun ki sonra "bilmiyorduk" denmesin.

**ROOT, BAŞKASININ YAZABİLDİĞİ YERE YAZIYORSA — sembolik bağ.** En
pahalı ders bu oldu: shivtools **1.1.1 yayında açıktı** (1.1.2'de
kapandı) ve bu bölümün ilk hâlindeki örnek iskelet de aynı kalıbı
taşıyordu. Yardımcı root çalışıp `mobile`'ın dizinine sabit adla
yazıyordu; `>`/`>>`/`chmod` bağı izler, yani oraya bağ bırakan bir
tweak root'a keyfî dosya yazdırabilirdi (ölçüldü). Kural: **rastgele ad
+ `set -C` (O_EXCL) + `umask 022` + `mv`**; okunan dosya bağsa okuma;
`/tmp`'de de sabit ad yok. Ayrıntı ve ölçüm: `ornekler/04-kurulum-sihirbazi/OKU.md`.

**Ölçülmüş tuzaklar — her biri bir tur yedi**

| Tuzak | Belirti | Çare |
|---|---|---|
| İsteği **başta** silmek | Günlük ilk satırdan sonra kesiliyor, durum dosyası önceki turda kalıyor | Silme `WatchPaths`'i yeniden tetikliyor ve launchd çalışan işi kesiyor. İsteği **işin sonunda** sil; sonsuz döngüye karşı **deneme sayacı** koy (3. denemede bırak) |
| launchd betiği exec edemez | Daemon hiç çalışmaz | `Program = /bin/sh`, betik **argüman**. RootHide `Program`'ı geçerli jbroot ile kendi yamalar (`__Patched`), oraya jbroot yolu yazma — her jailbreak'te değişir |
| Namespace | Daemon dosyayı yazıyor, sayfa göremiyor | Daemon jbroot'u `/` görür, Ayarlar **gerçek** kökü. İki `/var/mobile/Library/Preferences` AYRI dizin (34'e karşı 473 dosya). Paylaşılan her dosyaya `/rootfs` öneki (`ortak.sh st_ayarlar_yolu`) |
| `WatchPaths` hangi kökte | Daemon hiç uyanmaz | **Gerçek kökte** değerlendiriliyor (ÖLÇÜLDÜ) — daemon jbroot görse de. İkisini birden yazmak zararsız |
| launchd job'ının PATH'i | `shiv-frida-kur bulunamadi` — araç yerli yerindeyken | Job'ın PATH'inde `/usr/local/bin` YOK. Kardeş araçları **mutlak yolla** çöz (`ortak.sh st_arac`) |
| `apt-get update` | Tur **3,5 dakika** sürüyor, ekran donmuş görünüyor | apt BÜTÜN depoları tarıyor. Geçici bir kaynak dosyasıyla **yalnız kendi deponu** güncelle: `-o Dir::Etc::sourcelist=<tmp> -o Dir::Etc::sourceparts=/dev/null -o APT::Get::List-Cleanup=0`. **9 saniye**e indi. `List-Cleanup=0` şart, yoksa apt diğer depoların listelerini siler (57 liste sınandı, yerinde) |
| Depo `Release`'i statik | Yeni yayınlanan paket apt'te **hiç görünmüyor**, tazeleme "başarılı" | apt önce `Release`'e bakar; değişmediyse `Packages`'ı **indirmez**. Checksum'suz, tarihsiz statik bir `Release` ile liste sonsuza kadar eski kalır (ölçüldü: XS'te 12,7 saat, tazeleme yalnız 208 baytlık `Release`'i çekti). Depo betiği **her yayında** `Date:` + `MD5Sum:`/`SHA256:` yazsın. Sileo kendi yoluyla tazelediği için fark edilmez — apt kullanan sihirbaz görmez |
| `NSTimer` varsayılan kip | "Sonuçlar sayfa değiştirince döküldü" | Varsayılan kipteki zamanlayıcı kaydırma/geçiş sırasında DURUR. `NSRunLoopCommonModes` |
| Detay sınıfı | Ayarlar `setRootController:`'da çöker | Push edilen sınıf `PSViewController` soyundan olmalı (§7'nin kuralı) |

**Arayüz — kullanıcıdan gelen, ölçülmüş dersler**

1. **Göster, anlatma.** İlk yazımda başlıkta *"ne kurulduğunu, nereden
   geldiğini ve kimin kurduğunu aşağıda görebilirsin"* yazıyordu.
   Kullanıcı: *"fazla temkinli davranmışsın, bu da ayrı bir şüphe
   uyandırıyor."* Şeffaflık, gösterdiğini ayrıca ANLATMAK değildir.
   Paket adı, depo ve çalışacak komut zaten her şeyi söylüyor;
   "kurulumu root yardımcısı yapar" gibi açıklama satırları kalktı.
2. **İşaretleyici, gösterge değil.** Sağdaki boş daire "bekliyor"
   demek içindi; kullanıcı *"bu işaretleyici gibi duruyor, tıklayıp
   durabilir"* dedi ve devamında daha iyisini önerdi: gerçekten
   işaretleyici olsun, **varsayılan hepsi işaretli**, istemediğini
   çıkarsın. Bir şey gibi GÖRÜNEN şey, o olmalı.
3. **Ekranda yazan komut ile gönderilen istek aynı kaynaktan
   üretilmeli.** Seçim değişince komut satırı da değişir; yoksa
   şeffaflık lafta kalır.
4. **Sonradan düğme çıkarma.** Hata anında beliren "Komutu kopyala"
   düğmesi akışı bozuyordu. Kopyalama **sabit ikon** olarak komut
   satırının sağında dursun; dokununca 2 saniye onay işaretine dönüp
   geri gelsin + titreşim. Geri bildirim eylemin YANINDA olur, sayfanın
   tepesinde değil — üstelik oraya yazmak canlı durum satırını ele
   geçiriyordu.
5. **Ham günlük sabit açık**, üstünde yalnız "Ayrıntılar" başlığı.
   Gizlemek, gizlenecek bir şey olduğunu ima eder. Ama ham günlük ÖNDE
   de olmaz: *"modern olmayan sıradan bir terminal gibi çalışırsa bu da
   şüphe uyandırabilir."* Önde okunur özet, altta ham kayıt.
6. **Uzun adımın adını yaz.** `apt-get update` dakikalarca sürerken
   başlık "Kuruluyor: Node.js" diyordu, gerçek bilgi yalnız günlükteydi.
   Başlık hangi bileşen, alt yazı **o anki adım** (durum dosyasının
   `ileti` alanı). İki ayrı kaynak aynı satıra yazmasın.
7. **İlerleme çubuğu alt adımı da saysın.** Bileşen başına tek sıçrama,
   uzun adımda donmuş görünür. Motor bileşen içi yüzdeyi yazsın
   (`altadim`), sayfa `(biten + altadim/100) / toplam` çizsin.
8. **Durumu dosyadan oku, bellekte tutma.** Ekrandan çıkıp girince
   arayüz sıfırlanıyordu. Günlüğü her turun başındaki işaretten
   (`[kurd] istek:`) oku; istek dosyası duruyorsa **süren kuruluma
   bağlan**. Durum dosyada olunca "ne zaman gelindiği" önemini yitirir.
9. **Satırın simgesi ne yaptığını söylesin.** Kopyalayan satırda
   `doc.on.doc`, sayfa açanda `chevron.right`, kurulum sürerken dönen
   gösterge. Sürerken de satır dokunulabilir kalsın — dokunan
   ilerlemeyi görmek istiyordur.

**Root'u reddeden bir kurucu varsa betiği değil adımlarını kullan.**
theos'un kurucusu root ile çalışmayı REDDEDİYOR ve şifreyi terminalden
okuyor (ÖLÇÜLDÜ). shivtools 1.3.0 bu yüzden betiği hiç çağırmıyor:
root yalnız bağımlılığı apt ile kuruyor, klon ve SDK `su mobile` ile
mobile olarak iniyor (internetten gelen kod root'ta çalışmaz). `su mobile`
iki şemada da doğru eve gidiyor (RootHide `/var/mobile`, rootless
`/var/jb/var/mobile` — rootless'ta sistemin `/etc/passwd`'ı YANLIŞ evi
gösteriyor, `su` Procursus'unkini okuyor; ÖLÇÜLDÜ 30 Eyl). Çıkış yolu
her zaman dursun: yardımcı yoksa, istek yazılamazsa ya da 30 saniyede
uyanmazsa sayfa panoya-kopyala yoluna düşsün ve **sebebini söylesin**.

### 7.6 Ayarlar sayfasını açma
Ayarlar ayaktayken `uiopen` yok sayılır. Doğru sıra:
```
launchctl list | grep -F "UIKitApplication:com.apple.Preferences["
kill -9 <pid>
uiopen "prefs:root=<Sayfa>"          # alt sayfa: &path=<specifier-id>
```
Süreci öldürmek ayrıca yeni prefs bundle'ının yüklenmesini sağlar.

---

## 8. Bilinen duvarlar — belirti → sebep → çare

| Belirti | Sebep (ölçüldü) | Çare |
|---|---|---|
| Ayarlar sayfası boş | Kendi yükleyici, `bundleForClass:` nil | Bundle'ı ID ile bul, plist'i elle oku |
| Ayar kaydolmuyor / kendiliğinden geri dönüyor | İki yazıcı; cfprefsd önbelleği dosyayı geri yazıyor | Tek yazıcı |
| Yeni ayar ilk yazımda siliniyor | Dosya baştan yazılıyor, anahtar okumaya eklenmemiş | Oku+değiştir+yaz üçüne ekle |
| Ayarlar çöküyor | Detay sınıfı `PSViewController` soyundan değil / `specifiers` boş / yanlış `validValues` anahtarı | İlgili maddeyi düzelt |
| Tweak yüklenmiyor, SpringBoard safe mode | İmzasız private çağrı ya da caps 0x00 + tetikleyici + oldabi yok | İmzayı ölç; caps'i ölç |
| View gizlendi ama yerinde boşluk | Uygulama alanı veriden bağımsız ayırıyor | Veriyi süz |
| Animasyonum saçmalıyor | Özellik sistemin; her karede geri yazılıyor | Snapshot kopyasını canlandır |
| Respring sonrası ilk açılışta titreme | View görünür doğuyor, ilk kararda gizleniyor | Kapalı doğsun |
| Yatayda düzen bozuk | `safeAreaInsets` dikey değerleri veriyor; pencere dönmüyor | İçerik boyutundan yön oku |
| Rozet/etkileşim bazen iki kez | Hücre yeniden kullanımı | Idempotent kurulum |
| Hook kurulu ama hiçbir şey olmuyor | Metot o yolda hiç çağrılmıyor | İlk çağrıyı logla; zinciri ölç |
| Kurduğum sürüm eski davranıyor | Derleme başarısız, eski deb kuruldu | `dm.pl` satırı + `LC_UUID` |
| `command not found` (cihazda) | PATH'te `/usr/local/bin` yok (tek komutluk SSH) | `export PATH=/usr/local/bin:$PATH` |
| Yazdığım dosya yok | Namespace aynası | `/rootfs/...`; dosya araçlarına gerçek yol |
| Sileo'da ikon/açıklama yok | `control`'de depo alanları eksik ya da indeks üreticisi alanları attı | Alanları ekle, indeksi denetle |

---

## 9. Sürüm kontrol listesi

1. Yeni işten **önce** `SOURCE-x.y.z/` aç (öncekini kopyala; `DEBS`,
   `_zula`, `.theos`, `packages` hariç). Paketler o klasörün `DEBS/`'una.
2. Her düzenlemeden önce **üstüne yazmayan** yedek; var olan `.bak`
   dosyasının üstüne asla yazma.
3. Toplu yeniden yazma yok: `grep -n` ile bul, `sed -n <aralık>` ile oku,
   40 satırlık parçalar hâlinde düzenle. Büyük silmeler için yedek + diff
   + denetim yapan bir araç kullan.
4. Her yazımdan sonra bozuk yorum kontrolü.
5. §3.4'teki altı adım.
6. Rapora o sürümün bölümü: **belirti, ölçüm, sebep, düzeltme**;
   ölçmediğini "ölçülmedi" diye işaretle.
7. Kullanıcıya numaralı test adımları + **geri dönüş komutu**.
8. Yayını kullanıcı yapar.

---

## 10. Ajanla çalışma — ölçülmüş davranış notları

- **Bağlam pahalı.** Günlüğü `cat` ile okuma: `tail -60` + `grep`, ya da
  olayları **sayan** bir özet. Büyük raporun tamamı değil son bölümü
  okunur.
- **Respring oturumu da kapatır** — ajan cihazın terminal uygulamasının
  içinde çalışıyorsa. Test betiğinin son adımı "terminali aç, oturuma
  devam et" olsun; SSH'tan bağlı oturum etkilenmez.
- **Uzun işleri boyutla doğrula:** arka planda çıkarılan bir arşiv,
  sarmalayıcı kabuk bitince "tamamlandı" sanılıp yarım mount edildi.
- **zsh'de eşleşmeyen glob komutun tamamını iptal eder** (`no matches
  found`) — glob'lu `rm`'yi ayrı satıra al.
- **Alt görev (subagent) kullanma**; ölçümü böler, parayı yer.
- **Arayüze dokunma — koşullu serbest** (27 Eyl 2026'da gevşedi; iOS MCP
  ile ajan cihazı sürebiliyor). Gezinme serbest; etkileşimli içerik
  (kupon, takip, sepet) önce sınırı söyle + açık onay; para her seferinde
  ayrı onay. **Zamanlama/hareket hatası ölçümünde dokunuşu yine kullanıcı
  yapar** — sentetik dokunuş sentetik sonuç verir. Yazmadan önce
  `get_frontmost_app`: kullanıcı terminale dönmüşse metin onun giriş
  satırına düşer. Frida'yla tercih yazıp sonucu okumak (çeviri testi)
  hâlâ en ucuz yol; aparat iş bitince geri alınır.
- **`NSLog` artık okunuyor**: MCP'nin `get_syslog`'u canlı unified log
  veriyor (27 Eyl, ÖLÇÜLDÜ). Dosyaya log yedek yol.
- Model bir "tahmin ↔ ölçüm" sapması gördüğünde **kalibrasyon çarpanı
  büyütmez, sayılmayan kalemi arar.**

---

## 11. Açık maddeler

- **KASwitcher:** elle (yukarı fırlatarak) kapatmada seçili animasyon —
  iki tur doldu, vazgeçildi. Denenecekse: karar için
  `scrollViewWillBeginDecelerating`/`killingProgress`, kimlik için
  kapsayıcının kendi `appLayout`'u.
- **DolapClean:** Menü banner'ının 160 pt boşluğu (veri süzme yolu
  denenmedi); CleverTap tam ekran penceresi hiç tetiklenmedi; arama
  sonuçlarındaki sponsorlu ürünler (farklı uç nokta) ölçülmedi.
- **ActionButtonFix:** rootless paket cihazda hâlâ denenmedi; 17.3'teki
  cep durumu bastırma ve host bundle doğrulaması bugün davranışı
  etkilemiyor, ileride kamera eylemi reddedilirse ilk bakılacak yer.
- **Ortak:** rootful jailbreak hiç denenmedi. (Rootless — iPhone XS,
  iOS 16.1.1 — artık denendi: shivtools 1.0.3'ün altı frida ajanı, MCP
  ve node orada geçti, 27–28 Eyl 2026.) iOS 18/26 cihazı yok.
