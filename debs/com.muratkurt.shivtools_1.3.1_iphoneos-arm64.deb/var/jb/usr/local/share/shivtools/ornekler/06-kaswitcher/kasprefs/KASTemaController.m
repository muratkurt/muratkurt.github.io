// Aciklama: KASTemaController.h
#import "KASTemaController.h"

// Tema anahtarlari ve Root.strings'teki Turkce kaynak basliklari (dil-uret.py).
static NSArray<NSArray<NSString *> *> *kas_temalar(void) {
    return @[@[@"acik", @"Varsayılan"], @[@"cam", @"Koyu"], @[@"neon", @"Neon"], @[@"cuzdan", @"Cüzdan"],
             @[@"mor", @"Aurora"], @[@"nostalji", @"Nostalji"], @[@"modern", @"Modern"],
             @[@"holo", @"Holografik"], @[@"terminal", @"Terminal"], @[@"oyun", @"Retro Oyun"]];
}

static UIColor *kas_rgb(CGFloat r, CGFloat g, CGFloat b) { return [UIColor colorWithRed:r green:g blue:b alpha:1]; }

// 60x40 mini kasa: zemin + kart(lar) + altta X ve kasa dugmesi.
static UIImage *kas_onizleme(NSString *t) {
    CGSize s = CGSizeMake(60, 40);
    return [[[UIGraphicsImageRenderer alloc] initWithSize:s] imageWithActions:^(UIGraphicsImageRendererContext *c) {
        CGContextRef x = c.CGContext;
        CGRect tum = CGRectMake(0, 0, s.width, s.height);
        UIBezierPath *cerceve = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(tum, 0.5, 0.5) cornerRadius:8];
        [cerceve addClip];
        UIColor *zemin = kas_rgb(0.07, 0.07, 0.08), *kart = kas_rgb(0.20, 0.20, 0.22), *dugme = kas_rgb(0.25, 0.25, 0.27);
        UIColor *kenar = nil;
        if ([t isEqualToString:@"acik"]) { zemin = kas_rgb(0.95, 0.95, 0.97); kart = UIColor.whiteColor; dugme = kas_rgb(0.85, 0.85, 0.88); }
        else if ([t isEqualToString:@"neon"]) { zemin = UIColor.blackColor; kart = kas_rgb(0.08, 0.08, 0.1); dugme = UIColor.blackColor; kenar = UIColor.systemPinkColor; }
        else if ([t isEqualToString:@"nostalji"]) { zemin = kas_rgb(0.22, 0.23, 0.25); kart = kas_rgb(0.96, 0.96, 0.96); dugme = kas_rgb(0.80, 0.18, 0.15); }
        else if ([t isEqualToString:@"modern"]) { zemin = kas_rgb(0.30, 0.36, 0.46); kart = [UIColor colorWithWhite:1 alpha:0.18]; dugme = [UIColor colorWithWhite:1 alpha:0.2]; kenar = [UIColor colorWithWhite:1 alpha:0.8]; }
        if ([t isEqualToString:@"terminal"]) { zemin = UIColor.blackColor; kart = UIColor.blackColor; dugme = UIColor.blackColor; kenar = kas_rgb(0.25, 1.0, 0.40); }
        else if ([t isEqualToString:@"oyun"]) { zemin = kas_rgb(0.61, 0.74, 0.06); kart = kas_rgb(0.55, 0.67, 0.06); dugme = kas_rgb(0.60, 0.13, 0.34); kenar = kas_rgb(0.06, 0.22, 0.06); }
        else if ([t isEqualToString:@"holo"]) { zemin = kas_rgb(0.04, 0.04, 0.07); kart = kas_rgb(0.16, 0.16, 0.2); dugme = kas_rgb(0.1, 0.1, 0.14); }
        if ([t isEqualToString:@"mor"]) {   // Aurora gradyani
            NSArray *r = @[(id)kas_rgb(0.20, 0.08, 0.38).CGColor, (id)kas_rgb(0.06, 0.10, 0.32).CGColor, (id)kas_rgb(0.03, 0.28, 0.33).CGColor];
            CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
            CGGradientRef g = CGGradientCreateWithColors(cs, (__bridge CFArrayRef)r, NULL);
            CGContextDrawLinearGradient(x, g, CGPointZero, CGPointMake(s.width, s.height), 0);
            CGGradientRelease(g); CGColorSpaceRelease(cs);
            kart = [UIColor colorWithWhite:1 alpha:0.2]; dugme = kas_rgb(0.35, 0.25, 0.65);
        } else { [zemin setFill]; UIRectFill(tum); }
        if ([t isEqualToString:@"holo"]) {   // gokkusagi folyo
            NSMutableArray *r = [NSMutableArray array];
            for (int i = 0; i <= 6; i++) [r addObject:(id)[UIColor colorWithHue:i / 6.0 saturation:0.55 brightness:1 alpha:0.45].CGColor];
            CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
            CGGradientRef g = CGGradientCreateWithColors(cs, (__bridge CFArrayRef)r, NULL);
            CGContextDrawLinearGradient(x, g, CGPointZero, CGPointMake(s.width, s.height), 0);
            CGGradientRelease(g); CGColorSpaceRelease(cs);
            kenar = [UIColor colorWithWhite:1 alpha:0.85];
        }
        if ([t isEqualToString:@"terminal"]) {   // yesil harf sutunlari
            [kas_rgb(0.25, 1.0, 0.40) setFill];
            for (int i = 0; i < 6; i++) for (int j = 0; j < 4; j++)
                if ((i * 7 + j * 3) % 5 < 3) UIRectFill(CGRectMake(3 + i * 10, 3 + j * 7 + (i % 3) * 2, 2, 3));
        }
        if ([t isEqualToString:@"oyun"]) {   // LCD izgarasi
            [[kas_rgb(0.06, 0.22, 0.06) colorWithAlphaComponent:0.15] setFill];
            for (int i = 0; i < 40; i += 3) UIRectFill(CGRectMake(0, i, s.width, 0.5));
        }
        if ([t isEqualToString:@"nostalji"]) {   // keten cizgileri
            [[UIColor colorWithWhite:1 alpha:0.07] setFill];
            for (int i = 0; i < 40; i += 3) UIRectFill(CGRectMake(0, i, s.width, 1));
        }
        if ([t isEqualToString:@"cuzdan"]) {   // ust uste deste
            for (int i = 0; i < 3; i++) {
                [kas_rgb(0.25 + i * 0.08, 0.25 + i * 0.08, 0.28 + i * 0.08) setFill];
                [[UIBezierPath bezierPathWithRoundedRect:CGRectMake(9, 5 + i * 6, 42, 20) cornerRadius:3] fill];
            }
        } else {   // yan yana iki kart
            for (int i = 0; i < 2; i++) {
                UIBezierPath *k = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(12 + i * 20, 5, 16, 22)
                                                             cornerRadius:([t isEqualToString:@"nostalji"] || [t isEqualToString:@"oyun"]) ? 0.5 : 3];
                [kart setFill]; [k fill];
                if (kenar) { [kenar setStroke]; k.lineWidth = 0.8; [k stroke]; }
            }
        }
        // altta X (daire) + kasa dugmesi (hap); cuzdan'da ortak dok
        if ([t isEqualToString:@"cuzdan"]) {
            [[UIColor colorWithWhite:1 alpha:0.25] setFill];
            [[UIBezierPath bezierPathWithRoundedRect:CGRectMake(16, 30, 28, 8) cornerRadius:4] fill];
        }
        UIBezierPath *xd = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(20, 30, 8, 8)];
        UIBezierPath *hap = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(30, 31, 12, 6) cornerRadius:3];
        UIColor *hapRenk = [t isEqualToString:@"nostalji"] ? kas_rgb(0.35, 0.48, 0.68)
                         : [t isEqualToString:@"oyun"] ? kas_rgb(0.55, 0.55, 0.62) : dugme;
        [dugme setFill]; [xd fill];
        [hapRenk setFill]; [hap fill];
        if (kenar) { [kenar setStroke]; xd.lineWidth = 0.8; [xd stroke]; hap.lineWidth = 0.8; [hap stroke]; }
        [[UIColor colorWithWhite:0.5 alpha:0.35] setStroke];
        cerceve.lineWidth = 1; [cerceve stroke];
    }];
}

@implementation KASTemaController
- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *h = [super tableView:tv cellForRowAtIndexPath:ip];
    NSString *yazi = h.textLabel.text;
    NSBundle *b = [NSBundle bundleForClass:[self class]];
    for (NSArray<NSString *> *t in kas_temalar()) {
        NSString *ceviri = [b localizedStringForKey:t[1] value:t[1] table:@"Root"];
        if ([yazi isEqualToString:ceviri] || [yazi isEqualToString:t[1]]) {
            h.imageView.image = kas_onizleme(t[0]);
            break;
        }
    }
    return h;
}
@end
