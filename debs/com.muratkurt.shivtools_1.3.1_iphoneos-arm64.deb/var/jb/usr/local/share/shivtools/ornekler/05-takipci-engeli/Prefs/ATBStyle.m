// AppTrackerBlock Settings page — visual helpers. Pattern: shivtools ShivStil.m.
// Difference: that one is built on a Mac (caps 0x80); this one is built on
// device, so there are no literals and the icon is drawn with the
// block-free UIGraphicsBeginImageContext API.
#import "ATBStyle.h"

NSString *ATBS(const char *s) { return [NSString stringWithUTF8String:s]; }

NSString *ATBL(const char *english) {
    static NSBundle *bundle;
    if (!bundle) bundle = [NSBundle bundleForClass:[ATBHeaderView class]];
    NSString *key = ATBS(english);
    return [bundle localizedStringForKey:key value:key table:ATBS("Localizable")];
}

UIImage *ATBIcon(const char *symbol, UIColor *color) {
    CGFloat side = 29.0;
    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration
        configurationWithPointSize:15 weight:UIImageSymbolWeightSemibold];
    UIImage *s = [UIImage systemImageNamed:ATBS(symbol) withConfiguration:cfg]
              ?: [UIImage systemImageNamed:ATBS("questionmark") withConfiguration:cfg];
    s = [s imageWithTintColor:[UIColor whiteColor]
                renderingMode:UIImageRenderingModeAlwaysOriginal];
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(side, side), NO, 0);
    [color setFill];
    [[UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, side, side) cornerRadius:6.5] fill];
    CGSize z = s.size;
    [s drawInRect:CGRectMake((side - z.width) / 2, (side - z.height) / 2, z.width, z.height)];
    UIImage *result = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return result;
}

NSString *ATBVersion(void) {
    NSBundle *b = [NSBundle bundleForClass:[ATBHeaderView class]];
    NSString *p = [b pathForResource:ATBS("version") ofType:nil];
    NSString *v = p ? [NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:NULL] : nil;
    v = [v stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return v.length ? v : nil;
}

@implementation ATBHeaderView

- (instancetype)initWithStatus:(NSString *)status color:(UIColor *)color {
    self = [super initWithFrame:CGRectMake(0, 0, 320, 228)];
    if (!self) return nil;

    NSBundle *b = [NSBundle bundleForClass:[self class]];
    UIImageView *icon = [[UIImageView alloc] initWithImage:
        [UIImage imageNamed:ATBS("header") inBundle:b compatibleWithTraitCollection:nil]];
    icon.layer.cornerRadius = 16;
    icon.layer.cornerCurve = kCACornerCurveContinuous;
    icon.clipsToBounds = YES;

    UILabel *name = [UILabel new];
    name.text = ATBS("AppTrackerBlock");
    name.font = [UIFont systemFontOfSize:28 weight:UIFontWeightBold];

    UILabel *tagline = [UILabel new];
    tagline.text = ATBL("Blocks trackers inside apps");
    tagline.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
    tagline.textColor = UIColor.secondaryLabelColor;

    NSString *v = ATBVersion();
    UILabel *version = [UILabel new];
    version.text = v ? [NSString stringWithFormat:ATBL("Version %@"), v] : ATBL("Version unknown");
    version.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightMedium];
    version.textColor = UIColor.tertiaryLabelColor;

    // Badge: colored dot + text on 14% of the status color.
    UIColor *c = color ?: UIColor.secondaryLabelColor;
    UILabel *badge = [UILabel new];
    badge.text = [NSString stringWithFormat:ATBS("  ●  %@  "), status ?: ATBL("Status unknown")];
    badge.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    badge.textColor = c;
    badge.backgroundColor = [c colorWithAlphaComponent:0.14];
    badge.layer.cornerRadius = 12;
    badge.clipsToBounds = YES;
    badge.textAlignment = NSTextAlignmentCenter;

    NSArray *views = [NSArray arrayWithObjects:icon, name, tagline, version, badge, nil];
    for (UIView *v2 in views) {
        v2.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:v2];
    }
    NSMutableArray *k = [NSMutableArray array];
    [k addObject:[icon.topAnchor constraintEqualToAnchor:self.topAnchor constant:20]];
    [k addObject:[icon.widthAnchor constraintEqualToConstant:72]];
    [k addObject:[icon.heightAnchor constraintEqualToConstant:72]];
    [k addObject:[name.topAnchor constraintEqualToAnchor:icon.bottomAnchor constant:12]];
    [k addObject:[tagline.topAnchor constraintEqualToAnchor:name.bottomAnchor constant:2]];
    [k addObject:[version.topAnchor constraintEqualToAnchor:tagline.bottomAnchor constant:2]];
    [k addObject:[badge.topAnchor constraintEqualToAnchor:version.bottomAnchor constant:10]];
    [k addObject:[badge.heightAnchor constraintEqualToConstant:24]];
    for (UIView *v2 in views) [k addObject:[v2.centerXAnchor constraintEqualToAnchor:self.centerXAnchor]];
    [NSLayoutConstraint activateConstraints:k];
    return self;
}

@end
