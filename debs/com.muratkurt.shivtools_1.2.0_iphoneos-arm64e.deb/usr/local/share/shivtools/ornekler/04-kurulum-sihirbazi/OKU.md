# 04 — Ayarlar'dan kurulum sihirbazı (iskelet)

Ayarlar sayfası paket **kuramaz**: `mobile` olarak çalışır, `apt` root
ister. Bu iskelet o duvarı aşan çalışan düzeni veriyor — shivtools
1.1.0'da ölçülerek geliştirildi, buraya sadeleştirilmiş hâli kondu.

```
prefs/    Ayarlar sayfası + CANLI kurulum ekranı
motor/    ornek-kur    — denetler, kurar, durum yazar
kurd/     ornek-kurd   — root LaunchDaemon; isteği root olarak işler
```

Üçü de **dosya üzerinden** konuşur; soket, servis, XPC yok:

```
Ayarlar (mobile) ──yazar──> ornek-kur-istek
                              │ launchd WatchPaths ile uyanır
                              ▼
                          ornek-kurd (root) ──> ornek-kur <ad>... --yap
                              │                      │
                              └── ornek-kurd.log     └── ornek-kur.json
                                        ▲
                       Ayarlar 0,5 sn'de bir okur ────┘
```

## Neyi değiştireceksin

| Dosya | Değiştir |
|---|---|
| `motor/ornek-kur` | `DEPO_URL`, `BILESENLER`, `denetle()` içindeki sınavlar, argüman `case`'i |
| `kurd/ornek-kurd` | `IZIN` (izinli bileşen adları), dosya adları |
| `kurd/*.plist` | `Label`, `WatchPaths` yolları, betik adı |
| `prefs/*` | Sınıf önekleri, başlıklar |
| `control`, `Makefile` | Paket kimliği |

Geri kalanına dokunma: durum protokolü, apt kısıtlaması, tazelik
ölçütü ve hata çevirisi **ölçülerek** bu hâle geldi.

## GÜVENLİK — root, başkasının yazabildiği yere yazıyorsa

Bu iskeletin **ilk hâli açıklıydı**: shivtools 1.1.1'de yayında olan ve
1.1.2'de kapatılan açığın aynısını taşıyordu. Yardımcı ROOT çalışıyor
ve `mobile`'ın yazabildiği dizine (günlük, sayaç, durum) **sabit adla**
yazıyordu. `>` ve `>>` sembolik bağı izler: oraya bağ bırakan bir tweak,
root'a istediği dosyayı oluşturtur ve yazdırır.

Kural (1.1.2'de cihazda ölçüldü):
- **Sabit adla açma** — rastgele ad + `set -C` (O_EXCL): bağ varsa açılmaz.
- **`umask 022`**, sonradan `chmod` YOK (chmod da bağı izler).
- Yerine koymak için **`mv`** — hedefteki bağı izlemez, onun yerine geçer.
- Okuduğun dosya **bağ ise okuma** (istek, sayaç).
- Sayacı **sayı olarak doğrula** (kabuk aritmetiğine düz metin girmesin).
- Reddettiğin girdiyi günlüğe **basma** (günlük bir bağ üzerinden akabilir).
- `/tmp`'deki kaynak listesi de **rastgele ad + O_EXCL**: sabit adı
  `mobile` önceden sahiplenip içeriği kendi deposuna çevirebilir.

ÖLÇÜLDÜ (29 Eyl 2026, RootHide, bu iskeletin düzeltilmiş hâli): günlük ve
sayaç yerine bağ → hedefler oluşmadı, bağların yerini gerçek dosyalar
aldı; istek dosyasının kendisi bağ → okunmadan silindi; motorun durum
dosyası yerine bağ → hedef oluşmadı, dosya 644.

**Paket sahipliği:** launchd `root` dışı sahipli daemon plist'ini
reddediyor ("bad ownership"). theos'un `dm.pl`'i `root/wheel` basıyor
(ölçüldü), yani bu iskelet etkilenmiyor. Kendi paketleyicini
yazıyorsan `dpkg-deb --root-owner-group` kullan.

## Karşılığını ödediğimiz yerler

- **İsteği SONDA sil.** Başta silmek `WatchPaths`'i yeniden tetikler
  ve launchd **çalışan işi keser**. Sonsuz döngüye karşı deneme sayacı.
- **Tazelik ölçütü.** "İstek dosyası var" ≠ "kurulum sürüyor";
  yardımcı ölürse o dosya sonsuza kadar kalır ve sayfa sonsuza kadar
  "sürüyor" der.
- **Denetim durum dosyasına yazmaz.** Salt okunur sorgu süren
  kurulumun durumunu silerse, ekran bitmiş sanıp yanlış sonuç gösterir.
- **Önceki turun sonucunu bu turun sonucu sanma.** Başlarken eski
  durum dosyasını sil, damgasını not et, ilerleme görmeden terminal
  aşamayı kabul etme.
- **Bileşen hatası turu bitirmez.** `kuruluyor/tamam/basarisiz` bileşen
  olayı, `bitti` turun sonu. Tek kelimeyi iki anlamda kullanma.
- **Yalnız kendi deponu `apt-get update` et** (geçici kaynak dosyası +
  `List-Cleanup=0`). Düz update bütün depoları tarar: 3,5 dakika → 9 sn.
- **Deponun `Release`'i her yayında yeniden yazılmalı** (`Date:` +
  checksum). Statik `Release` ile apt `Packages`'ı hiç yeniden
  indirmez; yeni paket sihirbazda görünmez (ölçüldü, 29 Eyl 2026).
- **Kardeş araçları mutlak yolla çağır.** launchd job'ının PATH'inde
  `/usr/local/bin` yok; rootless'ta `date/mv/head/tr/rm` bile yok
  (`/var/jb` altında) — yardımcı PATH'i kendisi kuruyor.
- **`NSTimer`'ı `NSRunLoopCommonModes`'a ekle**, yoksa kaydırma ve
  geçiş sırasında durur.
- **Staging yoluna şema öneki ekleme.** theos zaten ekliyor; bir daha
  eklersen paket `/var/jb/var/jb/...` olur.

Ayrıntılı gerekçeler ve ölçüm izleri: `rehber/TWEAK-GELISTIRME.md §7.5c`.

## Ne doğrulandı (29 Eylül 2026, Mac)

- İki şema da derlendi ve **deb üretildi** (`dm.pl` satırı görüldü).
- Düzen doğru: roothide `Library/…` + `usr/local/…`, rootless
  `var/jb/…` (tek önek).
- `@ONEK@` plist içinde şemaya göre doldu: `/bin/sh` ↔ `/var/jb/bin/sh`.
- Mac derlemesi arm64e diliminde **caps 0x80**.

Cihazda **çalıştırılmadı**: bileşen adları (`aracbir`, `aracIki`) ve
depo (`ornek.github.io`) örnektir. Kendi adlarını koyduktan sonra
cihazda ölç.
