# shiv tools — cihaz üstünde tweak geliştirme

Bu dosya, bir ajanın (Claude Code, Codex, başka bir CLI, düz SSH ile
çalışan bir insan) jailbreak'li bir iOS cihazında tweak geliştirirken
uyacağı kalıcı talimattır. Tek bir tweak'e ait değildir.

**Kaynak:** buradaki kuralların tamamı KASwitcher 0.0.1 → 0.4.3 (Eylül
2026) geliştirmesi sırasında **cihazda ölçülerek** öğrenildi. Her biri
en az bir kez ihlal edildi; bedeli safe mode, kayıp kurulum turu ya da
bozuk kaynak oldu.

**Bu dosya ile `TWEAK.md`'nin işi ayrı — karıştırma:**

| Dosya | İşi |
|---|---|
| **SHIVTOOLS.md** (bu dosya) | **Kanun.** Kırmızı çizgiler, çalışma döngüsü, araçlar, disiplin. Kısa olmak zorunda: her oturumda okunup uyulacak. |
| **TWEAK.md** | **Reçete kitabı.** Derleme akışları, ABI/caps, prefs, hook kalıpları, keşif, namespace — ayrıntı ve çalışan kod. Gerektiğinde açılır. |

Bir konu iki dosyada da anlatılmaz. Bu dosya ayrıntıya girmek yerine
`TWEAK.md §X` der. **Kaynaklar çelişirse sıra:** cihazdan yeni okuduğun
ÖLÇÜM → bu dosyadaki KURAL → `TWEAK.md`'deki REÇETE. Ölçüm bir reçeteyi
çürütürse reçete bayatlamıştır: söyle ve hangi satırın güncellenmesi
gerektiğini yaz.

---

## 0. Araçlar nereden gelir

Araçlar `com.muratkurt.shivtools` paketinden gelir; shiv kurulu olmasına
**gerek yok** (shiv kaldırılmış bir cihazda ölçüldü). Her araç `--help`
ile tek ekran kullanım basar.

**Üç paket, hepsi birlikte kurulur** (27 Eyl 2026):

| paket | ne getirir | ayrılabilir mi |
|---|---|---|
| `com.muratkurt.shivtools` | araçlar, belgeler, ajanlar | çekirdek |
| `com.muratkurt.nodejs` | node 24 + npm + npx | evet, `Recommends` |
| `com.muratkurt.ios-mcp` | MCP sunucusu, OCR, IPA zinciri | evet, `Recommends` |

Son ikisi ayrı paket **bilerek**: kullanıcı kendi node'unu ya da kendi
MCP'sini kurmak isterse bizimkini kaldırıp onu koyabilsin, shivtools'u
kaybetmesin. Sileo ikisini de kendiliğinden kurar, yani pratikte tek
paket gibi gelir.

- `node` yalnız `shiv-sinif` için; yoksa araç bunu **adıyla** söyler.
  Diğer araçlar node istemez. "node var" da yetmez: bir zamanlar
  `nodejs` paketinin sarmalayıcısı bozuktu, o yüzden araç adayı
  **çalıştırarak** sınıyor (24 Eyl 2026'da ölçüldü). Aday listesi
  `ortak.sh`'deki `st_node()`'da, tek yerde.
- frida'ya bağlı olanlar: `shiv-ekran`, `shiv-pencere`, `shiv-oku`,
  `shiv-cek`, `shiv-sinif --tip`. Eksikse araç adıyla söyler
  (`shiv-frida-kur` denetler).
- Paketteki frida istemcisi (`shivfrida`) **frida 17** ile derlendi ve
  **fat** (arm64 + arm64e); RootHide A17 ve rootless A12'de ÇALIŞIYOR
  (27–28 Eyl 2026, ÖLÇÜLDÜ). A11 ve öncesi **DOĞRULANMADI** — elde o
  donanım yok. `shiv-sinif` frida'ya hiç dokunmadığı için orada da çalışır.
- **frida 17 + RootHide + SpringBoard = bilinen kusur** (27 Eyl 2026,
  ÖLÇÜLDÜ): SpringBoard'a art arda ~3. attach'ta SpringBoard düşüyor ve
  cihaz safe mode'a iniyor. Sıradan uygulamalar sağlam (YouTube,
  Instagram, WhatsApp, Safari, Photos 5/5); frida 16'da ve rootless'ta
  sorun yok. **SpringBoard işini topla:** `shiv-pencere` ve
  `shiv-sinif --tip` varsayılan olarak SpringBoard'a bağlanır — bir kez
  oku, dökümü yeniden kullan. `shiv-ortam` bunu RootHide'da uyarır.
- **AYARLAR'A DA BAĞLANMA** (28 Eyl 2026, ÖLÇÜLDÜ — bir kez).
  `shiv-ekran com.apple.Preferences` RootHide'da safe mode'a düşürdü.
  Ayarlar sıradan bir uygulama değil: preferenceloader ve cihazdaki
  **her** prefs bundle onun içine giriyor, yani SpringBoard'dan sonra
  en çok hook'lanan süreç — kusurun tarifine birebir uyuyor.
  **Prefs sayfanı frida ile okuma; MCP'nin AX ağacıyla oku**
  (`describe_screen` → `get_ui_elements`), o hiç enjekte etmez.
  Tek olay, ama bedeli safe mode; tekrarını beklemeye değmez.
- **MCP** `com.muratkurt.ios-mcp` paketinden gelir ve SpringBoard'ın
  içinde çalışır. `shiv-mcp durum` ile bak. İki varsayılanı bizim
  koyduğumuzu bil: sunucu **yalnız 127.0.0.1**'i dinler ve `mcp-root`
  **setuid'siz** kurulur. İkisi de ayar, duvar değil.
- Projeye kalıcı talimat: `cd <proje> && shiv-kurulum` — bu dosyayı
  `CLAUDE.md` ve `AGENTS.md` olarak kurar, var olanı önce tarihli yedeğe
  alır. Otomatik oluşmaz, sen çalıştırınca oluşur.

**shiv de kuruluysa KURULUM SIRASI önemli (24 Eyl 2026'da ölçüldü).**
İki paket de `/usr/local/bin/shiv-*` adlarını kullanıyor; shiv o adları
`postinst`'te kendi kopyalarına bağlıyor, `postrm`'de siliyor. dpkg
çakışmayı görmüyor, çünkü bağları dpkg değil postinst yapıyor.

| Ne oldu | Sonuç |
|---|---|
| shiv kuruldu / güncellendi | shivtools araçları **gölgelenir** (`--tip` kaybolur) |
| shiv kaldırıldı | shivtools'un **dokuz** dosyası silinir |

Çare tek satır: **shivtools deb'ini shiv'den sonra yeniden kur.**
`shiv-ortam` ve `shiv-kurulum` gölgelenmeyi görürse adıyla uyarır.

---

## 0.1 Her oturumun ilk işi

```
shiv-ortam
```

Cihazın ne olduğunu, jailbreak türünü, iOS sürümünü, hangi araçların ve
bağımlılıkların var olduğunu basar. **Bunu çalıştırmadan hiçbir şey
varsayma** — "frida vardır", "node vardır", "oldabi kuruludur" diye
başlayan her tur bir kez patladı.

**Eksik görürsen kullanıcıya SÖYLE — sessiz geçme, kafadan kurma.**
Kullanıcı Ayarlar'ı hiç açmamış olabilir (28 Eyl 2026, kullanıcı kararı).
Her eksik satırın yanındaki `#` ipucu hangi komutun kullanılacağını
yazar. Kullanıcıya iki yol sun:
1. "Onaylarsan ben kurarım" → onay gelince o komutu SEN çalıştır
   (şifre gerekiyorsa kullanıcı girer). **Tek komut yeter:**
   `shiv-kur` neyin eksik olduğunu yazar, `sudo shiv-kur hepsi --yap`
   onaylandığında kurar. Paket adlarını ezberleme, onu çalıştır.
2. "Ya da Ayarlar › shivtools'tan kendiniz kurabilirsiniz."

Elle indirme adımı ya da ham kurulum betiği UYDURMA: ham `install-theos`
bir cihazda iki kez yarıda kaldı, `shiv-theos-kur` o yüzden var.
Onaysız kurma.

---

## 1. Bilgi kaynağı etiketleme kuralı

> **Başlık dökümünden, GitHub'dan, dokümandan ya da hafızadan gelen
> bilgi, cihazda görülene kadar "DOĞRULANMADI" etiketiyle yazılır.**

Bu, listedeki en pahalı ders. KASwitcher 0.4.3'te bu dosyanın atası, yön
bilgisini taşıyan bir metodu yanlış sınıfta gösteriyordu ve ana ekranı
yanlış bir bundle id ile tanıyordu. İkisi de **başlık dökümünden**
gelmişti ama **ölçülmüş gibi** yazılmıştı. Talimat harfiyen uygulansaydı
hook hiç çalışmayacak, doğru yol yanlışlıkla "olmuyor" diye elenecekti.

Ölçülmüş bilgiyle doğrulanmamış bilgi aynı cümlede durursa, sonraki
oturum ikisini ayırt edemez. Ayır:

```
- appLayout argümanı yönü taşır (iOS 17.0.3'te ÖLÇÜLDÜ)
- iOS 18'de de aynı olmalı (DOĞRULANMADI)
```

---

## 2. Kırmızı çizgiler

Tartışmaya açık değil.

1. **Respring / `killall SpringBoard` / `sbreload` ÇALIŞTIRMA.**
   Gerekiyorsa kullanıcıya AÇIKÇA "respring et" de, o yapar. Sebebi
   nezaket değil: kullanıcı o an ne yaptığını bilir, sen bilmezsin.
2. **İmzasını görmediğin private metodu ÇAĞIRMA.** İmza demek **tip
   kodlaması**: `shiv-sinif --metod <Sınıf> --tip` çıktısında **birebir
   gördüğün satır**. `--tip`'siz çağrı yalnız metot ADLARINI basar; ad
   imza değildir ve bu kural ada bakarak uygulanamaz.
   Dönüş tipi bilinmeyen bir metodu çağırıp dönen değeri tutmak
   `objc_retain` çökmesi ve safe mode demektir (iki kez yaşandı).
   Private objeyi `%@` ile **loglama** — loglamak da çağırmaktır.
   **Blok argümanları da imza kapsamında:** tip kodlaması bloğu yalnız
   `@?` diye gösterir, içine ne geldiğini SÖYLEMEZ. Bloğun argümanını
   nesne sanıp dokunmak PAC çökmesi verdi (ActionButtonFix 2.10,
   `startRecordingWithHandler:`, ÖLÇÜLDÜ). Bilmiyorsan bloğu
   `void (^)(void)` yaz, argümana bakma.
3. **Dosyayı baştan yazma.** `python3` heredoc ile toplu yeniden yazma
   ve çok satırlı `sed` **yasak** — bir `Tweak.x` üç kez bozuldu.
   `grep -n` ile bul, `sed -n <aralık>` ile oku, ayrı ayrı **en fazla
   40 satırlık** düzenleme yap.
4. **Her düzenlemeden önce üstüne yazmayan yedek:**
   `cp Tweak.x "Tweak.x.$(date +%H%M%S).bak"` — var olan bir `.bak`
   dosyasının üstüne **ASLA** yazma. Bir kez yazıldı ve iki tur yanlış
   kaynağın üstüne inşa edildi.
5. **Her yazımdan sonra bozuk yorum kontrolü:**
   `grep -n '^[[:space:]]*/[^/*]' <dosya>` — yorumlar tek `/` ile
   düşebiliyor ve derleyici bazen sessiz kalıyor.
6. **En fazla iki kurulum turu.** Üçüncüye girme; DUR, ölçtüğünü yaz,
   geri dönüş komutunu ver. Üçüncü tur hiçbir zaman işe yaramadı.
7. **Alt görev / subagent kullanma.** Ölçümü bozuyor ve parayı yiyor.
   Bu madde **durmaya devam ediyor**.

   **Arayüze dokunma yasağı 27 Eyl 2026'da GEVŞETİLDİ** (kullanıcı
   kararı). MCP geldi; ajan artık cihazı sürebiliyor. Yeni sınır:
   - **Gezinme serbest**: sekme değiştirme, geri, uygulama açma,
     kaydırma, yenileme. Ajan kendi yapar, sormaz.
   - **Etkileşimli içerik** (kupon, takip, sepet, uygulamanın öne
     çıkardığı buton): önce **sınırı söyle** — neye, kaç kez, neden,
     yan etkisi ne — sonra **açık onay al**. Onay o kapsam içindir,
     bir sonraki iş için yeniden alınır.
   - **Para / satın alma**: her seferinde ayrı onay. İstisnasız.
   - **Ayrım**: birinci taraf öne çıkarma ≠ reklam ağı. (DolapClean'de
     "reklamlar" birinci taraftı; tıklamak kimseye para ödetmiyordu.)
   - **İSTİSNA DURUYOR:** zamanlama ya da hareket hatası **ölçümünde**
     dokunuşu yine KULLANICI yapar. Ajanın dokunuşu gerçek kullanımı
     ölçmez — sentetik dokunuş sentetik sonuç verir.
8. **Bir yol tıkanırsa aynı yolu ikinci kez deneme.** Ölç, yön değiştir.

---

## 3. Çalışma döngüsü

1. **ÖLÇ** — belirtinin sebebini tahmin etme, cihazdan veri al.
2. **SEBEP** — ölçümden çıkan **tek cümlelik** sebep.
3. **DÜZELT** — yalnız o sebebi hedefleyen **en küçük** değişiklik.
4. **DOĞRULA** — derlenen ürünün *içinde* izini ara, sonra cihazda test.

Bu adımlardan biri atlandığında tur boşa gitti. İstisnasız.

### Ölçüm yöntemi — en kârlı tek alışkanlık
> **Önce davranışı değiştirmeden dosyaya logla; düzeltmeyi sonra yaz.**

KASwitcher'ın son iki hatası da (680 ms'lik gecikme, respring sonrası tek
seferlik titreme) tamamen bu yolla bulundu — araçla değil, yöntemle.
Ölçüm hook'u `%orig`'i olduğu gibi çağırır, yalnızca satır yazar:
**ms damgası + olay adı + ilgili alanlar + o anki durum.**

Bir olayın anlamını, hemen **ardından** gelen olayın değerine bakarak
belirle. Böylece testleri rastgele sırayla yapabilirsin; sınıflandırma
günlükten çıkar.

**Geometri/pencere ölçümünde tek atış yerine KAYIT MODU.**
`shiv-pencere --izle <sn>` arka planda başlatılır, kullanıcıya en fazla
5 adımlık numaralı bir betik verilir (örn. dikey switcher → yatay app →
yatay switcher → kapat). Araç her düzen değişiminde **telefonu titretir**
ve numaralı döküm yazar — kullanıcı hangi anın yakalandığını titreşimden
anlar, ajanla eşzamanlama gerekmez. Tek kayıt birden çok durumu kapsar;
hangi dökümün hangi adım olduğu, dökümün saati + içerik farkından çıkar
(yukarıdaki "anlamı sonraki değerden belirle" kuralının araç karşılığı).
Kullanıcıya "her yakalamada titreyecek" demeyi unutma.

**Görsel hatayı günlükte arama — KAREYE bak.** Titreme, tek karelik
yeniden çizim, yanlış konum, kesik metin günlüğe düşmez. Akış:
`shiv-kare isaret` → kullanıcı ekran kaydı alıp hatalı kareyi
Fotoğraflar > Düzenle'den ekran görüntüsüne çevirir → `shiv-kare yeni`
yolu verir → kareyi doğrudan oku. KASwitcher 0.4.4–0.5.0 oturumunun
kilit bulguları bu yoldan geldi. **Gizlilik:** kamera rulosu kişiseldir;
yalnız işaretten sonraki kareler açılır, gördüğün yalnız hedef bölge
için yorumlanır.

**Kendi animasyonun tutmuyorsa MODEL ile EKRANI ayrı ölç.** Sistem bazı
özellikleri her karede geri yazıyor: `view.transform`/`alpha` (model) ile
`layer.presentationLayer` (ekranda görünen) ayrı ayrı loglanır — önce, ve
sürenin ¼/½/¾'ünde. KASwitcher 0.5.0'da tek satırlık bu ölçüm sebebi
gösterdi (model ölçek 0.685, ekran alfa sabit 1.00 → sistem sahipleniyor).
`shiv-pencere` artık fark varsa satıra `EKRAN:alpha=…(model …)` yazıyor,
yani çoğu durumda kurulum turu harcamadan görülür. **Çare:** sistemin
sahiplendiği görünüme dokunma; `snapshotViewAfterScreenUpdates:NO`
kopyasını canlandır, aslını kendi yolundan kaldır.

### Ölçüm hook'u nasıl yazılır

- **Ölçüm için YENİ API getirme.** Tweak'in zaten kullandığı yolu kullan.
  Yeni bir çağrı eklersen, ölçtüğün şey artık ürünün davranışı değil;
  üstelik çökerse sebebin ölçüm mü ürün mü olduğunu ayıramazsın.
- Her adımda `respondsToSelector:`; boş/nil değer çökme yerine **ayrı bir
  etiketle** loglanır (`bos-layout`, `bilinmiyor` gibi) — "yok" da veridir.
- Tamamı `@try` içinde, `@catch`'te ayrı bir satır yaz. Ölçüm kodu
  ürünü düşürmez.
- Private objeyi `%@` ile yazma; günlüğe **yalnız string etiket** ve sayı.
- **Animasyonun bitiş bayrağını da logla** (`finished=0` = yarıda
  kesildi). Kesintiler ancak böyle görünür; "kapandı sanılan" animasyon
  çoğu zaman kesilmiş animasyondur.
- Günlüğü **kullanıcıya görünür bir anahtara bağla** (Ayarlar'da bir
  `gunluk` anahtarı). Hem yayında sessiz kalır, hem kullanıcıdan günlük
  isteyebilirsin.

### Düzeltmeyi idempotent bir yola bağla
`ka_butonGizle` gibi "zaten o durumdaysa hemen dön" diyen bir fonksiyona
bağlanan düzeltme, yanlış yerde tetiklense bile zarar vermez. 0.4.3'te
app içinden ana ekrana kaydırmada düzeltme gereksiz yere çalıştı ve
**hiçbir etkisi olmadı** — çünkü çağrılan yol idempotentti. Yeni bir
kapatma/açma yolu yazmak yerine var olanı çağır.

### Cihaz testi düzeni
kur → `dpkg -l` ile **doğrula** → kullanıcıya AÇIKÇA "respring et" de →
**en fazla 5 adımlık numaralı** test betiği ver → kullanıcı "bitti"
deyince günlüğü oku.

Günlüğü `cat` ile okuma — `tail -60` + `grep`. Her turdan önce `rm -f`
ile sıfırla.

**`NSLog` artık OKUNUYOR** (27 Eyl 2026'da değişti). Eskiden bu
kurulumlarda `NSLog` ve `log show` okunamıyordu, o yüzden her tweak
dosyaya log yazmak zorundaydı. MCP'nin `get_syslog`'u canlı unified
log veriyor:

```
get_syslog(process: "SpringBoard", last_seconds: 30)
```

Yeni reçete: tweak `NSLog` bassın, test sırasında `get_syslog` ile oku.
**Dosyaya log yedek yol olarak kalır** — MCP kurulu değilse, ya da
tweak uygulama sandbox'ındaysa (orası ayrı bir dünya, `TWEAK.md §6`).
MCP yoksa `shiv-log parca` hâlâ doğru cevap.

**Respring'den hemen sonraki İLK etkileşimi ayrıca test et.** Tek
seferlik hatalar sonraki denemelerde görünmez; KASwitcher'da böyle bir
hata baştan beri durdu ve her ölçümde kaçtı.

### Ekrana bakmanın ucuz yolu — SIRA ÖNEMLİ

MCP kuruluysa (`shiv-mcp durum`) ekranı okumanın dört yolu var ve
maliyetleri arasında iki mertebe fark var. **Bu sırayla dene:**

1. `describe_screen` — varsayılan hâli, ekran görüntüsüz. Öndeki
   uygulamayı, tıklanabilir öğeleri ve koordinatları birlikte verir.
   Çoğu sorunun cevabı burada.
2. `get_ui_elements` — ekran dışı / tıklanamaz düğümler, sonuç sınırı,
   AX hata ayıklama gerekince.
3. `ocr_screen` — AX'in göremediği içerik (oyun, Flutter/RN/Unity,
   Canvas, resim içindeki metin).
4. `screenshot` — **en son.** Gerçekten görsele ihtiyacın varsa.

**`describe_screen include_screenshot:true` 94 bin karakter** (ÖLÇÜLDÜ)
— kullanma. Her eylemden sonra ekran görüntüsü almak da alışkanlık
değil israftır.

### Yazmadan önce HER ZAMAN `get_frontmost_app`

`input_text` öndeki uygulamaya yazar. Kullanıcı o sırada terminale
dönmüşse metin **onun giriş satırına** düşer ve geri alınamaz.
Ölçülerek yakalandı, yaşanmadı — yaşanmasın diye burada duruyor.

### Kullanıcı terminale dönerse — HATA DEĞİL (bilgi)

Kullanıcı, uygulama uzun süre önde kaldığında terminali canlı tutmak
için kendisi geri döner. Öndeki uygulama terminalse **kullanıcı
oradadır; bir şey ters gitmemiştir.** Yön değiştirme, yeniden deneme
döngüsüne girme; işin yarım kaldıysa ne gerektiğini bir cümleyle söyle.

ÖLÇÜLDÜ (1 Eki 2026, RootHide 15 Pro, diffTerm, ekran açık): terminal
**10 dakikadan uzun** arka planda kaldı; ajanın kabuk süreci kesintisiz
çalıştı, durumu değişmedi. Yalnız uygulama değiştirme anında ~20 sn
yavaşlama oldu. Yani bu koşullarda askıya alınma YOK.
DOĞRULANMADI: ekran kilitliyken, 10 dakikadan uzun, düşük güç modu,
API çağrısının kendisi (yalnız yerel süreç ölçüldü), başka terminaller,
rootless.

Ölçüm yolunu ajan seçer — uygulamayı açmak çoğu zaman en iyi ölçümdür;
burada bir kısıtlama YOK. Yalnız bir alışkanlık (zorunluluk değil):
- **Önden haber ver, süre ver:** "Reddit'i ~20 sn öne alıyorum, bitince
  terminale ben döneceğim." Kullanıcı ne zaman bekleyeceğini bilir.
  İş bitince terminali öne getir: `shiv-don` (terminali kendisi bulur).

Bilgi: MCP `launch_app` uygulama öne gelene kadar bekler; kullanıcı o
sırada terminale döndüyse uzun bekleyebilir (bir kez 280 sn ÖLÇÜLDÜ).
Bu da hata değil — aracı tekrarlama, `get_frontmost_app` ile durumu gör.

### Respring — uygulama tweak'inde GEREKMEZ

- **Uygulama tweak'i**: respring yok. `kill_app` + `launch_app` yeter;
  döngüyü belirgin biçimde kısaltır.
- **SpringBoard tweak'i**: respring şart ama **kullanıcıdan istenir** —
  kırmızı çizgi 1 yerinde duruyor.
- **MCP'nin `install_app`'i deb kurunca respring ATMAZ — bizim pakette.**
  Üst kaynak (witchan) atıyor; bu hem kırmızı çizgi 1'i çiğniyor hem de
  cihazdaki ajanın kendi oturumunu öldürüyor. `com.muratkurt.ios-mcp`
  bunu ayara bağladı, **varsayılan kapalı** (`shiv-mcp respring-ac` açar).
  Orijinal paket kuruluysa (`shiv-mcp durum`) eski davranış geçerlidir.
  Her durumda: deb'i `dpkg -i` ile kur, respring'i kullanıcıya bırak.

**Oturum cihazın terminal uygulamasının içindeyse, respring SENİ DE
kapatır** (25 Eyl 2026'da ölçüldü: diffTerm → zsh → claude; respring
sonrası oturum sıfırdan başladı). Test betiğinin son adımı
"terminali aç, `claude -c` ile devam et" olsun. SSH'ten bağlı oturum
etkilenmez. (Araç bunu kendiliğinden tespit edemiyor: bu cihazlardaki
`ps` üst süreç (`ppid`) sütununu desteklemiyor — ÖLÇÜLDÜ.)

---

## 4. Araçlar

| Ne lazım | Araç |
|---|---|
| Ortam, jailbreak türü, eksik bağımlılıklar | `shiv-ortam` |
| Eksik bileşen var mı, nasıl kurulur | `shiv-kur` denetler (hiçbir şey değiştirmez) · `sudo shiv-kur <theos\|node\|frida\|mcp\|hepsi\|paketler> --yap` kurar; birden çok bileşen yazılabilir. theos'u `shiv-theos-kur`'a, frida'yı `shiv-frida-kur`'a devreder — o ikisi ölçülmüş, ikinci kopya yazılmadı |
| Kullanıcı Ayarlar'dan kurmak isterse | Ayarlar › shivtools › **KURULUM**. node/frida/MCP orada kurulur, **şifre sorulmaz** (root yardımcısı `shivtools-kurd` yapar). **Theos da orada kurulur (1.3.0)**: `install-theos` root'u reddettiği için betik kullanılmıyor; root yalnız `theos-dependencies`'i apt ile kurar, klon ve SDK `su mobile` ile (iki cihazda ÖLÇÜLDÜ, 30 Eyl 2026) |
| Sınıf var mı, hangi imajda | `shiv-sinif <desen>` · `shiv-sinif --tara <desen>` |
| Metot **adları** (cache'ten, frida gerekmez) | `shiv-sinif --metod <Sınıf>` |
| Metot **imzası** — kırmızı çizgi 2 buna dayanır | `shiv-sinif --metod <Sınıf> --tip` — ÇALIŞAN süreçten okur; varsayılan hedef SpringBoard, `--pid N` / `--bid <id>` ile değişir, `--desen` ile süzülür |
| **Uygulama** ekranındaki görünüm ağacı | `shiv-ekran <bundle-id>` |
| **SpringBoard** görünüm ağacı, pencereler/seviyeler | `shiv-pencere` — `shiv-ekran` SpringBoard'da ÇALIŞMAZ. Yalnız okur, özel metot çağırmaz; kendi ajanını yazmadan önce bunu dene. `--izle <sn>` kayıt modu; satırlarda `safe=` (üstten farklıysa), `tf=`, `EKRAN:alpha=` ve başta `YON:` |
| jbroot / gerçek yol çevirisi | `shiv-yol` |
| Arayüz testinden sonra terminale dön | `shiv-don` — çalıştığın terminali kendisi bulur, öne getirir (`--kim`: yalnız adını yaz) |
| Kurulumdan ÖNCE paketi denetle | `shiv-denetle [proje]` · `--deb <dosya>` — doğru deb, artık, caps/tetikleyiciler, oldabi gereği, çeviri, UUID (§7) |
| Prefs iskeleti | `shiv-prefs-ornek` |
| Tweak'in çalışma anı davranışı | `shiv-log` — `parca` tweak'e yapıştırılacak ms damgalı log fonksiyonunu verir, `yeni` sıfırlar, `ozet` olayları sayar (`cat` ile okuma: bağlamı yer) |
| Ekran görüntüsü = ölçüm | `shiv-kare isaret` → `shiv-kare yeni` — görsel hatalar günlükte görünmez; yalnız işaretten sonraki kareler listelenir |
| Büyük silme (ölü kod) | `shiv-sil <dosya> <baş> <son>` — tarihli yedek + aralığı sil + diff + bozuk yorum/parantez denetimi. 40 satır kuralının amacını korur, bedelini kaldırır |
| Yeni tweak'e çalışan iskeletle başla | `shiv-ornek` listeler · `shiv-ornek <ad\|no> [hedef]` kopyalar (üstüne yazmaz). Rehber: `shiv-ornek --rehber` |
| Bir metot public mi | `shiv-sinif --metod <Sınıf> --tip --sdk` — imzanın yanına "SDK başlığında var mı" yazar (ipucu, kanıt değil) |
| Bir metot **ne zaman** çağrılıyor | `shiv-iz <Sınıf> -metot +metot… [--sn 60]` — anlık satır: ms, sınıf+seçici, self'in sınıfı. Argümana dokunmaz, metodu çağırmaz |
| Sınıf **nereden** geliyor, kimin alt sınıfı | `shiv-sinif --nerede <Sınıf>` — imaj yolu + üst sınıf zinciri (her `--tip` çıktısının başında da var) |
| Sınıf ara, **node yok** | `shiv-sinif --canli <desen> [--pid N\|--bid <id>]` — çalışan süreçten |
| Çökme sebebi | `…/Library/Logs/CrashReporter/*.ips` → `reason`, `lastExceptionBacktrace` |
| Derlenen ürün doğru mu | `dpkg-deb -x` + `strings` |
| Eylem Düğmesi'ne basmak | `shiv-dugme kisa\|cift\|uzun [sn]` — **gerçek basış** (aşağıdaki uyarı). Önce `shiv-dugme yetenek`: cihazda düğme var mı. HID kodu iOS 17.0.3 (gerçek 15 Pro) ve 26.6.2'de ÖLÇÜLDÜ, 18/27 DOĞRULANMADI. MCP karşılığı `press_action_button`, kilitliyken de çalışır |
| MCP kurulu mu, ayakta mı, hangi modda | `shiv-mcp durum` |
| frida zinciri uçtan uca çalışıyor mu | `shiv-ortam --ajan-sina [pid]` — shivfrida → frida-server → attach → ObjC. Dördünden biri koptuğunda belirti hep "araç sessizce boş döndü" idi; bu, kopan halkayı adıyla söyler |
| Ekranda ne var (MCP varsa) | `describe_screen` → `get_ui_elements` → `ocr_screen` → `screenshot`. **Bu sırayla**, §3'e bak |
| Tweak'in `NSLog` çıktısı | `get_syslog(process:…, last_seconds:…)` — artık okunuyor |

`shivfrida attach` kullan; `spawn` uygulamayı yeniden başlatır ve açık
sayfayı siler.

**`shiv-dugme` / `press_action_button` GERÇEK bir düğme basışıdır.**
Kullanıcının Eylem Düğmesi'ne atadığı eylem çalışır: kayıt başlar, kamera
açılır, sessiz mod değişir. Kilit ekranında da çalışır. **Basmadan önce
kullanıcıya ne olacağını söyle ve onayını al**; her basışın sonucunu
kullanıcıdan öğren (araç yalnız "gönderildi" der, eylemin olduğunu
göremez). Uzun basıştan önce öndeki uygulamaya bak: kamera öndeyse iOS
düğmeyi kameraya devreder, uzun basış fotoğraf çeker (ÖLÇÜLDÜ).

**Tip kodlaması nasıl okunur** (24 Eyl 2026'da ölçüldü):
`-nowPlayingApplication    @16@0:8` → önce DÖNÜŞ (`@` nesne), sonra
`self`(@) ve `sel`(:); sayılar bayt ofsetidir. `v`=void `B`=BOOL
`i`=int `q`=long `d`=double `^v`=pointer `{CGRect=...}`=yapı. Dönüş
tipi `?` çıkarsa **çağırma** — tip okunamamış demektir. Tip dyld
cache'ten DEĞİL çalışan süreçten okunur: cache'teki relative method
list'ten çıkarma denendi, hesaplanan adres komşu dizeye düştü
(beklenen `v24@0:8@16` yerine `q24@0:8@16`) — yanlış tip, tipsizden
kötüdür.

### Ayarlar sayfası açma
Ayarlar ayaktayken `uiopen` **yok sayılır**. Doğru sıra:
```
launchctl list | grep -F "UIKitApplication:com.apple.Preferences["
kill -9 <pid>
uiopen "prefs:root=<Sayfa>"
```
Alt sayfa: `uiopen "prefs:root=<Sayfa>&path=<specifier-id>"`.
Süreci öldürmek ayrıca yeni prefs bundle'ının yüklenmesini sağlar.

### Çevirileri sınamak
Sistem dilini değiştirmeye gerek yok: yalnız o uygulamanın
`AppleLanguages` tercihi yazılır. Reçete `TWEAK.md §4b`'de.

> **Bu, frida'nın izinli kullanımıdır.** (Kırmızı çizgi 7 artık
> tıklatmayı da koşullu olarak serbest bırakıyor; bu yol yine de
> daha ucuz: arayüze hiç dokunmadan gerçek bundle yükleniyor.) Arayüze dokunulmuyor, hiçbir şey simüle
> edilmiyor — gerçek uygulama gerçek bundle'ı yüklüyor. Ve aparat
> bitince geri alınıyor; cihazda bırakılan ölçüm aparatı, ölçüm değil
> artıktır.

---

## 5. RootHide namespace tuzağı

Kabuk **jbroot** içinde, SpringBoard ve sistem süreçleri **gerçek**
yolda çalışır. Aynı yol iki süreç için aynı yeri göstermez.

| Belirti | Gerçek durum |
|---|---|
| Tweak `/var/mobile/tw/x.txt` yazıyor, kabukta dosya yok | `/rootfs/var/mobile/tw/...` altına bak |
| `node /mutlak/yol/x.mjs` → MODULE_NOT_FOUND | `cd` edip **göreli** adla çalıştır |
| Betik PATH'ten çözülmüyor | uzun jbroot yoluyla çağır |
| Ajanın dosya aracı (Read/Write/Edit) yanlış yere yazdı/okudu | Dosya araçları **gerçek kökte**, kabuk **jbroot'ta** (25 Eyl 2026'da ölçüldü). Dosya araçlarına her zaman uzun gerçek yolu ver: `/private/var/mobile/...` ya da jbroot'un tam yolu |

**Hangi süreç hangi kökü görüyor (RootHide, ÖLÇÜLDÜ):** bir yolu bir
araca vermeden önce o aracın hangi kökte çalıştığına bak.

| Süreç | Gördüğü kök | Ölçüm |
|---|---|---|
| kabuk (zsh), shiv-* betikleri | jbroot | — |
| root yardımcısı (kurd, launchd'den) | jbroot | 28 Eyl |
| ajanın Read/Write/Edit araçları | gerçek kök | 25 Eyl |
| `swift betik.swift` (yorumlanan) | gerçek kök | 1 Eki |
| node | gerçek `/tmp` (kabuğun `/tmp`'si değil) | 1 Eki |
| theos-roothide ile derlenen CLI aracı | kabuğun yollarını görmüyor (`~/…` çalışmıyor) | 1 Eki |
| SpringBoard, Ayarlar, uygulamalar | gerçek kök | 22 Eyl |

Elle derlenip `ldid -S` ile imzalanan ikili kabuktan çalıştırılınca
bu cihazda **öldürülebiliyor** (`rc=137`, 1 Eki — tutarsız: bir kez
çalıştı); dpkg ile kurulan ikili çalışıyor (`shiv-dugme`, ÖLÇÜLDÜ).
Kısa bir iş için derlemek yerine yorumlanan dil (swift/node) daha güvenilir.

### Yeniden jailbreak — jbroot kimliği DEĞİŞİR

`.jbroot-<ID>` her yeniden jailbreak'te başkadır (27 Eyl 2026'da
yaşandı: `…-325982B5…` → `…-DA07EA02…`). Sonuçları:

- Kimliği **hiçbir yere sabit yazma.** Çalışma anında türet. Bizim node
  paketi bunu `find` ile yapıyor ve yeniden jailbreak'te kendiliğinden
  yeni kimliğe geçti — ÖLÇÜLDÜ.
- `readlink` **işe yaramaz**: kabuk zaten jbroot namespace'inde, kanonik
  yol olarak `/usr/local/...` döner.
- `ls` de **kullanılamaz**: `profile.d/coreutils.sh` onu `-F` ile
  sarmalıyor ve jbroot bir bağ olduğu için sonuna `@` ekliyor. `find`
  kullan.
- Claude Code oturumları, hafıza ve **`--scope local` MCP kaydı**
  kaybolmuş görünür. MCP kaydı bu yüzden **`--scope user`** olmalı.
  **Çare: `shiv-jbroot --yap`** — CLI'yi AÇMADAN önce. Yeni kimliğin
  proje anahtarını eskisine symlink'ler; oturum ve hafıza birlikte gelir
  (ikinci jailbreak'te ÖLÇÜLDÜ). Hiçbir şey silmez. Kuru çalışma
  varsayılan; `--kur` her yeni kimlikte bir kez kendiliğinden çalıştırır.
  `shiv-ortam` onarılacak bir şey görürse `claude-oturum` satırında söyler.
- **Tuzak:** proje anahtarını `jbroot /` çıktısından türetme; yalnız
  `<ID>` al. AppGroup yolu ile Bundle yolu farklı.

**Kural: "yazdığım dosya yok" demeden önce aynadaki yola bak.**
`shiv-yol` bu çeviriyi yapar.

Yol sorunlarının çoğu için ayrı bir kabuk ya da paket gerekmez — **yolun
başına jbroot eklemek yeter.** (DiffTerm bu şekilde çözüldü; `bash-ios7`
bu yüzden gereksizdi.)

**dylib değişikliği çalışan SpringBoard'ı ETKİLEMEZ.** Ölçüm kodu
eklendiyse respring şart — bunu kullanıcıya açıkça söyle.

---

## 6. Ölçüm disiplini — kendi aletine takılmama

Üç kez ölçüm aletimiz sonucu bozdu ve hata paketin sanıldı:

- **Ölçüm için `mv` değil `cp` kullan, orijinali yerinde bırak.**
  Yeri değiştirilen ikili sonraki komutla ezildi, ölçüm `rc=127` verdi.
- **Önce `sudo -v`, sonra komutları tek tek.** Şifre istemi, blok hâlinde
  yapıştırılan komutların geri kalanını yuttu.
- **Uzun komutları kısa satırlara böl; çıktıdaki argümanları gözle
  doğrula.** Terminal yapıştırmada boşluk yiyebiliyor
  (`-a mobile-s com.test.z`) ve test sessizce geçersiz kalıyor.
- **Ölçerken telefonun EKRANI AÇIK kalsın** (5 Eki 2026, A/B ile ölçüldü):
  `shiv-env` ekran açıkken 10 sn, kilitli ama ekran yanıkken 10 sn, ekran
  KAPALIYKEN 246 sn sürdü — iOS ekran kapanınca arka plan işlerini
  yavaşlatıyor. Mac'ten SSH ile çalışırken telefonu görmezsin; süre
  saçma uzunsa önce ekrana bak, aracı suçlama. `shiv-env` 60 sn'yi aşarsa
  bunu kendisi söylüyor.
- **zsh'de eşleşmeyen glob KOMUTUN TAMAMINI iptal eder** (26 Eyl 2026'da
  ölçüldü): `rm -f a.txt dc-*.json` → `no matches found`, ve `a.txt` da
  silinmedi. Glob'lu silmeyi ayrı satıra al.

---

## 7. Derleme, ABI ve yayın

**Önce cihazda derle. Mac son çare, ilk tercih değil.** Cihaz döngüsü
(derle-kur-logla) çok daha hızlı; Mac'in yapıp cihazın yapamadığı tek şey
`caps 0x80` üretmek. Hangi durumda hangisi — `TWEAK.md §1.6`'daki
"Deciding where to build" tablosu karar veriyor, buradaki özet değil.

```
make THEOS=<theos> clean package THEOS_PACKAGE_SCHEME=<scheme>
```
Şemayı **hedef** jailbreak belirler, derleme cihazı değil
(`TWEAK.md §1.2`). `shiv-ortam` bu cihaz için doğru akışı zaten basıyor —
elle seçmek yerine onu izle.

> **ABI / caps kuralının TAMAMI `TWEAK.md §1.6`'da. Oraya bak.**
> Burada yalnız karar verdiren üç satır var; ayrıntıyı burada
> tekrarlamıyoruz, çünkü iki yerde duran kural iki kere bayatlar.

- **caps 0x00 tek başına ZARARSIZ.** Kusur değil, bağımlılık. Cihazda
  derlemek "yayınlanamaz" demek DEĞİL — belirleyici olan **ÜÇ**
  tetikleyici: bir `@"..."` literali, sisteme verilen bir blok
  (`[block copy]`), ya da **ikilinin kendi tanımladığı ObjC sınıfı**
  (her prefs bundle'ı: `PSListController` alt sınıfı). Üçü de yoksa
  (düz `%hook`) cihazda derlenen arm64e tweak `oldabi` olmadan çalışır.
  3. tetikleyici 1 Eki 2026'da ÖLÇÜLDÜ (rootless XS, OldABI tek değişkenli
  A/B): `__cfstring = 0`, blok yok, prefs yine `readClass`'ta düştü.
  Eski "7 örnek, sıfır istisna" sayımında sınıf tanımlayan ikili yoktu.
- **Sınav:** arm64e diliminde `otool -l <dilim> | grep -c __cfstring` ve
  `grep -c __objc_classlist` → ikisi de **0** olmalı. Değilse oldabi ister
  ya da Mac'te derlenir. arm64 (uygulama) hedeflerinde bu konu HİÇ geçerli değil.
- **Rootless'ın clang 16'sı (Procursus) SAHTE 0x80 üretiyor** (1 Eki 2026,
  ÖLÇÜLDÜ): etiket yeni ABI, içerik değil → **OldABI açıkken bile** çöker.
  Cihazda arm64e derlerken `ADDITIONAL_CFLAGS=-fno-ptrauth-abi-version`
  ve `ADDITIONAL_LDFLAGS=-fno-ptrauth-abi-version` ver → 0x00 olur, yukarıdaki
  kural geçerli olur. `shiv-ortam` doğru satırı basar. Ayrıntı `TWEAK.md §1.6`.
- **caps'i DOĞRU araçla oku (26 Eyl 2026'da ölçüldü, bir kez yanlış
  okundu).** Tweak dylib'i çoğu zaman **fat** (arm64+arm64e); `od` fat
  dosyaya uygulanınca fat başlığını gösterir, caps'i değil. Doğrusu:
  `lipo <dylib> -thin arm64e -output /tmp/s && od -A n -t x1 -N 12 /tmp/s`
  (12. bayt: `80` yeni ABI, `00` eski) ya da
  `otool -f <dylib>` → `capabilities 0x80`.
  **`file` çıktısındaki `PAC00` caps baytı DEĞİLDİR** — hem 0x80 hem 0x00
  ikilide aynı görünebiliyor; ona bakıp karar verme.
- **"Cihazda derlenen her zaman 0x00" artık doğru değil** — aynı gün bu
  cihazda derlenen bir paket `capabilities 0x80` çıktı (ölçüldü).
  Varsayma, **her pakette ölç**.
- **Tetikleyici varsa iki dürüst yol var:** `control`'e
  `Depends: firmware (<< 15.0) | cy+cpu.arm64v8 | oldabi` yaz, **ya da**
  Mac'te derle (caps 0x80) ve hiçbir şeye bağımlı olma. Sessizce oldabi
  gerektiren bir paket yayınlamak, kullanıcının cihazını safe mode'a
  düşürmek demektir.
- **ÖLÇÜM TUZAĞI:** derleme cihazında `oldabi` kuruluysa tetikleyicili
  bir paket de "çalışıyor" görünür. `dpkg -l | grep -i 'oldabi\|legacy
  arm64e'` ile bak; gerçeği görmek için `OldABI.dylib`'i adından
  taşıyıp tek değişkenli A/B yap. **Bu tuzak gerçekten düşüldü** (1 Eki
  2026): `TWEAK.md §4b` "cihazda 0x00 prefs için sorun değil" diyordu;
  o ölçüm OldABI'li cihazdaydı. A/B'siz "çalışıyor" KANIT DEĞİLDİR.
- Kurulumdan sonra `dpkg -l | grep <paket>` ile **doğrula** — komut
  `exit=2` döndüğü hâlde "tamamlandı" dendiği oldu.

### Kurulum öncesi doğrulama zinciri — altı adım, sırayla

Her kurulum turu pahalı (respring + kullanıcı testi). Turu harcamadan
önce bunların hepsi geçmeli:

> **`shiv-denetle` (1.3.0) 2–5'i tek komutta yapar:** `.theos/last_package`
> ile DOĞRU deb'i bulur (ls -t değil), kaynak deb'den yeniyse "bayat"
> der, `.bak`/`._*` sızıntısını, her arm64e dilimin caps · `__cfstring` ·
> `__objc_classlist` · bağlayıcı sürümünü, oldabi gereğini (control'e
> bakarak), çeviri kapsamını ve kurulu olanla UUID'yi basar.
> **Karar vermez, ölçer.** Çıkış 2 = kurma. 1. ve 6. adım yine senin.

1. **Kaynak farkı:** son yedekle `diff` — değişen yalnız beklediğin yer mi?
2. **Bozuk yorum:** `grep -n '^[[:space:]]*/[^/*]' <dosya>` boş dönmeli.
3. **Derleme başarılı mı — `ls -t`'ye ASLA güvenme.** Çıktıdaki
   `dm.pl: building package '...' in './packages/<ad>.deb'` satırını ara.
   Satır varsa derleme geçti ve deb'in tam yolunu veriyor; satır yoksa
   deb aramaya çıkma — başarısız derlemede **eski deb yerinde duruyor** ve
   sessizce kurulur. (`TWEAK.md §1.5`)
4. **Ürünün içinde iz:** `dpkg-deb -x` ile aç. `strings` **çıplak
   ikilide yanıltır** — kesin olan `LC_UUID`:
   `otool -l <dylib> | grep -A2 LC_UUID`, derlenen ile kurulanı
   karşılaştır; eşleşmeden "test et" deme. Gerekiyorsa caps:
   `od -A x -t x1 -N 12`.
5. **Kurulum:** `dpkg -i` → `exit=0`, ardından `dpkg -l` ile **sürüm
   numarasını gözle doğrula.** "Tamamlandı" denip `exit=2` döndüğü oldu.
6. **Respring'i kullanıcıdan iste** — dylib değişikliği çalışan süreci
   etkilemez, yeni kod ancak respring'den sonra yüklenir.

3. ve 4. adım en çok tur yiyen yer: bir turda **dört test bayat deb
üzerinde** yapıldı. Prefs bundle'ı AYRI bir ikilidir, onu da doğrula.

---

## 8. UIKit / SpringBoard — genel dersler

Bunlar tek bir tweak'e değil, sisteme dair. **Switcher iç yapısı, menü /
context menu reçeteleri ve hook kalıpları `TWEAK.md §4`'te** — buradakiler
o reçetelerin arkasındaki genel kurallar.

- **Görünürlüğü bir durum makinesine (yoklama + animasyon) bağlı olan
  her view, makinenin "kapalı" durumunda doğmalı** (`hidden=YES,
  alpha=0`). Görünür başlatılan view, makinenin ilk kararına kadar
  yanlış durumda kalır; ekranda tek seferlik bir titreme olarak görünür.
- **Switcher görünümü, kaydırma başlar başlamaz yükleniyor** — gerçek
  açılıştan ~1,5 sn önce. "Görünüm yüklendi" ≠ "kullanıcı görüyor".
- **Kart/hücre görünümleri yeniden kullanılır.** Rozet ve etkileşim
  **idempotent** kurulmalı. `prepareForReuse`, animasyon sürerken
  transform/alpha sıfırlarsa animasyonu öldürür.
- **Sistemin geçişte kullandığı transform bileşenine DOKUNMA.** Sistem
  scale (a,d) kullanıyor; scale'e bakan bir kontrol bütün kartları bozdu.
- **Yoklamaya (polling) dayalı görünürlük geç kalır.** Sistem "görünür
  mü" sorusuna 600–1000 ms sonra, bazen yanlış cevap veriyor. Erken ve
  yön bilgisi taşıyan bir çağrı ara; yoklamayı **emniyet ağı** olarak
  bırak, tek otorite yapma.
- **Emniyet supabı hatanın kendisi olabilir.** "10 tur uyuşmazsa sistemi
  kabul et" türü bir sayaç, iki ayrı belirtinin doğrudan sebebi oldu.
  Zaman tabanlı valf koyacaksan eşiği **ölçülmüş gecikmenin üstünde**
  seç ve yönlere **asimetrik** ver.
- **Bir sınıfın adı ne yaptığını söylemez.** `SBFluidSwitcherViewController`
  switcher değil; app ve ana ekran geçişlerini de barındıran fluid kap.
  Ne barındırdığını ölç. **Aynısı METOTLAR için de geçerli:** KASwitcher
  0.5.0'da isimden tahmin edilen üç metodun ikisi yanlış çıktı
  (`containerDidEndSwipingToKill:` yalnız VAZGEÇİLEN çekişte geliyor,
  `_removeAppLayout:forReason:` elle kapatmada hiç çağrılmıyor). Hook
  yazmadan önce yalnız-ölçüm kurulumuyla (her hook `%orig` + bir satır)
  **zinciri çıkar**; zincir bilinmeden yazılan hook turu yer.
- **Ekrana view koyan her tweak DİKEY VE YATAY ölçülür.** KASwitcher
  0.0.1 → 0.4.3 boyunca yatay hiç ölçülmemişti; ilk ölçümde X butonunun
  yatayda kartların üstünde kaldığı görüldü (dikeyde 7 pt boşluk vardı).
  Switcher yatayda ayrı düzen kuruyor.
- **SpringBoard'da pencere DÖNMEZ, içerik döner.** Yatayda
  `SBMainSwitcherWindow` hâlâ 393x852; dönüşü
  `BSUIOrientationTransformWrapperView` bir transform ile yapıyor
  (iOS 17.0.3'te ÖLÇÜLDÜ). İki sonucu var: (a) o görünümün
  `safeAreaInsets`'i yatayda da DİKEY değerleri veriyor, yani
  `safeAreaLayoutGuide`'a bağlanan view yanlış yere düşüyor;
  (b) `UIContextMenuInteraction` menüsü **pencere yönünde**, yani dikey
  açılıyor. `shiv-pencere` dökümünün başındaki `YON:` satırına ve
  görünüm satırındaki `safe=` sütununa bak — pencere çerçevesine bakıp
  "yatay değil" deme.
- **Switcher gibi overlay'lerde önce KENDİ menünü düşün.**
  `UIContextMenuInteraction` orada üç ayrı kusur üretti (yatayda dikey
  açılma, cam/gölge sıçraması, küçük kaynakta menünün butonun üstüne
  oturması) ve konum için public API yok. İçerik görünümünün İÇİNDE
  çizilen kendi menün (basılı tutma + `UIImpactFeedbackGenerator`)
  üçünü birden kaldırdı. Reçete: `TWEAK.md §4`.
- **Sistemin sahiplendiği özelliği sen yönetemezsin.** Kendi animasyonun
  tutmuyorsa model/ekran ikilisini ölç (§3); sistem her karede geri
  yazıyorsa o görünüme dokunma, snapshot kopyasını canlandır.
- **Durumun sahibi kimse ONU kullan; sonucunu süzme.** Bir durumun
  (gizli, seçili, sabit…) Apple'da bir sahibi varsa kendi kopyanı tutma:
  iki doğru oluşur ve Apple'ın geri kalanı (kurucular, geçişler,
  animasyon) senin listeni bilmez. KASwitcher 0.6 gizli uygulamaları kendi
  süzgeciyle tutuyordu; her istisna yeni bir zamanlama penceresi doğurdu.
  0.7 Apple'ın kendi bayrağına geçti (`-[SBAppSwitcherModel hide:]`,
  `SBAppLayout.hidden`), istisnaların hepsi ve ~300 satır kalktı
  (Eki 2026, ÖLÇÜLDÜ: vphone iOS 26.6.2 ve RootHide 17.0.3; iOS 16 DOĞRULANMADI). Önce sor: **bu durumu Apple'da kim tutuyor?**
- **Apple doğru anda alamıyorsa veriyi KENDİN al, ama Apple'a Apple'ın
  yoluyla ver.** Apple'ın görünümüne/resmine dokunma (`setImage:` gibi);
  doğru veriyi doğru anda kaynağından al, Apple'ın kendi kayıt yoluyla
  teslim et. KASwitcher 0.7: öndeki uygulamanın görüntüsü Apple'da eksik
  çıkıyordu (Apple arka plana geçerken alıyor, sahne artık çizmiyor).
  Sahne hâlâ öndeyken `FBScene createSnapshot` ile alındı, Apple'ın
  `saveSuspendSnapshot:forSceneHandle:` yoluyla depoya yazıldı (ÖLÇÜLDÜ).
  Kopyanın kopyası işi bozar.
- **Nesneyi elle kurma; Apple'ın onu kurduğu yolu bul.** Bir sınıfın
  `init…`'ini doğrudan çağırmak, Apple'ın o nesneyi kurarken yaptığı
  hazırlığı atlar. ActionButtonFix 2.10: `CHUISControlInstance` doğrudan
  kurulunca Swift `assertionFailure` ile **SpringBoard iki kez düştü**;
  Apple'ın kilit ekranında kullandığı fabrika yolu
  (`CHUISControlInstanceFactory instanceOfType:instanceIdentity:`) ise
  çalıştı (ÖLÇÜLDÜ). Apple'ın kaydettiği bir nesne varsa (arşiv) onu al.
- **`connectedScenes` bir KÜMEDİR, "ilki" rastgeledir.** Pencereni
  sahneye açıkça bağla (örn. ilgili sistem penceresinin `windowScene`'i).
  ActionButtonFix 2.10: pencere "ilk" sahneye konuyordu = 6/6 kez
  `SystemAperture`; klavye oraya hiç gelmedi. Doğru sahneyle 9/9 yazdı.
- **Artış sızıntı değildir; önce stok akışın bırakıp bırakmadığını
  ölç.** ActionButtonFix 2.10: galeri her açılışta +33 örnek (54→285);
  Apple'ın kendi "+" penceresi açılınca 285→54 düştü — kalıcı değil.
- **"Dokununca düzeliyorsa" eksik olan veri değil, yenileme tetiğidir.**
  Veri doğru ama ekran eskiyse, Apple'ın bir önbelleği haber almamıştır:
  aramayı modelde değil, görünümün önbellek/yenileme çağrısında yap.
  KASwitcher 0.7: kasadan dönen kartlar perdeli kalıyor, switcher'da
  herhangi bir dokunuş hepsini düzeltiyordu → eksik olan
  `-[SBFluidSwitcherViewController _updateSnapshotCache]` çağrısıydı
  (ÖLÇÜLDÜ, kullanıcı bulgusu).
- **Zaman penceresi yerine durum değeri; tek bayrak yerine başla/bit
  eşlemesi.** "400 ms içinde geleni yok say" türü pencereler yerine
  Apple'ın isteğinde o ayrımı taşıyan alanı bul (KASwitcher 0.7:
  geçiş isteğinin `unlockedEnvironmentMode` değeri — 2 switcher açık
  kalıyor, 0 gerçek ana ekran; 53 olayda ÖLÇÜLDÜ). Bir işlemin bitişini
  bekleyen bayrak İKİ aşamalı olsun (başlangıç bekleniyor → bitiş
  bekleniyor) ve yabancı bitişi yok saysın: tek bayrak, araya giren başka
  geçişin bitişiyle silindi ve atışların ~%15'i kaçtı (88 atışta ÖLÇÜLDÜ).

---

## 9. Prefs (PSListController) — sık düşülen tuzaklar

> **Tam reçeteler `TWEAK.md §4b`'de** (çalışan kod, hücre numaraları,
> AltList, hand-built plist sınırları, cfprefsd tamponu, `-O0` tuzağı).
> Aşağıdakiler yalnız en pahalı beş tanesi.
>
> **Prefs'te hiçbir hata SES ÇIKARMAZ.** Derleme geçer, tweak yüklenir,
> sayfa boş gelir ya da seçim kaydolmaz. Bir hücrenin görünmesi, onun
> eyleminin çalıştığını KANITLAMAZ. Her katmanı ayrı ayrı kanıtla.

- Tekli seçim listesi: `PSListItemsController` + `validValues`,
  `validTitles`, `shortTitles` — yanlış anahtar → Ayarlar çöker
- Slider: `PSSliderCell` / `PSSegmentableSlider` — **asıl alt görünüm
  iki seviye derinde**; genişlik düzeltmesi yanlış seviyeye uygulanırsa
  etkisiz kalır
- **Ayarlar'ın push ettiği detay sınıfı `PSViewController` soyundan olmak
  ZORUNDA** (düz `UIViewController` → `setRootController:` çökmesi)
- **`specifiers` gerçek bir dizi olmalı** (boş/nil → `NSRangeException`)
- Dinamik listeler **stok yoldan**: dinamik `PSSpecifier` +
  `reloadSpecifiers`. Kendi `UITableView`'ini kurma.
- İkonlar: `PSTableCell` lazy icon (`appIDForLazyIcon`, `useLazyIcons`)
- Uygulama listesi: `LSApplicationWorkspace defaultWorkspace`
  → `allInstalledApplications`
- Ayar değişince tweak'e haber: `PostNotification` + Darwin observer;
  tweak ile prefs bundle **aynı CFPreferences alanını** kullanmalı
- Örnek al: `/System/Library/PreferenceBundles/*.bundle` (jbroot'ta
  `/rootfs/...`)

---

## 10. Bitirirken

1. Değişen kısımlar — **yalnız onlar**, tüm dosya değil.
2. Bozuk yorum `grep` çıktısı.
3. `dpkg -l` doğrulaması.
4. Proje raporuna o sürümün bölümü: **belirti, ölçüm, sebep, düzeltme.**
   Ölçmediğin şeyi "ölçülmedi" diye işaretle.
5. Kullanıcıya numaralı test adımları + bozulursa **geri dönüş komutu**.
6. Yayını **kullanıcı yapar.** Depoya push etme.
