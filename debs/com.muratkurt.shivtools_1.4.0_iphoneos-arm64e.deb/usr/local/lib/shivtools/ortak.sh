# shivtools ortak cozucu — bu dosya KAYNAK olarak okunur (`.` ile).
#
# Amac: dokuz arac yollari ve eksik bagimliliklari TEK yerden bilsin.
# Sahada olculen uc sorun buradan cozuluyor:
#   - 'shivfrida' PATH'te degildi ve klasorle ayni adi tasiyordu
#     (…/lib/shivfrida/shivfrida) - dogru yolu bulmak uc deneme yedi.
#   - Rootless cihazda ne 'frida' ne 'lsof' vardi; araclar sessizce
#     patliyordu, eksigin ADINI soylemiyordu.
#   - Modul dizinini $0'dan tahmin etmek kirilgan: sh'de
#     `dirname "$0"` sembolik bagin HEDEFINI vermez.
#
# Cevre degiskenleriyle ezilebilir:
#   SHIVTOOLS_LIB   /usr/local/lib/shivtools
#   SHIVTOOLS_AJAN  $SHIVTOOLS_LIB/ajanlar
#   SHIVFRIDA       shivfrida ikilisinin tam yolu
#   SHIVTOOLS_PAY   /usr/local/share/shivtools

# ---- kok: rootless'ta /var/jb oneki olabilir ----
st_kok() {
  for k in "" /var/jb; do
    [ -d "$k/usr/local/lib/shivtools" ] && { echo "$k"; return; }
  done
  echo ""
}
ST_KOK="$(st_kok)"

SHIVTOOLS_LIB="${SHIVTOOLS_LIB:-$ST_KOK/usr/local/lib/shivtools}"
SHIVTOOLS_AJAN="${SHIVTOOLS_AJAN:-$SHIVTOOLS_LIB/ajanlar}"
SHIVTOOLS_PAY="${SHIVTOOLS_PAY:-$ST_KOK/usr/local/share/shivtools}"

# ---- shivfrida ikilisi ----
# ONCE PATH: paket onu /usr/local/bin'e koyuyor. Sonra eski shiv
# duzeni (klasor adi = ikili adi), en son kaynak agaci.
st_shivfrida() {
  if [ -n "$SHIVFRIDA" ] && [ -x "$SHIVFRIDA" ]; then echo "$SHIVFRIDA"; return; fi
  P=$(command -v shivfrida 2>/dev/null)
  [ -n "$P" ] && [ -x "$P" ] && { echo "$P"; return; }
  for c in "$ST_KOK/usr/local/bin/shivfrida" \
           /var/jb/usr/local/bin/shivfrida \
           /usr/local/bin/shivfrida \
           /var/jb/usr/local/lib/shivfrida/shivfrida \
           /usr/local/lib/shivfrida/shivfrida; do
    [ -x "$c" ] && { echo "$c"; return; }
  done
  echo ""
}

# ---- ajan dosyasi ----
st_ajan() {   # st_ajan ekran.js -> tam yol ya da bos
  for d in "$SHIVTOOLS_AJAN" \
           /var/jb/usr/local/lib/shivtools/ajanlar \
           /usr/local/lib/shivtools/ajanlar \
           /var/jb/usr/local/lib/shivfrida \
           /usr/local/lib/shivfrida \
           /var/mobile/tw; do
    [ -f "$d/$1" ] && { echo "$d/$1"; return; }
  done
  echo ""
}

# ---- eksik bagimliligi ADIYLA soyle ----
# st_eksik <arac-adi> <eksik> [alternatif cumlesi]
# Metinler cagirandan gelir; iki dilli istenirse cagiran $(sy ..) verir.
st_eksik() {
  echo "[$1] $(sy eksik missing): $2" >&2
  [ -n "$3" ] && echo "[$1]   $3" >&2
  return 1
}

# frida zinciri: ikili + sunucu. Eksikse hangisinin eksik oldugunu
# ve NE YAPILACAGINI yazar. Donus 0 = hazir.
st_frida_hazir() {   # st_frida_hazir <arac-adi>
  ARAC="$1"
  SF=$(st_shivfrida)
  if [ -z "$SF" ]; then
    st_eksik "$ARAC" "$(sy 'shivfrida (frida istemcisi)' 'shivfrida (frida client)')" \
      "$(sy "shivtools paketi eksik kurulmus; 'dpkg -l | grep shivtools' ile bakin." \
            "the shivtools package is incompletely installed; check with 'dpkg -l | grep shivtools'.")"
    return 1
  fi
  # frida-server: ADI ve YERI ile. 'frida' CLI'si GEREKMIYOR - araclar
  # sunucuya kendileri baglaniyor (rootless cihazda 'frida' yoktu ama
  # frida-server /var/jb/usr/sbin altinda duruyordu - olculdu).
  FS=""
  for c in /var/jb/usr/sbin/frida-server /usr/sbin/frida-server \
           "$(command -v frida-server 2>/dev/null)"; do
    [ -n "$c" ] && [ -x "$c" ] && { FS="$c"; break; }
  done
  if [ -z "$FS" ]; then
    st_eksik "$ARAC" "$(sy 'frida-server (cihazda kurulu degil)' 'frida-server (not installed on the device)')" \
      "$(sy 'Denetlemek icin: shiv-frida-kur · kurmak icin: sudo shiv-frida-kur --kur' \
            'To check: shiv-frida-install · to install: sudo shiv-frida-install --install')"
    return 1
  fi
  CALISIYOR=0
  if command -v pgrep >/dev/null 2>&1; then
    pgrep -x frida-server >/dev/null 2>&1 && CALISIYOR=1
  fi
  if [ "$CALISIYOR" = "0" ] && ps ax -o comm= >/dev/null 2>&1; then
    ps ax -o comm= 2>/dev/null | sed 's#.*/##' | grep -qx frida-server && CALISIYOR=1
  fi
  if [ "$CALISIYOR" = "0" ]; then
    launchctl list 2>/dev/null | grep -qi 're\.frida\.server' && CALISIYOR=1
  fi
  if [ "$CALISIYOR" = "0" ]; then
    st_eksik "$ARAC" "$(sy "frida-server calismiyor ($FS var ama surec yok)" \
                            "frida-server not running ($FS is there but no process)")" \
      "$(sy 'Durum icin: shiv-frida-kur' 'For status: shiv-frida-install')"
    return 1
  fi
  # MIMARI SINIRI: shivfrida arm64e. A11 ve oncesi cihazlarda
  # (iPhone X/8 ve eski iPad'ler) bu ikili CALISMAZ. Paket kurulumu
  # engellenmiyor - shiv-sinif frida'ya hic dokunmuyor ve A11
  # kullanicisi onu kullanabilmeli.
  return 0
}

# Donanim arm64e mi (A12+)? Emin olamazsak 'bilinmiyor' deriz.
st_arm64e_mi() {
  S=$(sysctl -n hw.optional.arm64 2>/dev/null)
  [ "$S" = "1" ] && return 0
  S2=$(sysctl -n hw.cpusubtype 2>/dev/null)
  [ "$S2" = "2" ] && return 0
  return 2      # bilinmiyor
}

# Tek satirlik yardim basligi (her aracin kendi metni var).
st_pay_dosya() {   # st_pay_dosya SHIVTOOLS.md
  for d in "$SHIVTOOLS_PAY" /var/jb/usr/local/share/shivtools \
           /usr/local/share/shivtools; do
    [ -f "$d/$1" ] && { echo "$d/$1"; return; }
  done
  echo ""
}

# shiv'in GOLGELEDIGI arac adlarini yazar (bosluk ayirmali), yoksa
# hicbir sey. 24 Eyl 2026'da cihazda olculdu:
#   shiv'in postinst'i /usr/local/bin/shiv-* adlarini 'ln -sf' ile
#   KENDI kopyalarina baglar, postrm'i ayni yollari 'rm -f' eder.
#   Ikisi de shivtools'un GERCEK dosyalarinin ustune yazar:
#     shiv kurulur/guncellenir -> shivtools araclari GOLGELENIR
#     shiv kaldirilir          -> shivtools araclari SILINIR (9 dosya)
#   dpkg cakismayi gormez, cunku baglari dpkg degil postinst yapiyor.
# Gercek cozum shiv tarafinda (bag kurarken/silerken sahibe bakmak) -
# ayri tur. Care tek satir: shiv'den SONRA shivtools'u yeniden kur.
st_golge() {
  _g=""
  for _t in shiv-sinif shiv-ortam shiv-ekran shiv-oku shiv-cek \
            shiv-pencere shiv-yol shiv-prefs-ornek shiv-frida-kur; do
    _y=$(command -v "$_t" 2>/dev/null)
    [ -n "$_y" ] && [ -L "$_y" ] || continue
    _h=$(readlink "$_y" 2>/dev/null)
    case "$_h" in */lib/shiv/*) _g="$_g $_t" ;; esac
  done
  echo $_g
}

# ---- st_node: calisan bir node yolu bas, yoksa bos ----------------
#
# Bu liste 27 Eyl 2026'ya kadar shiv-ortam ve shiv-sinif'te BIREBIR
# KOPYAYDI. Node yerlesimi degisince ikisi birden bayatladi: yeni
# paket (com.muratkurt.nodejs) node'u /usr/local/lib/node-ios/dist/bin
# altina koyuyor ve iki arac da "node yok" dedi. Kopya listenin bedeli
# budur; artik tek yerde duruyor.
#
# ADAY VAR OLMASI YETMEZ, CALISMASI LAZIM — 24 Eyl 2026'da rootless
# cihazda olculdu: eski nodejs paketinin /usr/local/bin/node
# SARMALAYICISI kendi ikilisinin kabul etmedigi V8 bayraklarini
# geciyordu ('bad option: --no-wasm-code-gc', rc=9). Dosya vardi,
# calismiyordu. O yuzden her aday CALISTIRILARAK sinanir.
#
# SIRA ONEMLI: once kullanicinin verdigi SHIV_NODE, sonra PATH, sonra
# bilinen yerlesimler. PATH'e guvenilemez — giris kabugu olmayan bir
# ssh oturumunda /usr/local/bin PATH'te YOK (27 Eyl 2026'da olculdu).
# ADAYLAR HOME'DAN BAGIMSIZ OLMALI — 29 Eyl 2026'da olculdu.
# Listede yalniz "$HOME/shiv-bin/node" vardi. Sonuc: AYNI cihazda
# AYNI anda iki farkli cevap. Ayarlar'in baslattigi surec
# HOME=/var/mobile ile calisiyor ve '/var/mobile/shiv-bin/node'u
# buluyordu (eski shiv'den kalma v18.20.4); root kabugunda HOME
# /var/root oldugu icin ayni dosya hic gorunmuyordu. Sayfa "node
# kurulu" derken terminal "node yok" diyordu. Olcum araci ortamina
# gore cevap degistiriyorsa, olcmuyor demektir.
st_node() {
  for _n in "$SHIV_NODE" "$(command -v node 2>/dev/null)" \
            /usr/local/lib/node-ios/dist/bin/node \
            /var/jb/usr/local/lib/node-ios/dist/bin/node \
            /usr/local/bin/node /var/jb/usr/local/bin/node \
            /usr/local/lib/nodejs/node /var/jb/usr/local/lib/nodejs/node \
            "$HOME/shiv-bin/node" /var/mobile/shiv-bin/node \
            /usr/local/lib/shiv/node \
            /var/jb/usr/local/lib/shiv/node; do
    [ -n "$_n" ] && [ -x "$_n" ] || continue
    "$_n" -e '' >/dev/null 2>&1 || continue
    echo "$_n"; return 0
  done
  return 1
}

# ---- st_mcp_saglik: MCP sunucusu ayakta mi — UC SONUC (1.3.2) -----
# vphone'da OLCULDU (5 Eki 2026): curl yoktu, saglik sorusu bos dondu ve
# 'shiv-mcp status' ile Ayarlar "KAPALI" dedi — sunucu AYAKTAYDI (python
# ile /health ok). Eksik arac yuzunden olculemeyen sey "kapali" DEGILDIR.
#   cikti: /health govdesi (ayaktaysa) · donus: 0 ayakta, 1 kapali, 2 olculemedi
st_mcp_saglik() {
  _u="http://127.0.0.1:${1:-8090}/health"
  if command -v curl >/dev/null 2>&1; then
    _h=$(curl -s --max-time 3 "$_u" 2>/dev/null)
  elif command -v python3 >/dev/null 2>&1; then
    _h=$(python3 -c 'import sys,urllib.request
try: print(urllib.request.urlopen(sys.argv[1],timeout=3).read().decode())
except Exception: pass' "$_u" 2>/dev/null)
  else
    return 2
  fi
  [ -n "$_h" ] || return 1
  printf '%s\n' "$_h"; return 0
}

# ---- st_mobile_defaults: mobile'in tercih alaninda defaults (1.3.2) --
# 'su mobile' YALNIZ root iken: zaten mobile olan birine su SIFRE sorar ve
# takilir (28 Eyl 2026'da OLCULDU, 11 dk). defaults ya da (root iken) su
# yoksa 2 doner — cagiran "yazildi/okundu" DEMEZ (vphone'da ikisi de yoktu:
# 'shiv-mcp mod ag' hicbir sey yazmadan "mod: ag" diyordu).
st_mobile_defaults() {   # st_mobile_defaults read|write <alan> <anahtar> [-bool deger]
  command -v defaults >/dev/null 2>&1 || return 2
  if [ "$(id -u)" = "0" ]; then
    command -v su >/dev/null 2>&1 || return 2
    su mobile -c "defaults $*" </dev/null 2>/dev/null
  else
    defaults "$@" </dev/null 2>/dev/null
  fi
}

# ---- st_node_bozuk: VAR ama CALISMAYAN node (1.3.1) ----------------
# vphone'da OLCULDU (4 Eki 2026): paket kurulu, 'node --version' calisiyor,
# 'node -e ""' Killed: 9 (rc=137) — VM cekirdegi V8'in JIT iznini vermiyor.
# st_node onu haklı olarak elerdi; ama sayfa "kurulu degil" deyip YENIDEN
# KURMAYI oneriyordu, oysa yeniden kurmak bunu cozmez. Cikti: "yol|rc".
st_node_bozuk() {
  for _n in /usr/local/lib/node-ios/dist/bin/node /var/jb/usr/local/lib/node-ios/dist/bin/node \
            /usr/local/bin/node /var/jb/usr/local/bin/node "$(command -v node 2>/dev/null)"; do
    [ -n "$_n" ] && [ -x "$_n" ] || continue
    "$_n" -e '' >/dev/null 2>&1; _rc=$?
    [ "$_rc" -ne 0 ] && { echo "$_n|$_rc"; return 0; }
  done
  return 1
}

# ---- st_shivfrida_ikili: sunucuya UYAN istemcinin tam yolu ---------
#
# Paket iki istemci tasiyor (frida 16 ve 17, ikisi de fat arm64+arm64e).
# Sebep 27 Eyl 2026'da olculdu: istemci ile sunucunun ANA SURUMU
# eslesmezse "major versions match" hatasi gelir ve frida'ya bagli
# butun araclar birden duser. Kullanicinin elindeki frida'yi biz
# secmiyoruz; ona UYUYORUZ.
#
# Sunucu surumu ikiliden okunur (paket kaydindan degil): kullanici
# frida'yi elle degistirmis olabilir, paket yalan soyleyebilir.
st_shivfrida_ikili() {
  _fs=""
  for _c in /var/jb/usr/sbin/frida-server /usr/sbin/frida-server \
            "$(command -v frida-server 2>/dev/null)"; do
    [ -n "$_c" ] && [ -x "$_c" ] && { _fs="$_c"; break; }
  done
  _maj=""
  [ -n "$_fs" ] && _maj=$("$_fs" --version 2>/dev/null | head -1 | cut -d. -f1 | tr -dc '0-9')

  # Sunucu yoksa/okunamazsa en yeni istemciyi ver: hicbir sey
  # dondurmemek, arac "shivfrida yok" deyip yaniltir.
  [ -n "$_maj" ] || _maj=17

  for _d in /usr/local/lib/shivtools /var/jb/usr/local/lib/shivtools; do
    [ -x "$_d/shivfrida-$_maj" ] && { echo "$_d/shivfrida-$_maj"; return 0; }
  done
  return 1
}

# ---- st_kunye: kunye dosyasinin tam yolu (yoksa bos) ---------------
#
# Kunye = "arac-adi|tek satirlik amaci" satirlari. paketle.sh bunu
# ELLE DEGIL, bin/shiv-* dosyalarinin kendi kaynagindan uretiyor.
st_kunye() {
  for _d in "$SHIVTOOLS_LIB" /usr/local/lib/shivtools \
            /var/jb/usr/local/lib/shivtools; do
    [ -n "$_d" ] && [ -f "$_d/kunye" ] && { echo "$_d/kunye"; return 0; }
  done
  echo ""
}

# ---- st_araclar: paketteki arac adlari, bosluk ayirmali ------------
#
# ELLE LISTE TUTULMUYOR (N1, 28 Eyl 2026). Ayni liste dort yerde elle
# duruyordu ve UC KEZ bayatladi: once shiv-ekran, sonra shiv-mcp +
# shiv-frida-kur + shiv-ortam, sonra shiv-ornek. Her seferinde arac
# KURULU oldugu halde 'shiv-ortam' raporunda ve Ayarlar sayfasinda
# hic gorunmedi -- yani hata sessizdi ve kullanici bulmak zorunda
# kaldi. Liste artik tek kaynaktan: kunye.
#
# Kunye okunamazsa KURULU dosyalardan turetilir. Bos liste dondurmek,
# bayat liste dondurmekten KOTUDUR: "hicbir arac yok" diye yanlis
# rapor verir.
st_araclar() {
  _k=$(st_kunye)
  _l=""
  [ -n "$_k" ] && _l=$(cut -d'|' -f1 "$_k" 2>/dev/null | tr '\n' ' ')
  if [ -z "$(printf '%s' "$_l" | tr -d ' ')" ]; then
    _l=$(ls /usr/local/bin/shiv-* /var/jb/usr/local/bin/shiv-* 2>/dev/null \
         | while read -r _p; do basename "$_p"; done | sort -u | tr '\n' ' ')
  fi
  printf '%s' "$_l"
}

# ---- st_theos: "yol|catal|sdk" (yoksa bos, donus 1) ---------------
#
#   catal = 1  roothide catali (vendor/mod/roothide var)
#   catal = 0  standart theos
#   sdk        ilk iPhoneOS SDK'sinin adi; bos = SDK yok
#
# AYNI ADAY LISTESI IKI YERDE ELLE DURUYORDU (shiv-ortam ve
# shiv-theos-kur) ve shiv-theos-kur'un basinda "aday listesi
# shiv-ortam ile AYNI tutulmali" diye bir not vardi -- yani
# bayatlama biliniyordu ama care elle eslemekti. N1 ile ayni sinif:
# liste tek yerde.
#
# Adaylarin neden bu kadar cok oldugu OLCULDU:
#   $THEOS               kullanici acikca vermis olabilir
#   $HOME/theos*         normal kurulum
#   /var/mobile/theos*   HOME tanimsiz kabukta '$HOME/theos' -> '/theos'
#   /var/jb/var/mobile/  Dopamine'de mobile'in evi orasi; install-theos
#                        oraya kuruyor (1.0.4'te olculdu)
st_theos() {
  _h="${HOME:-/var/mobile}"
  _b=""; _c=0
  for _d in "$THEOS" "$_h/theos-roothide" "$_h/theos" \
            /var/mobile/theos-roothide /var/mobile/theos \
            /var/jb/var/mobile/theos-roothide /var/jb/var/mobile/theos \
            /var/jb/theos /var/theos /opt/theos; do
    [ -n "$_d" ] && [ -f "$_d/makefiles/common.mk" ] || continue
    # Catal bulununca DUR: roothide catali standarttan onceliklidir.
    if [ -d "$_d/vendor/mod/roothide" ]; then _b="$_d"; _c=1; break; fi
    [ -z "$_b" ] && _b="$_d"
  done
  [ -n "$_b" ] || return 1
  _s=$(ls "$_b/sdks" 2>/dev/null | grep -i '^iphoneos' | head -1)
  printf '%s|%s|%s' "$_b" "$_c" "$_s"
}

# ---- st_jb: jailbreak semasi -> roothide | rootless | rootful -----
#
# AYNI TEST UC YERDE ELLE DURUYORDU (shiv-ortam, shiv-theos-kur,
# shiv-frida-kur) ve UCU AYNI DEGILDI: ikisinde .jbroot ile readlink
# sirasi ters, ikisinde '/var/jb baska yere -> rootless' dali hic
# yok. Ayrisma baslamisti; tek yere alindi (28 Eyl 2026).
#
# ESKI HATA: '[ -L /var/jb ] && JB=roothide'. Dopamine'de de /var/jb
# bir symlink (-> /private/preboot/.../procursus), o yuzden ROOTLESS
# cihaz "roothide" gorunuyordu; sema, yollar ve patcher rehberliginin
# tamami bu tek yanlis testten bozuluyordu.
#
# DOGRU SIRA — en kesin isaretten baslar ve HEDEFE bakar:
#   /rootfs              roothide'in en kesin isareti (rootless'ta YOK)
#   .jbroot- dizini      iki yerde aranir
#   readlink /var/jb=/   roothide '/var/jb -> /' yapar
#   /var/jb baska yere   rootless (Dopamine golge koku)
st_jb() {
  if [ -d /rootfs ]; then echo "roothide"
  elif ls -d /var/containers/Bundle/Application/.jbroot-* \
             /var/mobile/Containers/Shared/AppGroup/.jbroot-* \
             >/dev/null 2>&1; then echo "roothide"
  elif [ "$(readlink /var/jb 2>/dev/null)" = "/" ]; then echo "roothide"
  elif [ -e /var/jb ]; then echo "rootless"
  else echo "rootful"
  fi
}

# ---- st_ayarlar_yolu <dosya-adi>: Ayarlar'in OKUYABILECEGI yol -----
#
# BU KURAL BIR SURUME MAL OLDU (1.0.4, 28 Eyl 2026). Ayarlar sayfasi
# RootHide'da her zaman "OLCUM YOK" diyordu: kabuk jbroot'ta, Ayarlar
# GERCEK kokte calisiyor ve iki '/var/mobile/Library/Preferences'
# AYRI dizin (olculdu: jbroot'ta 34 dosya, /rootfs'te 469). jbroot'a
# yazilan dosyayi sayfa hic goremiyor.
#
# /rootfs varsa gercek yol oradan yazilir. Sayfa ile paylasilan HER
# dosya bu fonksiyondan gecmeli; yol elle yazilirsa ayni hata geri
# gelir (rootless'ta hicbir sey degismez, yani hata ROOTLESS'TA
# GORUNMEZ - tam da o yuzden kacmisti).
st_ayarlar_yolu() {   # st_ayarlar_yolu shivtools-ortam.json
  _p="/var/mobile/Library/Preferences/$1"
  [ -d "/rootfs$(dirname "$_p")" ] && _p="/rootfs$_p"
  echo "$_p"
}

# ---- st_ayarlar_yaz <dosya-adi> <icerik>: atomik + 644 ------------
# 644 ve mobile okunabilir olmali: yazan betik cogu zaman root,
# Ayarlar ise mobile. Atomik (gec + mv): sayfa saniyede bir okuyor,
# yarim dosya gormemeli.
st_ayarlar_yaz() {
  _o=$(st_ayarlar_yolu "$1")
  [ -d "$(dirname "$_o")" ] || return 0
  st_guvenli_yaz "$_o" "$2"
}

# ---- st_guvenli_yaz <tam-yol> <icerik>: BAG IZLEMEYEN atomik yazim --
# 1.1.2 GUVENLIK — 29 Eyl 2026'da OLCULDU: bu dosyalar mobile'in
# yazabildigi dizinde ve yazan cogu zaman ROOT (kurd). Eski kalip
# ('> dosya.gec' + chmod + mv) sembolik bagi IZLIYORDU: bag birakildi,
# root hedefi kendi sahipliginde olusturup icine yazdi, chmod 644 yapti.
# Kalip:
#   * rastgele ad + 'set -C' -> O_EXCL: dosya/bag varsa ACMAZ (dash'te
#     olculdu: "cannot create: File exists"); bagi izlemez.
#   * umask 022 -> dosya 644 dogar; sonradan chmod YOK (chmod bagi izler).
#   * mv -> hedefteki bagi izlemez, bagin YERINE gecer.
# Acilamazsa sessizce vazgecer (DoS'tan ote zarar yok); yabanci dosyayi
# SILMEZ.
st_guvenli_yaz() {
  _gy="$1.$$.$(date +%s)"
  ( umask 022; set -C; printf '%s' "$2" > "$_gy" ) 2>/dev/null || return 0
  mv -f "$_gy" "$1" 2>/dev/null || rm -f "$_gy" 2>/dev/null
}

# ---- st_arac <ad>: kardes aracin TAM YOLU (yoksa bos) -------------
#
# PATH'E GUVENILMEZ — 29 Eyl 2026'da olculdu. 'shiv-kur' frida
# adimini 'command -v shiv-frida-kur' ile ariyordu; kullanicinin
# kabugunda calisirken sorun yok, ama root yardimcisi launchd'den
# geliyor ve PATH'inde /usr/local/bin YOK. Sonuc: kurulum
# "shiv-frida-kur bulunamadi" deyip durdu — arac yerli yerinde
# oldugu halde. Ayni sinif kanunda zaten yazili (§4.10: roothide'de
# tek komutluk SSH kabugunda da /usr/local/bin yok).
st_arac() {
  for _d in /usr/local/bin /var/jb/usr/local/bin; do
    [ -x "$_d/$1" ] && { echo "$_d/$1"; return 0; }
  done
  _c=$(command -v "$1" 2>/dev/null)
  [ -n "$_c" ] && { echo "$_c"; return 0; }
  echo ""; return 1
}

# ---- st_depo_guncelle <depo-url>: YALNIZ bizim depoyu tazele -----
#
# 'apt-get update' BUTUN depolari tariyor; kullanicinin kaynak
# listesi kabarikken bir tur 3,5 DAKIKA surdu (29 Eyl 2026'da
# olculdu) ve o surenin neredeyse tamami buydu. Gecici bir kaynak
# dosyasiyla yalniz kendi depomuzu tazeleyince 9 saniyeye indi.
#
# 'List-Cleanup=0' SART: kisitli kaynak listesiyle calisirken apt
# DIGER depolarin indirilmis listelerini siler. Bayragin varken 57
# liste yerinde kaldi (olculdu).
#
# TEK YERDE: hem 'shiv-kur' hem 'shiv-frida-kur' buradan cagiriyor.
# Ilk yazimda yalniz shiv-kur'a konmustu; frida adimi eski yoldan
# gidip turu dakikalarca kilitledi.
# '[trusted=yes]' ZORUNLU — 29 Eyl 2026'da olculdu, sessiz hataydi.
# Depomuz imzasiz; bayraksiz gecici kaynak dosyasiyla apt
#   E: The repository '...' is not signed.
# deyip listeyi HIC yazmiyor. Cagiran taraf '|| true' ile yuttugu
# icin her sey yolunda gorunuyordu: guncelleme iki saniyede
# "bitiyor", liste GUNLERCE eski kaliyor ve kurulum "paket depoda
# yok" diye patliyordu. Sebep paket degil, tazelenmeyen listeydi.
#
# Kurulumun kendisi zaten '--allow-unauthenticated' ile yapiliyor;
# guncellemenin de ayni gerceği kabul etmesi gerekiyor.
st_depo_guncelle() {
  # 1.1.2 GUVENLIK: ad SABIT idi (/tmp/shivtools-depo.list). mobile onu
  # onceden sahiplenirse root yazdiktan SONRA icerigi kendi deposuna
  # cevirebilir; apt 'trusted=yes' ile oradan ROOT olarak paket kurar.
  # O_EXCL (set -C): dosya varsa acmaz. Root'un 644 dosyasi yapiskan
  # /tmp'de mobile tarafindan ne degistirilir ne silinir.
  _dl="/tmp/shivtools-depo.$$.$(date +%s).list"
  ( umask 022; set -C; printf 'deb [trusted=yes] %s/ ./\n' "${1%/}" > "$_dl" ) \
    2>/dev/null || return 1
  _c=$(apt-get update -o Dir::Etc::sourcelist="$_dl" \
                      -o Dir::Etc::sourceparts=/dev/null \
                      -o APT::Get::List-Cleanup=0 2>&1)
  _r=$?
  rm -f "$_dl" 2>/dev/null
  # Sessiz basarisizlik birakma: apt cikis 0 dondurse bile 'E:'
  # satiri varsa liste yazilmamis olabilir.
  if [ "$_r" -ne 0 ] || printf '%s' "$_c" | grep -q '^E:'; then
    printf '%s\n' "$_c" | grep -m1 '^E:' >&2
    return 1
  fi
  return 0
}

# ---- st_depo_oku / st_guncelleme: yan paket guncellemesi (1.3.0, G1) ----
#
# NEDEN apt-cache DEGIL — 30 Eyl 2026'da XS'te OLCULDU: apt listesi
# 29 Eyl 21:53'te kalmisti; depoda MCP 1.2.8-3 varken 'apt-cache
# policy' aday olarak kurulu 1.2.8-2'yi gosterdi. Liste ancak Sileo
# son tazelendiginde kadar taze, mobile da 'apt update' yapamaz.
# Ustelik cikti YERELLESTIRILMIS ("Kurulu:", "Aday:").
# Bu yuzden YALNIZ BIZIM deponun Packages dosyasi okunur (57 KB,
# ~0,7 sn, root gerekmez, yalniz okuma). KURULUM yine apt ile ve
# root'ta; apt_kur once bizim depoyu tazeler.
# Ag yoksa sessiz: guncelleme yok sayilir, yanlis alarm verilmez.
#
# BIR KEZ OKUNUR: st_depo_oku alt kabukta ($(...)) DEGIL, dogrudan
# cagrilmali; yoksa degisken kaybolur ve her paket icin yeniden iner.
# awk KULLANILMAZ: XS rootless'ta yok (28 Eyl olculdu).
st_depo_oku() {
  [ -n "${ST_DEPO_OKUNDU:-}" ] && return 0
  ST_DEPO_OKUNDU=1
  ST_DEPO_TABLO=""
  _pk=$(curl -fsS --max-time 4 "https://muratkurt.github.io/Packages" 2>/dev/null) || return 0
  _ar=$(dpkg --print-architecture 2>/dev/null)
  # Her kayit -> "paket surum" (yalniz bu mimari ve 'all').
  ST_DEPO_TABLO=$(printf '%s\n\n' "$_pk" | {
    _p=""; _v=""; _a=""
    while IFS= read -r _s; do
      case "$_s" in
        "Package: "*)      _p=${_s#Package: } ;;
        "Version: "*)      _v=${_s#Version: } ;;
        "Architecture: "*) _a=${_s#Architecture: } ;;
        "")
          if [ -n "$_p" ] && [ -n "$_v" ] && { [ "$_a" = "$_ar" ] || [ "$_a" = "all" ]; }; then
            printf '%s %s\n' "$_p" "$_v"
          fi
          _p=""; _v=""; _a="" ;;
      esac
    done; })
}

# st_guncelleme <paket> -> "kurulu|depodaki" (cikis 0) ya da hic (cikis 1).
# Yalniz KURULU paket icin; kurulu degilse bu bir 'eksik', guncelleme degil.
st_guncelleme() {
  _k=$(dpkg-query -W -f='${Status} ${Version}' "$1" 2>/dev/null)
  case "$_k" in *" ok installed "*) _k=${_k##* } ;; *) return 1 ;; esac
  [ -n "${ST_DEPO_TABLO:-}" ] || return 1
  _en=""
  for _v in $(printf '%s\n' "$ST_DEPO_TABLO" | grep "^$1 " | cut -d' ' -f2); do
    if [ -z "$_en" ] || dpkg --compare-versions "$_v" gt "$_en"; then _en="$_v"; fi
  done
  [ -n "$_en" ] && dpkg --compare-versions "$_en" gt "$_k" || return 1
  printf '%s|%s' "$_k" "$_en"
}

# ---- st_terminal: hangi terminal uygulamasinin icinde calisiyoruz ----
# (1.3.0: shiv-ekran'dan TASINDI, shiv-don de kullaniyor — tek kopya, N1.)
# Surec zincirinde yukari cik; 'launchctl list'te UIKitApplication olan
# ilk sureci al. Olculdu: 'ps -o ppid=' bu cihazda "bad output format"
# verdi, 'ps -o ppid' + son satir calisti; launchctl sutunlari sekmeyle
# ayrili. ps yoksa (Dopamine) ya da zincir bos donerse TERM_PROGRAM.
# NewTerm -> ws.hbang.Terminal, uiopen ile one geldi (21 Eyl 2026, OLCULDU).
# Elle vermek icin: SHIV_TERMINAL=<bundle-id>.
st_terminal() {
  if [ -n "${SHIV_TERMINAL:-}" ]; then echo "$SHIV_TERMINAL"; return; fi
  _P=$PPID; _n=0
  while [ -n "$_P" ] && [ "$_P" -gt 1 ] 2>/dev/null && [ "$_n" -lt 12 ]; do
    _T=$(launchctl list 2>/dev/null | grep UIKitApplication | while read a b c; do
          [ "$a" = "$_P" ] && echo "$c"; done)
    if [ -n "$_T" ]; then
      echo "$_T" | sed 's/^UIKitApplication://; s/\[.*$//'
      return
    fi
    _P=$(ps -o ppid -p "$_P" 2>/dev/null | tail -1 | tr -d ' \t')
    _n=$((_n + 1))
  done
  case "${TERM_PROGRAM:-}" in
    NewTerm) echo ws.hbang.Terminal ;;
  esac
}

# ---- st_dil / sy: araclarin CIKTI DILI (1.3.0) -----------------------
#
# Kullanici karari (1 Eki 2026): yorumlar Turkce kalir, CIKTI iki dilli.
# Cihaz Turkceyse Turkce, degilse Ingilizce. Her mesaj iki dilde YAN
# YANA yazilir: sy "Turkce" "English". Ayri ceviri dosyasi YOK — biri
# degisince oteki unutulmasin (N1).
#
# NEREDEN — OLCULDU (1 Eki, RootHide): kabukta LANG/LC_ALL BOS; dil
# sistemin listesinde (.GlobalPreferences AppleLanguages = tr-TR, en-GB).
# BEDEL — OLCULDU: bu cihazda HER dis komut 80-150 ms (defaults 250 ms,
# plutil 140 ms, 'true' bile 80 ms). Araclari ajan sik cagiriyor; her
# acilisa bunu eklemek olmaz. Bu yuzden sonuc ONBELLEGE yazilir ve
# kabugun kendi 'read'iyle okunur (yeni surec yok). Onbellegi
# shiv-ortam her oturumda tazeler (st_dil_tazele).
# ROOT ONBELLEK YAZMAZ: mobile'in dizininde ada gore yazmak bag
# saldirisina acik (1.1.2 kurali); root yalniz okur.
#
# Oncelik: SHIV_DIL > LANG/LC_ALL (doluysa; Mac'ten SSH) > onbellek >
# sistem listesi > en.
st_dil_dosya() {
  if [ -d /rootfs/var/mobile/Library/Preferences ]; then
    echo /rootfs/var/mobile/Library/Preferences/shivtools-dil
  else
    echo /var/mobile/Library/Preferences/shivtools-dil
  fi
}
st_dil_sistem() {   # sistem listesinin ilk dili -> tr | en
  _gp=/var/mobile/Library/Preferences/.GlobalPreferences.plist
  [ -f "/rootfs$_gp" ] && _gp="/rootfs$_gp"
  _l=$(plutil -AppleLanguages "$_gp" 2>/dev/null | tr -dc 'a-zA-Z-\n' | grep -m1 -E '^[a-z]{2}')
  [ -n "$_l" ] || _l=$(defaults read -g AppleLanguages 2>/dev/null | tr -dc 'a-zA-Z-\n' | grep -m1 -E '^[a-z]{2}')
  case "$_l" in tr*) echo tr ;; *) echo en ;; esac
}
st_dil_tazele() {   # onbellegi yeniden yaz (yalniz mobile)
  [ "$(id -u)" = "0" ] && return 0
  _f=$(st_dil_dosya); _d=$(st_dil_sistem)
  { printf '%s\n' "$_d" > "$_f.$$" && mv -f "$_f.$$" "$_f"; } 2>/dev/null || rm -f "$_f.$$" 2>/dev/null
  ST_DIL=$_d
}
st_dil() {
  if [ -n "${SHIV_DIL:-}" ]; then
    case "$SHIV_DIL" in tr*) ST_DIL=tr ;; *) ST_DIL=en ;; esac; return
  fi
  _lg="${LC_ALL:-${LANG:-}}"
  if [ -n "$_lg" ] && [ "$_lg" != "C" ] && [ "$_lg" != "POSIX" ]; then
    case "$_lg" in tr*) ST_DIL=tr ;; *) ST_DIL=en ;; esac; return
  fi
  ST_DIL=""
  _f=$(st_dil_dosya)
  [ -f "$_f" ] && read -r ST_DIL < "$_f" 2>/dev/null
  case "$ST_DIL" in tr|en) return ;; esac
  if [ "$(id -u)" = "0" ]; then ST_DIL=$(st_dil_sistem); else st_dil_tazele; fi
}
# sy "Turkce" "English"  — bir satir yaz (stdout).  sye: ayni, stderr'e.
sy()  { if [ "$ST_DIL" = tr ]; then printf '%s\n' "$1"; else printf '%s\n' "$2"; fi; }
sye() { sy "$@" >&2; }
st_dil
